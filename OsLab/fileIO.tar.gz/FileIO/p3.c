#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void main()
{
	printf("Enter your #:\r\n");
	int no;
	scanf ("%d",&no);
	if((no) % 2 == 0)
	{
		system("./p1.out");
	}
	else
	{
		system("./p2.out");
	}
}

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void main()
{
	printf("P1 has been invoked.\r\n");
    FILE* fp;
	fp  = fopen("file1.txt", "w");
	printf("Enter # of numbers:\r\n");	
	int count;
	scanf ("%d",&count);	
	int i = 0;
	for(;i<count;i++)
	{
		printf("Enter number %d :\t",i);
		int no;
		scanf ("%d",&no);
		fprintf(fp,"%d\r\n",no);
	}		
	fclose(fp);
	printf("DONE...\r\n");
}

gcc p1.c -o p1.out;
gcc p2.c -o p2.out;
gcc p3.c -o p3.out; 

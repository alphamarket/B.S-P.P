#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void main()
{
	printf("P2 has been invoked!\r\n");
    FILE* fp;
	printf("Opening the file `file1.txt`\r\n");
	fp  = fopen("file1.txt", "r");
	if(fp==NULL)
	{
		printf("The file does not exists");
		return;
	}
	printf("Enter the line count of file do you want to read : \t");
	int count;
	scanf("%d",&count);
	int i = 0;
	for(;i<count;i++)
	{
		char* s=NULL;
		fscanf(fp, "%s", s);
		if(s==NULL)
			break;
		printf("%s\r\n",s);
	}		
	fclose(fp);
	printf("DONE...\r\n");
}

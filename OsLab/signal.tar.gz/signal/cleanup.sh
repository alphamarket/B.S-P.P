rm *~ tamrin file

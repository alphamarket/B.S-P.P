clear;
gcc tamrin.c -o tamrin;

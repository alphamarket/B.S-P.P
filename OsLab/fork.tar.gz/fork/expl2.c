#include <stdio.h>
#include <stdlib.h>

void main()
{
	pid_t parent = getpgrp();
	pid_t p;
	printf("fork program starting { p_pid = %d }...\r\n", parent++);
	char* message;
	int n;
	p = fork();
	// bade fork kardan `parent_id + 1` mishe chra!?
	printf("current pid = %d\r\n",p);
	switch(p)
	{
		case -1:perror("fork failed ...\r\n");exit(p);break;
		case 0: message = "child...";n=3;break;
		default:
			if(p == parent)
			{
				message = "father...";
				n = 3;
			}
			else
			{
				printf("Unknown pid : %d\r\n",p);
				exit(p);
			}
			break;
	}
	printf("n = %d\r\n",n); 
	for(;n>0;n--){puts(message);sleep(1);}
	exit(0);
}

clear;
gcc expl2.c -o expl2;
gcc tamrin.c -o tamrin;

rm *~ expl2 tamrin file

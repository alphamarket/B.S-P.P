#include <stdio.h>
#include <stdlib.h>

#define COUNT_OF_IO 10

void RunParentProc(void);
void RunChildProc(void);

const char* file_name = "file";

void main()
{
	system("clear");
	pid_t parent = getpgrp();
	pid_t p;
	printf("IO program starting { p_pid = %d }...\r\n", parent++);
	p = fork();
	printf("current pid = %d ~> %d\r\n",p, getpgrp());
	switch(p)
	{
		case -1:perror("fork failed ...\r\n\r\n");exit(p);break;
		case 0:
			RunChildProc();
			break;
		default:
			RunParentProc();
	}
	exit(EXIT_SUCCESS);
}

void RunChildProc(void)
{
	int no_of_tries = 0;
__try_read:
	system("sleep 0.1");
	FILE* fp = fopen(file_name,"r");
	if(no_of_tries++>3)
	{
    	printf("Failed to read from file....\r\nTried %d times!\r\n",no_of_tries);
    	printf("Child process exited!\r\n");
    	exit(-1);
	}
   	if(!fp)
        goto __try_read;
    // in here we have an opened file
    printf("The child process has opened the `%s` file ...\r\n", file_name);
	int i=0;
	int n;
	while(fscanf(fp, "%i", &n)!=EOF)
	{
		printf("[R %i] %i\r\n",i++,n);
		system("sleep 0.11");
	}
	printf("The file has been read successfully...\r\n");
__EXIT:
	fclose(fp);
}

void RunParentProc(void)
{
	printf("The parent process is about to write into the `%s` file ...\r\n", file_name);
	FILE* fp = fopen(file_name, "w");
	int i=0;
	srand(getpgrp());
	printf("Starting to write %i objects into file.\r\n", COUNT_OF_IO);
	for(;i<COUNT_OF_IO;i++)
	{
		int r=rand() % 1000;
		printf("[W %i] %i\r\n",i,r);
		fprintf(fp, "%d\r\n",r);
		fflush (fp);
		system("sleep 0.1");
	}
	printf("The file has been written successfully ...\r\n");
__EXIT:
	fclose(fp);
}

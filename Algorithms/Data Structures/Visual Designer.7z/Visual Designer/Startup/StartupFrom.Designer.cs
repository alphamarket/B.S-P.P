﻿namespace Startup
{
    partial class StartupFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartupFrom));
            this.ProjectGB = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CpBrowse = new System.Windows.Forms.Button();
            this.CpLocation = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CpSolution = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CpName = new System.Windows.Forms.TextBox();
            this.CpCreate = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.EpBrowse = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.EpSolution = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.EpLocation = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.EpName = new System.Windows.Forms.TextBox();
            this.EpCreate = new System.Windows.Forms.Button();
            this.ProjectFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.vdpFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.CloseThis = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ProjectGB
            // 
            this.ProjectGB.Location = new System.Drawing.Point(12, 12);
            this.ProjectGB.Name = "ProjectGB";
            this.ProjectGB.Size = new System.Drawing.Size(361, 359);
            this.ProjectGB.TabIndex = 0;
            this.ProjectGB.TabStop = false;
            this.ProjectGB.Text = "Recent Projects";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Silver;
            this.groupBox2.Controls.Add(this.CpBrowse);
            this.groupBox2.Controls.Add(this.CpLocation);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.CpSolution);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.CpName);
            this.groupBox2.Controls.Add(this.CpCreate);
            this.groupBox2.Location = new System.Drawing.Point(379, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(530, 168);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Create new project";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // CpBrowse
            // 
            this.CpBrowse.Location = new System.Drawing.Point(415, 55);
            this.CpBrowse.Name = "CpBrowse";
            this.CpBrowse.Size = new System.Drawing.Size(75, 23);
            this.CpBrowse.TabIndex = 2;
            this.CpBrowse.Text = "Browse ...";
            this.CpBrowse.UseVisualStyleBackColor = true;
            this.CpBrowse.Click += new System.EventHandler(this.CpBrowse_Click);
            // 
            // CpLocation
            // 
            this.CpLocation.Location = new System.Drawing.Point(159, 58);
            this.CpLocation.Name = "CpLocation";
            this.CpLocation.ReadOnly = true;
            this.CpLocation.Size = new System.Drawing.Size(242, 20);
            this.CpLocation.TabIndex = 1;
            this.CpLocation.TabStop = false;
            this.CpLocation.TextChanged += new System.EventHandler(this.CpLocation_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Solution Name:";
            // 
            // CpSolution
            // 
            this.CpSolution.Location = new System.Drawing.Point(159, 83);
            this.CpSolution.Name = "CpSolution";
            this.CpSolution.Size = new System.Drawing.Size(331, 20);
            this.CpSolution.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Location:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Name:";
            // 
            // CpName
            // 
            this.CpName.Location = new System.Drawing.Point(159, 31);
            this.CpName.Name = "CpName";
            this.CpName.Size = new System.Drawing.Size(331, 20);
            this.CpName.TabIndex = 0;
            this.CpName.TextChanged += new System.EventHandler(this.CpName_TextChanged);
            // 
            // CpCreate
            // 
            this.CpCreate.Location = new System.Drawing.Point(385, 118);
            this.CpCreate.Name = "CpCreate";
            this.CpCreate.Size = new System.Drawing.Size(109, 23);
            this.CpCreate.TabIndex = 4;
            this.CpCreate.Text = "Create";
            this.CpCreate.UseVisualStyleBackColor = true;
            this.CpCreate.Click += new System.EventHandler(this.CpCreate_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Silver;
            this.groupBox3.Controls.Add(this.EpBrowse);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.EpSolution);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.EpLocation);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.EpName);
            this.groupBox3.Controls.Add(this.EpCreate);
            this.groupBox3.Location = new System.Drawing.Point(379, 186);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(530, 185);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Open an exists project";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // EpBrowse
            // 
            this.EpBrowse.Location = new System.Drawing.Point(415, 54);
            this.EpBrowse.Name = "EpBrowse";
            this.EpBrowse.Size = new System.Drawing.Size(75, 23);
            this.EpBrowse.TabIndex = 2;
            this.EpBrowse.Text = "Browse ...";
            this.EpBrowse.UseVisualStyleBackColor = true;
            this.EpBrowse.Click += new System.EventHandler(this.EpBrowse_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Solution Name:";
            // 
            // EpSolution
            // 
            this.EpSolution.Enabled = false;
            this.EpSolution.Location = new System.Drawing.Point(159, 83);
            this.EpSolution.Name = "EpSolution";
            this.EpSolution.Size = new System.Drawing.Size(331, 20);
            this.EpSolution.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Location:";
            // 
            // EpLocation
            // 
            this.EpLocation.Location = new System.Drawing.Point(159, 57);
            this.EpLocation.Name = "EpLocation";
            this.EpLocation.ReadOnly = true;
            this.EpLocation.Size = new System.Drawing.Size(242, 20);
            this.EpLocation.TabIndex = 1;
            this.EpLocation.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Name:";
            // 
            // EpName
            // 
            this.EpName.Enabled = false;
            this.EpName.Location = new System.Drawing.Point(159, 31);
            this.EpName.Name = "EpName";
            this.EpName.Size = new System.Drawing.Size(331, 20);
            this.EpName.TabIndex = 0;
            // 
            // EpCreate
            // 
            this.EpCreate.Location = new System.Drawing.Point(385, 118);
            this.EpCreate.Name = "EpCreate";
            this.EpCreate.Size = new System.Drawing.Size(109, 23);
            this.EpCreate.TabIndex = 4;
            this.EpCreate.Text = "Open";
            this.EpCreate.UseVisualStyleBackColor = true;
            this.EpCreate.Click += new System.EventHandler(this.EpCreate_Click);
            // 
            // vdpFileDialog
            // 
            this.vdpFileDialog.Filter = "Visual Design|*.vdp";
            // 
            // CloseThis
            // 
            this.CloseThis.AutoSize = true;
            this.CloseThis.Location = new System.Drawing.Point(12, 377);
            this.CloseThis.Name = "CloseThis";
            this.CloseThis.Size = new System.Drawing.Size(176, 17);
            this.CloseThis.TabIndex = 3;
            this.CloseThis.Text = "Close this form after project load";
            this.CloseThis.UseVisualStyleBackColor = true;
            this.CloseThis.CheckedChanged += new System.EventHandler(this.CloseThis_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(264, 373);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Clear projetc\'s list";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StartupFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(921, 400);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CloseThis);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.ProjectGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "StartupFrom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Visual Designer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StartupFrom_FormClosing);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox ProjectGB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CpSolution;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CpName;
        private System.Windows.Forms.Button CpCreate;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button EpBrowse;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox EpSolution;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EpLocation;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EpName;
        private System.Windows.Forms.Button EpCreate;
        private System.Windows.Forms.Button CpBrowse;
        private System.Windows.Forms.TextBox CpLocation;
        private System.Windows.Forms.FolderBrowserDialog ProjectFolderDialog;
        private System.Windows.Forms.OpenFileDialog vdpFileDialog;
        private System.Windows.Forms.CheckBox CloseThis;
        private System.Windows.Forms.Button button1;
    }
}


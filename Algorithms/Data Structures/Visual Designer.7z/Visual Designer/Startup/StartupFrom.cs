﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace Startup
{
    partial class StartupFrom : Form
    {
        List<ElementHost> hosts = new List<ElementHost>();
        Projects projs = new Projects();
        public StartupFrom()
        {
            InitializeComponent();

            LoadProjects();
            this.MaximizeBox = false;
            CloseThis.Checked = Properties.Settings.Default.CloseThis;
            CpCreate.Enabled = false;
            EpCreate.Enabled = false;
            EpLocation.Enabled = true;
        }

        bool reloading;
        private void LoadProjects()
        {
            projs.Clear();
            reloading = true;
            foreach (ElementHost i in hosts)
            {
                i.Dispose();
            }
            hosts.Clear();

            foreach (string i in RegistryInfo.ProjectsRoot.GetValueNames())
            {
                if (System.IO.File.Exists(i + ".exe"))
                    projs.Add(new Project(RegistryInfo.ProjectsRoot.GetValue(i).ToString(), i));
                else
                    RegistryInfo.ProjectsRoot.DeleteValue(i);
            }

            projs.Reverse();

            int counter = 0;
            foreach (Project i in projs)
            {
                if (counter > 13)
                    break;

                ElementHost host = new ElementHost();

                DeactiveProjectLink dpl = new DeactiveProjectLink(i, host);

                host.Child = dpl;

                host.Location = new Point(23, 25 + 23 * counter);

                host.Size = new System.Drawing.Size(310, 24);

                host.Disposed += new EventHandler(host_Disposed);

                host.CreateControl();

                dpl.MouseEnter += new System.Windows.Input.MouseEventHandler(ProjectLinker_MouseEnter);

                hosts.Add(host);

                ProjectGB.Controls.Add(host);

                counter++;
            }
            reloading = false;
        }

        void host_Disposed(object sender, EventArgs e)
        {
            if (!reloading)
            {
                LoadProjects();
            }
        }

        void ProjectLinker_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            Sources.ActivateProjectLink apl = sender as Sources.ActivateProjectLink;

            DeactiveProjectLink dpl = new DeactiveProjectLink(apl.ProjectInfo, apl.Host);

            dpl.MouseEnter += new System.Windows.Input.MouseEventHandler(ProjectLinker_MouseEnter);

            dpl.Host.Child = dpl;
        }

        void ProjectLinker_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            //inja hameye active haye ehtemali dge ro deactive mikonim!!
            foreach (ElementHost i in ProjectGB.Controls)
            {
                if (i.Child is Sources.ActivateProjectLink)
                {
                    ProjectLinker_MouseLeave(i.Child, e);
                }
            }
            DeactiveProjectLink dpl = sender as DeactiveProjectLink;

            Sources.ActivateProjectLink apl = new Sources.ActivateProjectLink(dpl.ProjectInfo, dpl.Host);

            apl.MouseLeave += new System.Windows.Input.MouseEventHandler(ProjectLinker_MouseLeave);

            dpl.Host.Child = apl;
        }

        private void CpName_TextChanged(object sender, EventArgs e)
        {
            CpSolution.Text = CpName.Text;

            CpLocation_TextChanged(sender, e);
        }

        private void CpBrowse_Click(object sender, EventArgs e)
        {
            if (ProjectFolderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                CpLocation.Text = ProjectFolderDialog.SelectedPath;
            }
        }

        private void CpLocation_TextChanged(object sender, EventArgs e)
        {
            if (CpLocation.Text == "" || CpName.Text == "")
            {
                CpCreate.Enabled = false;
            }
            else
            {
                CpCreate.Enabled = true;
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            foreach (Control i in groupBox3.Controls)
            {
                if (i is TextBox)
                    i.Text = "";
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
            foreach (Control i in groupBox2.Controls)
            {
                if (i is TextBox)
                    i.Text = "";
            }
        }

        private void StartupFrom_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void CpCreate_Click(object sender, EventArgs e)
        {
            try
            {
                var path = CpLocation.Text + "\\" + CpName.Text;
                try
                {
                    if (System.IO.Directory.Exists(path))
                        System.IO.Directory.Delete(path, true);
                }
                catch { }
                System.IO.Directory.CreateDirectory(path);

                projs.AddProject(new Project(CpSolution.Text, path));

                CopyDependedAssembly(path);

                System.Diagnostics.Process.Start(path + "\\" + CpSolution.Text + ".exe");

                if (CloseThis.Checked)
                {
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
                CpLocation.Text = "";
                CpSolution.Text = "";
                CpName.Text = "";
                CpCreate.Enabled = false;
                LoadProjects();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CopyDependedAssembly(string path)
        {
            System.IO.File.Copy("Loader.exe", path + "\\" + CpSolution.Text + ".exe", true);

            foreach (var i in System.IO.Directory.GetFiles("."))
            {
                if (i.Contains(".dll"))
                {
                    System.IO.File.Copy(i, path + "\\" + i, true);

                    new System.IO.FileInfo(path + "\\" + i).Attributes = System.IO.FileAttributes.System | System.IO.FileAttributes.Hidden;
                }
            }
        }

        private void CloseThis_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.CloseThis = CloseThis.Checked;
            Properties.Settings.Default.Save();
        }

        private void EpBrowse_Click(object sender, EventArgs e)
        {
            if (vdpFileDialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                //TODO: ye file ba extention'e ' .vdp ' ro migire ke mishe hamon ' .xml ''e ma va bara oun ye project baz mikone!!
                EpLocation.Text = vdpFileDialog.FileName;
                System.IO.FileInfo fi = new System.IO.FileInfo(EpLocation.Text);
                EpName.Text = fi.Name;
                EpSolution.Text = fi.Name;
                EpName.Enabled = false;
                EpLocation.Enabled = true;
                EpSolution.Enabled = false;
                EpCreate.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistryInfo.ClearAll();
            LoadProjects();
        }

        private void EpCreate_Click(object sender, EventArgs e)
        {
            if (System.IO.File.Exists(EpLocation.Text))
            {
                var path = EpLocation.Text.Replace("\\" + EpName.Text, "");
                projs.AddProject(new Project(EpName.Text.Replace(".vdp", ""), path));
                System.IO.FileInfo fi = new System.IO.FileInfo(EpLocation.Text);
                System.IO.FileInfo[] f = fi.Directory.GetFiles();
                foreach (var i in f)
                {
                    if (i.Extension.Contains(".exe") && i.Name.Contains(EpName.Text.Replace(".vdp", "")))
                    {
                        System.Diagnostics.Process.Start(i.FullName);
                        break;
                    }
                }

                if (CloseThis.Checked)
                {
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
                EpLocation.Text = "";
                EpSolution.Text = "";
                EpName.Text = "";
                EpCreate.Enabled = false;
                LoadProjects();
            }
        }
    }
}

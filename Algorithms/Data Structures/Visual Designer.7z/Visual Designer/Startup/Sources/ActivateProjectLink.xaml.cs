﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms.Integration;

namespace Startup.Sources
{
    /// <summary>
    /// Interaction logic for ActivateProjectLink.xaml
    /// </summary>
    partial class ActivateProjectLink : UserControl
    {
        Project proj;
        ElementHost parent;
        public ActivateProjectLink()
        {
            InitializeComponent();
        }

        internal ActivateProjectLink(Project project, ElementHost host = null)
        {
            InitializeComponent();
            this.Host = host;
            this.ProjectInfo = project;
        }

        internal Project ProjectInfo
        {
            get
            {
                return proj;
            }
            set
            {
                proj = value;
                label.Content = proj.Name;
            }
        }
        public ElementHost Host
        {
            get
            {
                return parent;
            }
            set
            {
                parent = value;
            }
        }
        public Size Size
        {
            get
            {
                return new Size(this.Width, this.Height);
            }
        }
        public override string ToString()
        {
            return "Activate Link : [ " + proj + " ]";
        }

        private void ActiveLink_Clicked(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(proj.Location + ".exe");
                if (Properties.Settings.Default.CloseThis)
                {
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
            }
            catch
            {
                if (MessageBox.Show("This doese not exists, do you want to remove this link from list?", "Out of date project ...", MessageBoxButton.YesNo, MessageBoxImage.Error, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    RegistryInfo.DeleteProject(proj);
                    Host.Dispose();
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms.Integration;

namespace Startup
{
    /// <summary>
    /// Interaction logic for DeactiveProjectLink.xaml
    /// </summary>
    partial class DeactiveProjectLink : UserControl
    {
        Project proj = new Project();
        ElementHost parent;
        public DeactiveProjectLink()
        {
            InitializeComponent();
        }
        internal DeactiveProjectLink(Project project, ElementHost host = null)
        {
            InitializeComponent();
            this.Host = host;
            this.ProjectInfo = project;
        }
        internal Project ProjectInfo
        {
            get
            {
                return proj;
            }
            set
            {
                proj = value;
                label.Content = proj.Name;
            }
        }
        public ElementHost Host
        {
            get
            {
                return parent;
            }
            set
            {
                parent = value;
            }
        }

        public Size Size
        {
            get
            {
                return new Size(this.Width, this.Height);
            }
        }
        public override string ToString()
        {
            return "Deactivate Link : [ " + proj + " ]";
        }
    }
}

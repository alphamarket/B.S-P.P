﻿using System.Collections.Generic;

namespace Startup
{
    class Project
    {
        string name, loc;
        public Project(string name, string Location)
        {
            this.name = name;
            loc = Location;
        }

        public Project()
        {
            // TODO: Complete member initialization
        }
        public string Name
        {
            get
            {
                return name;
            }
        }
        public string Location
        {
            get
            {
                return loc;
            }
        }

        public override string ToString()
        {
            return name;
        }
    }
    class Projects : System.Collections.IEnumerable
    {
        List<Project> proj = new List<Project>();
        public void Add(Project project)
        {
            foreach (Project i in proj)
            {
                if (i.Location == project.Location)
                    return;
            }
            proj.Add(project);
        }
        public void AddProject(Project project)
        {
           RegistryInfo.AddProject(project);
        }
        public bool Load(Project p)
        {
            try
            {
                System.Diagnostics.Process.Start(p.Location);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Clear()
        {
            proj.Clear();
        }
        public int Count
        {
            get { return proj.Count; }
        }
        public void Reverse()
        {
            proj.Reverse();
        }

        public System.Collections.IEnumerator GetEnumerator()
        {
            return proj.GetEnumerator();
        }
    }
}

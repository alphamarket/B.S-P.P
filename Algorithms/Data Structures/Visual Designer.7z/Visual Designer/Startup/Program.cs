﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Win32;
namespace Startup
{
    struct RegistryInfo
    {
        public static RegistryKey RegKeyRoot;
        public static RegistryKey ProjectsRoot;
        public static void AddProject(Project project)
        {
            RegistryInfo.ProjectsRoot.SetValue(project.Location+"\\"+project.Name, project.Name, RegistryValueKind.String);
        }
        public static void DeleteProject(Project project)
        {
            foreach (string i in ProjectsRoot.GetValueNames())
            {
                if (i == project.Location)
                    ProjectsRoot.DeleteValue(i);
            }

        }
        public static void ClearAll()
        {
            RegKeyRoot.DeleteSubKeyTree("Projects");
            ProjectsRoot = RegKeyRoot.CreateSubKey("Projects");
        }
    }
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            SetRegistry();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new StartupFrom());
        }

        private static void SetRegistry()
        {
            RegistryKey reg = Registry.CurrentUser.OpenSubKey("Software", true);
            RegistryInfo.RegKeyRoot = reg.CreateSubKey("ds_VisualDesigner");
            RegistryInfo.ProjectsRoot = Startup.RegistryInfo.RegKeyRoot.CreateSubKey("Projects");
        }
    }
}

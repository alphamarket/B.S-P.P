﻿using System.Drawing;
using System.Windows.Forms;
namespace Dragging
{
    public class Dragable
    {
        Control c;
        bool dragging;
        Point clickOffset, clickLocation;
        public Dragable(System.Windows.Forms.Control control)
        {
            control.MouseDown += new MouseEventHandler(control_MouseDown);
            control.MouseMove += new MouseEventHandler(control_MouseMove);
            control.MouseUp += new MouseEventHandler(control_MouseUp);
            c = control;
        }
        
        void control_MouseUp(object sender, MouseEventArgs e)
        {
            Control c = sender as Control;
            if (c.Location.X < 0 || c.Location.Y < 0 || c.Location.X + c.Size.Width > c.Parent.ClientSize.Width || c.Location.Y + c.Size.Height > c.Parent.ClientSize.Height)
                c.Location = clickLocation;
            dragging = false;
            c.Cursor = Cursors.Default;
        }

        void control_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Control c = sender as Control;
                c.Left += (e.X - clickOffset.X);
                c.Top += (e.Y - clickOffset.Y);
                c.Refresh();
            }
        }

        void control_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                dragging = true;
                clickLocation = (sender as Control).Location;
                clickOffset = new Point(e.X, e.Y);
                c.Cursor = Cursors.NoMove2D;
            }
            else
            {
                dragging = false;
            }
        }
    }
}

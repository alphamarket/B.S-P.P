﻿using System;

namespace Modalizer.XML
{
    public class SerializeRunTimeException : Exception
    {
        public SerializeRunTimeException(string message) : base(message) { }
        public SerializeRunTimeException(string message, Exception innerException) : base(message, innerException) { }
    }
}

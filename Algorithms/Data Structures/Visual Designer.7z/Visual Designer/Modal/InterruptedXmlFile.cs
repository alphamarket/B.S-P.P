﻿using System;

namespace Modalizer.XML
{
    public class InterruptedXmlFile : Exception
    {
        public InterruptedXmlFile() { }
        public InterruptedXmlFile(string message) : base(message) { }
        public InterruptedXmlFile(string message, Exception innerException)
            : base(message, innerException) { }
        //TODO: add additional options here
    }
}
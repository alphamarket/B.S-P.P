﻿using System;
using System.IO;
using System.Xml;
namespace Modalizer.XML
{
    class XmlFileNode
    {
        public string Path;
        public int Count;
        public XmlTextWriter Writer;
        bool handled = false;
        public XmlFileNode(string name, int Count)
        {
            if (Count < 0)
                throw new ArgumentOutOfRangeException();
            this.Count = Count;
            if (!name.Contains(".xml"))
                name += ".xml";
            this.Path = name;
            Writer = new XmlTextWriter(name, null);
            Writer.Formatting = Formatting.Indented;
        }
        public Boolean Handled
        {
            get { return handled; }
            set
            {
                handled = value;
                if (handled)
                {
                    Writer.WriteFullEndElement();
                    Writer.Close();
                    try
                    {
                        File.Delete(Path);
                    }
                    catch
                    {
                    }
                }
            }
        }
        public void Close(bool delete=false)
        {
            Writer.Close();
            if (delete)
                File.Delete(Path);
        }
        public override string ToString()
        {
            return Path + "[" + Count + "]";
        }
    }
}

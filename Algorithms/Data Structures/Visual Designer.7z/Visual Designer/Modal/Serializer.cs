﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace Modalizer.XML
{
    public partial class XmlSerializer
    {
        string tmpPath;
        private static bool isSerializing;

        public static bool IsSerializInProcess
        {
            get { return isSerializing; }
            set { isSerializing = value; }
        }
        string GetRealFileName(string filename)
        {
            return filename.Replace(".", "") + ".vdp";
        }
        public void Serialize(System.Windows.Forms.Form Form, System.Windows.Forms.Form cmprr, string fileName, FeedBack feed)
        {
            lock (this)
            {
                try
                {
                    fileName = GetRealFileName(fileName);
                    isSerializing = true;
                    Backup(fileName);
                    using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.Read))
                    {
                        using (XmlTextWriter xml = new XmlTextWriter(fs, null))
                        {
                            feed(new object[] { "> [ " + Util.Time + " ] : Create save file : " + fileName + "..." });

                            xml.Formatting = Formatting.Indented;
                            xml.WriteStartDocument();
                            xml.WriteStartElement("Project");
                            xml.WriteAttributeString("Location", fileName.Replace(".vdp", ".exe"));

                            #region Serializing form attributes
                            feed(new object[] { "> [ " + Util.Time + " ] : Start Sersializing form attributes  ..." });
                            SerializeForm(Form, cmprr, xml);
                            feed(new object[] { "> [ " + Util.Time + " ] : Serializing form attributes is done   ..." });
                            #endregion

                            #region Serializing form components
                            feed(new object[] { "> [ " + Util.Time + " ] : Start Serializing form components ..." });
                            SerializableControls(Form, xml);
                            feed(new object[] { "> [ " + Util.Time + " ] : Serializing form components is done  ..." });
                            #endregion

                            xml.WriteEndElement();
                        }
                    }
                }
                catch (Exception e)
                {
                    if (!String.IsNullOrEmpty(tmpPath))
                        File.Copy(tmpPath, fileName, true);

                    e = new Exception(e.Message + "\r\n" + fileName);
                    throw e;
                }
                finally
                {
                    File.Delete(tmpPath);
                    isSerializing = false;
                }
            }
        }

        private void Backup(string filename)
        {
            if (File.Exists(filename))
            {
                File.Copy(filename, tmpPath = filename + ".tmp", true);
            }
        }

        private void SerializeForm(Form Form, Form cmprr, XmlTextWriter xml)
        {
            xml.WriteStartElement("Form");
            xml.WriteStartElement("Attributes");
            System.Reflection.PropertyInfo[] pi = Form.GetType().GetProperties();
            System.Reflection.PropertyInfo[] p = cmprr.GetType().GetProperties();

            if (pi.Length != p.Length)
                throw new SerializeRunTimeException("Target form and passed comparred form configs does not match to eatch other ...");

            for (int i = 0; i < pi.Length; i++)
            {
                object foo = pi[i].GetValue(Form, null);
                if (foo != null && pi[i].CanWrite && !foo.Equals(p[i].GetValue(cmprr, null)))
                {
                    if (pi[i].Name == "BackColor" || pi[i].Name == "ForeColor")
                    {
                        xml.WriteStartElement("id");
                        xml.WriteAttributeString("value", i.ToString());
                        xml.WriteStartElement(pi[i].Name);
                        System.Drawing.Color color = (System.Drawing.Color)pi[i].GetValue(Form, null);
                        xml.WriteAttributeString("A", color.A.ToString());
                        xml.WriteAttributeString("B", color.B.ToString());
                        xml.WriteAttributeString("G", color.G.ToString());
                        xml.WriteAttributeString("R", color.R.ToString());
                        xml.WriteEndElement();
                        xml.WriteEndElement();
                    }
                    else
                    {
                        WriteNasted(pi[i], xml, Form, i);
                    }
                }
            }
            xml.WriteEndElement();
            xml.WriteEndElement();
        }

        private void SerializableControls(Form Form, XmlTextWriter xml)
        {
            xml.WriteStartElement("Controls");
            foreach (System.Windows.Forms.Control i in Form.Controls)
            {
                Type t = i.GetType();
                Control tmp = Create.InstanceObject(new Catcher.Events.Event(t).Related);
                xml.WriteStartElement("Control");
                xml.WriteStartElement(t.Name);
                int Count = 0;
                System.Reflection.PropertyInfo[] tmp_p = tmp.GetType().GetProperties();
                foreach (System.Reflection.PropertyInfo j in t.GetProperties())
                {
                    System.Reflection.PropertyInfo k = tmp_p[Count];
                    if (k.Name == j.Name)
                    {
                        try
                        {
                            object foo = j.GetValue(i, null);
                            if (foo != null && j.CanWrite && !foo.Equals(k.GetValue(tmp, null)))

                                if (k.Name == "BackColor" || k.Name == "ForeColor")
                                {
                                    xml.WriteStartElement("id");
                                    xml.WriteAttributeString("value", Count.ToString());
                                    xml.WriteStartElement(k.Name);
                                    System.Drawing.Color color = (System.Drawing.Color)k.GetValue(i, null);
                                    xml.WriteAttributeString("A", color.A.ToString());
                                    xml.WriteAttributeString("B", color.B.ToString());
                                    xml.WriteAttributeString("G", color.G.ToString());
                                    xml.WriteAttributeString("R", color.R.ToString());
                                    xml.WriteEndElement();
                                    xml.WriteEndElement();
                                }
                                else
                                {
                                    WriteNasted(j, xml, i, Count);
                                }
                        }
                        catch (Exception e)
                        {
                            using (StreamWriter sw = new StreamWriter("Errors.txt", true))
                            {
                                sw.WriteLine("{0} ==> {1} ==> {2}", t.Name, k.Name, e.Message);
                            }
                        }
                    }
                    else
                    {
                        throw new Exception();
                    }
                    Count++;
                }
                xml.WriteEndElement();
                xml.WriteEndElement();
            }
        }

        /// <summary>
        /// Serialize nasted property info
        /// </summary>
        /// <param name="pi"></param>
        /// <param name="xml"></param>
        /// <param name="i"></param>
        /// <param name="Count"></param>
        private void WriteNasted(System.Reflection.PropertyInfo pi, XmlTextWriter xml, object i, int Count)
        {
            if (pi.PropertyType.IsSerializable && !pi.PropertyType.IsAbstract && !pi.PropertyType.IsInterface)
            {
                xml.WriteStartElement("id");
                xml.WriteAttributeString("value", Count.ToString());
                //xml.WriteStartElement(pi.Name);
                try
                {
                    System.Xml.Serialization.XmlSerializer xs = new System.Xml.Serialization.XmlSerializer(pi.PropertyType);
                    object foo;
                    if ((foo = pi.GetValue(i, null)) != null)
                    {
                        xs.Serialize(xml, foo);
                    }
                }
                catch { }
                //xml.WriteEndElement();
                xml.WriteEndElement();
            }
        }
    }
}
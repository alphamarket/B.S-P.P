﻿using System;
using System.Collections;
using System.Windows.Forms;
using Catcher.Events;
namespace Modalizer
{
    class Tracker
    {
        static Hashtable trckr = new Hashtable();
        public static int Add(Catcher.Control control)
        {
            int tmp = 1;
            if (trckr.ContainsKey(control))
            {
                trckr[control] = tmp = Convert.ToInt32(trckr[control]) + 1;
            }
            else
            {
                trckr.Add(control, tmp);
            }
            return tmp;
        }
    }
    class Name
    {
        public static string ToFomral(Type type)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(type.Name);
            sb = sb.Replace(sb[0], sb[0].ToString().ToLower().ToCharArray()[0], 0, 1);
            return sb.ToString();
        }
    }
    public class Create
    {
        private System.Windows.Forms.Control control;
        /// <summary>
        /// Sets generic options to control and Add to form's controls
        /// </summary>
        /// <param name="Parent"></param>
        /// <param name="Control"></param>
        public Create(Form Parent, System.Windows.Forms.Control Control)
        {
            control = Control;
            Tracker.Add(new Event(control.GetType()).Related);
            new Dragging.Dragable(control);
            control.CreateControl();
            control.SuspendLayout();
            Parent.Controls.Add(control);
            control.Focus();
        }

        /// <summary>
        /// Create an instance object based on information saved in Catcher.Events.Caption in specified location and add create control to parent
        /// </summary>
        /// <param name="Parent"></param>
        /// <param name="Location"></param>
        public Create(Form Parent, System.Drawing.Point Location)
        {
            if (!Caption.Handled)
            {
                control = InstanceObject(Caption.Control);

                GenericOptions(Parent, Location);
                
                SpecifiedOption();
                
                Catcher.Events.Caption.Handled = true;
            }
        }

        private void SpecifiedOption()
        {
            try
            {
                control.Text = control.Name;
            }
            catch { }
        }

        private void GenericOptions(Form f, System.Drawing.Point p)
        {
            new Dragging.Dragable(control);
            control.Location = p;
            control.Name = Name.ToFomral(control.GetType()) + Tracker.Add(Catcher.Events.Caption.Control);
            control.CreateControl();
            control.SuspendLayout();
            f.Controls.Add(control);
            control.Focus();
        }

        public static System.Windows.Forms.Control InstanceObject(Catcher.Control _control)
        {
            System.Windows.Forms.Control control;
            switch (_control)
            {
                case Catcher.Control.Button:
                    control = new Button();
                    break;
                case Catcher.Control.CheckBox:
                    control = new CheckBox();
                    break;
                case Catcher.Control.CheckedListBox:
                    control = new CheckedListBox();
                    break;
                case Catcher.Control.ComboBox:
                    control = new ComboBox();
                    break;
                case Catcher.Control.DateTimePicker:
                    control = new DateTimePicker();
                    break;
                case Catcher.Control.Label:
                    control = new Label();
                    break;
                case Catcher.Control.LinkLabel:
                    control = new LinkLabel();
                    break;
                case Catcher.Control.ListBox:
                    control = new ListBox();
                    break;
                case Catcher.Control.ListView:
                    control = new ListView();
                    break;
                case Catcher.Control.MaskedTextBox:
                    control = new MaskedTextBox();
                    break;
                case Catcher.Control.MonthCalendar:
                    control = new MonthCalendar();
                    break;
                case Catcher.Control.NumericUpDown:
                    control = new NumericUpDown();
                    break;
                case Catcher.Control.PictureBox:
                    control = new PictureBox();
                    break;
                case Catcher.Control.ProgressBar:
                    control = new ProgressBar();
                    break;
                case Catcher.Control.RadioButton:
                    control = new RadioButton();
                    break;
                case Catcher.Control.RichTextBox:
                    control = new RichTextBox();
                    break;
                case Catcher.Control.TextBox:
                    control = new TextBox();
                    break;
                case Catcher.Control.TreeView:
                    control = new TreeView();
                    break;
                default:
                    throw new InvalidOperationException();
            }
            return control;
        }
        public System.Windows.Forms.Control Control
        {
            get { return control; }
        }
    }
}

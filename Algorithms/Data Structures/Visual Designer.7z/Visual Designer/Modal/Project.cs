﻿using Microsoft.Win32;

namespace Modalizer.Project
{
    public class Current
    {
        static string sn = "Test", l = ".";
        public Current()
        {
            try
            {
                RegistryKey r = Registry.CurrentUser.OpenSubKey("Software\\ds_VisualDesigner\\Projects\\Current");
                l = r.GetValue("Path").ToString();
                sn = r.GetValue("Name").ToString();
            }
            catch { }
        }
        public static string SolutionName
        {
            get { return sn; }
        }
        public static string Location
        {
            get { return l+"\\"; }
        }
    }
}

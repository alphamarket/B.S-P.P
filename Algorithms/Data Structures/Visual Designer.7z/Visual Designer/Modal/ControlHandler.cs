﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
namespace Modalizer.XML
{
    class ControlHandler : IEnumerable
    {
        /// <summary>
        /// Control related to this object
        /// </summary>
        public Control Control;

        public System.Reflection.PropertyInfo[] Properties;

        Stack<XmlFileNode> xfn = new Stack<XmlFileNode>();

        private string currentDirectory;

        public ControlHandler(Control control)
        {
            this.Control = control;

            this.Properties = control.GetType().GetProperties();

            Directory.CreateDirectory(currentDirectory = "Tmp\\" + control.GetType().FullName + Path.GetRandomFileName());
        }
        /// <summary>
        /// Push new element of this instance control to stack for futhur usage
        /// </summary>
        /// <param name="Count">The index control's property is about to init</param>
        /// <param name="name">A name for tmp file(optional)</param>
        public void Push(Int16 Count, String name = "")
        {
            if (name == "")
            {
                name = Path.GetRandomFileName().Replace(".", "") + ".xml";
            }
            name = currentDirectory + "\\" + name;
            xfn.Push(new XmlFileNode(name, Count));
        }
        /// <summary>
        /// Returns current property file info object
        /// </summary>
        public XmlFileNode Current
        {
            get { return xfn.Peek(); }
        }
        /// <summary>
        /// Pops a property file info object
        /// </summary>
        /// <returns></returns>
        public XmlFileNode Pop()
        {
            return xfn.Pop();
        }

        public int Count
        {
            get { return xfn.Count; }
        }

        public override string ToString()
        {
            return Control.GetType().FullName + "[Count: " + xfn.Count + "]";
        }

        public IEnumerator GetEnumerator()
        {
            return xfn.GetEnumerator();
        }
        /// <summary>
        /// Closes current opened file node
        /// </summary>
        internal void Close()
        {
            if (xfn.Count > 0)
            {
                Current.Close();
                if (new FileInfo(Current.Path).Length == 0)
                    Pop().Close(true);
            }
        }
    }
}
﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml;
namespace Modalizer.XML
{
    public partial class XmlSerializer
    {
        String serializeError = "Seems the source file has been interrupted, can not interpret the context!";
        public delegate void FeedBack(object[] senders);

        internal enum Node { Control, Property, None, Title }

        public void Deserialize(System.Windows.Forms.Form Form, String fileName, FeedBack feed = null)
        {
            lock (this)
            {
                fileName = GetRealFileName(fileName);
                if (!File.Exists(fileName) || new FileInfo(fileName).Length == 0)
                    throw new SerializeRunTimeException("Seems the source file has been interrupted, can not interpret the context", new Exception("The file does not exist or is empty."));
                feed(new object[] { "> [ " + Util.Time + " ] : loading save file : " + fileName + "..." });
                feed(new object[] { "> [ " + Util.Time + " ] : Testing save file ..." });
                TestDeserializeFile(fileName);
                feed(new object[] { "> [ " + Util.Time + " ] : Testing save file passed successfully ..." });
                try
                {
                    isSerializing = true;
                    using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        using (XmlTextReader xt = new XmlTextReader(fs))
                        {
                            feed(new object[] { "> [ " + Util.Time + " ] : Starting initializing form attributes  ..." });
                            DeserializeForm(xt, Form, feed);
                            feed(new object[] { "> [ " + Util.Time + " ] : Initializing form attributes is done   ..." });
                            feed(new object[] { "> [ " + Util.Time + " ] : Starting deserializing form components ..." });
                            DeserializeControls(xt, Form, feed);
                            feed(new object[] { "> [ " + Util.Time + " ] : Deserializing form components is done  ..." });
                        }
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                finally
                {
                    isSerializing = false;
                }
            }
        }

        private void TestDeserializeFile(string fileName)
        {
            bool id = false;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (XmlTextReader xt = new XmlTextReader(fs))
                {
                    while (xt.Read())
                    {
                        switch (xt.NodeType)
                        {
                            case XmlNodeType.Element:
                                id = (xt.Name.ToLower() == "id");
                                if (id)
                                {
                                    if (xt.AttributeCount == 0)
                                        throw new SerializeRunTimeException(serializeError);
                                }
                                break;
                        }
                    }
                }
            }
            if (id)
            {
                throw new SerializeRunTimeException(serializeError);
            }
        }

        private void DeserializeForm(XmlTextReader xt, Form Form, FeedBack feed)
        {
            try
            {
                System.Reflection.PropertyInfo[] pi = Form.GetType().GetProperties();
                while (xt.Read())
                {
                    switch (xt.NodeType)
                    {
                        case XmlNodeType.Element:
                            if (xt.Name.ToLower() == "id")
                            {
                                System.Reflection.PropertyInfo p = pi[int.Parse(xt.GetAttribute(0))];
                                while (xt.Read() && xt.NodeType != XmlNodeType.Element) ;

                                switch (xt.AttributeCount)
                                {
                                    case 0:
                                        p.SetValue(Form, new System.Xml.Serialization.XmlSerializer(p.PropertyType).Deserialize(xt), null);
                                        break;
                                    case 4:
                                        p.SetValue(Form, System.Drawing.Color.FromArgb(int.Parse(xt.GetAttribute("A")), int.Parse(xt.GetAttribute("R")), int.Parse(xt.GetAttribute("G")), int.Parse(xt.GetAttribute("B"))), null);
                                        break;
                                }
                            }
                            break;
                        case XmlNodeType.EndElement:
                            if (xt.Name.ToLower() == "form")
                                return;
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                throw new SerializeRunTimeException("Seems the source file has been interrupted, can not interpret the context!\r\n>>" + e.Message, e.InnerException);
            }
        }

        private void DeserializeControls(XmlTextReader xt, Form Form, FeedBack feed)
        {
            try
            {
                Control c = null;
            ControlReader:
                while (xt.Read())
                {
                    switch (xt.NodeType)
                    {
                        case XmlNodeType.Element:
                            if (xt.Name.ToLower() == "control")
                            {
                                while (xt.Read() && xt.NodeType != XmlNodeType.Element) ;
                                c = Create.InstanceObject(new Catcher.Events.Event(xt.Name).Related);
                                System.Reflection.PropertyInfo[] p = c.GetType().GetProperties();
                                while (xt.Read())
                                {
                                    switch (xt.NodeType)
                                    {
                                        case XmlNodeType.Element:
                                            if (xt.Name.ToLower() == "id")
                                            {
                                                System.Reflection.PropertyInfo pi = p[int.Parse(xt.GetAttribute(0))];

                                                while (xt.Read() && xt.NodeType != XmlNodeType.Element) ;

                                                switch (xt.AttributeCount)
                                                {
                                                    case 0:
                                                        pi.SetValue(c, new System.Xml.Serialization.XmlSerializer(pi.PropertyType).Deserialize(xt), null);
                                                        break;
                                                    case 4:
                                                        pi.SetValue(c, System.Drawing.Color.FromArgb(int.Parse(xt.GetAttribute("A")), int.Parse(xt.GetAttribute("R")), int.Parse(xt.GetAttribute("G")), int.Parse(xt.GetAttribute("B"))), null);
                                                        break;
                                                }
                                            }
                                            break;
                                        case XmlNodeType.EndElement:
                                            if (xt.Name.ToLower() == "control")
                                            {
                                                if (c != null)
                                                {
                                                    new Create(Form, c);
                                                    c = null;
                                                }
                                                goto ControlReader;
                                            }
                                            break;
                                    }
                                }
                            }
                            break;
                        case XmlNodeType.EndElement:
                            if (xt.Name.ToLower() == "controls")
                            {
                                if (c != null)
                                    new Create(Form, c);
                                return;
                            }
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                throw new SerializeRunTimeException("Seems the source file has been interrupted, can not interpret the context!\r\n>>" + e.Message, e.InnerException);
            }
        }
    }
}
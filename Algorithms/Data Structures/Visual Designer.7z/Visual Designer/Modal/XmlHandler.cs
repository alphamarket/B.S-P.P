﻿using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
namespace Modalizer.XML
{
    class XmlHandler : IEnumerable
    {
        Stack<ControlHandler> ch = new Stack<ControlHandler>();

        /// <summary>
        /// Current control which is being handling
        /// </summary>
        public ControlHandler Current
        {
            get { return ch.Peek(); }
        }
        /// <summary>
        /// Pop a control from stack
        /// </summary>
        /// <returns></returns>
        public ControlHandler Pop()
        {
            return ch.Pop();
        }
        /// <summary>
        /// Push new control to stack
        /// </summary>
        /// <param name="control"></param>
        public void Push(Control control)
        {
            ch.Push(new ControlHandler(control));
        }

        public IEnumerator GetEnumerator()
        {
            return ch.GetEnumerator();
        }
        public int Count
        {
            get { return ch.Count; }
        }
        public override string ToString()
        {
            return "XmlHandler [Count: " + Count + "]";
        }
    }
}

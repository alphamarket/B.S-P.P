﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modalizer
{
    public class Util
    {
        public static string Time
        {
            get
            {
                return DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second + ":" + DateTime.Now.Millisecond;
            }
        }
    }
}

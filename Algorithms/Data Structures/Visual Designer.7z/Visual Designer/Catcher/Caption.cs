﻿using System;
namespace Catcher
{
    public enum Control
    {
        None,
        Pointer,
        Button,
        CheckBox,
        CheckedListBox,
        ComboBox,
        DateTimePicker,
        Label,
        LinkLabel,
        ListBox,
        ListView,
        MaskedTextBox,
        MonthCalendar,
        NumericUpDown,
        PictureBox,
        ProgressBar,
        RadioButton,
        RichTextBox,
        TextBox,
        TreeView
    }
}
namespace Catcher.Events
{
    /// <summary>
    /// in class bara interaction'e control selection hastesh!!
    /// </summary>
    /// Tamamiye member hash bayad static bashan!
    public class Caption
    {
        static Events.Event e = new Event("");
        static bool hndl;
        
        public static void Happen(Event e)
        {
            Caption.e = e;
            hndl = false;
        }
        
        public static Control Control
        {
            get { return e.Related; }
        }
        
        public static bool Handled
        {
            get { return hndl; }
            set
            {
                hndl = value;
                if (hndl)
                {
                    Catcher.Events.Caption.Reset();
                }
            }
        }

        public static void Reset()
        {
            e = new Event("");
        }

        public static bool IsActive
        {
            get { return e.Related != Catcher.Control.Pointer && e.Related != Catcher.Control.None; }
        }

        public override string ToString()
        {
            return e.ToString();
        }
    }
    public class Event
    {
        Catcher.Control control;
        public Event(String ObjectType)
        {
            if (ObjectType == "")
            {
                control = Control.None | Control.Pointer;
            }
            else
            {
                control = (Catcher.Control)Enum.Parse(typeof(Catcher.Control), ObjectType);
            }
        }
        public Event(Type type)
        {
            control = (Catcher.Control)Enum.Parse(typeof(Catcher.Control), type.Name);
        }
        public Catcher.Control Related
        {
            get { return control; }
        }
        public override string ToString()
        {
            return control.ToString();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Catcher.Events;
namespace Loader.Controls
{
    partial class ToolBox : UserControl
    {
        bool pinClicked = false;
        public ToolBox()
        {
            InitializeComponent();
            foreach (System.Windows.Forms.Control i in this.Controls)
            {
                if (i is CustomUserControl)
                {
                    (i as CustomUserControl).RelatedControl.Click += new EventHandler(RelatedControl_Click);
                }
            }
        }
        void RelatedControl_Click(object sender, EventArgs e)
        {
            bool done = false;
            foreach (System.Windows.Forms.Control i in this.Controls)
            {
                if (i is CustomUserControl)
                {
                    CustomUserControl cuc = i as CustomUserControl;
                    if (cuc.Activate)
                    {
                        cuc.Activate = false;
                    }
                    if (!done && cuc.RelatedControl.Equals(sender))
                    {
                        Caption.Happen(new Event(cuc.RelatedType));
                        cuc.Activate = true;
                        done = true;
                    }
                }
            }
        }
        private void Close_MouseEnter(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.CloseHover;
        }

        private void Close_MouseLeave(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.close;
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void pin_MouseEnter(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.PinHover;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.UnPinHover;
            }
        }

        private void pin_MouseLeave(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.pin;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.unpin;
            }
        }

        private void pin_Click(object sender, EventArgs e)
        {
            pinClicked = !pinClicked;
            pin_MouseEnter(sender, e);
            this.Focus();
        }

        private void ToolBox_Leave(object sender, EventArgs e)
        {
            if (!pinClicked)
                close_Click(sender, e);
            RelatedControl_Click(sender, e); 
        }
        public bool Deactivate
        {
            get
            {
                if (pinClicked)
                    pin_MouseLeave(new object(), new EventArgs());

                return !pinClicked;
            }
            set
            {
                if (!value)
                {
                    this.Show();
                }
                else
                {
                    ToolBox_Leave(new object(), new EventArgs());
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Focus();
        }
    }
}

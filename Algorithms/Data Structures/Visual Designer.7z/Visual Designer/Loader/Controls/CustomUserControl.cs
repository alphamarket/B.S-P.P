﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Loader.Controls
{
    class CustomUserControl : UserControl
    {
        bool active;
        System.Windows.Forms.Control rc; 
        Type rt;
        public delegate void CMouseEnter(object sender, EventArgs e);
        public delegate void CMouseLeave(object sender, EventArgs e);
        CMouseLeave ml;
        CMouseEnter me;
        protected System.Windows.Forms.Control RelatedWith
        {
            set
            {
                rc = value;
            }
            get
            {
                return rc;
            }
        }
        public virtual bool Activate
        {
            get
            {
                return active;
            }
            set
            {
                active = value;
                if (active)
                {
                    me(new object(), new EventArgs());
                }
                else
                {
                    ml(new object(), new EventArgs());
                }
            }
        }

        public Type RelatedType
        {
            get { return rt; }
            protected set { rt = value; }
        }

        public System.Windows.Forms.Control RelatedControl
        {
            get { return rc; }
            protected set { rc = value; }
        }
        
        public override string ToString()
        {
            return rt.Name;
        }

        protected void Config(System.Windows.Forms.Control control, Type t, CMouseEnter me, CMouseLeave ml)
        {
            this.ml = ml;
            this.me = me;
            RelatedControl = control;
            RelatedType = t;
        }
    }
}

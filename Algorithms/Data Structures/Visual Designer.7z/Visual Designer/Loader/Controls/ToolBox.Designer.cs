﻿namespace Loader.Controls
{
    partial class ToolBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToolBox));
            this.pin = new System.Windows.Forms.PictureBox();
            this.close = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.treeView1 = new Loader.Controls.TreeView();
            this.textBox1 = new Loader.Controls.TextBox();
            this.richTextBox1 = new Loader.Controls.RichTextBox();
            this.radioButton1 = new Loader.Controls.RadioButton();
            this.progressBar1 = new Loader.Controls.ProgressBar();
            this.pictureBox2 = new Loader.Controls.PictureBox();
            this.numericUpDown1 = new Loader.Controls.NumericUpDown();
            this.monthCalendar1 = new Loader.Controls.MonthCalendar();
            this.maskedTextBox1 = new Loader.Controls.MaskedTextBox();
            this.listView1 = new Loader.Controls.ListView();
            this.listBox1 = new Loader.Controls.ListBox();
            this.linkLabel1 = new Loader.Controls.LinkLabel();
            this.label1 = new Loader.Controls.Label();
            this.dateTimePicker1 = new Loader.Controls.DateTimePicker();
            this.comboBox1 = new Loader.Controls.ComboBox();
            this.checkedListBox1 = new Loader.Controls.CheckedListBox();
            this.checkBox1 = new Loader.Controls.CheckBox();
            this.button1 = new Loader.Controls.Button();
            this.pointer1 = new Loader.Controls.Pointer();
            ((System.ComponentModel.ISupportInitialize)(this.pin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pin
            // 
            this.pin.Image = ((System.Drawing.Image)(resources.GetObject("pin.Image")));
            this.pin.Location = new System.Drawing.Point(238, 5);
            this.pin.Name = "pin";
            this.pin.Size = new System.Drawing.Size(16, 16);
            this.pin.TabIndex = 2;
            this.pin.TabStop = false;
            this.pin.Click += new System.EventHandler(this.pin_Click);
            this.pin.MouseEnter += new System.EventHandler(this.pin_MouseEnter);
            this.pin.MouseLeave += new System.EventHandler(this.pin_MouseLeave);
            // 
            // close
            // 
            this.close.Image = global::Loader.Properties.Resources.close;
            this.close.Location = new System.Drawing.Point(257, 5);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(16, 16);
            this.close.TabIndex = 1;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            this.close.MouseEnter += new System.EventHandler(this.Close_MouseEnter);
            this.close.MouseLeave += new System.EventHandler(this.Close_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(283, 24);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // treeView1
            // 
            this.treeView1.Activate = false;
            this.treeView1.Location = new System.Drawing.Point(0, 367);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(283, 19);
            this.treeView1.TabIndex = 21;
            // 
            // textBox1
            // 
            this.textBox1.Activate = false;
            this.textBox1.Location = new System.Drawing.Point(0, 348);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(283, 19);
            this.textBox1.TabIndex = 20;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Activate = false;
            this.richTextBox1.Location = new System.Drawing.Point(1, 329);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(283, 19);
            this.richTextBox1.TabIndex = 19;
            // 
            // radioButton1
            // 
            this.radioButton1.Activate = false;
            this.radioButton1.Location = new System.Drawing.Point(1, 310);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(283, 19);
            this.radioButton1.TabIndex = 18;
            // 
            // progressBar1
            // 
            this.progressBar1.Activate = false;
            this.progressBar1.Location = new System.Drawing.Point(0, 291);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(283, 19);
            this.progressBar1.TabIndex = 17;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Activate = false;
            this.pictureBox2.Location = new System.Drawing.Point(0, 272);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(283, 19);
            this.pictureBox2.TabIndex = 16;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Activate = false;
            this.numericUpDown1.Location = new System.Drawing.Point(0, 254);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(283, 18);
            this.numericUpDown1.TabIndex = 15;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Activate = false;
            this.monthCalendar1.Location = new System.Drawing.Point(0, 235);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.Size = new System.Drawing.Size(283, 19);
            this.monthCalendar1.TabIndex = 14;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Activate = false;
            this.maskedTextBox1.Location = new System.Drawing.Point(0, 216);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(283, 19);
            this.maskedTextBox1.TabIndex = 13;
            // 
            // listView1
            // 
            this.listView1.Activate = false;
            this.listView1.Location = new System.Drawing.Point(0, 197);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(283, 19);
            this.listView1.TabIndex = 12;
            // 
            // listBox1
            // 
            this.listBox1.Activate = false;
            this.listBox1.Location = new System.Drawing.Point(0, 178);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(283, 19);
            this.listBox1.TabIndex = 11;
            // 
            // linkLabel1
            // 
            this.linkLabel1.Activate = false;
            this.linkLabel1.Location = new System.Drawing.Point(0, 159);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(283, 19);
            this.linkLabel1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.Activate = false;
            this.label1.Location = new System.Drawing.Point(0, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 19);
            this.label1.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Activate = false;
            this.dateTimePicker1.Location = new System.Drawing.Point(0, 121);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(283, 19);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // comboBox1
            // 
            this.comboBox1.Activate = false;
            this.comboBox1.Location = new System.Drawing.Point(0, 102);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(283, 19);
            this.comboBox1.TabIndex = 7;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.Activate = false;
            this.checkedListBox1.Location = new System.Drawing.Point(0, 83);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(283, 19);
            this.checkedListBox1.TabIndex = 6;
            // 
            // checkBox1
            // 
            this.checkBox1.Activate = false;
            this.checkBox1.Location = new System.Drawing.Point(0, 64);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(283, 19);
            this.checkBox1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Activate = false;
            this.button1.Location = new System.Drawing.Point(0, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(283, 19);
            this.button1.TabIndex = 4;
            // 
            // pointer1
            // 
            this.pointer1.Activate = false;
            this.pointer1.Location = new System.Drawing.Point(0, 26);
            this.pointer1.Name = "pointer1";
            this.pointer1.Size = new System.Drawing.Size(283, 19);
            this.pointer1.TabIndex = 3;
            // 
            // ToolBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pointer1);
            this.Controls.Add(this.pin);
            this.Controls.Add(this.close);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ToolBox";
            this.Size = new System.Drawing.Size(283, 387);
            this.Leave += new System.EventHandler(this.ToolBox_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.pin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox close;
        private System.Windows.Forms.PictureBox pin;
        private Pointer pointer1;
        private Button button1;
        private CheckBox checkBox1;
        private CheckedListBox checkedListBox1;
        private ComboBox comboBox1;
        private DateTimePicker dateTimePicker1;
        private Label label1;
        private LinkLabel linkLabel1;
        private ListBox listBox1;
        private ListView listView1;
        private MaskedTextBox maskedTextBox1;
        private MonthCalendar monthCalendar1;
        private NumericUpDown numericUpDown1;
        private PictureBox pictureBox2;
        private ProgressBar progressBar1;
        private RadioButton radioButton1;
        private RichTextBox richTextBox1;
        private TextBox textBox1;
        private TreeView treeView1;
    }
}

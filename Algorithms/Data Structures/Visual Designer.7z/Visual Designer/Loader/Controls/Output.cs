﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Loader.Controls
{
    public partial class OutPut : UserControl
    {
        private bool pinClicked = false;
        public OutPut()
        {
            InitializeComponent();
            PanelReadOnly = false;
            this.Hide();
        }

        public bool Deactivate
        {
            get
            {
                if (pinClicked)
                    pin_MouseLeave(new object(), new EventArgs());

                return !pinClicked;
            }
            set
            {
                if (!value)
                {
                    this.Show();
                }
                else
                {
                    this.Hide();
                }
            }
        }

        public void Clear()
        {
            richTextBox1.Clear();
        }

        private void Close_MouseEnter(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.CloseHover;
        }

        private void Close_MouseLeave(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.close;
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void pin_MouseEnter(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.PinHover;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.UnPinHover;
            }
        }

        private void pin_MouseLeave(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.pin;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.unpin;
            }
        }

        private void pin_Click(object sender, EventArgs e)
        {
            pinClicked = !pinClicked;
            pin_MouseEnter(sender, e);
            this.Focus();
        }

        public bool PanelReadOnly
        {
            get { return richTextBox1.ReadOnly; }
            set { richTextBox1.ReadOnly = value; }
        }

        public string PanelText
        {
            get { return richTextBox1.Text; }
            set { richTextBox1.Text = value; }
        }

        public Size PanelSize
        {
            get { return this.Size; }
            set { this.Size = value; }
        }

        public void FeedBack(object[] sender)
        {
            foreach (var i in sender)
            {
                richTextBox1.AppendText("\r\n" + i.ToString());
                Application.DoEvents();
            }
        }
    }
}

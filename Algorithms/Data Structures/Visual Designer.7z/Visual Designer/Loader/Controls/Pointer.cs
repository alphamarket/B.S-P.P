﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Loader.Controls
{
    partial class Pointer : CustomUserControl
    {
        public Pointer()
        {
            InitializeComponent();
            base.Config(pictureBox1, typeof(Pointer), new CMouseEnter(pictureBox1_MouseEnter), new CMouseLeave(pictureBox1_MouseLeave));
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            pictureBox1.Image = global::Loader.Properties.Resources.Pointer1;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            if (!base.Activate)
                pictureBox1.Image = global::Loader.Properties.Resources.Pointer;
        }
    }
}

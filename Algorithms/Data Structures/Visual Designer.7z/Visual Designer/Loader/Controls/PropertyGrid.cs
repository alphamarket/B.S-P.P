﻿using System;
using System.Windows.Forms;

namespace Loader.Controls
{
    partial class PropertyGrid : UserControl
    {
        bool pinClicked= false;
        public PropertyGrid()
        {
            InitializeComponent();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void Close_MouseEnter(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.CloseHover;
        }

        private void Close_MouseLeave(object sender, EventArgs e)
        {
            close.Image = global::Loader.Properties.Resources.close;
        }
        private void pin_MouseEnter(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.PinHover;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.UnPinHover;
            }
        }

        private void pin_MouseLeave(object sender, EventArgs e)
        {
            if (!pinClicked)
            {
                pin.Image = global::Loader.Properties.Resources.pin;
            }
            else
            {
                pin.Image = global::Loader.Properties.Resources.unpin;
            }
        }

        private void pin_Click(object sender, EventArgs e)
        {
            pinClicked = !pinClicked;
            pin_MouseEnter(sender, e);
            this.Focus();
        }

        public System.Windows.Forms.PropertyGrid Grid
        {
            get { return propertyGrid1; }
        }

        private void PropertyGrid_Load(object sender, EventArgs e)
        {
            if (!pinClicked)
                this.Hide();
        }

        private void PropertyGrid_Leave(object sender, EventArgs e)
        {
            PropertyGrid_Load(sender, e);
        }
        public bool Deactivate
        {
            get
            {
                return this.Focused;
            }
            set
            {
                if (!value)
                {
                    this.Show();
                }
                else
                {
                    PropertyGrid_Leave(new object(), new EventArgs());
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Focus();
        }

        public delegate void PropertyValueChanged(object sender, PropertyValueChangedEventArgs e);
        public PropertyValueChanged Property_PropertyValueChanged;
        private void propertyGrid1_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            if (Property_PropertyValueChanged != null)
                Property_PropertyValueChanged(s, e);
        }
    }
}

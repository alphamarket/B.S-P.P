﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Catcher.Events;
namespace Loader
{
    partial class Slot : Form
    {
        Point offset;
        public delegate void OutDuty();
        OutDuty duty;
        Loader.Controls.PropertyGrid pg;
        public Slot(Point offset, OutDuty duty, Loader.Controls.PropertyGrid pg,string Name = "form1")
        {
            InitializeComponent();
            this.Location = new Point(0, 0);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Text = Name;
            this.Name = Name;
            this.offset = offset;
            this.duty = duty;
            this.pg = pg;
            this.ControlAdded += new ControlEventHandler(Slot_ControlAdded);
            this.KeyDown+=new KeyEventHandler(Slot_KeyDown);
        }

        void Slot_ControlAdded(object sender, ControlEventArgs e)
        {
            SetOptions(false,sender as Control);
        }

        public Slot()
        {
            // TODO: Complete member initialization
        }

        Point ClickLocation
        {
            get
            {
                return new Point(Cursor.Position.X - this.Left - this.MdiParent.Left - offset.X, Cursor.Position.Y - this.Top - this.MdiParent.Top - offset.Y);
            }
        }

        private void Slot_Click(object sender, EventArgs e)
        {
            if (Caption.IsActive)
            {
                Modalizer.Create mc=new Modalizer.Create(this, ClickLocation);

                SetOptions(false, mc.Control);

            }
            else
            {
                this.SelectedObject = this;
                this.ActiveControl = null;
            }

            //TODO: after adjustment call duty from MdiParent form
            duty();
        }

        /// <summary>
        /// Set generic options to enetry control
        /// </summary>
        /// <param name="control"></param>
        public void SetOptions(bool toAll = true, Control control = null)
        {
            if (!toAll && control == null)
                throw new ArgumentException();
            if (toAll)
            {
                foreach (Control i in this.Controls)
                {
                    SetOptions(false, i);
                }
            }
            else
            {
                control.KeyDown += new KeyEventHandler(Control_KeyDown);
                control.Click += new EventHandler(control_Click);
            }
        }

        void control_Click(object sender, EventArgs e)
        {
            SelectedObject = sender;
            return;
        }
        public object SelectedObject
        {
            get
            {
                try
                {
                    return pg.Grid.SelectedObject;
                }
                catch
                {
                    return null;
                }
            }
            set
            {
                pg.Grid.SelectedObject = value;
            }
        }
        void Control_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    duty();
                    pg.Deactivate = false;
                    SelectedObject = sender;
                    break;
                case Keys.Delete:
                    duty();
                    (sender as Control).Dispose();
                    break;
            }
        }

        private void Slot_MouseEnter(object sender, EventArgs e)
        {
            if (Catcher.Events.Caption.IsActive)
            {
                this.Cursor = Cursors.Cross;//new System.Windows.Forms.Cursor("Selected.Stream");
            }
            else
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void Slot_MouseLeave(object sender, EventArgs e)
        {
            Cursor = Cursors.Default;
        }

        private void Slot_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    duty();
                    pg.Deactivate = false;
                    SelectedObject = sender;
                    break;
            }
        }

        private void Slot_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
                e.Cancel = true;
        }
    }
}

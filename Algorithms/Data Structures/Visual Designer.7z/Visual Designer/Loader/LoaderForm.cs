﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace Loader
{
    public partial class LoaderForm : Form
    {
        Slot ws;
        String svFile;
        public LoaderForm()
        {
            InitializeComponent();
            this.Text = System.Diagnostics.Process.GetCurrentProcess().ProcessName.Replace(".", "");
            svFile = Application.StartupPath + "\\" + this.Text;
            this.FormClosing += new FormClosingEventHandler(LoaderForm_FormClosing);
            ws = new Slot(new Point(13, 77), new Slot.OutDuty(AfterAdjustment), propertyGrid1);
            ws.MdiParent = this;
            ws.Show();
            openToolStripMenuItem_Click(new object(), new EventArgs());
        }

        private void ToolBoxPic_Click(object sender, EventArgs e)
        {
            toolBox1.Deactivate = false;
            outPut1.Deactivate = true;
            propertyGrid1.Deactivate = true;
        }

        private void PropertiesPic_Click(object sender, EventArgs e)
        {
            toolBox1.Deactivate = true;
            outPut1.Deactivate = true;
            propertyGrid1.Deactivate = false;
        }

        void AfterAdjustment()
        {
            propertyGrid1.Deactivate = true;
            toolBox1.Deactivate = true;
            outPut1.Deactivate = true;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outPut1.Clear();
            outPut1.Deactivate = false;
            try
            {
                new Modalizer.XML.XmlSerializer().Serialize(ws, new Slot(new Point(13, 77), new Slot.OutDuty(AfterAdjustment), propertyGrid1), svFile, new Modalizer.XML.XmlSerializer.FeedBack(outPut1.FeedBack));
            }
            catch (Modalizer.XML.SerializeRunTimeException sre)
            {
                outPut1.FeedBack(new object[] { sre.Message, (sre.InnerException != null ? new string(' ', 6) + sre.InnerException.Message : "") });
            }
            catch { }
            finally
            {
                System.Threading.Thread.Sleep(1000);
                outPut1.Deactivate = true;
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DisposeSlot();
            outPut1.Clear();
            outPut1.Deactivate = false;
            Application.DoEvents();
            try
            {
                new Modalizer.XML.XmlSerializer().Deserialize(ws, svFile, new Modalizer.XML.XmlSerializer.FeedBack(outPut1.FeedBack));
            }
            catch (Modalizer.XML.SerializeRunTimeException sre)
            {
                outPut1.FeedBack(new object[] { sre.Message, (sre.InnerException != null ? new string(' ', 6) + sre.InnerException.Message : "") });
            }
            catch { }
            finally
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(1000);
                outPut1.Deactivate = true;
            }
            ws.SetOptions();
        }

        delegate void _FormInvoker(Form f, Boolean visibale);
        void FormInvoker(Form f, Boolean visible)
        {
            if (f.InvokeRequired)
            {
                f.Invoke(new _FormInvoker(FormInvoker), new object[] { f, visible });
            }
            else
            {
                if (visible)
                    f.Show();
                else
                    f.Hide();
            }
        }

        private void LoaderForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void output_Click(object sender, EventArgs e)
        {
            toolBox1.Deactivate = true;
            outPut1.Deactivate = false;
            propertyGrid1.Deactivate = true;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Slot tmp = new Slot();
            if ((ws.Controls.Count != 0 || ws.Location != tmp.Location || ws.Size != tmp.Size) && MessageBox.Show("Are you sure to dispose all created controls in this form and create new form?", "Confirmation ...", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == System.Windows.Forms.DialogResult.Yes)
            {
                DisposeSlot();
            }
        }

        private void DisposeSlot()
        {
            ws.Dispose();
            ws = new Slot(new Point(13, 77), new Slot.OutDuty(AfterAdjustment), propertyGrid1);
            ws.MdiParent = this;
            ws.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoaderForm_FormClosing(sender, new FormClosingEventArgs(CloseReason.UserClosing, false));
        }
    }
}
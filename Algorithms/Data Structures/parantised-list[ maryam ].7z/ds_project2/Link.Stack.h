#pragma once

#include "Link.List.h"
#include <exception>

namespace Link{
	// implement of Stack class.
	template<class T>class Stack{
		Link::List<T>* list;
	public:
		// ctor of stack class
		Stack(void){
			list=new Link::List<T>();
		}
		// push an element to the stack.
		void Push(T value){
			list->AddFront(new Node<T>(value));
		}
		// pop an element from stack
		T Pop(){
			return list->RemoveFront()->Value;
		}
		// peek an element from stack, without removing it.
		T Peek(){
			return list->getTop()->Value;
		}
		// get count of stack objects.
		int getCount(){return list->getCount();}
	};
}
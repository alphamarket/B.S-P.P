// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

// Enum to demonstrate using technique
enum tech {DG, NOT_DG};
// create a Linked-list using DQ technique.
void createList_DQ(string,unsigned*,List<char>*);
// create a Linked-list using a non-DQ technique, but simulated.
void createList_UDQ(string,unsigned*,List<char>*);
// declarer that the given string is macth with normal string definition.
bool IsNormal_String(string* str);
// an interface for GetList algorithm.
List<char>* GetList(string, tech);

// main function of program
int _tmain(int argc, _TCHAR* argv[])
{
	// this is a sample of the output of the project
	for(int i=0;i<2;i++)
	{
		List<char>* list=GetList("((acj)(sa*/(sak)ksjbbj(f726&())))",(tech)i);
		if(list!=null)
		{
			list->Print();
			list->Dispose();
		}
		cout<<"\r\n\n";
	}
	getchar();
	return 0;
}

void createList_UDQ(string str,unsigned* index=0,List<char>* lst=null){
	if(lst==null)
		lst=new List<char>();
	List<char>* tmp_lst=null;
	Simu<char>* tmp_simu=null;
	Link::Stack<Simu<char>*> s;
	s.Push(new Simu<char>(null, lst));
	while(s.getCount()!=0){
		char simple=str[*index];
		tmp_simu=s.Pop();
		if(*index>=str.length())
			break;
		switch(str[*index]){
			case '(':	
				if(lst->getCount()==0){
					lst->AddNext(char(0));
					s.Push(tmp_simu);
					goto CIRCYLE_UP;
				}
				tmp_lst=new List<char>();
				tmp_simu->Child->AddNext(char(0));
				tmp_lst->AddNext(char(0));
				s.Push(tmp_simu);
				s.Push(new Simu<char>(tmp_simu->Child, tmp_lst));
				break;
			case ')':
				if(tmp_simu->Parent!=null)
					tmp_simu->Parent->AddUpDown(tmp_simu->Child);
				break;
			default:
				tmp_simu->Child->AddNext(str[*index]);
				s.Push(tmp_simu);
				break;
		}
CIRCYLE_UP:
		(*index)++;
	}
}

void createList_DQ(string str,unsigned* index=0,List<char>* lst=null){
	if(*index>=str.length())
		return;
	if(lst==null){
		lst=new List<char>();
	}
	List<char>* tmp_lst=null;
	switch(str[*index]){
		case '(':
			if(lst->getCount()==0){
				lst->AddNext(char(0));
				goto CIRCYLE_UP;
			}
			tmp_lst=new List<char>();
			lst->AddNext(char(0));
			tmp_lst->AddNext(char(0));
			createList_DQ(str, &(++(*index)),tmp_lst);
			lst->AddUpDown(tmp_lst);
			break;
		case ')': 
			return;
		default:
			lst->AddNext(str[*index]);
	}
CIRCYLE_UP:
	createList_DQ(str, &(++*index), lst);
}

List<char>* GetList(string str, tech t){
	if(IsNormal_String(&str)){
		List<char>* list=new List<char>();
		switch(t){
			case DG:
				cout<<"calling createList_DQ()... ";
				createList_DQ(str,new unsigned(0),list);
				break;
			case NOT_DG:
				cout<<"calling createList_UDQ()... ";
				createList_UDQ(str,new unsigned(0),list);
				break;
			default:
				break;
		}
		return list;
	}else{
		cout<<"The input string is not a normal string. so cannot be processed!";
		return null;
	}
}
bool IsNormal_String(string* str){
	int count=0;
	for(unsigned i=0;i<str->length();i++)
	{	
		switch((*str)[i]){
			case '(':
				count++;
				break;
			case ')':
				count--;
				break;
		}
	}
	if(count!=0) return false;
	return true;
}

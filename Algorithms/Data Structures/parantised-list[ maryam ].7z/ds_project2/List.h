#pragma once

#include "Node.h"
#include <iostream>
using namespace std;
// implementation of un-ordinary List class, suits for project objective needs
template<class T>class List{
	Node<T>* root;
	int count;
public:
	// ctor
	List(void){
		root=null;
		count=0;
	}

	
	/*
	 *
	 * ADDNEXT() REGION
	 *
	 */

	// Add a value to the next element's value where the list's circyle is began
	void AddNext(T value){
		if(root==null)
		{
			root=new Node<T>(value);
			root->IsRoot=true;
			root->Next=root;
		}
		else{
			Node<T>* tmp=root;
			while(tmp->Next!=null && tmp->Next!=root) tmp=tmp->Next;
			tmp->Next=new Node<T>(value);
			tmp->Next->Next=root;
		}
		count++;
	}
	// Add a node to where the list's circyle is began as Next element of list
	void AddNext(Node<T>* node){
		if(root==null)
		{
			root=node;
			root->IsRoot=true;
			root->Next=root;
		}
		else{
			Node<T>* tmp=root;
			while(tmp->Next!=null && tmp->Next!=root) tmp=tmp->Next;
			node->IsRoot=false;
			tmp->Next=node;
			tmp->Next->Next=root;
		}
		count++;
	}
	// Add a whole new list to where the list's circyle is began as Next element of list
	void AddNext(List<T>* list){
		AddNext(list->root);
		count--;
		count+=list->getCount();
	}

	
	/*
	 *
	 * ADDUPDOWN() REGION
	 *
	 */

	// Add a value to the updown element's value where the list's circyle is began
	void AddUpDown(T value){		
		if(root==null)
		{
			root=new Node<T>(value,null, root);
			root->IsRoot=true;
			root->Next=root;
		}
		else{
			Node<T>* tmp=root;
			while(tmp->Next!=null && tmp->Next!=root) tmp=tmp->Next;
			tmp->UpDown=node;
			tmp->UpDown->UpDown=tmp;
			tmp->Next=root;
		}
		count++;
	}
	// Add a node to where the list's circyle is began as Next element of list
	void AddUpDown(Node<T>* node){
		if(root==null)
		{
			root=node;
			root->IsRoot=true;
			root->Next=root;
		}
		else{
			Node<T>* tmp=root;
			while(tmp->Next!=null && tmp->Next!=root) tmp=tmp->Next;
			node->IsRoot=false;
			tmp->UpDown=node;
			tmp->UpDown->UpDown=tmp;
			tmp->Next=root;
		}
		count++;
	}
	// Add a whole new list to where the list's circyle is began as Next element of list
	void AddUpDown(List<T>* list){
		AddUpDown(list->root);
		count--;
		count+=list->getCount();
	}
	
	/*
	 *
	 * SUNDRIES REGION
	 *
	 */
	
	// dispose interface for the disposing the list's objects
	void Dispose(){
		Node<T>* tmp=root,*garb=null;
		for(int i=0;i<count && !(i!=0 && tmp==root) && tmp!=null;i++){
			if(tmp->UpDown!=null){
				DisposeUpDown(tmp->UpDown,tmp);
			}
			garb=tmp;
			tmp=tmp->Next;
			delete garb, garb->UpDown;
		}
		root=null;
		count=0;
	}

	// get root element
	Node<T>* getRoot(){return root;}
	// get the count of the list's objects
	int getCount(){return count;}
	// print the list's objects
	void Print(){
		if(count==0)cout<<"List\'s empty."<<endl;
		Node<T>* tmp=root;
		for(int i=0;i<count && !(i!=0 && tmp==root) && tmp!=null;i++, tmp=tmp->Next){
			if(tmp->Value!=char(0))
				cout<<tmp->Value;
			else if(tmp==root)
				cout<<"(";
			if(tmp->UpDown!=null){
				PrintUpDown(tmp->UpDown,tmp);
			}
		}
		if(root->Value==char(0))cout<<")";
	}

private:
	// internal print for the elements of the list which contains updown Link
	void PrintUpDown(Node<T>* node,Node<T>* root){
		if(node->UpDown!=null && node->UpDown!=root){
			PrintUpDown(node->UpDown,node);
		}else{
			if(node->Value!=char(0))
				cout<<node->Value;
			else cout<<"(";
		}
		if(node->Next!=null && node->Next!=root->UpDown)
			PrintUpDown(node->Next, root);
		else
			cout<<")";
		
	}

	// internal disposal for the elements of the list which contains updown Link
	void DisposeUpDown(Node<T>* node,Node<T>* root){
		if(node->UpDown!=null && node->UpDown!=root)
			DisposeUpDown(node->UpDown,node);
			
		if(node->Next!=null && node->Next!=root->UpDown)
			DisposeUpDown(node->Next, root);

		delete node;
	}
};
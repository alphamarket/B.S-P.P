#pragma once

namespace Link{
	// simple implementation of list class, just enough to use in stack class!
	template<class T> class List{
		Node<T>* root,*top;
		int count;
	public:
		// ctor of class
		List(void){
			root=null;
			count=0;
		}
		// add an element to the end of the list
		void AddFront(Node<T>* node)
		{
			if(root==null)
			{
				root=node;
				root->IsRoot=true;
				top=root;
			}
			else{
				Node<T>* tmp=root;
				while(tmp->Next!=null) tmp=tmp->Next;
				node->IsRoot=false;
				tmp->Next=node;
				top=node;
			}
			count++;
		}
		// remove an element from end of the list
		Node<T>* RemoveFront(){
			if(root==null || count<=0)
				throw new std::exception("List is empty");
			Node<T>* tmp=root,*deleted=null;
			if(count==1)
			{
				deleted=new Node<T>(root);
				root=null;
				top=null;
			}
			else if(count==2)
			{
				deleted=new Node<T>(root->Next);
				root->Next=null;
				top=root;
			}
			else{
				while(tmp!=null && tmp->Next->Next!=null) tmp=tmp->Next;
				deleted = new Node<T>(tmp->Next);
				tmp->Next=null;
				top=tmp;
			}
			count--;
			return deleted;
		}
		// get count of list's object
		int getCount(){return count;}
		// get top element of list
		Node<T>* getTop(){return top;}
		// get the list's root element
		Node<T>* getRoot(){return root;}
	};
}
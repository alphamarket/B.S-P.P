#pragma once
template<class T> class Node
{
public:
	T Value;
	Node* Next;
	Node* UpDown;
	bool IsRoot;

	Node(void){
		Next=null;
		UpDown=null;
		IsRoot=false;
	}

	Node(T value, Node<T>* next=null, Node<T>* upDown=null)
	{
		this->Value=value;
		this->Next=next;
		this->UpDown=upDown;
		this->IsRoot=false;
	}

	Node(Node<T>* node)
	{
		IsRoot=node->IsRoot;
		Value=node->Value;
		Next=node->Next;
		UpDown=node->UpDown;
	}
};

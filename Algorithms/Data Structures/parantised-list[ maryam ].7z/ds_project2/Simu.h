#pragma once

template<class T>class Simu{
public:
	List<T>* Parent;
	List<T>* Child;
	Simu(void){}
	Simu(List<T>* parent,List<T>* child){
		Parent=parent;
		Child=child;
	}
};
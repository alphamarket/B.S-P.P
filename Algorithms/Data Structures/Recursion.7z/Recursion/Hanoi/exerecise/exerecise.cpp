// exerecise.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "fstream"
#include "string"
display myDisplay;
disks myDisks;
pegs myPegs;
movement myMovement;
menu myMenu;
circumstance myCircumstance;
int Interface(int);
int menuInterFace();

int _tmain(int argc, _TCHAR* argv[])//user enterface
{
	_Time time1;
	time1.calculate_E_TF();
	system("color 0B");
	bool continuance=true;
	do{
		int N=menuInterFace();
		if(N==-1)break;
		else{
			_Time time2;
			myDisks.firstShowInitializing(N);
			time2.calculate_E_TF();
			do{
				COORD x;
				HANDLE hndl;
				x.X=48;
				x.Y=20;
				hndl=GetStdHandle(STD_OUTPUT_HANDLE);
				SetConsoleCursorPosition(hndl,x);
				cout<<"Maximum move allowed : "<<myCircumstance.getMaximumMoves()<<endl;
				x.X=48;
				x.Y=21;
				hndl=GetStdHandle(STD_OUTPUT_HANDLE);
				SetConsoleCursorPosition(hndl,x);
				cout<<"Your total move till now : "<<myMovement.getMovementCounter()<<endl;
				continuance=true;
				cout<<"MOVE A DISK FROM PEG\t";
				char now,destiny;
				cin>>now;
				cin.ignore();
				cout<<"To PEG\t\t";
				cin>>destiny;
				cin.ignore();
				myMovement.POSITIONS(now,destiny);
				myDisplay.frontYardDisplay();
				for(int j=N-1;j>=0;j--){
					if(!(myDisks.isThereADisk(2,j)) && myCircumstance.getMaximumMoves()>
						myMovement.getMovementCounter())
						break;
				if (myDisks.isThereADisk(2,0)){
					x.X=0;
					x.Y=20;
					hndl=GetStdHandle(STD_OUTPUT_HANDLE);
					SetConsoleCursorPosition(hndl,x);
					_getch();
					myMenu.winMenu();
					cout<<"\n\n\nyour total move is : "<<myMovement.getMovementCounter()<<" ."<<endl
						<<"\n\nthe minimum move is : "<<pow(2.,N)-1<<" ."<<endl<<endl<<endl
						<<"Elapsed time   ";
					time2.display_time();
					_getch();
					system("color 0B");
					int move=myMovement.getMovementCounter();
					//lastPalyers(&move,&N);
					continuance=false;
					break;
				}else if(!(myCircumstance.getMaximumMoves()>myMovement.getMovementCounter())){
					x.X=0;
					x.Y=27;
					hndl=GetStdHandle(STD_OUTPUT_HANDLE);
					SetConsoleCursorPosition(hndl,x);
					_getch();
					myMenu.loseMenu();
					cout<<"Elapsed Time   ";
					time2.display_time();
					_getch();
					continuance=false;
					break;
				}
				}
			}while(continuance);
			system("color 0B");
		}
	}while(true);
	system("cls");
	COORD x;
	HANDLE hndl;
	x.X=8;
	x.Y=10;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,x);
	cout<<"Total time that you have worked with this game is : ";
	time1.display_time();
	_getch();
	return 0;
	}
int Interface(int N){
	bool continuance=true;
	char choose;
	do{
		continuance=true;
		myMenu.manualP();
		cin>>choose;
		cin.ignore();
		switch (choose){
			case '1':
				myCircumstance.setCircumstance_EASY(N);
				choose='0';
				break;
			case '2':
				myCircumstance.setCircumstance_MEDIUM(N);
				choose='0';
				break;
			case '3':
				myCircumstance.setCircumstance_HARD(N);
				choose='0';
				break;
			case '4':
				myMovement.resetCounter();
				myDisks.reset();
				return -1;
		}
		system("cls");
	}while(choose!='0');
	return 0;
}
int menuInterFace(){
	COORD coordinate;
	HANDLE hndl;
	bool continuance=true;
	int numberOfDisks;
	char choose;
	do{
		system("cls");
		myMenu.mainMenu();
		cin>>choose;
		cin.ignore();
		switch ((int)choose){
			case '1':
				myMovement.resetCounter();
				myDisks.reset();
				system("cls");
				//myMenu.emptyMenu();
				coordinate.X=0;
				coordinate.Y=10;
				hndl=GetStdHandle(STD_OUTPUT_HANDLE);
				SetConsoleCursorPosition(hndl,coordinate);
				cout<<"Enter number of disks:\t\t";
				cin>>numberOfDisks;
				cin.ignore();
				if(numberOfDisks<=10 && numberOfDisks>0){
					if(Interface(numberOfDisks)==-1)
						continue;
					return numberOfDisks;
				}else{
					cout<<"\n\n\nNumber of disks have been limitted upto 10."<<endl
						<<"\n\nand also it should be more than zero.\n\n\n\n\n\n\n\n\n"<<endl;
					_getch();
				}
				break;
			case '2':
				{myMovement.resetCounter();
				myDisks.reset();
				_Time time3;
				system("cls");
				//myMenu.emptyMenu();
				coordinate.X=0;
				coordinate.Y=10;
				hndl=GetStdHandle(STD_OUTPUT_HANDLE);
				SetConsoleCursorPosition(hndl,coordinate);
				cout<<"Enter disk number :\t\t";
				cin>>numberOfDisks;
				cin.ignore();
				if(numberOfDisks>0 && numberOfDisks<11){
					HanoiSolver myHanoi;
					time3.calculate_E_TF();
					myDisks.firstShowInitializing(numberOfDisks);
					myHanoi.Solver((int)numberOfDisks,'A','C','B');
					coordinate.X=29;
					coordinate.Y=22;
					hndl=GetStdHandle(STD_OUTPUT_HANDLE);
					SetConsoleCursorPosition(hndl,coordinate);
					cout<<"Game is done!"<<endl;
					coordinate.X=15;
					coordinate.Y=23;
					hndl=GetStdHandle(STD_OUTPUT_HANDLE);
					SetConsoleCursorPosition(hndl,coordinate);
					cout<<"Elapsed time   ";
					coordinate.X=45;
					coordinate.Y=23;
					hndl=GetStdHandle(STD_OUTPUT_HANDLE);
					SetConsoleCursorPosition(hndl,coordinate);
					time3.display_time();
				}else{
					cout<<"\n\n\nNumber of disks have been limitted upto 10."<<endl
						<<"\n\nand also it should be more than zero.\n\n\n\n\n\n\n\n\n"<<endl;
				}
				_getch();
				system("cls");}
				break;
			case '3':
				system("cls");
				myMenu.help();
				_getch();
				system("cls");
				break;
			case '4':
				return -1;
		}
		system("cls");
	}while(continuance);
	return numberOfDisks;
}
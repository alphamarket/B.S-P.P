#pragma once

class circumstance
{
	int _MAXIMUM_MOVES;
public:
	circumstance(void){_MAXIMUM_MOVES=0;}
	~circumstance(void);
	void setCircumstance_EASY(int N){_MAXIMUM_MOVES=(int)pow(2.,N)+5*N;}
	void setCircumstance_MEDIUM(int N){	_MAXIMUM_MOVES=(int)pow(2.,N)+3*N;}
	void setCircumstance_HARD(int N){_MAXIMUM_MOVES=(int)pow(2.,N)+N;}
	int circumstance::getMaximumMoves(){return _MAXIMUM_MOVES;}

};
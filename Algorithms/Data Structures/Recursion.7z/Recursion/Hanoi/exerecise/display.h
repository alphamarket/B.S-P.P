#pragma once
class display
{
	void displayPegA();
	void displayPegB();
	void displayPegC();
public:
	display(void);
	~display(void);
	void frontYardDisplay();
};

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"
#include <iostream>
#include<iomanip>
#include "disks.h"
#include "windows.h"
#include "display.h"
#include "pegs.h"
#include "movement.h"
#include "menu.h"
using namespace std;
#include <time.h>
#include <ctime>
#include "HanoiSolver.h"
#include "conio.h"
#include <stdio.h>
#include <tchar.h>
#include "math.h"
#include "_Time.h"
#include "circumstance.h"
//using namespace dariush;





// TODO: reference additional headers your program requires here

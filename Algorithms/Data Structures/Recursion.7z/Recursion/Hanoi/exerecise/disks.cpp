#include "StdAfx.h"
#include "disks.h"

disks::disks(void)//initializing disk amount and their status on the first
{
	for(int j=0;j<10;j++){
		for(int i=0;i<3;i++){
			diskValidate[i][j]=false;
			disk[i][j]=0;
		}
	}
	tempDiskValue=0;
}
disks::~disks(void)
{
}
void disks::reset(){
	for(int j=0;j<10;j++){
		for(int i=0;i<3;i++){
			diskValidate[i][j]=false;
			disk[i][j]=0;
		}
	}
	tempDiskValue=0;
}
void disks::firstShowInitializing(int N){//first showing the pegs and disk for first time and initializing the value of disk
	extern display myDisplay;
	for(int i=0,j=N;i<=N-1;i++,j--){
		createDisk(0,i,2*j-1);
	}
	myDisplay.frontYardDisplay();//display status of bars and disks which user desire
}
void disks::createDisk(int i, int j, int diskAmount){//set a position on a peg as there is a disk with specific size as we create a disk
	if(!isThereADisk(i,j)){
		diskValidate[i][j]=true;
		disk[i][j]=diskAmount;
	}
}
void disks::deleteDisk(int i, int j){//set a disk on a position as there is no disk (it seem we delete it)
	if(isThereADisk(i,j)){
		diskValidate[i][j]=false;
		disk[i][j]=0;
	}
}





#include "StdAfx.h"
#include "menu.h"

menu::menu(void)
{
}

menu::~menu(void)
{
}
void menu::mainMenu(){ 
	cout<<left<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl
		<<char(752)<<setw(77)<<" "<<char(752)<<endl						
		<<char(752)<<setw(77)<<"                     Towers of Hanoi version 1.1.02"<<char(752)<<endl						
		<<char(752)<<setw(77)<<" "<<char(752)<<endl						
		<<char(752)<<"*****************************************************************************"<<char(752)<<endl	
		<<char(752)<<setw(77)<<" "<<char(752)<<endl	
		<<char(752)<<setw(77)<<"               1)Want to play game."<<char(752)<<endl
		<<char(752)<<setw(77)<<" "<<char(752)<<endl	
		<<char(752)<<setw(77)<<"               2)Want Machine to play game."<<char(752)<<endl	
		<<char(752)<<setw(77)<<" "<<char(752)<<endl	
		<<char(752)<<setw(77)<<"               3)Learn more about game."<<char(752)<<endl											
		<<char(752)<<setw(77)<<" "<<char(752)<<endl							
		<<char(752)<<setw(77)<<"               4)Quit."<<char(752)<<endl						
		<<char(752)<<setw(77)<<" "<<char(752)<<endl										
		<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl;
}
void menu::manualP(){
	system("cls");
		cout<<left<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<"                     Towers of Hanoi version 1.1.02"<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl	
			<<char(752)<<setw(77)<<"   1)I want to play in easy circumstance."<<char(752)<<endl
			<<char(752)<<setw(77)<<" "<<char(752)<<endl	
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl	
			<<char(752)<<setw(77)<<"   2)I want to play in medium circumstance."<<char(752)<<endl	
			<<char(752)<<setw(77)<<" "<<char(752)<<endl	
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl	
			<<char(752)<<setw(77)<<"   3)I want to play in hard circumstance."<<char(752)<<endl											
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<"   4)Back to main menu"<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl						
			<<char(752)<<setw(77)<<" "<<char(752)<<endl
			<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl;
}
void menu::help(){
	cout<<left<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl
		<<setw(77)<<" "<<char(752)<<endl						
		<<setw(77)<<"                     Towers of Hanoi version 1.1.02"<<char(752)<<endl						
		<<setw(77)<<" "<<char(752)<<endl						
		<<setw(77)<<"*****************************************************************************"<<char(752)<<endl						
		<<setw(77)<<" "<<char(752)<<endl				
		<<setw(77)<<"The Towers of Hanoi is one of the most famous classic problems every budding"<<char(752)<<endl
		<<setw(77)<<"computer scientist must grapple with. Legend has it that in a temple in the"<<char(752)<<endl
		<<setw(77)<<"Far East, priests are attempting to move a stack of golden disks from one"<<char(752)<<endl
		<<setw(77)<<"diamond peg to another . The initial stack has 64 disks threaded onto one peg"<<char(752)<<endl
		<<setw(77)<<"and arranged from bottom to top by decreasing size. The priests are "<<char(752)<<endl
		<<setw(77)<<"attempting to move the stack from one peg to another under the constraints"<<char(752)<<endl
		<<setw(77)<<"that exactly one disk is moved at a time and at no time may a larger disk "<<char(752)<<endl
		<<setw(77)<<"be placed above a smaller disk. Three pegs are provided, one being used for"<<char(752)<<endl
		<<setw(77)<<"temporarily holding disks. Supposedly, the world will end when the priests"<<char(752)<<endl
		<<setw(77)<<"complete their task"<<char(752)<<endl
		<<setw(77)<<"                              GOOD LUCK"<<char(752)<<endl						
		<<setw(77)<<" "<<char(752)<<endl				
		<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl;
}
void menu::winMenu(){
	system("cls");
	system("color 1F");
	COORD coordinate;
	HANDLE hndl;
	coordinate.X=0;
	coordinate.Y=5;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"*         *   *     *     *       * * *     * * *     * * *"<<endl
		<<"*         *   *     *     *     *       *     **        *"<<endl
		<<"*         *   *     *     *    *         *    * *       *"<<endl
		<<"*         *   *     *     *    *         *    *  *      *"<<endl
		<<"*         *   *     *     *    *         *    *   *     *"<<endl
 		<<"*         *   *     *     *    *         *    *    *    *"<<endl
		<<"*         *   *     *     *    *         *    *     *   *"<<endl
		<<"*         *   *     *     *    *         *    *      *  *"<<endl
		<<"*         *   *     *     *    *         *    *       * *"<<endl
		<<"  *     *       *   *   *       *       *     *        **"<<endl
		<<"    * *           *   *           * * *     * * *     * * *"<<endl;
}
void menu::loseMenu(){
	system("cls");
	system("color 1F");
	COORD coordinate;
	HANDLE hndl;
	coordinate.X=0;
	coordinate.Y=5;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"*         *   *               * * *            * * *   * * * * * * *"<<endl
		<<"*         *   *             *       *        *               *"<<endl
		<<"*         *   *            *         *      *                *"<<endl
		<<"*         *   *            *         *      *                *"<<endl
		<<"*         *   *            *         *       *               *"<<endl
		<<"*         *   *            *         *         *             *"<<endl
 		<<"*         *   *            *         *           *           *"<<endl
		<<"*         *   *            *         *             *         *"<<endl
 		<<"*         *   *            *         *              *        *"<<endl
		<<"  *     *     *             *       *               *        *"<<endl
		<<"    * *       * * * * * *     * * *           * * *        * * * "<<endl
		<<"\n\n\n\nBecause of your tatol moves became bigger than maximum allowed movement\n\n"
		<<"you become loser, try some other time.\n\n\n\n"<<endl;
}
void menu::emptyMenu(){
	
	cout<<left<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl
		<<setw(77)<<" "<<char(752)<<endl						
		<<setw(77)<<"                        Towers of Hanoi version 1.1.2"<<char(752)<<endl						
		<<setw(77)<<" "<<char(752)<<endl						
		<<"*****************************************************************************"<<char(752)<<endl	
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl	
		<<setw(77)<<"   "<<char(752)<<endl	
		<<setw(77)<<"   "<<char(752)<<endl	
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl	
		<<setw(77)<<"   "<<char(752)<<endl											
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl						
		<<setw(77)<<"   "<<char(752)<<endl				
		<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<char(752)<<endl;
}
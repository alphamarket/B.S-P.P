#pragma once
class pegs
{
	int pegNumber;
public:
	pegs(void);
	~pegs(void);
	void matterOfPegA(int);
	void matterOfPegB(int);
	void matterOfPegC(int);
	void setPegNumber(int);
	int getPegNumber();
};


#include "StdAfx.h"
#include "display.h"
//#define _H_SECOND 500
//#include "time.h"
display::display(void)
{
}

display::~display(void)
{
}

void display::frontYardDisplay(){//show final picture of bars status
	system("cls");
	extern menu myMenu;
	//myMenu.emptyMenu();
	COORD coordinate;
	HANDLE hndl;
	coordinate.X=2;
	coordinate.Y=17;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"=========A=========";
	coordinate.X=27;
	coordinate.Y=17;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"=========B=========";
	coordinate.X=52;
	coordinate.Y=17;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"=========C=========";
	displayPegA();
	displayPegB();
	displayPegC();//from this point forward anything which print out is matter of base of pegs
	coordinate.X=52;
	coordinate.Y=16;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<endl;
}
void display::displayPegA(){//desine pegA with its disks
	extern disks myDisks;
	for(int j=0,y=16;j<=9;j++,y--){
		COORD coordinate;
		HANDLE hndl;
		coordinate.X=11;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		cout<<"|";
		coordinate.X=00;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		if(myDisks.isThereADisk(0,j)){//looking for if there is a disk on this position for purpose of printing it
			int diskAmount=myDisks.getDiskAmount(0,j);//get amount of current disk
			
			for(int y=10-(diskAmount-1)/2;y>=0;y--)
				cout<<" ";
			for(;diskAmount>0;diskAmount--)
				cout<<"*";
		}
	}
}
void display::displayPegB(){//desine pegB with its disks
	extern disks myDisks;
	for(int j=0,y=16;j<=9;j++,y--){
		COORD coordinate;
		HANDLE hndl;
		coordinate.X=36;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		cout<<"|";
		coordinate.X=25;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		if(myDisks.isThereADisk(1,j)){//looking for if there is a disk on this position for purpose of printing it
			int diskAmount=myDisks.getDiskAmount(1,j);//get amount of current disk
			
			for(int y=10-(diskAmount-1)/2;y>=0;y--)
				cout<<" ";
			for(;diskAmount>0;diskAmount--)
				cout<<"*";
		}
	}
}
void display::displayPegC(){//desine pegC with its disks
	extern disks myDisks;
	for(int j=0,y=16;j<=9;j++,y--){
		COORD coordinate;
		HANDLE hndl;
		coordinate.X=61;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		cout<<"|";
		coordinate.X=50;
		coordinate.Y=y;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordinate);
		if(myDisks.isThereADisk(2,j)){//looking for if there is a disk on this position for purpose of printing it
			int diskAmount=myDisks.getDiskAmount(2,j);//get amount of current disk
			
			for(int y=10-(diskAmount-1)/2;y>=0;y--)
				cout<<" ";
			for(;diskAmount>0;diskAmount--)
				cout<<"*";
		}
	}
}

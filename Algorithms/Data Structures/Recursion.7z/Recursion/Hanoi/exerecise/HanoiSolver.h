#pragma once

class HanoiSolver
{
public:
	HanoiSolver(void);
	~HanoiSolver(void);
	void Solver(int,char,char,char);
};

#include "StdAfx.h"
#include "circumstance.h"


circumstance::~circumstance(void)
{
}

#pragma once

class _Time
{
	int _HOUR,_MINUTE,_SECOND;
	unsigned long _ELA_T;
	unsigned long long F_T,S_T;
	void cal_second(){_SECOND=(_ELA_T%60);}
	void cal_minute(){_MINUTE=(int)((_ELA_T/60)%60);}
	void cal_hour(){_HOUR=(int)(_ELA_T/3600);}
	void calculate_E_TS(){S_T=time(NULL);}
public:
	_Time(void);
	~_Time(void);
	void calculate_E_TF(){F_T=time(NULL);}
	void display_time();

};

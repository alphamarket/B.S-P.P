#pragma once

class disks
{
	bool diskValidate[3][10];
	int disk[3][10], tempDiskValue,rowNumber;	
public:
	disks(void);
	~disks(void);
	void reset();
	void firstShowInitializing(int);
	int getDiskAmount(int i,int j){return disk[i][j];}
	void createDisk(int,int,int);
	void deleteDisk(int,int);
	bool isThereADisk(int i,int j){return diskValidate[i][j];}
	void setRowNumber(int row){rowNumber=row;}
	int getRowNumber(){return rowNumber;}
	int getTempDiskValue(){return tempDiskValue;}
	void setTempDiskValue(int tempDiskValue){this->tempDiskValue=tempDiskValue;}

};

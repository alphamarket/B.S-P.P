﻿using System;
using System.Windows.Forms;
namespace Recursion
{
    enum Operation { Sum, Minus, Division, Fibonacci, Factorial, Power, Multiply, Greatest_Common_Divisor }
    internal partial class Operating : Form
    {
        static Operation opr;
        /// <summary>
        /// An interface Function!
        /// </summary>
        /// <param name="_Operator">kind of Operating demanded!</param>
        public static void ShowForm(Operation _Operator)
        {
            opr = _Operator;
            Operating obj = new Operating();
            obj.Show();
        }
        /// <summary>
        /// ctor!
        /// </summary>
        private Operating()
        {
            InitializeComponent();
            if (opr == Operation.Fibonacci || opr == Operation.Factorial)
            {
                label1.Text = "Enter the number :";
                label2.Visible = false;
                textBox2.Visible = false;
            }
            Text = opr.ToString().Replace("_", " ");
        }

        /// <summary>
        /// textBoxes event raiser!
        /// </summary>
        /// <param name="sender">Get Btn</param>
        /// <param name="e">raised KeyDownEvent</param>
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    txt.Text = Math.Abs(long.Parse(txt.Text.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries)[0])).ToString();
                    foreach (Control i in this.Controls)
                        if (i is TextBox && i != txt)
                            if (i.Text == "" && opr != Operation.Fibonacci && opr != Operation.Factorial)
                                i.Focus();
                            else
                                button1_Click(sender, e);
                }
            }
            catch (FormatException)
            {
                txt.Text = "";
            }
            catch (IndexOutOfRangeException)
            {
            }
        }
        /// <summary>
        /// GetBtn Event Raiser Function!
        /// </summary>
        /// <param name="sender">GetBtn object</param>
        /// <param name="e">raised event!</param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Result.Text = "The " + Text + " of the " + textBox1.Text + " and " + textBox2.Text + " is " +
                    GetResult(Convert.ToInt64(textBox1.Text), Convert.ToInt64(opr == Operation.Fibonacci || opr == Operation.Factorial ? "0" : textBox2.Text));
            }
            catch (StackOverflowException)
            {
                MessageBox.Show("Stack overflowed!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (NotImplementedException er)
            {
                MessageBox.Show(er.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception err)
            {
                Processor_Manager.Logs.LogError(err);
            }
            finally
            {
                foreach (Control i in Controls)
                {
                    if (i is TextBox)
                        i.Text = "";
                }
                textBox1.Focus();
            }
        }
        /// <summary>
        /// Function that handle kinds of demanded oprating!
        /// </summary>
        /// <param name="p">textBox1 Value!</param>
        /// <param name="p_2">textBox2 Value!</param>
        /// <returns>produced result!</returns>
        private long GetResult(long p, long p_2)
        {
            switch (opr)
            {
                case Operation.Sum:
                    return GetSum(p, p_2);

                case Operation.Division:
                    return GetDivision(p, p_2);

                case Operation.Minus:
                    return GetMinus(p, p_2);

                case Operation.Fibonacci:
                    return GetFibonacci(p);

                case Operation.Factorial:
                    return GetFactorial(p);

                case Operation.Power:
                    return GetPower(p, p_2);

                case Operation.Greatest_Common_Divisor:
                    return GetGcd(p > p_2 ? p : p_2,
                        p_2 > p ? p : p_2);

                case Operation.Multiply:
                    if (p == 0 || p_2 == 0)
                        return 0;
                    return GetMultiply(p > p_2 ? p : p_2,
                        p_2 > p ? p : p_2);
            }
            return 0;
        }
        /// <summary>
        /// Function'i ke recursion'e amale zarb ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetMultiply(long p, long p_2)
        {
            if (p_2 <= 1)
                return p;
            return GetMultiply(p, p_2 - 1) + p;
        }
        /// <summary>
        /// Function'i ke recursion'e amale bozorgtarin mazrabe moshtak ro bar migardone! ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetGcd(long p, long p_2)
        {
            if (p_2 < 1)
                return p;
            return GetGcd(p_2, p % p_2);
        }
        /// <summary>
        /// Function'i ke recursion'e amale tavan resondan ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetPower(long p, long p_2)
        {
            if (p_2 == 1)
                return p;
            return GetPower(p, p_2 - 1) * p;
        }
        /// <summary>
        /// Function'i ke recursion'e amale mohasebeye factorial ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetFactorial(long p)
        {
            if (p == 1)
                return p;
            return p * GetFactorial(p - 1);
        }
        /// <summary>
        /// Function'i ke recursion'e amale mohasebeye fib ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetFibonacci(long p)
        {
            if (p <= 1)
                return p;
            return GetFibonacci(p - 1) + GetFibonacci(p - 2);
        }
        /// <summary>
        /// Function'i ke recursion'e amale menha ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetMinus(long p, long p_2)
        {
            if (p_2 == 0)
                return p;
            return GetMinus(p, p_2 - 1) - 1;
        }
        /// <summary>
        /// Function'i ke recursion'e amale tagsim ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        private long GetDivision(long p, long p_2)
        {
            if (p_2 > p)
                return 0;
            return GetDivision(p - p_2, p_2) + 1;
        }
        /// <summary>
        /// Function'i ke recursion'e amale jam ro anjam mide!
        /// </summary>
        /// <param name="p">Value of textBox1!</param>
        /// <param name="p_2">Value of textBox2</param>
        /// <returns>the result!</returns>
        long GetSum(long a, long b)
        {
            if (b == 0)
                return a;
            return GetSum(a, b - 1) + 1;
        }
        /// <summary>
        /// textBox2 event raiser!
        /// </summary>
        /// <param name="sender">an object of textBox2</param>
        /// <param name="e">raised event!</param>
        private void textBox2_Leave(object sender, EventArgs e)
        {
            textBox1_KeyDown(sender, new KeyEventArgs(Keys.Enter));
        }
    }
}

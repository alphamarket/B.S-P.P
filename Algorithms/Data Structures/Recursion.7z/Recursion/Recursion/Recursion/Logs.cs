﻿using System;
using System.Data;
using System.IO;
using System.Xml;
namespace Processor_Manager
{
    internal class Logs
    {
        /// <summary>
        /// In fuction mire va oun exceptioni ke behesh pas shode 2 ye file'i ' LOG ' mikone
        /// </summary>
        /// <param name="error">Exceptioni ke throw shode!!</param>
        internal static void LogError(Exception error)
        {
            DataSet ds = null;
            bool Created = false;

            if (!File.Exists("Exceptions.xml"))
            {
                Created = true;
                CreateErrorLogFile();
            }
            using (FileStream f = new FileStream("Exceptions.xml", FileMode.OpenOrCreate, FileAccess.Read, FileShare.None))
            {
                ds = new DataSet();
                ds.ReadXml(f);
                DataTable dt = ds.Tables["Error"];
                if (dt == null)
                {
                    dt = new DataTable("Error");
                    dt.Columns.Add("Message");
                    dt.Columns.Add("Source");
                    dt.Columns.Add("StackTrace");
                    dt.Columns.Add("Function_Name");
                    dt.Columns.Add("Log_Date");
                }
                if (Created)
                    dt.Rows.Remove(dt.Rows[0]);
                dt.Rows.Add(new object[] { error.Message, error.Source, error.StackTrace, error.TargetSite.Name, DateTime.Now });
            }
            ds.WriteXml("Exceptions.xml", XmlWriteMode.IgnoreSchema);
        }
        private static void CreateErrorLogFile()
        {
            using (XmlTextWriter r = new XmlTextWriter("Exceptions.xml", null))
            {
                r.WriteStartDocument(true);
                r.WriteStartElement("Errors");
                r.WriteStartElement("Error");
                r.WriteStartElement("Message");
                r.WriteEndElement();
                r.WriteStartElement("Source");
                r.WriteEndElement();
                r.WriteStartElement("Stack_Trace");
                r.WriteEndElement();
                r.WriteStartElement("Funtcion_Name");
                r.WriteEndElement();
                r.WriteStartElement("Log_Date");
                r.WriteFullEndElement();
                r.WriteEndDocument();
                r.Flush();
            }
        }
    }
}
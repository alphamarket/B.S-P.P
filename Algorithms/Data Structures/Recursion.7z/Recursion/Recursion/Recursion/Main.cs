﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Recursion
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        List<System.Diagnostics.Process> LaunchedProc = new List<System.Diagnostics.Process>();
        private void Launch_Puzzle_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                LaunchedProc.Add(System.Diagnostics.Process.Start("puzzle.exe"));
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Launch_Hanoi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                LaunchedProc.Add(System.Diagnostics.Process.Start("Hanoi.exe"));
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Launch_Sum_Op_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Recursion.Operation.Sum);
        }

        private void Launch_Div_Op_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Division);
        }

        private void Launch_Minus_Op_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Minus);
        }

        private void Launch_Fibonacci_Op_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Fibonacci);
        }

        private void Launch_Factorial_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Factorial);
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Power);
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Greatest_Common_Divisor);
        }

        private void Launch_Multiply_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Operating.ShowForm(Operation.Multiply);
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                foreach (System.Diagnostics.Process i in LaunchedProc)
                {
                    if (!i.HasExited)
                        i.Kill();
                }
            }
            catch (System.ComponentModel.Win32Exception er) { }
            catch (Exception er) { MessageBox.Show(er.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}

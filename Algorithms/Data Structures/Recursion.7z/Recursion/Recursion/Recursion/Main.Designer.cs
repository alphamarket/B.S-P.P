﻿namespace Recursion
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.Launch_Puzzle = new System.Windows.Forms.LinkLabel();
            this.Launch_Hanoi = new System.Windows.Forms.LinkLabel();
            this.Launch_Sum_Op = new System.Windows.Forms.LinkLabel();
            this.Launch_Div_Op = new System.Windows.Forms.LinkLabel();
            this.Launch_Minus_Op = new System.Windows.Forms.LinkLabel();
            this.Launch_Fibonacci_Op = new System.Windows.Forms.LinkLabel();
            this.Launch_Factorial = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.Launch_Multiply = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // Launch_Puzzle
            // 
            this.Launch_Puzzle.AutoSize = true;
            this.Launch_Puzzle.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Puzzle.Location = new System.Drawing.Point(15, 17);
            this.Launch_Puzzle.Name = "Launch_Puzzle";
            this.Launch_Puzzle.Size = new System.Drawing.Size(77, 13);
            this.Launch_Puzzle.TabIndex = 0;
            this.Launch_Puzzle.TabStop = true;
            this.Launch_Puzzle.Text = "Launch Puzzle";
            this.Launch_Puzzle.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Puzzle_LinkClicked);
            // 
            // Launch_Hanoi
            // 
            this.Launch_Hanoi.AutoSize = true;
            this.Launch_Hanoi.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Hanoi.Location = new System.Drawing.Point(12, 59);
            this.Launch_Hanoi.Name = "Launch_Hanoi";
            this.Launch_Hanoi.Size = new System.Drawing.Size(74, 13);
            this.Launch_Hanoi.TabIndex = 1;
            this.Launch_Hanoi.TabStop = true;
            this.Launch_Hanoi.Text = "Launch Hanoi";
            this.Launch_Hanoi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Hanoi_LinkClicked);
            // 
            // Launch_Sum_Op
            // 
            this.Launch_Sum_Op.AutoSize = true;
            this.Launch_Sum_Op.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Sum_Op.Location = new System.Drawing.Point(12, 100);
            this.Launch_Sum_Op.Name = "Launch_Sum_Op";
            this.Launch_Sum_Op.Size = new System.Drawing.Size(116, 13);
            this.Launch_Sum_Op.TabIndex = 2;
            this.Launch_Sum_Op.TabStop = true;
            this.Launch_Sum_Op.Text = "Launch Sum Operation";
            this.Launch_Sum_Op.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Sum_Op_LinkClicked);
            // 
            // Launch_Div_Op
            // 
            this.Launch_Div_Op.AutoSize = true;
            this.Launch_Div_Op.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Div_Op.Location = new System.Drawing.Point(278, 59);
            this.Launch_Div_Op.Name = "Launch_Div_Op";
            this.Launch_Div_Op.Size = new System.Drawing.Size(132, 13);
            this.Launch_Div_Op.TabIndex = 3;
            this.Launch_Div_Op.TabStop = true;
            this.Launch_Div_Op.Text = "Launch Division Operation";
            this.Launch_Div_Op.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Div_Op_LinkClicked);
            // 
            // Launch_Minus_Op
            // 
            this.Launch_Minus_Op.AutoSize = true;
            this.Launch_Minus_Op.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Minus_Op.Location = new System.Drawing.Point(12, 145);
            this.Launch_Minus_Op.Name = "Launch_Minus_Op";
            this.Launch_Minus_Op.Size = new System.Drawing.Size(123, 13);
            this.Launch_Minus_Op.TabIndex = 4;
            this.Launch_Minus_Op.TabStop = true;
            this.Launch_Minus_Op.Text = "Launch Minus Operation";
            this.Launch_Minus_Op.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Minus_Op_LinkClicked);
            // 
            // Launch_Fibonacci_Op
            // 
            this.Launch_Fibonacci_Op.AutoSize = true;
            this.Launch_Fibonacci_Op.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Fibonacci_Op.Location = new System.Drawing.Point(278, 145);
            this.Launch_Fibonacci_Op.Name = "Launch_Fibonacci_Op";
            this.Launch_Fibonacci_Op.Size = new System.Drawing.Size(141, 13);
            this.Launch_Fibonacci_Op.TabIndex = 5;
            this.Launch_Fibonacci_Op.TabStop = true;
            this.Launch_Fibonacci_Op.Text = "Launch Fibonacci Operation";
            this.Launch_Fibonacci_Op.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Fibonacci_Op_LinkClicked);
            // 
            // Launch_Factorial
            // 
            this.Launch_Factorial.AutoSize = true;
            this.Launch_Factorial.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Factorial.Location = new System.Drawing.Point(278, 17);
            this.Launch_Factorial.Name = "Launch_Factorial";
            this.Launch_Factorial.Size = new System.Drawing.Size(135, 13);
            this.Launch_Factorial.TabIndex = 6;
            this.Launch_Factorial.TabStop = true;
            this.Launch_Factorial.Text = "Launch Factorial Operation";
            this.Launch_Factorial.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Factorial_LinkClicked);
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel8.Location = new System.Drawing.Point(278, 100);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(125, 13);
            this.linkLabel8.TabIndex = 7;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "Launch Power Operation";
            this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel9.Location = new System.Drawing.Point(278, 189);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(165, 13);
            this.linkLabel9.TabIndex = 8;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "Launch Greatest Common Divisor";
            this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
            // 
            // Launch_Multiply
            // 
            this.Launch_Multiply.AutoSize = true;
            this.Launch_Multiply.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Launch_Multiply.Location = new System.Drawing.Point(15, 189);
            this.Launch_Multiply.Name = "Launch_Multiply";
            this.Launch_Multiply.Size = new System.Drawing.Size(130, 13);
            this.Launch_Multiply.TabIndex = 9;
            this.Launch_Multiply.TabStop = true;
            this.Launch_Multiply.Text = "Launch Multiply Operation";
            this.Launch_Multiply.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Launch_Multiply_LinkClicked);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 218);
            this.Controls.Add(this.Launch_Multiply);
            this.Controls.Add(this.linkLabel9);
            this.Controls.Add(this.linkLabel8);
            this.Controls.Add(this.Launch_Factorial);
            this.Controls.Add(this.Launch_Fibonacci_Op);
            this.Controls.Add(this.Launch_Minus_Op);
            this.Controls.Add(this.Launch_Div_Op);
            this.Controls.Add(this.Launch_Sum_Op);
            this.Controls.Add(this.Launch_Hanoi);
            this.Controls.Add(this.Launch_Puzzle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recursion Panel";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel Launch_Puzzle;
        private System.Windows.Forms.LinkLabel Launch_Hanoi;
        private System.Windows.Forms.LinkLabel Launch_Sum_Op;
        private System.Windows.Forms.LinkLabel Launch_Div_Op;
        private System.Windows.Forms.LinkLabel Launch_Minus_Op;
        private System.Windows.Forms.LinkLabel Launch_Fibonacci_Op;
        private System.Windows.Forms.LinkLabel Launch_Factorial;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.LinkLabel Launch_Multiply;
    }
}


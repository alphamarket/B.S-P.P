#include "StdAfx.h"
#include "initialization.h"
using namespace System::Windows::Forms;
initialization::initialization(int size){
	btn=gcnew array<int>(size);
	for(int i=0;i<size;i++)
		btn[i]=0;
	srand((firtsUseage?(int)time(NULL):rand()%INT_MAX));
	blank=rand()%(size-1);
	setBlankLocate(blank);
	for(int i=0;i<size;i++){
		if(i!=blank){
			while(true){
				bool checked=true;
				btn[i]=1+rand()%(size-1);
				for(int j=0;j<i;j++)
					if(btn[i]==btn[j])
						checked=false;
				if(checked)break;
			}
		}
	}
	firtsUseage=false;
}
void initialization::setBlankLocate(int locate){
	blank=locate;
	btn[locate]=0;
}
void initialization::setBtnValue(int locate, int value){
	btn[locate]=value;
}

void initialization::makeItSolvable(int size){
	int answer=0;
	for(int i=0;i<size;i++)
		for(int j=i+1;j<size;j++)
			if(btn[i]>btn[j])
				if(btn[j])
					answer++;
	if(answer%2){
		int k=btn[(blank==8)?blank-2:blank+1];
		btn[(blank==8)?blank-2:blank+1]=btn[(blank==0)?blank+2:blank-1];
		btn[(blank==0)?blank+2:blank-1]=k;
	}
}
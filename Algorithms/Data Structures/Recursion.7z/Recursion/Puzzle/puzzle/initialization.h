#pragma once
using System::Windows::Forms::Button;

ref class initialization
{
	int blank;
	array<int>^btn;
public:
	initialization(int);	
	int getBlankLocate(){return blank;}
	int getBtnValue(int locate){return btn[locate];}
	void setBtnValue(int locate,int value);
	void setBlankLocate(int locate);
	void makeItSolvable(int size);
	static bool firtsUseage;
};

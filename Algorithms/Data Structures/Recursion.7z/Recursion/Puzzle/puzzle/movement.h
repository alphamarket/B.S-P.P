#pragma once
#include "initialization.h"
using System::Windows::Forms::Button;
ref class movement
{
public:
	movement(void);
	void Swap(int clicked_locate,int target_locate,initialization^btni);
};

#pragma once
#include "initialization.h"
using System::Windows::Forms::Button;
ref class xRule
{
	bool Condition;
	int num;
protected:
	bool backwardByOne(int size,int clicked_locate);
	bool forSize(int size,int clicked_locate,initialization^btni,int caseN);
	bool forwardByOne(int size,int clicked_locate);
public:
	xRule(void);
	bool condition(){return Condition;}
	int getNum(){return num;}
	void rule(int clicked_locate,initialization^btni,int size);
};
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
#pragma once
#include "stdlib.h"
#include "ctime"
#include "display.h"
#include "movement.h"
#include "initialization.h"
#include "control.h"
#include "Rule.h"
#include "easyForm.h"
#include "hardForm.h"
using namespace std;
// TODO: reference additional headers your program requires here

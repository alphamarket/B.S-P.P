#include "StdAfx.h"
#include "control.h"

using namespace System::Windows::Forms;

control::control(initialization^btni,int size,Label^lab1,control^Xctrl){
	counter=0;
	checked=true;
	lab1->Visible::set(true);
	lab1->Text::set(Convert::ToString(Xctrl->getCounter())+" Moved block till now");
	if(checking(btni,size) && !save::isInAutoMode()){
		MessageBox::Show("You made it, You won the game"
			"\nWith total \" "+Convert::ToString(Xctrl->getCounter())+" \" move","Congratulations!!"
			,MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
	}
}
bool control::checking(initialization ^btni,int size){
	for(int i=0;i<size;i++){
		if(i!=btni->getBlankLocate())
			if(i!=(btni->getBtnValue(i))-1){
				checked=false;
				break;
			}
	}
	return checked;
}

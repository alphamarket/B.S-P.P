#pragma once

using namespace System;
using System::Exception;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace puzzle {

	/// <summary>
	/// Summary for Showhis
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Showhis : public System::Windows::Forms::Form
	{
	public:
		Showhis(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Showhis()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Showhis::typeid));
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->SuspendLayout();
			// 
			// richTextBox1
			// 
			this->richTextBox1->BackColor = System::Drawing::SystemColors::MenuBar;
			this->richTextBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->richTextBox1->Location = System::Drawing::Point(0, 0);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(577,373);
			this->richTextBox1->TabIndex = 0;
			this->richTextBox1->Text = L"";
			this->richTextBox1->Click += gcnew System::EventHandler(this, &Showhis::richTextBox1_Click);
			// 
			// Showhis
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(577, 400);
			this->Controls->Add(this->richTextBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"Showhis";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Your records";
			this->Load += gcnew System::EventHandler(this, &Showhis::Showhis_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
		static String^listPath="..\\Files\\users\\registry.xrec";
		static String^singlesPath="..\\Files\\saved\\";
private: System::Void Showhis_Load(System::Object^  sender, System::EventArgs^  e) {
				 save^saved=gcnew save;
				 richTextBox1->Clear();
				 try{
					 if(save::whichShow()=="USERS")
						 printLogIn(saved);
					 else if(save::whichShow()=="ALL")
						 printingAllInfo(saved);
					 else
						 printUserInfo(saved);
				 }catch(Exception^e){
					 if(e->Message::get()=="File"){
						 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
						 save::signOut();
						 this->Close();
					 }else if(e->Message::get()=="List"){
						 MessageBox::Show("The users list has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
						 if(Directory::Exists(singlesPath)){
							 Directory::Delete(singlesPath,true);
							 Directory::CreateDirectory(singlesPath);
						 }
						 if(Directory::Exists(listPath)){
							 Directory::Delete(listPath,true);
							 Directory::CreateDirectory(listPath);
						 }
						 save::signOut();
						 this->Close();
					 }else
						 MessageBox::Show("code 95/230.\n"+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
				 }
				 save::whichShow("");
			 }
private:void printingAllInfo(save^saved){
			this->Text = L"All users scores!";
			richTextBox1->Text+="\n";
			if(Directory::Exists("..\\Files\\users\\") && File::Exists(listPath)){
				StreamReader^read=File::OpenText(listPath);
				String^readed;
				while(readed=read->ReadLine()){
					bool isSaved=false;
					String^path=singlesPath+readed+"\\"+readed;
					if(Directory::Exists(singlesPath+readed)){
						if(File::Exists(path+".srec")&&File::Exists(path+".lrec") && File::Exists(path+".his")){
							richTextBox1->Text+="\t\t\t\t\t"+readed+"\n";
							richTextBox1->Text+="******************************************************************************************************************************************\n";
							StreamReader^useReader=File::OpenText(path+".srec");
							String^readedUseInfo;
							while(readedUseInfo=useReader->ReadLine()){
								richTextBox1->Text+=readedUseInfo;
								richTextBox1->Text+="\n";
								isSaved=true;
							}
							if(String::IsNullOrEmpty(readedUseInfo)&&!isSaved)
								richTextBox1->Text+="There is no saved information to show";
							richTextBox1->Text+="\n\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
							richTextBox1->Text+="----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
							useReader->Close();
						}else{
							read->Close();
							Directory::Delete(singlesPath+readed,true);
							if(readed==save::getUserID())
								throw gcnew Exception("File");
						}
					}else if(readed==save::getUserID()){
						read->Close();
						throw gcnew Exception("File");
					}
				}
				richTextBox1->Text+="\t\t\t\tTo exit click on this page.";
			}else
				throw gcnew Exception("List");
		}
private:void printUserInfo(save^saved){
			this->Text = L"Your scores";
			String^path=singlesPath+save::getUserID()+"\\"+save::getUserID();
			if(Directory::Exists("..\\Files\\users\\") && File::Exists(listPath)){
				if(Directory::Exists(singlesPath+save::getUserID())){
					if(File::Exists(path+".srec")&&File::Exists(path+".lrec")&&File::Exists(path+".his")){
						bool isSaved=false;
						richTextBox1->Text+="\t\t\t\t\t"+save::getUserID()+"\n";
						richTextBox1->Text+="******************************************************************************************************************************************\n";
						StreamReader^read=File::OpenText(path+".srec");
						String^readed;
						while((readed=read->ReadLine())){
							richTextBox1->Text+=readed;
							richTextBox1->Text+="\n";
							isSaved=true;
						}
						if(String::IsNullOrEmpty(readed)&&!isSaved)
							richTextBox1->Text+="There is no saved information to show\n";
						richTextBox1->Text+="******************************************************************************************************************************************\n";
						richTextBox1->Text+="\t\t\t\tTo exit click on this page.";
						read->Close();
					}else{
						Directory::Delete(singlesPath+save::getUserID(),true);
						throw gcnew Exception("File");
					}
				}else
					throw gcnew Exception("File");
			}else
				throw gcnew Exception("List");
		}
private:void printLogIn(save^saved){
			this->Text = L"All users historic information!";
			richTextBox1->Text+="\n";
			if(Directory::Exists("..\\Files\\users\\") && File::Exists(listPath)){
				StreamReader^listReader=File::OpenText(listPath);
				String^readed;
				while(readed=listReader->ReadLine()){
					bool isSaved=false;
					String^path=singlesPath+readed+"\\"+readed;
					if(Directory::Exists(singlesPath+readed)){
						if(File::Exists(path+".srec") && File::Exists(path+".lrec") && File::Exists(path+".his")){
							richTextBox1->Text+="\t\t\t\t\t"+readed+"\n";
							richTextBox1->Text+="******************************************************************************************************************************************\n";
							StreamReader^userReader=File::OpenText(path+".his");
							String^read;
							while(read=userReader->ReadLine()){
								richTextBox1->Text+=read;
								richTextBox1->Text+="\n";
								isSaved=true;
							}
							if(String::IsNullOrEmpty(read)&&!isSaved)
								richTextBox1->Text+="There is no saved information to show";
							richTextBox1->Text+="\n\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
							richTextBox1->Text+="----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n";
							userReader->Close();
						}else{
							listReader->Close();
							Directory::Delete(singlesPath+readed,true);
							if(readed==save::getUserID())
								throw gcnew Exception("File");
						}
					}else if(readed==save::getUserID()){
						listReader->Close();
						throw gcnew Exception("File");
					}
				}
				richTextBox1->Text+="\t\t\t\tTo exit click on this page.";
			}else
				throw gcnew Exception("List");
		}
private: System::Void richTextBox1_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close();
		 }
};
}

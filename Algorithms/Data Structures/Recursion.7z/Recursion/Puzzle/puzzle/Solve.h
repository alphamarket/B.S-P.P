#pragma once
using namespace System;
using System::Windows::Forms::Label;
#include "cmath"
#include <vcclr.h>
class Solve
{
	bool done,breakIt;
	int sizeOfPuzzle,depth;
	gcroot<String^>Stream,send;
	struct node{
		int data,count,pathScore;
		node*child[4];
		gcroot<String^> sended;
		bool done;
		gcroot<initialization^> object;
		node(){
			data=count=pathScore=0;
			for(int i=0;i<4;i++)
				child[i]=NULL;
			sended="";
			done=false;
			object=NULL;
		}
	}*list;
protected:
	bool backwardByOne(int);
	bool forwardByOne(int);
	bool canReturn(node*parent);
	bool check(initialization^,size_t);
	bool childSearch(node*parent);
	int search(initialization^, int i);
	void solving(node*parent);
	void setChildrenInOrder(node*parent);
	void setPosition(node*child,int=0);
	void makingChildren(node*);
	void _heuristic(node*);
	void recursionSaving(node*,int);
public:
	Solve(initialization^object,int);
	~Solve(void);
	bool isSolved(){return done;}
	bool shouldbreak(){return breakIt;}
};

///<summary>
///#About file type that have been used in this program:
///#.xrec===>keep track of Registered User Name.
///#.lrec===>keep track of The User Last Log In.
///#.srec===>keep track of Saved User Info Which Contain The Number Of Movement.
///#.his====>keep track of All User Log in Date Abd Time.
///</Summary>

#pragma once
#include "Solve.h"
#include"initialization.h"
#include"easyForm.h"
#include "hardForm.h"
#include "track.h"
#include "Showhis.h"
#include "UserID.h"
namespace puzzle {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  puzzleToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  hardToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  easyToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator3;
	private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  recordToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  showRecordsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  clearHistoryToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  deleteMyAccontToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  accontsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  showAllHistoriesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  viewAllAccontToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  creatANewAccontToolStripMenuItem;
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  statusLabel;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator4;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
	private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem1;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator5;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::Button^  myOptionsBtn;
	private: System::Windows::Forms::Button^  PlayPuzzleBtn;
	private: System::Windows::Forms::Panel^  panel1;
			 /// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->puzzleToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->hardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->easyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator3 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->recordToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->showRecordsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->clearHistoryToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator4 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator5 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->deleteMyAccontToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->accontsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->showAllHistoriesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewAllAccontToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->creatANewAccontToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->statusLabel = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->myOptionsBtn = (gcnew System::Windows::Forms::Button());
			this->PlayPuzzleBtn = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->menuStrip1->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->fileToolStripMenuItem, 
				this->recordToolStripMenuItem, this->accontsToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(424, 24);
			this->menuStrip1->TabIndex = 3;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->puzzleToolStripMenuItem, 
				this->toolStripSeparator3, this->exitToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(37, 20);
			this->fileToolStripMenuItem->Text = L"&File";
			// 
			// puzzleToolStripMenuItem
			// 
			this->puzzleToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->hardToolStripMenuItem, 
				this->easyToolStripMenuItem});
			this->puzzleToolStripMenuItem->Name = L"puzzleToolStripMenuItem";
			this->puzzleToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->puzzleToolStripMenuItem->Text = L"&Puzzle";
			// 
			// hardToolStripMenuItem
			// 
			this->hardToolStripMenuItem->Name = L"hardToolStripMenuItem";
			this->hardToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::D1));
			this->hardToolStripMenuItem->Size = System::Drawing::Size(136, 22);
			this->hardToolStripMenuItem->Text = L"&Hard";
			this->hardToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::hardToolStripMenuItem_Click);
			// 
			// easyToolStripMenuItem
			// 
			this->easyToolStripMenuItem->Name = L"easyToolStripMenuItem";
			this->easyToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::D2));
			this->easyToolStripMenuItem->Size = System::Drawing::Size(136, 22);
			this->easyToolStripMenuItem->Text = L"&Easy";
			this->easyToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::easyToolStripMenuItem_Click);
			// 
			// toolStripSeparator3
			// 
			this->toolStripSeparator3->Name = L"toolStripSeparator3";
			this->toolStripSeparator3->Size = System::Drawing::Size(131, 6);
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::F4));
			this->exitToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->exitToolStripMenuItem->Text = L"&Exit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
			// 
			// recordToolStripMenuItem
			// 
			this->recordToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->showRecordsToolStripMenuItem, 
				this->clearHistoryToolStripMenuItem, this->toolStripSeparator4, this->toolStripMenuItem1, this->toolStripSeparator5, this->deleteMyAccontToolStripMenuItem});
			this->recordToolStripMenuItem->Name = L"recordToolStripMenuItem";
			this->recordToolStripMenuItem->Size = System::Drawing::Size(90, 20);
			this->recordToolStripMenuItem->Text = L"&Your account";
			// 
			// showRecordsToolStripMenuItem
			// 
			this->showRecordsToolStripMenuItem->Name = L"showRecordsToolStripMenuItem";
			this->showRecordsToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>(((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::Shift) 
				| System::Windows::Forms::Keys::M));
			this->showRecordsToolStripMenuItem->Size = System::Drawing::Size(249, 22);
			this->showRecordsToolStripMenuItem->Text = L"&Show My Scores";
			this->showRecordsToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::showRecordsToolStripMenuItem_Click);
			// 
			// clearHistoryToolStripMenuItem
			// 
			this->clearHistoryToolStripMenuItem->Name = L"clearHistoryToolStripMenuItem";
			this->clearHistoryToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>(((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::Shift) 
				| System::Windows::Forms::Keys::Z));
			this->clearHistoryToolStripMenuItem->Size = System::Drawing::Size(249, 22);
			this->clearHistoryToolStripMenuItem->Text = L"&Clear My Scores";
			this->clearHistoryToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::clearHistoryToolStripMenuItem_Click);
			// 
			// toolStripSeparator4
			// 
			this->toolStripSeparator4->Name = L"toolStripSeparator4";
			this->toolStripSeparator4->Size = System::Drawing::Size(246, 6);
			// 
			// toolStripMenuItem1
			// 
			this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
			this->toolStripMenuItem1->ShortcutKeys = static_cast<System::Windows::Forms::Keys>(((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::Shift) 
				| System::Windows::Forms::Keys::S));
			this->toolStripMenuItem1->Size = System::Drawing::Size(249, 22);
			this->toolStripMenuItem1->Text = L"&Sign Out";
			this->toolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::toolStripMenuItem1_Click);
			// 
			// toolStripSeparator5
			// 
			this->toolStripSeparator5->Name = L"toolStripSeparator5";
			this->toolStripSeparator5->Size = System::Drawing::Size(246, 6);
			// 
			// deleteMyAccontToolStripMenuItem
			// 
			this->deleteMyAccontToolStripMenuItem->Name = L"deleteMyAccontToolStripMenuItem";
			this->deleteMyAccontToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>(((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::Shift) 
				| System::Windows::Forms::Keys::D));
			this->deleteMyAccontToolStripMenuItem->Size = System::Drawing::Size(249, 22);
			this->deleteMyAccontToolStripMenuItem->Text = L"&Delete My Account";
			this->deleteMyAccontToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::deleteMyAccontToolStripMenuItem_Click);
			// 
			// accontsToolStripMenuItem
			// 
			this->accontsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->showAllHistoriesToolStripMenuItem, 
				this->viewAllAccontToolStripMenuItem, this->toolStripSeparator2, this->creatANewAccontToolStripMenuItem});
			this->accontsToolStripMenuItem->Name = L"accontsToolStripMenuItem";
			this->accontsToolStripMenuItem->Size = System::Drawing::Size(69, 20);
			this->accontsToolStripMenuItem->Text = L"&Accounts";
			// 
			// showAllHistoriesToolStripMenuItem
			// 
			this->showAllHistoriesToolStripMenuItem->Name = L"showAllHistoriesToolStripMenuItem";
			this->showAllHistoriesToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::A));
			this->showAllHistoriesToolStripMenuItem->Size = System::Drawing::Size(228, 22);
			this->showAllHistoriesToolStripMenuItem->Text = L"&Show All Scores";
			this->showAllHistoriesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::showAllHistoriesToolStripMenuItem_Click);
			// 
			// viewAllAccontToolStripMenuItem
			// 
			this->viewAllAccontToolStripMenuItem->Name = L"viewAllAccontToolStripMenuItem";
			this->viewAllAccontToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>(((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::Shift) 
				| System::Windows::Forms::Keys::A));
			this->viewAllAccontToolStripMenuItem->Size = System::Drawing::Size(228, 22);
			this->viewAllAccontToolStripMenuItem->Text = L"&View Users info";
			this->viewAllAccontToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::viewAllAccontToolStripMenuItem_Click);
			// 
			// toolStripSeparator2
			// 
			this->toolStripSeparator2->Name = L"toolStripSeparator2";
			this->toolStripSeparator2->Size = System::Drawing::Size(225, 6);
			// 
			// creatANewAccontToolStripMenuItem
			// 
			this->creatANewAccontToolStripMenuItem->Name = L"creatANewAccontToolStripMenuItem";
			this->creatANewAccontToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::N));
			this->creatANewAccontToolStripMenuItem->Size = System::Drawing::Size(228, 22);
			this->creatANewAccontToolStripMenuItem->Text = L"&Creat a new account";
			this->creatANewAccontToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::creatANewAccontToolStripMenuItem_Click);
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->statusLabel});
			this->statusStrip1->Location = System::Drawing::Point(0, 132);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(424, 22);
			this->statusStrip1->SizingGrip = false;
			this->statusStrip1->TabIndex = 6;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// statusLabel
			// 
			this->statusLabel->Name = L"statusLabel";
			this->statusLabel->Size = System::Drawing::Size(0, 17);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"Hard", L"Easy"});
			this->comboBox1->Location = System::Drawing::Point(253, 25);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(163, 21);
			this->comboBox1->TabIndex = 4;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged_1);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(5) {L"Show My Scores", L"Clear My Scores", L"Delete My Account", 
				L"Sign Out", L"Exit"});
			this->comboBox2->Location = System::Drawing::Point(253, 69);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(163, 21);
			this->comboBox2->TabIndex = 9;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox2_SelectedIndexChanged);
			// 
			// myOptionsBtn
			// 
			this->myOptionsBtn->Location = System::Drawing::Point(12, 66);
			this->myOptionsBtn->Name = L"myOptionsBtn";
			this->myOptionsBtn->Size = System::Drawing::Size(122, 23);
			this->myOptionsBtn->TabIndex = 10;
			this->myOptionsBtn->Text = L"My Options";
			this->myOptionsBtn->UseVisualStyleBackColor = true;
			this->myOptionsBtn->Click += gcnew System::EventHandler(this, &Form1::myOptionsBtn_Click);
			// 
			// PlayPuzzleBtn
			// 
			this->PlayPuzzleBtn->Location = System::Drawing::Point(12, 25);
			this->PlayPuzzleBtn->Name = L"PlayPuzzleBtn";
			this->PlayPuzzleBtn->Size = System::Drawing::Size(122, 23);
			this->PlayPuzzleBtn->TabIndex = 11;
			this->PlayPuzzleBtn->Text = L"Play";
			this->PlayPuzzleBtn->UseVisualStyleBackColor = true;
			this->PlayPuzzleBtn->Click += gcnew System::EventHandler(this, &Form1::PlayPuzzleBtn_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::ControlDark;
			this->panel1->Controls->Add(this->PlayPuzzleBtn);
			this->panel1->Controls->Add(this->myOptionsBtn);
			this->panel1->Controls->Add(this->comboBox2);
			this->panel1->Controls->Add(this->comboBox1);
			this->panel1->Location = System::Drawing::Point(0, 25);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(428, 111);
			this->panel1->TabIndex = 7;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(424, 154);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->statusStrip1);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Puzzle";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->SizeChanged += gcnew System::EventHandler(this, &Form1::Form1_SizeChanged);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->panel1->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		static String^listPath="..\\Files\\users\\registry.xrec";
		static String^singlesPath="..\\Files\\saved\\";
		static bool i=false,validatcom1=true;
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 i=false,validatcom1=true;
			 this->Visible::set(false);
			 while(!save::canProceed()){
				 UserID^aForm=gcnew UserID;
				 aForm->ShowDialog();
			 }
			 if(save::shouldSigningOut()){
				 save^saved=gcnew save;
				 save::resetEth();
				 Form1_Load(sender,e);
			 }else if(save::keepGoing()){
				 comboBox1->Visible::set(false);
				 comboBox2->Visible::set(false);
				 this->Visible::set(true);
				 statusLabel->Text="Welcome "+save::getUserID()+", "+save::lastLogIn();
				 this->recordToolStripMenuItem->Text = L"&"+save::getUserID();
			 }
		 }
private: System::Void p2Exitbtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure?","Sure about it?",MessageBoxButtons::YesNo,MessageBoxIcon::Question,MessageBoxDefaultButton::Button2);
			 if(result==System::Windows::Forms::DialogResult::Yes)
				 Application::Exit();
		 }

private: System::Void easyToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);
			 String^path="..\\Files\\saved\\"+save::getUserID()+"\\"+save::getUserID();
			 try{
				 if(Directory::Exists("..\\Files\\saved\\"+save::getUserID())){
					 if(File::Exists(path+".srec")&&File::Exists(path+".lrec")&&File::Exists(path+".his")){
						 easyForm^aForm=gcnew easyForm;
						 do{
							 aForm->ShowDialog();
						 }while(save::shouldPlayAgain());
					 }else
						 throw gcnew Exception("File");
				 }else
					 throw gcnew Exception("List");
			 }catch(Exception^e){
				 if(e->Message::get()=="File"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 Directory::Delete("..\\Files\\saved\\"+save::getUserID(),true);
					 save::signOut();
				 }else if(e->Message::get()=="List"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 save::signOut();
				 }else
					 MessageBox::Show("code 395/423.\n"+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
			 }
			 Form1_Load(sender,e);
		 }
private: System::Void hardToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);
			 String^path="..\\Files\\saved\\"+save::getUserID()+"\\"+save::getUserID();
			 try{
				 if(Directory::Exists("..\\Files\\saved\\"+save::getUserID())){
					 if(File::Exists(path+".srec")&&File::Exists(path+".lrec")&&File::Exists(path+".his")){
						 hardForm^aForm=gcnew hardForm;
						 do{
							 aForm->ShowDialog();
						 }while(save::shouldPlayAgain());
					 }else
						 throw gcnew Exception("File");
				 }else
					 throw gcnew Exception("List");
			 }catch(Exception^e){
				 if(e->Message::get()=="File"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 Directory::Delete("..\\Files\\saved\\"+save::getUserID(),true);
					 save::signOut();
				 }else if(e->Message::get()=="List"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 save::signOut();
				 }else
					 MessageBox::Show("code 424/452.\n"+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
			 }
			 Form1_Load(sender,e);
		 }
private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 p2Exitbtn_Click(sender,e);
		 }
private: System::Void showRecordsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);
			 Showhis^aForm=gcnew Showhis;
			 aForm->ShowDialog();
			 Form1_Load(sender,e);
		 }
private: System::Void clearHistoryToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 bool reLoad=false;
			 save^saved=gcnew save;
			 try{
				 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure?\n"+
					 "All your account information will be removed...","Sure about it?",MessageBoxButtons::YesNo,MessageBoxIcon::Warning,MessageBoxDefaultButton::Button2);
				 if(System::Windows::Forms::DialogResult::Yes==result){
					 String^path="..\\Files\\saved\\"+save::getUserID()+"\\"+save::getUserID();
					 if(Directory::Exists("..\\Files\\saved\\"+save::getUserID())){
						 if(File::Exists(path+".his")){
							 File::Delete(path+".srec");
							 File::Create(path+".srec");
							 StreamWriter^write=File::AppendText(path+".his");
							 write->WriteLine("Scores has been cleaned at :			"+DateTime::Now::get());
							 write->Close();
							 MessageBox::Show("Your account Scores have been cleaned seccussfully","Done!",MessageBoxButtons::OK,MessageBoxIcon::Asterisk);
						 }else
							 throw gcnew Exception("File");
					 }else
						 throw gcnew Exception("List");
				 }
			 }catch(Exception^e){
				 if(e->Message::get()=="File"){
					 MessageBox::Show("It seems your account file has been deleted somehow!?","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 Directory::Delete("..\\Files\\saved\\"+save::getUserID(),true);
					 save::signOut();
					 reLoad=true;
				 }else if(e->Message::get()=="List"){
					 MessageBox::Show("It seems your account file has been deleted somehow!?","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 save::signOut();
					 reLoad=true;
				 }else
					 MessageBox::Show("code 462/497.\n"+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
			 }
			 if(reLoad)Form1_Load(sender,e);
		 }

private: System::Void deleteMyAccontToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure?\n"
				 +"Your account will be deleted for good","Sure about it?",MessageBoxButtons::YesNo,MessageBoxIcon::Warning,MessageBoxDefaultButton::Button2);
			 if(result==System::Windows::Forms::DialogResult::Yes){
				 save^saved=gcnew save;
				 Directory::Delete("..\\Files\\saved\\"+save::getUserID(),true);
				 save::signOut();
				 Form1_Load(sender,e);
			 }
		 }
private: System::Void creatANewAccontToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 save^saved=gcnew save;
			 save::create_One(true);
			 save::resetEth();
			 Form1_Load(sender,e);
		 }
private: System::Void showAllHistoriesToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);
			 save::whichShow("ALL");
			 Showhis^aForm=gcnew Showhis;
			 aForm->ShowDialog();
			 Form1_Load(sender,e);
		 }
private: System::Void viewAllAccontToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);			 
			 save::whichShow("USERS");
			 Showhis^aForm=gcnew Showhis;
			 aForm->ShowDialog();
			 Form1_Load(sender,e);
		 }
private: System::Void comboBox2_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(comboBox2->SelectedItem::get()=="Show My Scores"){
				 showRecordsToolStripMenuItem_Click(sender,e);
			 }else if(comboBox2->SelectedItem::get()=="Clear My Scores"){
				 clearHistoryToolStripMenuItem_Click(sender,e);
			 }else if(comboBox2->SelectedItem::get()=="Delete My Account"){
				 deleteMyAccontToolStripMenuItem_Click(sender,e);
			 }else if(comboBox2->SelectedItem::get()=="Sign Out"){
				 save^saved=gcnew save;
				 save::resetEth();
				 this->Visible::set(false);
				 Form1_Load(sender,e);
			 }else if(comboBox2->SelectedItem::get()=="Exit"){
				 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure?\n"
					 ,"Do You Confirm This?",MessageBoxButtons::YesNo,MessageBoxIcon::Question,MessageBoxDefaultButton::Button2);
				 if(result==System::Windows::Forms::DialogResult::Yes)
					 Application::Exit();
			 }
		 }	 
private: System::Void PlayPuzzleBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 i=!i;
			 comboBox2->Visible::set(false);
			 comboBox1->Text::set(String::Empty);
			 if(validatcom1 && i){comboBox1->Visible::set(validatcom1);i=!i;validatcom1=!validatcom1;}
			 else{comboBox1->Visible::set(validatcom1);validatcom1=!validatcom1;i=!i;}
		 }
private: System::Void myOptionsBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 i=!i;
			 comboBox1->Visible::set(false);
			 comboBox2->Text::set(String::Empty);
			 if(validatcom1 && i){comboBox2->Visible::set(validatcom1);i=!i;validatcom1=!validatcom1;}
			 else{comboBox2->Visible::set(validatcom1);validatcom1=!validatcom1;i=!i;}
		 }
private: System::Void comboBox1_SelectedIndexChanged_1(System::Object^  sender, System::EventArgs^  e) {
			 if(comboBox1->SelectedItem=="Easy"){
				 this->Visible::set(false);
				 easyForm^aForm=gcnew easyForm;
				 do{
					 aForm->ShowDialog();
				 }while(save::shouldPlayAgain());
				 Form1_Load(sender,e);
			 }else if(comboBox1->SelectedItem=="Hard"){
				 this->Visible::set(false);
				 hardForm^aForm=gcnew hardForm;
				 do{
					 aForm->ShowDialog();
				 }while(save::shouldPlayAgain());
				 Form1_Load(sender,e);
			 }
		 }
private: System::Void toolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {
			 save^saveing=gcnew save;
			 saveing->signOut();
			 Form1_Load(sender,e);
		 }
private: System::Void Form1_SizeChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}


#include "StdAfx.h"
#include "easyExample.h"


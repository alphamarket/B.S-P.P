#pragma once
#include "stdafx.h"
#include "hardEample.h"
#include "save.h"
using namespace System::IO;
using namespace System::Text;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace puzzle {

	/// <summary>
	/// Summary for hardForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class hardForm : public System::Windows::Forms::Form
	{
	public:
		hardForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~hardForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^  panel1;


	private: System::Windows::Forms::Button^  btn15;
	private: System::Windows::Forms::Button^  btn14;
	private: System::Windows::Forms::Button^  btn13;
	private: System::Windows::Forms::Button^  btn12;
	private: System::Windows::Forms::Button^  btn11;
	private: System::Windows::Forms::Button^  btn10;
	private: System::Windows::Forms::Button^  btn9;
	private: System::Windows::Forms::Button^  btn8;
	private: System::Windows::Forms::Button^  btn7;
	private: System::Windows::Forms::Button^  btn6;
	private: System::Windows::Forms::Button^  btn5;
	private: System::Windows::Forms::Button^  btn4;
	private: System::Windows::Forms::Button^  btn3;
	private: System::Windows::Forms::Button^  btn2;
	private: System::Windows::Forms::Button^  btn1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Panel^  panel2;
	private: System::Windows::Forms::Button^  btn16;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  optionBtn;
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(hardForm::typeid));
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->btn16 = (gcnew System::Windows::Forms::Button());
			this->btn15 = (gcnew System::Windows::Forms::Button());
			this->btn14 = (gcnew System::Windows::Forms::Button());
			this->btn13 = (gcnew System::Windows::Forms::Button());
			this->btn12 = (gcnew System::Windows::Forms::Button());
			this->btn11 = (gcnew System::Windows::Forms::Button());
			this->btn10 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->optionBtn = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->comboBox1);
			this->panel1->Controls->Add(this->optionBtn);
			this->panel1->Controls->Add(this->btn16);
			this->panel1->Controls->Add(this->btn15);
			this->panel1->Controls->Add(this->btn14);
			this->panel1->Controls->Add(this->btn13);
			this->panel1->Controls->Add(this->btn12);
			this->panel1->Controls->Add(this->btn11);
			this->panel1->Controls->Add(this->btn10);
			this->panel1->Controls->Add(this->btn9);
			this->panel1->Controls->Add(this->btn8);
			this->panel1->Controls->Add(this->btn7);
			this->panel1->Controls->Add(this->btn6);
			this->panel1->Controls->Add(this->btn5);
			this->panel1->Controls->Add(this->btn4);
			this->panel1->Controls->Add(this->btn3);
			this->panel1->Controls->Add(this->btn2);
			this->panel1->Controls->Add(this->btn1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(391, 414);
			this->panel1->TabIndex = 0;
			// 
			// btn16
			// 
			this->btn16->Location = System::Drawing::Point(306, 12);
			this->btn16->Name = L"btn16";
			this->btn16->Size = System::Drawing::Size(72, 66);
			this->btn16->TabIndex = 98;
			this->btn16->Text = L"16";
			this->btn16->UseVisualStyleBackColor = true;
			this->btn16->Click += gcnew System::EventHandler(this, &hardForm::btn16_Click);
			// 
			// btn15
			// 
			this->btn15->Location = System::Drawing::Point(206, 12);
			this->btn15->Name = L"btn15";
			this->btn15->Size = System::Drawing::Size(72, 66);
			this->btn15->TabIndex = 99;
			this->btn15->Text = L"15";
			this->btn15->UseVisualStyleBackColor = true;
			this->btn15->Click += gcnew System::EventHandler(this, &hardForm::btn15_Click);
			// 
			// btn14
			// 
			this->btn14->Location = System::Drawing::Point(106, 12);
			this->btn14->Name = L"btn14";
			this->btn14->Size = System::Drawing::Size(72, 66);
			this->btn14->TabIndex = 100;
			this->btn14->Text = L"14";
			this->btn14->UseVisualStyleBackColor = true;
			this->btn14->Click += gcnew System::EventHandler(this, &hardForm::btn14_Click);
			// 
			// btn13
			// 
			this->btn13->Location = System::Drawing::Point(12, 12);
			this->btn13->Name = L"btn13";
			this->btn13->Size = System::Drawing::Size(72, 66);
			this->btn13->TabIndex = 101;
			this->btn13->Text = L"13";
			this->btn13->UseVisualStyleBackColor = true;
			this->btn13->Click += gcnew System::EventHandler(this, &hardForm::btn13_Click);
			// 
			// btn12
			// 
			this->btn12->Location = System::Drawing::Point(306, 107);
			this->btn12->Name = L"btn12";
			this->btn12->Size = System::Drawing::Size(72, 66);
			this->btn12->TabIndex = 102;
			this->btn12->Text = L"12";
			this->btn12->UseVisualStyleBackColor = true;
			this->btn12->Click += gcnew System::EventHandler(this, &hardForm::btn12_Click);
			// 
			// btn11
			// 
			this->btn11->Location = System::Drawing::Point(206, 107);
			this->btn11->Name = L"btn11";
			this->btn11->Size = System::Drawing::Size(72, 66);
			this->btn11->TabIndex = 103;
			this->btn11->Text = L"11";
			this->btn11->UseVisualStyleBackColor = true;
			this->btn11->Click += gcnew System::EventHandler(this, &hardForm::btn11_Click);
			// 
			// btn10
			// 
			this->btn10->Location = System::Drawing::Point(106, 107);
			this->btn10->Name = L"btn10";
			this->btn10->Size = System::Drawing::Size(72, 66);
			this->btn10->TabIndex = 104;
			this->btn10->Text = L"10";
			this->btn10->UseVisualStyleBackColor = true;
			this->btn10->Click += gcnew System::EventHandler(this, &hardForm::btn10_Click);
			// 
			// btn9
			// 
			this->btn9->Location = System::Drawing::Point(12, 107);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(72, 66);
			this->btn9->TabIndex = 105;
			this->btn9->Text = L"9";
			this->btn9->UseVisualStyleBackColor = true;
			this->btn9->Click += gcnew System::EventHandler(this, &hardForm::btn9_Click);
			// 
			// btn8
			// 
			this->btn8->Location = System::Drawing::Point(306, 202);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(72, 66);
			this->btn8->TabIndex = 106;
			this->btn8->Text = L"8";
			this->btn8->UseVisualStyleBackColor = true;
			this->btn8->Click += gcnew System::EventHandler(this, &hardForm::btn8_Click);
			// 
			// btn7
			// 
			this->btn7->Location = System::Drawing::Point(206, 202);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(72, 66);
			this->btn7->TabIndex = 107;
			this->btn7->Text = L"7";
			this->btn7->UseVisualStyleBackColor = true;
			this->btn7->Click += gcnew System::EventHandler(this, &hardForm::btn7_Click);
			// 
			// btn6
			// 
			this->btn6->Location = System::Drawing::Point(106, 202);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(72, 66);
			this->btn6->TabIndex = 108;
			this->btn6->Text = L"6";
			this->btn6->UseVisualStyleBackColor = true;
			this->btn6->Click += gcnew System::EventHandler(this, &hardForm::btn6_Click);
			// 
			// btn5
			// 
			this->btn5->Location = System::Drawing::Point(12, 202);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(72, 66);
			this->btn5->TabIndex = 109;
			this->btn5->Text = L"5";
			this->btn5->UseVisualStyleBackColor = true;
			this->btn5->Click += gcnew System::EventHandler(this, &hardForm::btn5_Click);
			// 
			// btn4
			// 
			this->btn4->Location = System::Drawing::Point(306, 297);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(72, 66);
			this->btn4->TabIndex = 110;
			this->btn4->Text = L"4";
			this->btn4->UseVisualStyleBackColor = true;
			this->btn4->Click += gcnew System::EventHandler(this, &hardForm::btn4_Click);
			// 
			// btn3
			// 
			this->btn3->Location = System::Drawing::Point(206, 297);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(72, 66);
			this->btn3->TabIndex = 111;
			this->btn3->Text = L"3";
			this->btn3->UseVisualStyleBackColor = true;
			this->btn3->Click += gcnew System::EventHandler(this, &hardForm::btn3_Click);
			// 
			// btn2
			// 
			this->btn2->Location = System::Drawing::Point(106, 297);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(72, 66);
			this->btn2->TabIndex = 112;
			this->btn2->Text = L"2";
			this->btn2->UseVisualStyleBackColor = true;
			this->btn2->Click += gcnew System::EventHandler(this, &hardForm::btn2_Click);
			// 
			// btn1
			// 
			this->btn1->Location = System::Drawing::Point(12, 297);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(72, 66);
			this->btn1->TabIndex = 113;
			this->btn1->Text = L"1";
			this->btn1->UseVisualStyleBackColor = true;
			this->btn1->Click += gcnew System::EventHandler(this, &hardForm::btn1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(9, 404);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(113, 13);
			this->label2->TabIndex = 123;
			this->label2->Text = L"0 Moved block till now";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(79, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(143, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Please wait, Calculating . . . .";
			// 
			// panel2
			// 
			this->panel2->Controls->Add(this->label2);
			this->panel2->Location = System::Drawing::Point(3, 3);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(297, 63);
			this->panel2->TabIndex = 2;
			// 
			// optionBtn
			// 
			this->optionBtn->Location = System::Drawing::Point(12, 378);
			this->optionBtn->Name = L"optionBtn";
			this->optionBtn->Size = System::Drawing::Size(166, 23);
			this->optionBtn->TabIndex = 115;
			this->optionBtn->Text = L"Options";
			this->optionBtn->UseVisualStyleBackColor = true;
			this->optionBtn->Click += gcnew System::EventHandler(this, &hardForm::optionBtn_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(4) {L"Reset", L"Switch to easy mode", L"Example", L"Exit"});
			this->comboBox1->Location = System::Drawing::Point(206, 380);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(172, 21);
			this->comboBox1->TabIndex = 116;
			this->comboBox1->Visible = false;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &hardForm::comboBox1_SelectedIndexChanged);
			// 
			// hardForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::WhiteSmoke;
			this->ClientSize = System::Drawing::Size(391, 414);
			this->ControlBox = false;
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"hardForm";
			this->Opacity = 0.94;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Puzzle";
			this->Load += gcnew System::EventHandler(this, &hardForm::hardForm_Load);
			this->panel1->ResumeLayout(false);
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion

		///<begin of variable region>

		initialization^btni;
		movement^move;
		xRule^rul;
		display^dis;
		static control^Xctrl=gcnew control;
		static bool Option=true;

		///<end of variable region>

private: System::Void hardForm_Load(System::Object^  sender, System::EventArgs^  e) {
			 save^saving;
			 Option=true;
			 Xctrl->resetCounter();
			 save::setMode("hard");
			 save::setPlayAgain(false);
			 btni=gcnew initialization(16);
			 btni->makeItSolvable(16);
			 firstInitialization();
			 delete saving,btni;
		 }

		 ///<begin of 18 main elements region>

private: System::Void btn1_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(0,btni,16);
			 if(rul->condition()){
				 move->Swap(0,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn2_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(1,btni,16);
			 if(rul->condition()){
				 move->Swap(1,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn3_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(2,btni,16);
			 if(rul->condition()){
				 move->Swap(2,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn4_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(3,btni,16);
			 if(rul->condition()){
				 move->Swap(3,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn5_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(4,btni,16);
			 if(rul->condition()){
				 move->Swap(4,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn6_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(5,btni,16);
			 if(rul->condition()){
				 move->Swap(5,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn7_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(6,btni,16);
			 if(rul->condition()){
				 move->Swap(6,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn8_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(7,btni,16);
			 if(rul->condition()){
				 move->Swap(7,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn9_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(8,btni,16);
			 if(rul->condition()){
				 move->Swap(8,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn10_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(9,btni,16);
			 if(rul->condition()){
				 move->Swap(9,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn11_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(10,btni,16);
			 if(rul->condition()){
				 move->Swap(10,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn12_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(11,btni,16);
			 if(rul->condition()){
				 move->Swap(11,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn13_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(12,btni,16);
			 if(rul->condition()){
				 move->Swap(12,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn14_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(13,btni,16);
			 if(rul->condition()){
				 move->Swap(13,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn15_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(14,btni,16);
			 if(rul->condition()){
				 move->Swap(14,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void btn16_Click(System::Object^  sender, System::EventArgs^  e) {
			 rul=gcnew xRule;
			 rul->rule(15,btni,16);
			 if(rul->condition()){
				 move->Swap(15,rul->getNum(),btni);
				 Xctrl->setCounter();
			 }
			 showTime(btni->getBlankLocate(),rul->getNum());
			 control^ctrl=gcnew control(btni,16,label2,Xctrl);
			 if(ctrl->getChecked()){
				 track^aForm=gcnew track;
				 aForm->setCounter(Xctrl);
				 aForm->ShowDialog();
				 this->Close();
			 }
			 delete ctrl,rul;
		 }
private: System::Void optionBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 comboBox1->Text::set(String::Empty);
			 comboBox1->Visible::set(Option);
			 Option=!Option;
		 }
private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(comboBox1->SelectedItem::get()=="Reset"){
				 Xctrl->resetCounter();
				 label2->Text::set(Convert::ToString(Xctrl->getCounter())+" Moved block till now");
				 hardForm_Load(sender,e);
			 }else if(comboBox1->SelectedItem::get()=="Switch to easy mode"){
				 save::setPlayAgain(false);
				 delete Xctrl;
				 this->Visible::set(false);
				 easyForm^XFrom=gcnew easyForm;
				 do{
					 XFrom->ShowDialog();
				 }while(save::shouldPlayAgain());
				 this->Close();
			 }else if(comboBox1->SelectedItem::get()=="Exit"){
				 save::setPlayAgain(false);
				 this->Close();
			 }else if(comboBox1->SelectedItem::get()=="Example"){
				 this->ShowIcon::set(true);
				 this->Visible::set(false);
				 hardEample^aForm=gcnew hardEample;
				 aForm->ShowDialog();
				 this->Visible::set(true);
			 }
		 }
		 ///<end of 18 main elements region>

		 ///<begin of the sundry functions in order of usage region>

private: System::Void firstInitialization(){
				  dis->displayBtn(btni,btn1,0);
				  dis->displayBtn(btni,btn2,1);
				  dis->displayBtn(btni,btn3,2);
				  dis->displayBtn(btni,btn4,3);
				  dis->displayBtn(btni,btn5,4);
				  dis->displayBtn(btni,btn6,5);
				  dis->displayBtn(btni,btn7,6);
				  dis->displayBtn(btni,btn8,7);
				  dis->displayBtn(btni,btn9,8);
				  dis->displayBtn(btni,btn10,9);
				  dis->displayBtn(btni,btn11,10);
				  dis->displayBtn(btni,btn12,11);
				  dis->displayBtn(btni,btn13,12);
				  dis->displayBtn(btni,btn14,13);
				  dis->displayBtn(btni,btn15,14);
				  dis->displayBtn(btni,btn16,15);
			 }
private:System::Void showTime(int blank,int btn){
				   switch(btn){
						case 0:dis->displayBtn(btni,btn1,btn);break;
						case 1:dis->displayBtn(btni,btn2,btn);break;
						case 2:dis->displayBtn(btni,btn3,btn);break;
						case 3:dis->displayBtn(btni,btn4,btn);break;
						case 4:dis->displayBtn(btni,btn5,btn);break;
						case 5:dis->displayBtn(btni,btn6,btn);break;
						case 6:dis->displayBtn(btni,btn7,btn);break;
						case 7:dis->displayBtn(btni,btn8,btn);break;
						case 8:dis->displayBtn(btni,btn9,btn);break;
						case 9:dis->displayBtn(btni,btn10,btn);break;
						case 10:dis->displayBtn(btni,btn11,btn);break;
						case 11:dis->displayBtn(btni,btn12,btn);break;
						case 12:dis->displayBtn(btni,btn13,btn);break;
						case 13:dis->displayBtn(btni,btn14,btn);break;
						case 14:dis->displayBtn(btni,btn15,btn);break;
						case 15:dis->displayBtn(btni,btn16,btn);break;
				   }
				 showTime_Blank(btni->getBlankLocate());
			   }
private:System::Void showTime_Blank(int blank){
			switch(blank){
				case 0:dis->displayBtn(btni,btn1,blank);break;
				case 1:dis->displayBtn(btni,btn2,blank);break;
				case 2:dis->displayBtn(btni,btn3,blank);break;
				case 3:dis->displayBtn(btni,btn4,blank);break;
				case 4:dis->displayBtn(btni,btn5,blank);break;
				case 5:dis->displayBtn(btni,btn6,blank);break;
				case 6:dis->displayBtn(btni,btn7,blank);break;
				case 7:dis->displayBtn(btni,btn8,blank);break;
				case 8:dis->displayBtn(btni,btn9,blank);break;
				case 9:dis->displayBtn(btni,btn10,blank);break;
				case 10:dis->displayBtn(btni,btn11,blank);break;
				case 11:dis->displayBtn(btni,btn12,blank);break;
				case 12:dis->displayBtn(btni,btn13,blank);break;
				case 13:dis->displayBtn(btni,btn14,blank);break;
				case 14:dis->displayBtn(btni,btn15,blank);break;
				case 15:dis->displayBtn(btni,btn16,blank);break;				
			}
		}

		///<end of sundry functions in order of usage region >

};
}

#include "StdAfx.h"
#include "movement.h"

movement::movement(void){
}
void movement::Swap(int clicked_locate, int target_locate, initialization ^btni){
	btni->setBtnValue(target_locate,btni->getBtnValue(clicked_locate));
	btni->setBlankLocate(clicked_locate);
}

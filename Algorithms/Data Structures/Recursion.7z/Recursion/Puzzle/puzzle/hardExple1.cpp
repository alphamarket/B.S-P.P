#include "StdAfx.h"
#include "hardExple1.h"


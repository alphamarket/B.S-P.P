#include "StdAfx.h"
#include "display.h"
#include "save.h"
using namespace System::IO;
display::display(void)
{
}
void display::displayBtn(initialization^btni,Button ^btn,int i){
	if(btni->getBtnValue(i)){
		btn->Visible::set(true);
		btn->Text::set(Convert::ToString(btni->getBtnValue(i)));
		btn->BackColor = System::Drawing::Color::WhiteSmoke;
	}else{
		btn->Visible::set(false);
		btn->Text::set("");
	}
}
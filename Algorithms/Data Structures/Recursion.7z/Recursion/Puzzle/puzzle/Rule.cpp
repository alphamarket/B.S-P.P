#include "StdAfx.h"
#include "Rule.h"
#include "cmath"
xRule::xRule(void){
	Condition=false;
	num=0;
}
void xRule::rule(int clicked_locate, initialization ^btni,int size){
	if(forSize(size,clicked_locate,btni,1)){
		num=clicked_locate-1;
		Condition=true;
	}else if(forSize(size,clicked_locate,btni,2)){
		num=clicked_locate+1;
		Condition=true;
	}else if(forSize(size,clicked_locate,btni,3)){
		num=clicked_locate+(int)sqrt((double)size);
		Condition=true;
	}else if(forSize(size,clicked_locate,btni,4)){
		num=clicked_locate-(int)sqrt((double)size);
		Condition=true;
	}
}
bool xRule::forSize(int size,int clicked_locate,initialization^btni,int caseN){
	switch(caseN){
		case 1:
			if(clicked_locate>0 && backwardByOne(size,clicked_locate)
				&& btni->getBlankLocate()==(clicked_locate-1))
				return true;break;
		case 2:
			if(clicked_locate<(size-1) && forwardByOne(size,clicked_locate)
				&& btni->getBlankLocate()==(clicked_locate+1))
				return true;break;
		case 3:
			if(clicked_locate<(size-sqrt((double)size)) && btni->getBlankLocate()==(clicked_locate+sqrt((double)size)))
				return true;break; 
		case 4:
			if(clicked_locate>((sqrt((double)size))-1) && btni->getBlankLocate()==(clicked_locate-sqrt((double)size)))
				return true;break;
	}
	return false;
}
bool xRule::backwardByOne(int size,int clicked_locate){
	for(int i=1;i<((sqrt((double)size)));i++)
		if(clicked_locate==(i*(sqrt((double)size))))
			return false;
	return true;
}
bool xRule::forwardByOne(int size, int clicked_locate){
	for(int i=1;i<((sqrt((double)size)));i++)
		if(clicked_locate==(i*sqrt((double)size)-1))
			return false;
	return true;
}

#include "StdAfx.h"
#include "hardExple.h"


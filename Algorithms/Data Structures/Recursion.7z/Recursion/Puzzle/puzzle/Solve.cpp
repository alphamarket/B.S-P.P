#include "StdAfx.h"
#include "Solve.h"
#include "save.h"
#include "malloc.h"
using namespace System::IO;
Solve::Solve(initialization^object,int size){
	send="";
	list=new node;
	list->object=object;
	sizeOfPuzzle=size;
	if(size==9)save::depth(depth=25);
	solving(list);
}

Solve::~Solve(void){
	delete list;
}

void Solve::solving(Solve::node *parent){
	try{
		if(canReturn(parent))
			return;
		makingChildren(parent);//:))
		if(save::whatIsTheSolveMode()!="CHANCE")
			setChildrenInOrder(parent);
		for(int i=0;i<4;i++){
			if(parent->child[i]){
				setPosition(parent->child[i],1);
				if(time(NULL)%10==0)Application::DoEvents();
				solving(parent->child[i]);/*******************The Recursion!*******************/
				setPosition(parent->child[i],0);
				if(parent->child[i]->done){
					recursionSaving(parent,i);
					return;
				}
				parent->child[i]=NULL;
				if(childSearch(parent))
					continue;
				return;
			}
		}
	}catch(Exception^e){
		MessageBox::Show(e->Message::get());
		Application::Restart();
	}
}
bool Solve::canReturn(node*parent){
	if(parent->count>depth)
		return true;
	if(check(parent->object,9)){
		if(parent->count && save::getNoded()){
			if(File::Exists("..\\Files\\users\\solution.soda"))
				File::Delete("..\\Files\\users\\solution.soda");
			breakIt=false;
			return parent->done=true;
		}else{
			MessageBox::Show("It's been solved before!","Oops!",MessageBoxButtons::OK,MessageBoxIcon::Stop);
			return breakIt=true;
		}
	}
	return false;
}
bool Solve::childSearch(node*parent){
	for(int i=0;i<4;i++){
		if(parent->child[i]){
			return true;
		}
	}
	if(parent==list && sizeOfPuzzle==9 && depth==25){
		System::Windows::Forms::DialogResult result=MessageBox::Show("This puzzle cannot be solved in primary stage,But the program can enter to the second stage if you want so.\n"
			"And it would take more time that it toke till now(almost double!)\nDo you insist to solve this puzzle?","Do You Insist To Solve The Puzzle?",MessageBoxButtons::YesNo,MessageBoxIcon::Question);
		if(System::Windows::Forms::DialogResult::Yes==result){
			save::depth(this->depth=28);
			solving(parent);
		}else
			done=false;
	}
	if(parent==list){
		MessageBox::Show("This puzzle cannot be solved in circumstaces that predefined in this program!","Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
		done=false;
	}
	return false;
}
bool Solve::backwardByOne(int blank_locate){ 
	for(int i=1;i<((sqrt((double)sizeOfPuzzle)));i++)
		if(blank_locate==(i*(sqrt((double)sizeOfPuzzle))))
			return false;
	return true;
}
bool Solve::forwardByOne(int blank_locate){ 
	for(int i=1;i<((sqrt((double)sizeOfPuzzle)));i++)
		if(blank_locate==(i*sqrt((double)sizeOfPuzzle)-1))
			return false;
	return true;
}
bool Solve::check(initialization ^object, size_t size){
	for(size_t i=0;i<size;i++)
		if(i!=object->getBlankLocate())
			if(i!=(object->getBtnValue(i))-1)
				return false;
	return true;
}
int Solve::search(initialization^object,int i){
	switch(i){
		case 0:
			if(object->getBlankLocate()<sizeOfPuzzle-1 && forwardByOne(object->getBlankLocate())){
				send="Left";
				return object->getBtnValue(object->getBlankLocate()+1);
			}break;
		case 1:
			if(object->getBlankLocate()>0 && backwardByOne(object->getBlankLocate())){
				send="Right";
				return object->getBtnValue(object->getBlankLocate()-1);
			}break;
		case 2:
			if(object->getBlankLocate()<6){
				send="Down";
				return object->getBtnValue(object->getBlankLocate()+3);
			}break;
		case 3:
			if(object->getBlankLocate()>2){
				send="Up";
				return object->getBtnValue(object->getBlankLocate()-3);
			}break;
	}
	return 0;
}


void Solve::makingChildren(node*parent){
	for(int i=0;i<4;i++){
		int token=search(parent->object,i);
		if(token!=parent->data&&token){
			parent->child[i]=new node;
			parent->child[i]->data=token;
			parent->child[i]->count=parent->count;
			parent->child[i]->sended=send;
			parent->child[i]->object=parent->object;
			_heuristic(parent->child[i]);
			send="";
		}
	}
}

void Solve::recursionSaving(node*parent,int i){
	if (parent->child[i]->count<24){
		for(int j=0;j<4;j++){
			if(parent->child[i]->child[j])
				parent->child[i]->child[j]=NULL;
		}
	}
	if(!File::Exists("..\\Files\\users\\solution.soda")){
		StreamWriter^richWriter=File::CreateText("..\\Files\\users\\solution.soda");
		StreamWriter^codeWriter=File::CreateText("..\\Files\\users\\pathCode.soda");
		codeWriter->WriteLine(Convert::ToString(parent->child[i]->data));
		richWriter->WriteLine("\" "+Convert::ToString(parent->child[i]->data)+" \"\t\t"+"TO"+"\t\t\" "+Convert::ToString(parent->child[i]->sended)+" \"");
		richWriter->Close();
		codeWriter->Close();
	}else{
		StreamWriter^richWriter=File::AppendText("..\\Files\\users\\solution.soda");
		StreamWriter^codeWriter=File::AppendText("..\\Files\\users\\pathCode.soda");
		codeWriter->WriteLine(Convert::ToString(parent->child[i]->data));
		richWriter->WriteLine("\" "+Convert::ToString(parent->child[i]->data)+" \"\t\t"+"TO"+"\t\t\" "+Convert::ToString(parent->child[i]->sended)+" \"");
		richWriter->Close();
		codeWriter->Close();
	}
	parent->done=true;
	_heapmin();
}
void Solve::setPosition(node*child,int makeChanges){
	movement^move;
	for(int j=0;j<9;j++){
		if(child->data==child->object->getBtnValue(j)){
			move->Swap(j,child->object->getBlankLocate(),child->object);
			break;
		}
	}
	if(makeChanges){
		child->count++;
		save::addNode(1);
	}
}
void Solve::_heuristic(node*child){
	int score=0;
	if(save::whatIsTheSolveMode()=="#1"){
		setPosition(child);
		for(int i=0;i<9;i++){
			if(child->object->getBtnValue(i))
				if(i!=child->object->getBtnValue(i)-1)
					score++;
		}
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(i!=j && i+1==child->object->getBtnValue(j)){
					score+=(int)fabs((double)(i%3-j%3))+(int)fabs((double)((int)i/3-(int)(j/3)));
					break;
				}
			}
		}	
		child->pathScore=score%100;
		setPosition(child);
	}else if(save::whatIsTheSolveMode()=="#2"){
		setPosition(child);
		for(int i=0;i<9;i++){
			if(child->object->getBtnValue(i))
				score+=i*child->object->getBtnValue(i);
			else
				score+=9*i;
		}
		child->pathScore=240-score;
		setPosition(child);
	}
}
void Solve::setChildrenInOrder(Solve::node *parent){
	for(int i=0;i<3;i++){
		if(parent->child[i]){
			for(int j=i+1;j<4;j++){
				if(parent->child[j]){
					if(parent->child[i]->pathScore>parent->child[j]->pathScore){
						node*tmp=parent->child[j];
						parent->child[j]=parent->child[i];
						parent->child[i]=tmp;
						break;
					}
				}
			}
		}
	}
}


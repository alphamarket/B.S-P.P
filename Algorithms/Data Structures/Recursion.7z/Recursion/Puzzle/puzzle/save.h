#pragma once
#include "string"

using namespace std;
using namespace System;
ref class save
{
	static String^mode="";
	static String^userName="";
	static bool shouldStartTheGame=false,keeping=true,autoMode=false;
	static bool signing=false,createOne=false,playAgain=false;
	static String^which="",^LastLogIn="",^solveMode="";
	static int noded=0,Depth;
public:
	void saving(String^,String^);
	save();
	static bool keepGoing(){return keeping;}
	static bool shouldSigningOut(){return signing;}
	static bool canProceed(){return shouldStartTheGame;}
	static bool shouldPlayAgain(){return playAgain;}
	static bool isCreatingOne(){return createOne;}
	static bool isInAutoMode(){return autoMode;}
	static String^getUserID(){return userName;}
	static String^whichShow(){return which;}
	static String^lastLogIn(){return LastLogIn;}
	static String^whatIsTheSolveMode(){return solveMode;}
	static int getNoded(){return noded;}
	static int depth(){return Depth;}
	static void depth(int what){Depth=what;}
	static void setMode(String^);
	static void setSolveMode(String^what){solveMode=what;}
	static void setUserID(String^);
	static void isValidUserID(String^);
	static void setProceed(){shouldStartTheGame=true;}
	static void ShouldExit(){keeping=false;shouldStartTheGame=true;}
	static void resetEth();
	static void signOut(){signing=true;}
	static void create_One(bool what){createOne=what;}
	static void whichShow(String^what){which=what;}
	static void lastLogIn(String^what){LastLogIn=what;}
	static void setPlayAgain(bool what){playAgain=what;}
	static void addNode(int what);
	static void setAuto(bool what){autoMode=what;}
};

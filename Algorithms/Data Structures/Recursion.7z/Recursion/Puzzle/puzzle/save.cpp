#include "StdAfx.h"
#include "save.h"
#include "iomanip"
using namespace System;
using namespace System::Windows::Forms;
using namespace System::IO;
save::save(){}
void save::saving(String^userID,String^moves){
	mode="easy";
	String^path="..\\Files\\saved\\"+userID+"\\"+userID+".srec";
	if(File::Exists(path)){
		StreamWriter^write=File::AppendText(path);
		write->WriteLine(moves+"\t\t\t\t"+"mode : "+mode+"\t\t\t\t "+DateTime::Now::get());
		write->Close();
	}else{
		StreamWriter^write=File::CreateText(path);
		write->WriteLine(userID+"\t\t\t\t"+"mode : "+mode+"\t\t\t\t"+DateTime::Now::get());
		write->Close();
	}
}
void save::setMode(System::String ^Mode){
	mode=Mode;
}

void save::setUserID(System::String ^UserName){
	userName=UserName;
}
void save::isValidUserID(System::String ^userID){
	String^illegal="";
	for(int i=0;i<userID->Length::get();i++){
		switch(userID[i]){
			case '\\':illegal+=" \\";break;
			case'/':illegal+=" /";break;
			case ':':illegal+=" :";break;
			case '?':illegal+=" ?";break;
			case '\"':illegal+=" \"";break;
			case '>':illegal+=" >";break;
			case '<':illegal+=" <";break;
			case '|':illegal+=" |";break;
			case'*':illegal+=" *";break;
			case '.':illegal+=" .";break;
		}
	}
	if(!String::IsNullOrEmpty(illegal))
		throw gcnew Exception("A user ID can't contain \""+illegal+" \" character(s)!, Please choose another one.");
}
void save::resetEth(){
	userName=mode=LastLogIn="";
	shouldStartTheGame=signing=false;
	keeping=true;
}

void save::addNode(int what){
	if(what)
		noded+=what;
	else
		noded=what;
}
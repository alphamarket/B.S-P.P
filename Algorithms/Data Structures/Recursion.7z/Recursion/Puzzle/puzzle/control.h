#pragma once
#include "initialization.h"
using System::Windows::Forms::Label;
ref class control
{
	bool checked;
	int counter;
public:
	control(void){counter=0;}
	control(initialization^,int size,Label^,control^);
	bool checking(initialization^btni,int size);
	bool getChecked(){return checked;}
	void setCounter(){counter++;}
	int getCounter(){return counter;}
	void resetCounter(){counter=0;}
};

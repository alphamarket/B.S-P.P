#include "StdAfx.h"
#include "hardEample.h"


#pragma once
#include "initialization.h"
ref class display
{
public:
	display(void);
	void displayBtn(initialization^btni, Button ^btn,int i);
};

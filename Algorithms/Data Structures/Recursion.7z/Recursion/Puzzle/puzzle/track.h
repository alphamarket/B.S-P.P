#pragma once
#include "control.h"
#include "save.h"
using namespace std;
using namespace System::IO;
using namespace System::Text;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace puzzle {

	/// <summary>
	/// Summary for track
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class track : public System::Windows::Forms::Form
	{
	public:
		track(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~track()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  cancelBtn;
	private: System::Windows::Forms::Button^  OKBtn;
	private: System::Windows::Forms::Button^  playAgainBtn;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(track::typeid));
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->playAgainBtn = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->cancelBtn = (gcnew System::Windows::Forms::Button());
			this->OKBtn = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->playAgainBtn);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->cancelBtn);
			this->panel1->Controls->Add(this->OKBtn);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(338, 70);
			this->panel1->TabIndex = 0;
			// 
			// playAgainBtn
			// 
			this->playAgainBtn->Location = System::Drawing::Point(226, 38);
			this->playAgainBtn->Name = L"playAgainBtn";
			this->playAgainBtn->Size = System::Drawing::Size(100, 20);
			this->playAgainBtn->TabIndex = 3;
			this->playAgainBtn->Text = L"Play again";
			this->playAgainBtn->UseVisualStyleBackColor = true;
			this->playAgainBtn->Click += gcnew System::EventHandler(this, &track::playAgainBtn_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->label1->ForeColor = System::Drawing::Color::Black;
			this->label1->Location = System::Drawing::Point(12, 18);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(167, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Do you want to keep this record \?";
			// 
			// cancelBtn
			// 
			this->cancelBtn->Location = System::Drawing::Point(118, 38);
			this->cancelBtn->Name = L"cancelBtn";
			this->cancelBtn->Size = System::Drawing::Size(100, 20);
			this->cancelBtn->TabIndex = 2;
			this->cancelBtn->Text = L"No and quit";
			this->cancelBtn->UseVisualStyleBackColor = true;
			this->cancelBtn->Click += gcnew System::EventHandler(this, &track::cancelBtn_Click);
			// 
			// OKBtn
			// 
			this->OKBtn->Location = System::Drawing::Point(12, 38);
			this->OKBtn->Name = L"OKBtn";
			this->OKBtn->Size = System::Drawing::Size(100, 20);
			this->OKBtn->TabIndex = 1;
			this->OKBtn->Text = L"Yes";
			this->OKBtn->UseVisualStyleBackColor = true;
			this->OKBtn->Click += gcnew System::EventHandler(this, &track::OKBtn_Click);
			// 
			// track
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(338, 70);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"track";
			this->Opacity = 0.94;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Saving........";
			this->Load += gcnew System::EventHandler(this, &track::track_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
		static control^ctrl=gcnew control;
#pragma warning (disable : 4677)
public: void setCounter(control^Xctrl){
			ctrl=Xctrl;
		}
#pragma warning (default : 4677)
private: System::Void track_Load(System::Object^  sender, System::EventArgs^  e) {
			 this->Visible::set(false);
			 try{
				 String^path="..\\Files\\saved\\"+save::getUserID()+"\\"+save::getUserID();
				 if(Directory::Exists("..\\Files\\saved\\")){
					 if(File::Exists(path+".srec") && File::Exists(path+".lrec") && File::Exists(path+".his")){
						 panel1->Visible::set(true);
						 this->Visible::set(true);
					 }else
						 throw gcnew Exception("File");
				 }else
					 throw gcnew Exception("List");
			 }catch(Exception^e){
				 if(e->Message::get()=="File"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 Directory::Delete("..\\Files\\saved\\"+save::getUserID(),true);
					 save::signOut();
					 this->Close();
				 }else if(e->Message::get()=="List"){
					 MessageBox::Show("Your accont has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 save::signOut();
					 this->Close();
				 }else
					 MessageBox::Show("code 157/183."+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
			 }
		 }
private: System::Void OKBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 save^saving=gcnew save();
			 saving->saving(save::getUserID(),Convert::ToString(ctrl->getCounter()));
			 System::Windows::Forms::DialogResult result=MessageBox::Show("Your scores has been saved successfully....\nDo you want to play again?","Done!",MessageBoxButtons::YesNo,MessageBoxIcon::Question);
			 if(System::Windows::Forms::DialogResult::Yes==result)
				 save::setPlayAgain(true);
			 this->Close();
		 }
private: System::Void cancelBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close();
		 }
private: System::Void playAgainBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 save::setPlayAgain(true);
			 this->Close();
		 }
};
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WaitForm
{
    public partial class Wait : Form
    {
        public Wait()
        {
            InitializeComponent();
        }

        void wait()
        {
            while (true)
            {
                for (int i = 0; i < 5; i++)
                {
                    _Text(waitLabel, "Initializing " + new string('.', i).Replace(".", " . "));
                    System.Threading.Thread.Sleep(500);
                }
            }
        }

        delegate void text(Label l, string p);
        private void _Text(Label waitLabel, string p)
        {
            if (waitLabel.InvokeRequired)
            {
                waitLabel.Invoke(new text(_Text), new object[] { waitLabel, p });
            }
            else
            {
                waitLabel.Text = p;
            }
        }

        private void Wait_Load(object sender, EventArgs e)
        {
            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(wait));

            t.Start();
        }

        private void Wait_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mouse_Maze
{
    class Externals
    {
        public enum Windows { Wait }

        static Queue<System.Diagnostics.Process> processes = new Queue<System.Diagnostics.Process>();

        public static void Start(Windows win)
        {
            try
            {
                processes.Enqueue(System.Diagnostics.Process.Start(win.ToString()));
            }
            catch { }
        }

        public static void StopAll()
        {
            try
            {
                foreach (string i in Enum.GetNames(typeof(Windows)))
                    foreach (System.Diagnostics.Process item in System.Diagnostics.Process.GetProcessesByName(i))
                    {
                        item.Kill();
                    }
            }
            catch { }
        }

        public static void Stop(Windows win)
        {
            try
            {
                foreach (System.Diagnostics.Process i in System.Diagnostics.Process.GetProcessesByName(win.ToString()))
                {
                    i.Kill();
                }
            }
            catch { }
        }

        public static void StopCurrent()
        {
            try
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }
            catch { }
        }
    }
}

﻿using System.Collections.Generic;

namespace Mouse_Maze
{
    partial class Blocks
    {
        /// <summary>
        /// A class which will hold elements of a column blocks
        /// </summary>
        public class Column :System.Collections.IEnumerable
        {
            #region Variables

            /// <summary>
            /// Members of current column
            /// </summary>
            List<Block.Info> members;

            /// <summary>
            /// Number of column
            /// </summary>
            int columnNo;

            #endregion

            #region Class' Metods

            /// <summary>
            /// Ctor
            /// </summary>
            /// <param name="members">List of column members</param>
            /// <param name="columnNo">Column number</param>
            public Column(List<Block.Info> members, int columnNo)
            {
                this.columnNo = columnNo;
                this.members = members;
                exceptions = new List<Block.Info>(members.Count);
            }

            /// <summary>
            /// Ctor
            /// </summary>
            /// <param name="columnNo">Column number</param>
            public Column(int columnNo)
            {
                this.columnNo = columnNo;
            }

            /// <summary>
            /// Ctor
            /// </summary>
            public Column()
            {
                columnNo = 0;
            }

            /// <summary>
            /// Get or Set a block info at specific place in current column
            /// </summary>
            /// <param name="index">A zero-based index of block</param>
            /// <returns></returns>
            public Block.Info this[int index]
            {
                get { return members[index]; }
                set { members[index] = value; }
            }

            /// <summary>
            /// Count of members in current column;
            /// </summary>
            public int Count
            {
                get { return members.Count; }
            }

            /// <summary>
            /// Get the type of the current column
            /// </summary>
            public Block.Events.ColumnType Type
            {
                get { return columnNo % 2 == 0 ? Block.Events.ColumnType.Even : Block.Events.ColumnType.Odd; }
            }

            /// <summary>
            /// Get current column number
            /// </summary>
            public int ColumnNo
            {
                get { return columnNo; }
            }

            List<Block.Info> exceptions;

            public List<Block.Info> Exceptions
            {
                get { return exceptions; }
            }

            public void AddExceptionBlock(Block.Info exception)
            {
                if (!members.Contains(exception))
                    throw new BlockDoesNotExist("The Block does not exists .", exception);

                if (!exceptions.Contains(exception))
                    exceptions.Add(exception);

                exceptions.Sort(new System.Comparison<Block.Info>(SortBlocksByLocation_Y));
            }

            private int SortBlocksByLocation_Y(Block.Info i, Block.Info j)
            {
                if (i.Location.Y > j.Location.Y)
                    return 1;
                else if (i.Location.Y == j.Location.Y)
                    return 0;
                else
                    return -1;
            }

            public System.Collections.IEnumerator GetEnumerator()
            {
                return members.GetEnumerator();
            }
        }

            #endregion
    }
}

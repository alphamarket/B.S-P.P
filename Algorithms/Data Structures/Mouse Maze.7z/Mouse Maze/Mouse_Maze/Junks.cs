//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Mouse_Maze
//{
//    /// <summary>
//    /// in class path haye in maze ro initialize mikone; [ PART II ]
//    /// </summary>
//    partial class MazePaths
//    {
//        #region Initialize variables

//        #endregion

//        private void StartCalculateing(Block.Info initBlock, Block.Info Approximate)
//        {
//            try
//            {
//                #region Variable init

//                Block.Info[] Valids;

//                Block.Info info = initBlock;

//                int count = 0;

//                while (true)
//                {
//                    // get new work space!
//                    Valids = new Block.Info[3];

//                    count = 0;

//                    foreach (Blocks.CoordinatedD dir in directions)
//                    {
//                        BlockLocation.Location loc = BlockLocation.Location.GetLocation(dir, info.Location);
//                        if (loc.IsReferenced)
//                        {
//                            try
//                            {
//                                Block.Info tmp = Block.Events.GetBlock(loc);
//                                if (tmp.Location.X == Blocks.X)
//                                {
//                                    Block.Events.MakePath(tmp, info);
//                                    return;
//                                }

//                                if (tmp.Location.X == Approximate.Location.X && (tmp.Location.Y == Approximate.Location.Y + 1 || tmp.Location.Y == Approximate.Location.Y - 1))
//                                {
//                                    Block.Events.MakePath(tmp, info);
//                                    return;
//                                }
//                                // khub in khune gablan, joz'e khune ii boode;
//                                if (tmp == info.Parent)
//                                    continue;

//                                if (CheckFurther(tmp, info))
//                                    Valids[count++] = tmp;
//                            }
//                            catch (NullReferenceException) { }
//                        }
//                    }

//                    if (GetArrayElementCount(Valids) == 0)
//                        return;
//                    HeuristicFunction(ref Valids, Approximate.Location);

//                    Block.Info sample = Valids[new Random(RandomSeed).Next(0, GetArrayElementCount(Valids))];

//                    Block.Events.MakePath(sample, info);

//                    OpenPath.BlockSeries.Add(sample);

//                    info = sample;
//                }

//                #endregion
//            }
//            catch (NullReferenceException) { }
//        }

//        private bool CheckFurther(Block.Info tmp, Block.Info info)
//        {
//            if (tmp.IsPath)
//                return false;
//            if (tmp.Location.X == 1)
//                return false;
//            return true;
//        }
//        private void HeuristicFunction(ref Block.Info[] Valids, BlockLocation.Location Approximate)
//        {
//            try
//            {
//                List<HeuristicValue> tmp = new List<HeuristicValue>();

//                foreach (Block.Info i in Valids)
//                {
//                    if (i != null)
//                    {
//                        tmp.Add(new HeuristicValue(i, GetDestinySlope(i.Location, Approximate)));
//                    }
//                }

//                tmp.Sort(new Comparison<HeuristicValue>(CompareHeuristicValues));

//                Valids = new Block.Info[tmp.Count];
//                int count = 0;
//                foreach (var item in tmp)
//                {
//                    Valids[count++] = item.block;
//                }
//            }
//            catch (NullReferenceException e)
//            {
//                throw e;
//            }
//        }

//        /// <summary>
//        /// A compare function in order to sort list of blocks ordered by heuristic values desc;
//        /// </summary>
//        /// <param name="a">First block's heuristic value;</param>
//        /// <param name="b">Second block's heuristic value;</param>
//        /// <returns>return -1 if a.value less than b.balue; 0 if a.value == b.value; 1 if a.value is great than b.value;</returns>
//        int CompareHeuristicValues(HeuristicValue a, HeuristicValue b)
//        {
//            if (a.value > b.value)
//                return 1;
//            if (a.value == b.value)
//                return 0;
//            return -1;
//        }

//        /// <summary>
//        /// This is our heuristic function
//        /// </summary>
//        /// <param name="location">Location of block;</param>
//        /// <param name="approximate">Approximate location of destiny block</param>
//        /// <returns>Value of calculated heuristic value, related to specific block</returns>
//        private int GetDestinySlope(BlockLocation.Location location, BlockLocation.Location approximate)
//        {
//            try
//            {
//                int y = Math.Abs(location.Y - approximate.Y);
//                int x = Math.Abs(location.X - approximate.X);

//                return x + y;
//            }
//            catch (NullReferenceException e)
//            {
//                throw e;
//            }
//        }

//        private int GetArrayElementCount(Block.Info[] Valids)
//        {
//            int count = 0;
//            foreach (var item in Valids)
//            {
//                if (item != null)
//                    count++;
//            }
//            return count;
//        }



//        #region Sundries

//        /// <summary>
//        /// A struct which hold heuristic value of specific block
//        /// </summary>
//        struct HeuristicValue
//        {
//            public Block.Info block;
//            public int value;

//            /// <summary>
//            /// The ctor of this struct
//            /// </summary>
//            /// <param name="block">the block;</param>
//            /// <param name="value">the block's heuristic value;</param>
//            public HeuristicValue(Block.Info block, int value)
//            {
//                this.block = block;
//                this.value = value;
//            }
//        }

//        #endregion
//    }
//}
//private bool CheckFurther(Block.Info child, Block.Info parent)
//        {

//            if (child.IsNullBlock || child.Location.X == 1)
//                return false;

//            bool condition = false;

//            foreach (Blocks.CoordinatedD i in directions)
//            {
//                BlockLocation.Location loc = BlockLocation.Location.GetLocation(i, child);

//                if (loc.IsReferenced && !BlockLocation.Location.IsEqualLocation(parent.Location, loc))
//                {
//                    Block.Info tmp = Block.Events.GetBlock(loc);

//                    if (tmp.Parent == parent)
//                        continue;

//                    condition |= !tmp.IsPath;
//                }
//            }
//            return condition;
//        }

//        int counter = 0;
//        //(int)new Random(RandomSeed).Next(0, (GetArrayElementCount(Valids) - 1) * 10) / 10
//        private void GetProperBlock(out Block.Info sample,ref Block.Info[] Valids,Block.Info info)
//        {
//            bool foo = false;
                
//            while (true)
//            {
//                try
//                {
//                    sample = Valids[GetIndex(Valids)];
//                }
//                catch (IndexOutOfRangeException)
//                {
//                    try
//                    {
//                        sample = Valids[GetIndex(Valids)];
//                    }
//                    catch { sample = null; return; }
//                }
//                foo = false;

//                foreach (Blocks.CoordinatedD dir in directions)
//                {
//                    BlockLocation.Location loc = BlockLocation.Location.GetLocation(dir, sample.Location);
//                    if (loc.IsReferenced)
//                    {
//                        Block.Info tmp = Block.Events.GetBlock(loc);

//                        // khub in khune gablan, joz'e khune ii boode;
//                        if (tmp == info)
//                            continue;

//                        foo |= tmp.IsPath;
//                    }
//                }
                
//                if (foo)
//                {
//                    int count = 0;
//                    Block.Info[] _tmp_ = new Block.Info[GetArrayElementCount(Valids)-1];
//                    foreach (Block.Info i in Valids)
//                    {
//                        if (i != sample)
//                            _tmp_[count++] = i;
//                    }
//                    Valids = _tmp_;
//                }
//                else
//                {
//                    break;
//                }

//            }
//        }

//        private int GetIndex(Block.Info[] Valids)
//        {
//            int size=GetArrayElementCount(Valids);
//            if (counter < size)
//                return counter++;
//            else
//            {
//                if(counter>0)
//                    while (counter > size && counter > 0)
//                    {
//                        counter--;
//                    }
//                return counter;
//            }
//        }

////while (true)
//                //{
//                //    int counter = 0;

//                //    bool foo=false;
//                //    try
//                //    {
//                //        _tmp = Valids[(int)new Random(RandomSeed).Next(0, (GetArrayElementCount(Valids) - 1) * 10) / 10];
//                //    }
//                //    catch (ArgumentOutOfRangeException) { return; }
//                //    foreach (Blocks.CoordinatedD dir in directions)
//                //    {
//                //        BlockLocation.Location loc = BlockLocation.Location.GetLocation(dir, _tmp.Location);
//                //        if (loc.IsReferenced)
//                //        {
//                //            Block.Info tmp = Block.Events.GetBlock(loc);

//                //            // khub in khune gablan, joz'e khune ii boode;
//                //            if (tmp == info)
//                //                continue;

//                //            if (tmp.IsPath)
//                //            {
//                //                foo = true;
//                //                break;
//                //            }
//                //        }
//                //    }
//                //    if (foo)
//                //    {
//                //        Block.Info[] _tmp_ = new Block.Info[GetArrayElementCount(Valids)];
//                //        foreach (Block.Info i in Valids)
//                //        {
//                //            if (i != _tmp)
//                //                _tmp_[counter++] = i;
//                //        }
//                //        Valids = _tmp_;
//                //    }
//                //    else
//                //    {
//                //        break;
//                //    }

//                //}
/////MAZE I        
//#region IsProper function and associated functions

//        /// <summary>
//        /// Checks if location of Y coordinate is cool with specific block
//        /// </summary>
//        /// <param name="Y">A specific coordinate of Y</param>
//        /// <param name="i">Demanded block to check</param>
//        /// <returns>if is proper location returns true; otherwise returns false;</returns>
//        private bool IsProper(BlockLocation.Location location, Block.Info i)
//        {
//            int CUY = location.Y + 1;
//            int CDY = location.Y - 1;

//            BlockLocation.Location l = new BlockLocation.Location(location.Y + 1, CDY);
//            if (CheckValidPathBlock(l, i.location))
//                return false;

//            l = new BlockLocation.Location(location.Y - 1, CDY);
//            if (CheckValidPathBlock(l, i.location))
//                return false;

//            l = new BlockLocation.Location(location.Y + 1, CUY);
//            if (CheckValidPathBlock(l, i.location))
//                return false;

//            l = new BlockLocation.Location(location.Y - 1, CUY);
//            if (CheckValidPathBlock(l, i.location))
//                return false;

//            // inja nemikhad ke location haye (location.Y, CUY) va (location.Y, CDY) haro check koni choon ona momkenan ke be onvane path entekhab shavand;

//            return true;
//        }

//        /// <summary>
//        /// Checks if 2 location is same;
//        /// </summary>
//        /// <param name="location_1">First location</param>
//        /// <param name="location_2">Second location</param>
//        /// <returns>returns true if 2 location is same; otherwise returns false</returns>
//        private bool CheckValidPathBlock(BlockLocation.Location location_1, BlockLocation.Location location_2)
//        {

//            /// sth like sqrt, in puzzle checker!!;-))
//            //throw new NotImplementedException("tamamiye moshkelate in path init kardan az inja nashi mishe, man felan naytonestam ke factor'e khub bara filtering block ha peyda konam ...! ro on gesmate ' return ' bayad kar sheeeee! bagiyeye chiza haaleeee");

//            if (!location_1.IsReferenced || !location_2.IsReferenced)
//                return false;

//            //if (GetDestinySlope(location_1, location_2) == 0)
//              //  return false;

//            return location_1.X > 0 && location_1.Y > 0 && location_1.X <= Blocks.X && location_1.Y <= Blocks.Y &&
//                location_2.X > 0 && location_2.Y > 0 && location_2.X <= Blocks.X && location_2.Y <= Blocks.Y;
//        }

//        /// <summary>
//        /// Checks if demanded block is proper with the block in specific direction @ of block
//        /// </summary>
//        /// <param name="dir">the block @ the demanded block</param>
//        /// <param name="block">The demanded block</param>
//        /// <returns>returns if is proper; otherwise returns false;</returns>
//        private bool IsProper(Blocks.Direction dir, Block.Info block)
//        {
//            try
//            {

//                switch (dir)
//                {
//                    case Blocks.Direction.Center:
//                        return false;
//                }

//                BlockLocation.Location tmp = BlockLocation.Location.GetLocation(dir, block);

//                foreach (Blocks.Direction i in directions)
//                {
//                    if (IsCoordinated(i))
//                    {
//                        if (i != Blocks.Direction.Center)
//                        {
//                            BlockLocation.Location foo = BlockLocation.Location.GetLocation(i, tmp);
//                            if (Block.Events.GetBlock(foo).IsPath == true)
//                                return false;
//                        }
//                    }
//                }

//                bool c1 = CheckValidPathBlock(tmp, block.location);

//                bool c2 = tmp.X != 1 && tmp.Y != 1;

//                return c1 && c2;
//            }
//            catch
//            {
//                return false;
//            }
//        }

//        #endregion

/////MazeII
//        #region Class's main functions

//        /// <summary>
//        /// Starts Calculating of OpenPath;
//        /// </summary>
//        /// <param name="initBlock">Initial block where path is starting;s</param>
//        /// <param name="Approximate">An approximate location which this path heads for;</param>
//        private void StartCalculateing(Block.Info initBlock, BlockLocation.Location Approximate)
//        {
//            #region Init vars

//            List<Block.Info> valids = new List<Block.Info>();

//            Block.Info info = initBlock;

//            int limit = Blocks.X;

//            Random r=new Random(RandomSeed);

//            #endregion

//            #region path calculator

//            do
//            {
//                try
//                {
//                    valids.Clear();

//                    info = OpenPath.BlockSeries[countOfBlock];

//                    if (info.location.X == limit)
//                        break;

//                    foreach (Blocks.Direction j in directions)
//                    {
//                        if (IsCoordinated(j) && IsProper(j, info) && foo(j,info))
//                            valids.Add(Block.Events.GetBlock(j, info));
//                    }

//                    SortByHeuristicValue(ref valids, Approximate);

//                    Block.Info tmp = valids[r.Next(0, valids.Count - 1)];

//                    tmp.IsPath = true;

//                    Block.Events.MakePath(tmp);

//                    OpenPath.BlockSeries.Add(tmp);

//                    countOfBlock++;
//                }
//                catch (ArgumentOutOfRangeException) { }

//            } while (info.location.X != limit);

//            #endregion
//        }

//        private bool foo(Blocks.Direction j, Block.Info info)
//        {
//            Block.Info _info = Block.Events.GetBlock(j, info);
//            foreach (Block.Info i in OpenPath.BlockSeries)
//            {
//                if (_info.location == i.location)
//                    return false;
//            }
//            return true;
//        }
        
//        #endregion

//        #region Heuristic matters

//        /// <summary>
//        /// Sort list of blocks in order to heuristic value desc;
//        /// </summary>
//        /// <param name="blocks">List of blocks</param>
//        /// <param name="Approximate">An approximate location which blocks' path heads for;</param>
//        void SortByHeuristicValue(ref List<Block.Info> blocks,BlockLocation.Location Approximate)
//        {

//            List<HeuristicValue> tmp = new List<HeuristicValue>();

//            foreach (Block.Info i in blocks)
//            {
//                HeuristicValue foo = new HeuristicValue(i, GetDestinySlope(i.location, Approximate));
//                if (foo.value != 0)
//                    tmp.Add(foo);
//            }

//            //tmp.Sort(new Comparison<HeuristicValue>(CompareHeuristicValues));

//            blocks.Clear();
//            foreach (HeuristicValue i in tmp)
//            {
//                blocks.Add(i.block);
//            }
//        }

//        /// <summary>
//        /// A compare function in order to sort list of blocks ordered by heuristic values desc;
//        /// </summary>
//        /// <param name="a">First block's heuristic value;</param>
//        /// <param name="b">Second block's heuristic value;</param>
//        /// <returns>return -1 if a.value less than b.balue; 0 if a.value == b.value; 1 if a.value is great than b.value;</returns>
//        int CompareHeuristicValues(HeuristicValue a, HeuristicValue b)
//        {
//            if (a.value > b.value)
//                return 1;
//            if (a.value == b.value)
//                return 0;
//            return -1;
//        }

//        /// <summary>
//        /// This is our heuristic function
//        /// </summary>
//        /// <param name="location">Location of block;</param>
//        /// <param name="approximate">Approximate location of destiny block</param>
//        /// <returns>Value of calculated heuristic value, related to specific block</returns>
//        private int GetDestinySlope(BlockLocation.Location location, BlockLocation.Location approximate)
//        {
//            try
//            {
//                double y = Math.Abs(location.Y - approximate.Y);
//                double x = Math.Abs(location.X - approximate.X);

//                return (int)((y / x) * 10000);
//            }
//            catch (DivideByZeroException) { return 0; }
//        }
//        #endregion

//        #region Conditional Functions in here

//        /// <summary>
//        /// checks if entery direction is one of the 4 main direction in 2D coordinate
//        /// </summary>
//        /// <param name="i">Demanded direction</param>
//        /// <returns>returns true if entery direction is one of the 4 main direction is 2D coordinate</returns>
//        private bool IsCoordinated(Blocks.Direction i)
//        {
//            switch (i)
//            {
//                case Blocks.Direction.LeftDown:
//                case Blocks.Direction.LeftUp:
//                case Blocks.Direction.RightDown:
//                case Blocks.Direction.RightUp:
//                    return false;
//            }
//            return true;
//        }

//        #endregion

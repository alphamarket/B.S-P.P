﻿using System.Collections.Generic;

namespace Mouse_Maze
{
    partial class Blocks
    {
        #region Enumerations

        /// <summary>
        /// type of the path;
        /// </summary>
        public enum PathType { DeadPath, OpenPath }

        /// <summary>
        /// Direction which will need in further operation in order to sign block's direction a sign of specific block;
        /// </summary>
        public enum Direction { Left, LeftUp, LeftDown, Center, CenterUp, CenterDown, Right, RightUp, RightDown }

        /// <summary>
        /// Ye enum ke jahat haye asli ro be ma mide;
        /// </summary>
        public enum CoordinatedD{ Left, Right, CenterDown, CenterUp }

        #endregion

        #region Class' main functions

        /// <summary>
        /// This class is in order to keep a blocks collection which create a path, and the type of the path;
        /// </summary>
        public class Path : System.Collections.IEnumerable
        {
            /// <summary>
            /// A series of blocks which create a path;
            /// </summary>
            List<Block.Info> BlockSeries = new List<Block.Info>();

            /// <summary>
            /// Type of the current path;
            /// </summary>
            PathType pathType = PathType.DeadPath;

            public Path(PathType pathType)
            {
                this.pathType = pathType;
            }

            public PathType Type
            {
                get { return pathType; }
            }

            public void Add(Block.Info block)
            {
                BlockSeries.Add(block);
            }

            public int Count
            {
                get { return BlockSeries.Count; }
            }

            public void Clear()
            {
                BlockSeries.Clear();
            }

            public Block.Info this[int index]
            {
                get
                {
                    return BlockSeries[index];
                }
            }

            public System.Collections.IEnumerator GetEnumerator()
            {
                return BlockSeries.GetEnumerator();
            }
        }

        #endregion
    }
}

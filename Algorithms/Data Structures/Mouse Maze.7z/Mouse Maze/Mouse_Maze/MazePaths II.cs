﻿using System;
using System.Collections.Generic;

namespace Mouse_Maze
{
    partial class MazePathes
    {

        #region Variables Init

        /// <summary>
        /// A random object which will handle randomizing selection of dead-ends blocks;
        /// </summary>
        Random BlockSelector;

        /// <summary>
        /// A list of column which hold maze's columns info;
        /// </summary>
        List<Blocks.Column> MazeColumns = new List<Blocks.Column>();

        /// <summary>
        /// An randon number generator which will use in StackCalculator function to initialize open path
        /// </summary>
        private Random StackRandomSelector;

        #endregion

        #region Initialize Maze Pattern And Related Funcions

        /// <summary>
        /// Initialize whole entire maze pathes and made some block in each column
        /// </summary>
        /// <param name="initBlock">The block which all pathes will be started</param>
        private void InitialMazePattern()
        {
            BlockSelector = new Random(RandomSeed);

            foreach (Blocks.Column i in MazeColumns)
            {
                switch (i.Type)
                {
                    case Block.Events.ColumnType.Even:
                        for (int j = 0; j < 3; j++)
                        {
                            Block.Info tmp = i[BlockSelector.Next(0, i.Count - 1)];
                            if (tmp != initBlock)
                            {
                                tmp.IsPath = false;
                                i.AddExceptionBlock(tmp);
                            }
                        }
                        break;
                }
            }
        }

        #endregion

        #region Initialize An Open Path And Related Functions

        /// <summary>
        /// Initilize an open maze exactly from initial block to approximate block;
        /// </summary>
        /// <param name="initBlock">A block which all pathes started from</param>
        /// <param name="Approximate">A approximate block which open path will end there</param>
        private void InitialOpenPath(Block.Info initBlock)
        {
            StackRandomSelector=new Random(RandomSeed);

            StackCalculator(MazeColumns[1], initBlock);
            
        }

        /// <summary>
        /// An Stack work flow handler which will handle open path generating by self-recursion technique
        /// </summary>
        /// <param name="column">A column which indecate open path generating status, and the O.P.G process will start with this entery pramater</param>
        /// <param name="initBlock">An initial block which O.P.G will start with this block, this block should be an start block for maze</param>
        private void StackCalculator(Blocks.Column column, Block.Info initBlock)
        {
            if (RecursionSatisfied(column,initBlock))
            {
                return;
            }

            switch (column.Type)
            {

                case Block.Events.ColumnType.Even:

                    ValidateNextColumn(column, initBlock);

                    PushStack(InitialOpenBlock(column, initBlock),column.ColumnNo + 1);

                    break;


                case Block.Events.ColumnType.Odd:

                    // Age andazeye maze'emon, zooj bood, akharin block dar PushStack exception mindaze, bad onja ye done az vahed'e pishravimon kam mishe, bara hamin bejaye inke zooj bashe fard mishe, ke 2 inja malom mishe va baz migardim;

                    return;
            }
        }

        /// <summary>
        /// Checks if rescurtion condtion is satisfied or not
        /// </summary>
        /// <param name="column">current column which O.P.G process is into it</param>
        /// <param name="initBlock">The initial block of current column</param>
        /// <returns>return true if condtions is satisfied and the O.P.G process could be terminated</returns>
        private bool RecursionSatisfied(Blocks.Column column, Block.Info initBlock)
        {
            // inja nabayad, condition'e column.Type==Odd check she, choon ma niyaz darim ke 2 function'e ' ValidateNextColumn ' next column ro che konim ta hatman ye maze'e ma payan dashte bashe!!
            if (Blocks.X % 2 != 0 && Blocks.X == column.ColumnNo)
            {
                initBlock.IsPath = true;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Handle Push action of stack in O.P.G process
        /// </summary>
        /// <param name="io">The block should be pushed</param>
        /// <param name="next">Number of next column to push</param>
        private void PushStack(Block.Info io,int next)
        {
            try
            {
                StackCalculator(MazeColumns[next], io);
            }
            catch (ArgumentOutOfRangeException)
            {
                StackCalculator(MazeColumns[next - 1], io);
            }
        }

        /// <summary>
        /// handle intializing of Open block for current column which mouse in maze can move from current column to the next column
        /// </summary>
        /// <param name="column">Current column</param>
        /// <param name="initBlock">Entery block to this column</param>
        /// <returns>An opened block of nex column related to current column</returns>
        private Block.Info InitialOpenBlock(Blocks.Column column, Block.Info initBlock)
        {

            int Rand_block;

            RandomBlockSelection(GetsLimitBlocks(column, initBlock), out Rand_block);

            Block.Info tmp = Block.Events.GetBlock(column.ColumnNo, Rand_block);

            Block.Info further = Block.Events.GetBlock(Blocks.CoordinatedD.Right, tmp);

            if (!further.IsNullBlock)
            {
                if (!further.IsPath)
                {
                    further.IsPath = true;
                }
            }
            return further;

        }

        /// <summary>
        /// Validate and checks next column limit blocks status in order to eleminate dead-end O.P.G process
        /// </summary>
        /// <param name="column">Current column which OPG proc' is into it</param>
        /// <param name="initBlock">initial block of current column</param>
        private void ValidateNextColumn(Blocks.Column column, Block.Info initBlock)
        {
            Block.Info _tmp = Block.Events.GetBlock(Blocks.CoordinatedD.Right, initBlock);

            if (!_tmp.IsPath)
            {
                _tmp.IsPath = true;

                column.Exceptions.Remove(_tmp);
            }
        }

        /// <summary>
        /// Selects an arndom block, between limit blocks and return Y coordinate of selected block
        /// </summary>
        /// <param name="limits">Array of limit block, Array.Length should be 2</param>
        /// <param name="Rand_block">An out argu which will be initialize and will indecate of Y coordinate of selected block</param>
        private void RandomBlockSelection(Block.Info[] limits, out int Rand_block)
        {
            try
            {
                try
                {
                    Rand_block = StackRandomSelector.Next(limits[0].Location.Y + 1, limits[1].Location.Y - 1);
                }
                catch (ArgumentOutOfRangeException)
                {
                    Rand_block = StackRandomSelector.Next(limits[1].Location.Y + 1, limits[0].Location.Y - 1);
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                Rand_block = limits[StackRandomSelector.Next(0, 19) / 10].Location.Y;
            }
        }

        /// <summary>
        /// Block haye limit ro dar ye soton, ke beyneshon ye block grar dare ro mohasebe mikone
        /// </summary>
        /// <param name="i"></param>
        /// <param name="initBlock"></param>
        /// <returns>Ye arayeye be andazeye 2 ta ro bar migardoone</returns>
        private Block.Info[] GetsLimitBlocks(Blocks.Column i, Block.Info initBlock)
        {
            Block.Info[] tmp = new Block.Info[2];

            // Tavajoh she ke exception ha sort shodan,Ba asaye mokhtasate y sort shodan, acs;
            List<Block.Info> e = i.Exceptions;

            for (int J = 0; J < e.Count - 1; J++)
            {
                if (e[J].Location.Y < initBlock.Location.Y && initBlock.Location.Y < e[J + 1].Location.Y)
                {
                    tmp[0] = e[J];
                    tmp[1] = e[J + 1];
                }
            }

            if (tmp[0]==null)
            {
                if (e[0].Location.Y > initBlock.Location.Y)
                {
                    tmp[0] = e[0];
                    tmp[1] = new Block.Info(null, new BlockLocation.Location(i.ColumnNo, 1));
                }
                else
                {
                    tmp[0] = new Block.Info(null, new BlockLocation.Location(i.ColumnNo, Blocks.Y - 2));
                    tmp[1] = e[e.Count - 1];
                }
            }

            return tmp;
        }

        #endregion

        #region Sundries

        /// <summary>
        /// searches and will find intitial block in first column of maze
        /// </summary>
        /// <returns>Initial block</returns>
        static Block.Info FindInitialBlock()
        {
            Blocks.Column fclmn = Block.Events.GetColumns()[0];

            foreach (Block.Info i in fclmn)
            {
                if (i.IsPath)
                    return i;
            }
            return new Block.Info();
        }

        #endregion

    }
}
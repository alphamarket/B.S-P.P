﻿namespace Mouse_Maze
{
    partial class GameSize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this._Y = new System.Windows.Forms.NumericUpDown();
            this._X = new System.Windows.Forms.NumericUpDown();
            this.OkBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.remmberCHB = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this._Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._X)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Number of blocks parallel with X direction";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Number of blocks parallel with Y direction";
            // 
            // _Y
            // 
            this._Y.Location = new System.Drawing.Point(262, 60);
            this._Y.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this._Y.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this._Y.Name = "_Y";
            this._Y.Size = new System.Drawing.Size(120, 20);
            this._Y.TabIndex = 1;
            this._Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this._Y.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // _X
            // 
            this._X.Location = new System.Drawing.Point(262, 29);
            this._X.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this._X.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this._X.Name = "_X";
            this._X.Size = new System.Drawing.Size(120, 20);
            this._X.TabIndex = 0;
            this._X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this._X.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // OkBtn
            // 
            this.OkBtn.Location = new System.Drawing.Point(235, 103);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(75, 23);
            this.OkBtn.TabIndex = 2;
            this.OkBtn.Text = "Ok";
            this.OkBtn.UseVisualStyleBackColor = true;
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(316, 103);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 3;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // remmberCHB
            // 
            this.remmberCHB.AutoSize = true;
            this.remmberCHB.Location = new System.Drawing.Point(15, 107);
            this.remmberCHB.Name = "remmberCHB";
            this.remmberCHB.Size = new System.Drawing.Size(111, 17);
            this.remmberCHB.TabIndex = 6;
            this.remmberCHB.Text = "Remmber this size";
            this.remmberCHB.UseVisualStyleBackColor = true;
            // 
            // GameSize
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(403, 138);
            this.Controls.Add(this.remmberCHB);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.OkBtn);
            this.Controls.Add(this._X);
            this.Controls.Add(this._Y);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "GameSize";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Size of game";
            ((System.ComponentModel.ISupportInitialize)(this._Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._X)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown _Y;
        private System.Windows.Forms.NumericUpDown _X;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.CheckBox remmberCHB;
    }
}
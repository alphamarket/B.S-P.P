﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mouse_Maze
{
    class Solve
    {
        public enum Type { Stack, Recursive}
        class Node
        {
            Block.Info current;
            List<Block.Info> child;
            public Node(Block.Info currentBlock, List<Block.Info> Childs)
            {
                this.current = currentBlock;
                this.child = Childs;
            }

            public Block.Info Current
            {
                get
                {
                    return current;
                }
                set
                {
                    current = value;
                }
            }
            public List<Block.Info> Children
            {
                get { return child; }
                set { child = value; }
            }
            public Block.Info PopChild()
            {
                if (child.Count != 0)
                {
                    Block.Info tmp = child[0];
                    child.RemoveAt(0);
                    return tmp;
                }
                return new Block.Info();
            }
            public bool IsDeadBlock
            {
                get { return child.Count == 0; }
            }
            public override string ToString()
            {
                return current.ToString();
            }
        }
        Stack<Block.Info> path;

        Blocks.Path solution;

        List<Blocks.CoordinatedD> directions;

        Boolean recurtionSatisfied;

        public Blocks.Path Solution
        {
            get { return solution; }
        }

        public bool HasSolved
        {
            get { return recurtionSatisfied; }
        }
        
        public Solve(Type t)
        {
            InitializeVariables();
            switch (t)
            {
                case Type.Stack:
                    R(MazePathes.InitialBlock.Parent);
                    break;
                case Type.Recursive:
                    StackCalculation(MazePathes.InitialBlock, MazePathes.InitialBlock);
                    break;
            }
            Finalizing(t);
        }

        private void R(Block.Info info)
        {
            Stack<Node> stack = InitializeStack(info);

            Node tmp;

            while ((tmp=stack.Pop()).Current.Location.X!=Blocks.X)
            {
                if (!tmp.IsDeadBlock)
                {
                    Block.Info _t = tmp.PopChild();

                    stack.Push(tmp);

                    stack.Push(new Node(_t, GetChildren(_t, tmp.Current)));
                }
            }

            // age barname be inja berese yani ke maze hal shode 

            // in tmp akharin block'e path hastesh ke motaleg be maze's path'e
            stack.Push(tmp);

            // elam mikonim ke maze hal shode
            recurtionSatisfied = true;

            // stack ro varon mikonim va ye stack'e path misazim
            while (stack.Count != 0)
                path.Push(stack.Pop().Current);
        }

        /// <summary>
        /// stack ro init mikone
        /// </summary>
        /// <param name="info">Entery point of maze</param>
        /// <returns>initialized stack</returns>
        private Stack<Node> InitializeStack(Block.Info info)
        {
            Node n = new Node(info, GetChildren(info, info.Parent));

            Stack<Node> st = new Stack<Node>();

            st.Push(n);

            return st;
        }

        /// <summary>
        /// Var ha ro init mikonim
        /// </summary>
        private void InitializeVariables()
        {
            directions = MazePathes.Directions;
            
            solution = new Blocks.Path(Blocks.PathType.OpenPath);
            
            recurtionSatisfied = false;
            
            path = new Stack<Block.Info>();
        }

        /// <summary>
        /// Akhrin karaye hal ro anjam midim
        /// </summary>
        /// <param name="t">No'e raveshe hali ke bahash hal shode</param>
        private void Finalizing(Type t)
        {
            switch (t)
            {
                case Type.Recursive:
                    path.Push(MazePathes.InitialBlock);

                    path.Push(MazePathes.InitialBlock.Parent);
                    break;
            }

            foreach (Block.Info i in path)
            {
                solution.Add(i);
            }
        }

        private void ClearFields()
        {
            try
            {
                path.Clear();

                directions.Clear();

                solution.Clear();
            }
            catch (NullReferenceException) { }
        }

        private void StackCalculation(Block.Info child,Block.Info parent)
        {
            List<Block.Info> Children = GetChildren(child,parent);

            if (RecursionSatisfied(Children, child))
                return;

            foreach (Block.Info i in Children)
            {
                StackCalculation(i, child);

                if (recurtionSatisfied)
                {
                    SavePath(i);
                    return;
                }
            }
        }

        private void SavePath(Block.Info block)
        {
            path.Push(block);
        }

        private bool RecursionSatisfied(List<Block.Info> Children, Block.Info child)
        {
            if (child.Location.X == Blocks.X)
            {
                recurtionSatisfied = true;
                return true;
            }

            if (Children.Count == 0)
                return true;

            return false;
        }

        private List<Block.Info> GetChildren(Block.Info child, Block.Info parent)
        {
            List<Block.Info> children = new List<Block.Info>(3);

            Block.Info tmp;

            foreach (Blocks.CoordinatedD i in directions)
            {
                tmp = Block.Events.GetBlock(i, child);

                if (!tmp.IsNullBlock)
                {
                    if (PathPossibility(tmp, child))
                    {
                        if (tmp != parent)
                        {
                            if (tmp.IsPath)
                            {
                                children.Add(tmp);
                            }
                        }
                    }
                }
            }

            children.Sort(new Comparison<Block.Info>(MakeHeuristic));

            return children;
        }

        private int MakeHeuristic(Block.Info child1,Block.Info child2)
        {
            if (child1.Location.X < child2.Location.X)
                return 1;

            if (child1.Location.X == child2.Location.X)
            {
                int no1 = Math.Abs(child1.Location.Y - Blocks.Y),
                    no2 = Math.Abs(child2.Location.Y - Blocks.Y);
                
                if (no1 > no2)
                {
                    return -1;
                }
                
                if (no1 == no2)
                    return 0;
                
                return 1;
            }
            
            return -1;
        }

        private bool PathPossibility(Block.Info child,Block.Info parent)
        {
            if (child.Location.X < parent.Location.X)
                return false;

            return true;
        }
    }
}

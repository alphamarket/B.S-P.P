﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mouse_Maze
{
    public partial class Splash : Form
    {
        private static Form target;
        public Splash()
        {
            InitializeComponent();
        }

        public static void Start()
        {
            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(showing));
            t.Start();

            target = new GamePanel();

            t.Abort();
        }

        static void showing()
        {
            Splash tmp = new Splash();
            tmp.Show();
        }
        public static Form SplashTarget
        {
            get
            {
                return target;
            }
        }
    }
}

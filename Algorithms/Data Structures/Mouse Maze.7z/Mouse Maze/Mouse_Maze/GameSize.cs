﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mouse_Maze
{
    public partial class GameSize : Form
    {
        public int X
        {
            get { return int.Parse(_X.Value.ToString()); }
        }
        public int Y
        {
            get { return int.Parse(_Y.Value.ToString()); }
        }
        public GameSize(int x, int y)
        {
            InitializeComponent();
            _X.Value = x;
            _Y.Value = y;

            remmberCHB.Checked = !(x == 50 && y == 50);
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void OkBtn_Click(object sender, EventArgs e)
        {
            if (remmberCHB.Checked)
            {
                Properties.Settings.Default.Size_X = int.Parse(_X.Value.ToString());
                Properties.Settings.Default.Size_Y = int.Parse(_Y.Value.ToString());
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.Size_X = 50;
                Properties.Settings.Default.Size_Y = 50;
            }
            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Mouse_Maze
{
    class Block
    {
        #region BlockInfo region

        /// <summary>
        /// Ye class bara negah dariye info haye ye block!
        /// </summary>
        public class Info
        {
            /// <summary>
            /// Object'e block
            /// </summary>
            public System.Windows.Forms.Button Block;
            
            /// <summary>
            /// Location'e block;
            /// </summary>
            public BlockLocation.Location Location;

            /// <summary>
            /// Parent of current block;
            /// </summary>
            public Info Parent;

            /// <summary>
            /// Listi az child haye current block
            /// </summary>
            public List<Info> Child;
            
            /// <summary>
            /// A check mark if current block is belong to block series of a path;
            /// </summary>
            private bool isPath;

            public override string ToString()
            {
                return "Block Location : [ " + Location.X + " , " + Location.Y + " ]";
            }

            public bool IsPath
            {
                set
                {
                    isPath = value;
                    Block.Visible = !value;
                }
                get { return isPath; }
            }
            /// <summary>
            /// Ctor
            /// </summary>
            /// <param name="block">An object of block</param>
            /// <param name="location">An Object of location of block</param>
            public Info(System.Windows.Forms.Button block, BlockLocation.Location location)
            {
                this.Block = block;
                this.Location = location;
                this.Parent = null;
                this.isPath = false;
                Child = new List<Info>(3);
            }

            /// <summary>
            /// Ctor
            /// </summary>
            /// <param name="block">An object of block</param>
            /// <param name="location">An Object of location of block</param>
            /// <param name="Parent">An object of parent of current block</param>
            public Info(System.Windows.Forms.Button block, BlockLocation.Location location, Info Parent)
            {
                this.Block = block;
                this.Location = location;
                this.Parent = Parent;
                this.isPath = false;
                Child = new List<Info>(3);
            }

            public Info()
            {
                Block = null;
                Location = null;
                Parent = null;
                isPath = false;
            }

            public bool IsInitialBlock
            {
                get { return isPath && Parent == null; }
            }

            public bool IsNullBlock
            {
                get { return Block == null && Parent == null; }
            }
        }

        #endregion

        #region BlockEvents region

        /// <summary>
        /// in class barkhi info ha va function haii ro marboot be path/block mishe ro handle mikone!!
        /// </summary>
        public class Events :System.Collections.IEnumerable
        {
            /// <summary>
            /// a variable which will keep blocks' location
            /// </summary>
            static BlockLocation blocks = new BlockLocation();

            /// <summary>
            /// returns list maded blocks
            /// </summary>
            public static List<Block.Info> ListOfBlocks
            {
                get { return blocks.List; }
            }

            public enum ColumnType { Even, Odd }

            /// <summary>
            /// Get blocks ordered by columns
            /// </summary>
            /// <returns>List of columns</returns>
            public static List<Blocks.Column> GetColumns()
            {
                List<Blocks.Column> columns = new List<Blocks.Column>();

                for (int i = 1; i <= Blocks.X; i++)
                {
                    List<Block.Info> _blocks = new List<Info>();

                    for (int j = 2; j <= Blocks.Y; j++)
                    {
                        _blocks.Add(blocks[i, j]);
                    }

                    columns.Add(new Blocks.Column(_blocks, i));
                }

                return columns;
            }

            /// <summary>
            /// Block'e block ro ke 2 mokhtasate X,Y gara dare ro save mikone & parent ro save mikone!
            /// </summary>
            /// <param name="block"></param>
            /// <param name="X"></param>
            /// <param name="Y"></param>
            /// <param name="Parent"></param>
            public static void SaveBlock(ref System.Windows.Forms.Button block, int X, int Y, ref Info Parent)
            {
                blocks.SaveBlock(new Info(block, new BlockLocation.Location(X, Y), Parent));
            }

            /// <summary>
            /// Block'e block ro ke 2 mokhtasate X,Y gara dare ro save mikone;
            /// </summary>
            /// <param name="block"></param>
            /// <param name="X"></param>
            /// <param name="Y"></param>
            public static void SaveBlock(ref System.Windows.Forms.Button block, int X, int Y)
            {
                blocks.SaveBlock(new Info(block, new BlockLocation.Location(X, Y)));
            }

            public static void SaveSide(ref System.Windows.Forms.Button block, int X, int Y)
            {
                blocks.SaveSide(new Info(block, new BlockLocation.Location(X, Y)));
            }
            
            /// <summary>
            /// ye Block'ii ba info'e khasi save mikone;
            /// </summary>
            /// <remarks>in function parent ro save nemikone;</remarks>
            /// <param name="info"></param>
            public static void SaveBlock(ref Info info)
            {
                SaveBlock(ref info.Block, info.Location.X, info.Location.Y);
            }
            
            /// <summary>
            /// Handle blocks disposing
            /// </summary>
            public static void ClearBlocks()
            {
                blocks.Clear();
            }

            /// <summary>
            /// Gets the specific block at specific location
            /// </summary>
            /// <param name="location">demanded location</param>
            /// <returns>The block at demanded location</returns>
            public static Info GetBlock(BlockLocation.Location location)
            {
                Info info = blocks[location.X, location.Y];
                return info;
            }

            /// <summary>
            /// Get blockinfo in specific direction of specific block
            /// </summary>
            /// <param name="dir">demanded direction</param>
            /// <param name="block">target block</param>
            /// <returns>BlockInfo of block which is in specific direction of specific block</returns>
            public static Info GetBlock(Blocks.CoordinatedD dir, Info block)
            {
                BlockLocation.Location loc = BlockLocation.Location.GetLocation(dir, block);

                return blocks[loc.X, loc.Y];
            }

            /// <summary>
            /// Get blockinfo of specific block
            /// </summary>
            /// <param name="block">target block</param>
            /// <returns>BlockInfo of block of specific block</returns>
            public static Info GetBlock(System.Windows.Forms.Button block)
            {
                return blocks[block];
            }
            
            /// <summary>
            /// Gets the specific block at specific coordinate
            /// </summary>
            /// <param name="X">Location at specific X coordinate</param>
            /// <param name="Y">Location at specific Y coordinate</param>
            /// <returns>The block at demanded coordinates</returns>
            public static Info GetBlock(int X, int Y)
            {
                return GetBlock(new BlockLocation.Location(X, Y));
            }
            
            /// <summary>
            /// Get block with Y=0 location at specific coordinate of X
            /// </summary>
            /// <param name="X">Location at specific X coordinate</param>
            /// <returns>The block at demanded X coordinate with Y=0</returns>
            public static Info Get_X_Block(int X)
            {
                return GetBlock(new BlockLocation.Location(X, 1));
            }

            /// <summary>
            /// Get block with X=0 location at specific coordinate of Y
            /// </summary>
            /// <param name="Y">Location at specific Y coordinate</param>
            /// <returns>The block at demanded Y coordinate with X=0</returns>
            public static Info Get_Y_Block(int Y)
            {
                return GetBlock(new BlockLocation.Location(1, Y));
            }

            /// <summary>
            /// Make specific block visible to false, in order of making a path
            /// </summary>
            /// <param name="child">A block info object</param>
            public static void MakePath(Info child, Info Parent)
            {
                if (!child.IsNullBlock)
                {

                    child.IsPath = true;

                    child.Parent = Parent;

                    if (Parent != null && !Parent.Child.Contains(child))
                        Parent.Child.Add(child);
                }
            }

            /// <summary>
            /// A list which will hold select block as path in non-automatic process of OPG
            /// </summary>
            static List<Info> handly = new List<Info>();

            /// <summary>
            /// Makes specific block az path if status is true;
            /// </summary>
            /// <param name="block"></param>
            /// <param name="status"></param>
            public static void BlockAsPath(Info block,bool status)
            {
                Info info = blocks[block.Location];

                info.IsPath = status;

                if (status)
                {
                    handly.Add(block);
                }
                else
                {
                    handly.Remove(info);
                }
            }

            /// <summary>
            /// handle making selected block as path if status is true; [ blocks which marked as path in ' BlockAsPath ' function ]
            /// </summary>
            /// <param name="status"></param>
            public static void SelectedBlockAsPath(bool status)
            {
                if (status)
                {
                    foreach (var i in handly)
                    {
                        MakePath(i, null);
                    }
                }
                else
                {
                    foreach (var i in handly)
                    {
                        i.IsPath = false;
                        i.Block.BackColor = Blocks.BaseBlock.BackColor;
                    }
                }
            }

            /// <summary>
            /// An enumerator
            /// </summary>
            /// <returns></returns>
            public System.Collections.IEnumerator GetEnumerator()
            {
                throw new NotImplementedException();
            }
        }

        #endregion
    }
}

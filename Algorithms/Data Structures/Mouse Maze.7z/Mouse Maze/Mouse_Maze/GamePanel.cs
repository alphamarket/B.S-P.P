﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Mouse_Maze
{
    public partial class GamePanel : Form
    {

        public GamePanel()
        {
            InitializeComponent();

            toolStripComboBox1.SelectedIndex = 0;

            reInitializeToolStripMenuItem_Click(new object(), new EventArgs());
        }

        void SetPanelRight(Panel panel)
        {
            foreach (Control i in Controls)
            {
                if (i is Panel)
                    i.Visible = false;
            }
            panel.Visible = true;
            panel.Location = new Point(0, 0);
            this.Size = panel.Size;
            Application.DoEvents();
        }

        private void GamePanel_Load(object sender, EventArgs e)
        {
            panel1.Size = new Size(panel1.Controls[panel1.Controls.Count - 1].Location.X + 45, panel1.Controls[panel1.Controls.Count - 1].Location.Y + 60);
            Size = new Size(panel1.Size.Width, panel1.Size.Height + menuStrip1.Size.Height);
        }

        private void sizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                GameSize tmp = new GameSize(Blocks.X, Blocks.Y);

                if (tmp.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    Externals.Start(Externals.Windows.Wait);

                    Visible = false;

                    Application.DoEvents();

                    Blocks.InitializingBlocks.ResizeGame(Controls, tmp.X, tmp.Y);

                    solve = null;

                    clearSolutionToolStripMenuItem.Enabled = false;
                    
                    MazePathes pathes = new MazePathes();

                    Externals.StopAll();

                    Visible = true;

                    GamePanel_Load(new object(), new EventArgs());
                }
            }
            catch (FormatException er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Block.Events.SelectedBlockAsPath(true);
        }

        Solve solve;
        
        int time1, time2;
        
        private void solveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gameOptionsToolStripMenuItem.Enabled = false;

            clearSolutionToolStripMenuItem_Click(sender, e);

            Application.DoEvents();

            if (solve == null)
            {
                time1 = Environment.TickCount;

                solve = new Solve((Solve.Type)toolStripComboBox1.SelectedIndex);
                
                time2 = Environment.TickCount;

            }


            if (!solve.HasSolved)
            {
                System.Windows.Forms.MessageBox.Show("This maze has no solution ...", "No solution ...", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
                return;
            }

            foreach (Block.Info i in solve.Solution)
            {
                i.IsPath = false;
                
                i.Block.BackColor = Color.Black;
                
                Application.DoEvents();
                
                System.Threading.Thread.Sleep(100);
            }

            gameOptionsToolStripMenuItem.Enabled = true;

            MessageBox.Show("Maze solved by total move : " + solve.Solution.Count + " moves .\nIn " + ((double)(time2 - time1)/ 1000).ToString() + " seconds .", "Notification ....", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void GamePanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            Visible = false;

            Externals.StopAll();

            Externals.StopCurrent();
        }

        private void clearSolutionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (solve != null)
            {
                foreach (Block.Info i in solve.Solution)
                {
                    i.IsPath = true;
                    i.Block.BackColor = Blocks.BaseBlockBackColor;
                }
                clearSolutionToolStripMenuItem.Enabled = false;
            }
        }

        private void clearSolutionToolStripMenuItem_EnabledChanged(object sender, EventArgs e)
        {
            solveToolStripMenuItem.Enabled = !clearSolutionToolStripMenuItem.Enabled;
        }

        private void reInitializeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Externals.Start(Externals.Windows.Wait);

            reInitializeToolStripMenuItem.Enabled = false;

            this.Visible = false;
            
            Application.DoEvents();

            new Blocks.InitializingBlocks(panel1.Controls).CreateBlocks();

            panel1.Size = new Size(panel1.Controls[panel1.Controls.Count - 1].Location.X + 45, panel1.Controls[panel1.Controls.Count - 1].Location.Y + 60);

            Size = new Size(panel1.Size.Width, panel1.Size.Height + menuStrip1.Size.Height);

            solve = null;

            MazePathes pathes = new MazePathes();

            clearSolutionToolStripMenuItem.Enabled = false;

            reInitializeToolStripMenuItem.Enabled = true;

            this.Visible = true;

            Externals.Stop(Externals.Windows.Wait);
        }
    }
}
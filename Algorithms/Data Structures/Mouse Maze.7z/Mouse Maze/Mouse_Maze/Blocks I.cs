﻿using System;

namespace Mouse_Maze
{
    partial class Blocks
    {
        #region Global Variables Of Blocks

        static int x = 50, y = 50;

        static System.Windows.Forms.Button _BaseBlock = null;
        
        public static System.Windows.Forms.Button BaseBlock
        {
            get { return _BaseBlock; }
        }

        static System.Drawing.Color baseBlockBackColor;

        public static System.Drawing.Color BaseBlockBackColor
        {
            get { return baseBlockBackColor; }
        }

        /// <summary>
        /// returns current number of blocks parallel with X direction
        /// </summary>
        public static int X
        {
            get { return x; }
        }

        /// <summary>
        /// returns current number of blocks parallel with Y direction
        /// </summary>
        public static int Y
        {
            get { return y; }
        }

        #endregion

        #region InitializingBlocks

        /// <summary>
        /// in class block haye 
        /// </summary>
        public class InitializingBlocks
        {
            #region Varibales

            System.Windows.Forms.Control.ControlCollection Controls = null;
            System.Windows.Forms.Button BaseBlock = null;

            #endregion

            #region Class' main functions

            /// <summary>
            /// Handle recreation and resizing of game size, in both directions
            /// </summary>
            /// <param name="Controls">Controls</param>
            /// <param name="X">Number of blocks in X direction</param>
            /// <param name="Y">Number of blocks in Y direction</param>
            public static void ResizeGame(System.Windows.Forms.Control.ControlCollection Controls, int X, int Y)
            {
                InitializingBlocks tmp = new InitializingBlocks(Controls);
                x = X;
                y = Y;
                tmp.CreateBlocks();
            }

            /// <summary>
            /// a backup controls objects;
            /// </summary>
            static System.Windows.Forms.Control.ControlCollection DefControls = null;

            /// <summary>
            /// ye backup bara control ha ijad mikone;
            /// </summary>
            /// <param name="Controls">status'e current controls</param>
            public void SaveDefaultControls(System.Windows.Forms.Control.ControlCollection Controls)
            {
                DefControls = Controls;
            }

            /// <summary>
            /// retrieves backed up controls
            /// </summary>
            /// <returns>last saved controls backup</returns>
            public static System.Windows.Forms.Control.ControlCollection LoadDefaultControls()
            {
                return DefControls;
            }

            /// <summary>
            /// ctor
            /// </summary>
            /// <param name="form">A reference object to form;</param>
            public InitializingBlocks(System.Windows.Forms.Control.ControlCollection Controls)
            {
                x = Properties.Settings.Default.Size_X;
                y = Properties.Settings.Default.Size_Y;

                // checks if this is first time of block creation, so make a backup
                if (DefControls == null)
                {
                    this.Controls = Controls;

                    SaveDefaultControls(Controls);
                }
                // otherwise do this
                else
                {
                    // ye ReInit mikone;
                    Controls = LoadDefaultControls();

                    Block.Events.ClearBlocks();

                    this.Controls = Controls;
                }
            }

            /// <summary>
            /// An interface for blocks creation;
            /// </summary>
            public void CreateBlocks()
            {
                // Base Block maro init mikone ke bagiyeye block ha ro in block sakhte mishe;
                InitBaseBlock();

                // Block haye maro init mikone;
                InitializeBlocks();

                // Finalize creation of blocks
                DoFinalize();
            }

            /// <summary>
            /// Does finilzation;
            /// </summary>
            private void DoFinalize()
            {
                Controls.Owner.ResumeLayout(false);

                Controls.Owner.PerformLayout();
            }

            /// <summary>
            /// Block haye maro init mikone;
            /// </summary>
            private void InitializeBlocks()
            {
                // in for tedade khane haye ' Y ' 'e frame'e maro moshakhas mikone;
                for (int j = 1; j <= y; j++)
                {
                    // in for tedade khane haye ' X ' 'e frame'e maro moshakhas mikone;
                    for (int i = 1; i <= x; i++)
                    {
                        // block'e mojod dar khaneye [i,j] 'om ro misaze va be control haye in form add mikone;
                        Controls.Add(BlockInitailizer(i, j));
                    }
                }

            }

            /// <summary>
            /// A function which will handle block visible change events
            /// </summary>
            /// <param name="sender">The  terget block</param>
            /// <param name="e">event's argument</param>
            private void Blocks_VisibleChanged(object sender, EventArgs e)
            {
                System.Windows.Forms.Button tmp = (System.Windows.Forms.Button)sender;

                Block.Info info = Block.Events.GetBlock(tmp);
                info.IsPath = tmp.Visible;
                Block.Events.SaveBlock(ref info);
            }

            /// <summary>
            /// Block'e [i,j] 'ome frame ma ro init mikone; dar vage harmeye block ha properti haii ro daran ke 2 in function init shodan
            /// </summary>
            /// <param name="j">Block'e mokhatasate j 'om ro mehvare X</param>
            /// <param name="i">Block'e mokhatasate i 'om ro mehvare Y</param>
            /// <returns>Block'e sakhte shoda ro bar migardone</returns>
            private System.Windows.Forms.Control BlockInitailizer(int i, int j)
            {
                System.Windows.Forms.Button tmp = new System.Windows.Forms.Button();

                // size'e block ro ba asas'e size 'e ' BaseBlock ' init mikonim;
                tmp.Size = new System.Drawing.Size(BaseBlock.Size.Width, BaseBlock.Size.Height);

                // Location'e btn haro moshakhas mikone!! tavajoh ke age j va i az 0 shoro beshan magadire ezafe shode roye 
                tmp.Location = new System.Drawing.Point(BaseBlock.Location.X * (i + 1), BaseBlock.Location.Y * (j + 1));

                // enabled nemikonimesh; age auto nabashe enable = true; megdare avaliyeye auto=true hast;
                tmp.Enabled = false;
                
                tmp.TabStop = false;

                // Be elate inke in block ha enabled nistan, bara hamin be init kardan'e bagiyeye properti da niyazi nis;

                // in if baes mishe soston sazi sorat gire!!;
                if (i == 1 || j == 1 || i == x || j == y)
                {
                    tmp.UseVisualStyleBackColor = true;
                    tmp.BackColor = System.Drawing.Color.Brown;
                }
                //control'e ' new ' shode ro create mikonim;
                tmp.CreateControl();

                // Gabele dars mikone radife aval va akhar ro!!;
                if (j != 1 && j != y)
                {

                    // Tries 2 save block location
                    Block.Events.SaveBlock(ref tmp, i, j);

                    if (i != 1 && i != x)
                    {
                        if (i % 2 == 0 || j == 2 || j == y - 1)
                        {
                            Block.Events.GetBlock(i, j).IsPath = true;
                        }
                    }
                    
                }
                else
                {
                    tmp.Enabled = false;
                    Block.Events.SaveSide(ref tmp, i, j);
                }
                // block'e sakhte shoda ro barmigardoonim;
                return tmp;
            }

            /// <summary>
            /// in function ye base block ro init mikone ke bagiyeye block ha az ro in block sakhte mishan;
            /// </summary>
            private void InitBaseBlock()
            {
                BaseBlock = new System.Windows.Forms.Button();

                // Location init;
                BaseBlock.Location = new System.Drawing.Point(12, 12);

                // Size init;
                BaseBlock.Size = new System.Drawing.Size(15, 15);

                // Back color init;
                BaseBlock.BackColor = baseBlockBackColor = System.Drawing.SystemColors.Control;
                
            }

            #endregion

        }

        #endregion
    }
}
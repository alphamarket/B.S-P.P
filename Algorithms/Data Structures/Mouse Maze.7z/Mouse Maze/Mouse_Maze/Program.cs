﻿using System;
using System.Windows.Forms;

namespace Mouse_Maze
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            ValidateCurrentProcess();

            Application.EnableVisualStyles();

            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new GamePanel());

            Externals.StopAll();
        }
        private static void ValidateCurrentProcess()
        {
            foreach (var i in System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName))
            {
                if (i.Id != System.Diagnostics.Process.GetCurrentProcess().Id)
                    i.Kill();
            }

            try
            {
                Externals.Start(Externals.Windows.Wait);
                Externals.StopAll();
            }
            catch
            {
                MessageBox.Show("One of the essential file has been missed, can not run the maze ! ", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Externals.StopAll();
                //Externals.StopCurrent();
            }

            System.IO.FileInfo wait = new System.IO.FileInfo("Wait.exe");
            //wait.Attributes = System.IO.FileAttributes.Hidden;
            //wait.IsReadOnly=true;
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Mouse_Maze
{
    /// <summary>
    /// in class path haye in maze ro initialize mikone; [ PART I ]
    /// </summary>
    partial class MazePathes
    {
        /// <remarks>
        ///
        /// ye khune ba ye khuneye dge zamani hamsazand, ke dar movarab'e ham nabashan 
        /// 
        /// </remarks>

        #region List of pathes and variables
        
        /// <summary>
        /// OpenPath's Path;
        /// </summary>
        Blocks.Path OpenPath = new Blocks.Path(Blocks.PathType.OpenPath);

        /// <summary>
        /// List of directions;
        /// </summary>
        static List<Blocks.CoordinatedD> directions = new List<Blocks.CoordinatedD>();


        public static List<Blocks.CoordinatedD> Directions
        {
            get { return directions; }
        }

        /// <summary>
        /// A random object in order to randomise pathes initializing
        /// </summary>
        Random rand = new Random(RandomSeed);

        private static Block.Info initBlock;

        public static Block.Info InitialBlock
        {
            get
            {
                if (initBlock == null)
                    return FindInitialBlock();

                return initBlock;
            }
        }

        #endregion

        #region Ctor and sundires functions

        /// <summary>
        /// Ctor
        /// </summary>
        public MazePathes()
        {
            InitializeVariables();

            InitializeMaze();
        }

        /// <summary>
        /// Does some handy work with variables initializing
        /// </summary>
        private void InitializeVariables()
        {
            #region Init direction's list

            directions.Clear();

            directions.Add(Blocks.CoordinatedD.CenterDown);
            directions.Add(Blocks.CoordinatedD.CenterUp);
            directions.Add(Blocks.CoordinatedD.Left);
            directions.Add(Blocks.CoordinatedD.Right);

            #endregion

            #region MazeColumns

            MazeColumns = Block.Events.GetColumns();

            #endregion
        }

        /// <summary>
        /// Get random, randomseed
        /// </summary>
        private static int RandomSeed
        {
            get
            {
                return new Random(DateTime.Now.Millisecond).Next(int.MaxValue);
            }
        }

        #endregion

        #region OpenPath Creation and associated functions


        /// <summary>
        /// An intermediate function which will initialize maze
        /// </summary>
        private void InitializeMaze()
        {
            // Elate inke chra in random min'esh az 2 shoro mishe, va max'esh Y - 1 mishe, bara ine ke age in random be 1 ya Y khat beshe onvagt ke ehtemale inke ye masire azad be approximate point dashte bashim khahd bood ke nakhoshayande!!
            initBlock = CreateInitialOfPath(rand.Next(rand.Next(2, Blocks.Y-1), Blocks.Y-1));

            InitialMazePattern();

            CalculateOpenPath();
        }

        /// <summary>
        /// calculate a open path, with initial block, and approximate location 2 reach;
        /// </summary>
        /// <param name="initBlock">an initial block which path creating will start with it;</param>
        /// <param name="location">An approximate location which this path heads for;</param>
        private void CalculateOpenPath()
        {
            #region Start calculating

            InitialOpenPath(initBlock);

            #endregion

            #region Finalize path creation

            Block.Events.MakePath(Block.Events.GetBlock(Blocks.CoordinatedD.Right, OpenPath[OpenPath.Count - 1]), OpenPath[OpenPath.Count - 1]);

            #endregion
        }
        

        /// <summary>
        /// this will handle calculating of approximate location to reach with heuristic function in further operation
        /// </summary>
        /// <returns>the calculated approximate location to reach</returns>
        private Block.Info CreateDestApproximate()
        {
            Random r = new Random(RandomSeed);

            // beeyalite inke chra j az 2 shoro mishe, bayad begam, ke choon age 1 bashe onvagt radife aval'e soton ha mitoone entekhab she ke nakhoshaynd khahad bood; va be hamin elat ' Block.Y - 1 ';
            Block.Info LastBlock = Block.Events.GetBlock(new BlockLocation.Location(Blocks.X, r.Next(r.Next(1, Blocks.Y), Blocks.Y)));

            Block.Info bkwrd = Block.Events.GetBlock(BlockLocation.Location.GetLocation(Blocks.CoordinatedD.Left, LastBlock));

            Block.Events.MakePath(LastBlock, bkwrd);
            
            Block.Events.MakePath(bkwrd, null);

            return bkwrd;
        }

        #endregion

        #region IntialPath function and associated functions

        /// <summary>
        /// Create an initial path
        /// </summary>
        /// <param name="Y">at location ( 1 , Y )</param>
        private Block.Info CreateInitialOfPath(int Y)
        {
            Block.Info info = Block.Events.Get_Y_Block(Y);

            // make it a path partial
            Block.Events.MakePath(info, null);
            OpenPath.Add(info);

            //move toward
            Block.Info twrd = Block.Events.GetBlock(BlockLocation.Location.GetLocation(Blocks.CoordinatedD.Right, info));
            Block.Events.MakePath(twrd, info);
            OpenPath.Add(twrd);

            //return initail path of OpenPath
            return twrd;
        }
        
        #endregion
    }
}
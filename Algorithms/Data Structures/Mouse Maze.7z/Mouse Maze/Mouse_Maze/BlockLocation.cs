﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Mouse_Maze
{
    /// <summary>
    /// Handles any this which deals with location property of blocks
    /// </summary>
    class BlockLocation : IEnumerable
    {
        #region Location region

        /// <summary>
        /// A class in order to save location of blocks
        /// </summary>
        public class Location
        {
            int x = 0;
            int y = 0;

            /// <summary>
            /// Ctor
            /// </summary>
            /// <param name="X">Value of ' X ' coordinate</param>
            /// <param name="Y">Value of ' Y ' coordinate</param>
            public Location(int X, int Y)
            {
                x = X;
                y = Y;
            }

            /// <summary>
            /// checks if current location has ever reference to somewhere
            /// </summary>
            public bool IsReferenced
            {
                get { return x != 0 && y != 0; }
            }

            /// <summary>
            /// Am empty ctor
            /// </summary>
            public Location()
            {
                // TODO: Complete member initialization
            }

            /// <summary>
            /// Get ' X ' cooredinate value of current location
            /// </summary>
            public int X
            {
                get { return x; }
            }

            /// <summary>
            /// Get ' Y ' cooredinate value of current location
            /// </summary>
            public int Y
            {
                get
                { return y; }
            }

            /// <summary>
            /// checks if 2 location if is pointing to same place or not;
            /// </summary>
            /// <param name="location_1">First location object</param>
            /// <param name="location_2">Second location object</param>
            /// <returns>returns true; if 2 locations are samel otherwise returns false;</returns>
            public static bool IsEqualLocation(Location location_1, Location location_2)
            {
                try
                {
                    return location_1.x == location_2.x && location_1.y == location_2.y;
                }
                catch
                {
                    return false;
                }
            }
            
            /// <summary>
            /// get location of block in specific direction of specific block;
            /// </summary>
            /// <param name="dir">demanded direction</param>
            /// <param name="block">target block;</param>
            /// <returns>returns location of block in sight of taregt block;</returns>
            public static Location GetLocation(Blocks.Direction dir, Block.Info block)
            {
                try
                {
                    return GetLocation(dir, block.Location);
                }
                catch { }
                return new Location();
            }

            /// <summary>
            /// get location of block in specific direction of specific location
            /// </summary>
            /// <param name="dir">dimanded direction</param>
            /// <param name="location">target location</param>
            /// <returns></returns>
            public static Location GetLocation(Blocks.CoordinatedD dir, BlockLocation.Location location)
            {
                try
                {
                    int CUY = location.Y - 1;
                    int CDY = location.Y + 1;

                    switch (dir)
                    {
                        case Blocks.CoordinatedD.CenterDown:
                            return new BlockLocation.Location(location.X, CDY);

                        case Blocks.CoordinatedD.CenterUp:
                            return new BlockLocation.Location(location.X, CUY);

                        case Blocks.CoordinatedD.Left:
                            return new BlockLocation.Location(location.X - 1, location.Y);

                        case Blocks.CoordinatedD.Right:
                            return new BlockLocation.Location(location.X + 1, location.Y);
                    }
                }
                catch { }
                return new Location();
            }
            
            /// <summary>
            /// get location of block in specific direction of specific location
            /// </summary>
            /// <param name="dir">dimanded direction</param>
            /// <param name="location">target location</param>
            /// <returns></returns>
            public static Location GetLocation(Blocks.CoordinatedD dir, Block.Info block)
            {
                return GetLocation(dir, block.Location);
            }

            /// <summary>
            /// get location of block in specific direction of specific location
            /// </summary>
            /// <param name="dir">dimanded direction</param>
            /// <param name="location">target location</param>
            /// <returns></returns>
            public static Location GetLocation(Blocks.Direction dir, BlockLocation.Location location)
            {
                try
                {
                    int CUY = location.Y - 1;
                    int CDY = location.Y + 1;

                    switch (dir)
                    {
                        case Blocks.Direction.Center:
                            return location;

                        case Blocks.Direction.CenterDown:
                            return new BlockLocation.Location(location.X, CDY);

                        case Blocks.Direction.CenterUp:
                            return new BlockLocation.Location(location.X, CUY);

                        case Blocks.Direction.Left:
                            return new BlockLocation.Location(location.X - 1, location.Y);

                        case Blocks.Direction.LeftDown:
                            return new BlockLocation.Location(location.X - 1, CDY);

                        case Blocks.Direction.LeftUp:
                            return new BlockLocation.Location(location.X - 1, CUY);

                        case Blocks.Direction.Right:
                            return new BlockLocation.Location(location.X + 1, location.Y);

                        case Blocks.Direction.RightDown:
                            return new BlockLocation.Location(location.X + 1, CDY);

                        case Blocks.Direction.RightUp:
                            return new BlockLocation.Location(location.X + 1, CUY);
                    }
                }
                catch (ArgumentOutOfRangeException) { }
                catch (NullReferenceException) { }
                return new Location();
            }
        }

        #endregion

        #region Init Vars

        /// <summary>
        /// List'e geyre hashiye ha
        /// </summary>
        List<Block.Info> list = new List<Block.Info>();

        /// <summary>
        /// List of Blocks Info
        /// </summary>
        public List<Block.Info> List
        {
            get { return list; }
        }
        /// <summary>
        /// list'e hashiye ha
        /// </summary>
        List<Block.Info> Sides = new List<Block.Info>();

        #endregion

        #region Class' Metods

        /// <summary>
        /// Dispose every created block;
        /// </summary>
        public void Clear()
        {
            foreach (var item in Sides)
            {
                item.Block.Dispose();
            }
            foreach (var i in list)
            {
                i.Block.Dispose();
            }
            list.Clear();
        }

        /// <summary>
        /// save block's properties and add this to de created blocks
        /// </summary>
        /// <param name="block">target block</param>
        /// <param name="location">related loctaion to the block;</param>
        public void SaveBlock(Block.Info info)
        {
            int i = -1;
            if ((i = list.IndexOf(info)) > -1)
                list.RemoveAt(i);
            list.Add(info);
        }
        
        /// <summary>
        /// remove block at specific location;
        /// </summary>
        /// <param name="location"></param>
        private void Remove(Location location)
        {
            foreach (var i in list)
            {
                if (i.Location.X == location.X && i.Location.Y == location.Y)
                {
                    list.Remove(i);
                    break;
                }
            }
        }

        /// <summary>
        /// checks if at specific location is there any initialized block
        /// </summary>
        /// <param name="location">demanded block</param>
        /// <returns>returns true if the is a initialized block; otherwise returns false;</returns>
        private bool HasInit(Location location)
        {
            foreach (var i in list)
            {
                if (Location.IsEqualLocation(i.Location, location))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// an indexer which returns BlockInfo of specific block at specific coordinate
        /// </summary>
        /// <param name="X">Value of X direction of 2D coordinate</param>
        /// <param name="Y">Value of Y direction of 2D coordinate</param>
        /// <returns>returns demanded block's BlockInfo</returns>
        public Block.Info this[int X, int Y]
        {
            get
            {
                Location location = new Location(X, Y);
                foreach (var i in list)
                {
                    if (Location.IsEqualLocation(i.Location, location))
                    {
                        return i;
                    }
                }
                return new Block.Info();
            }
        }

        /// <summary>
        /// an indexer which returns BlockInfo of specific block at specific coordinate
        /// </summary>
        /// <param name="location">Location's value;</param>
        /// <returns>returns demanded block's BlockInfo</returns>
        public Block.Info this[Location location]
        {
            get
            {
                foreach (var i in list)
                {
                    if (Location.IsEqualLocation(i.Location, location))
                    {
                        return i;
                    }
                }
                return new Block.Info();
            }
        }
        
        /// <summary>
        /// an indexer which returns BlockInfo of specific block at specific coordinate
        /// </summary>
        /// <param name="block">the block</param>
        /// <returns>returns demanded block's BlockInfo</returns>
        public Block.Info this[System.Windows.Forms.Button block]
        {
            get
            {
                foreach (var i in list)
                {
                    if (i.Block==block)
                    {
                        return i;
                    }
                }
                return new Block.Info();
            }
        }

        internal void SaveSide(Block.Info info)
        {
            int i = -1;
            if ((i = Sides.IndexOf(info)) > -1)
                Sides.RemoveAt(i);
            Sides.Add(info);
        }

        public IEnumerator GetEnumerator()
        {
            return list.GetEnumerator();
        }

        #endregion
    }
}
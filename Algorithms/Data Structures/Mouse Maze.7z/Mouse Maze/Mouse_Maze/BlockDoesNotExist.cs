﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mouse_Maze
{
    partial class Blocks
    {
        class BlockDoesNotExist : Exception
        {
            private Block.Info exception;

            public BlockDoesNotExist(string message, Block.Info exception):base(message)
            {
                this.exception = exception;
            }

            public override string Message
            {
                get
                {
                    return base.Message + "\nBlock's Location : [ " + exception.Location.X + " , " + exception.Location.Y + " ] ";
                }
            }
        }
    }
}
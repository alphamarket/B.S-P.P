﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSProject_2
{
    class MatrixMultiplicate
    {
        public static MatrixRC.Matrix Calculate(MatrixRC.Matrix m1, MatrixRC.Matrix m2)
        {
            try
            {
                MatrixRC.Matrix matrix = new MatrixRC.Matrix(new System.Drawing.Size(m1.MatrixSize.Width, m2.MatrixSize.Height));


                for (int i = 0; i < matrix.MatrixSize.Width; i++)
                {
                    for (int j = 0; j < matrix.MatrixSize.Height; j++)
                    {
                        for (int k = 0; k < m1.MatrixSize.Height; k++)
                        {
                            matrix.Value[i, j] += m1.Value[i, k] * m2.Value[k, j];
                        }
                    }
                }

                return matrix;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            return new MatrixRC.Matrix();
        }
    }
}
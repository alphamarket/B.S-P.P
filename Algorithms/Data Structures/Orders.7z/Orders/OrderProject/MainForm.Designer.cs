﻿namespace DSProject_2
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.O_n = new System.Windows.Forms.LinkLabel();
            this.O_nLogN = new System.Windows.Forms.LinkLabel();
            this.O_n2 = new System.Windows.Forms.LinkLabel();
            this.O_n3 = new System.Windows.Forms.LinkLabel();
            this.O_n4 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // O_n
            // 
            this.O_n.AutoSize = true;
            this.O_n.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.O_n.Location = new System.Drawing.Point(12, 16);
            this.O_n.Name = "O_n";
            this.O_n.Size = new System.Drawing.Size(83, 13);
            this.O_n.TabIndex = 0;
            this.O_n.TabStop = true;
            this.O_n.Text = "Binary adder (N)";
            this.O_n.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.O_n_LinkClicked);
            // 
            // O_nLogN
            // 
            this.O_nLogN.AutoSize = true;
            this.O_nLogN.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.O_nLogN.Location = new System.Drawing.Point(12, 208);
            this.O_nLogN.Name = "O_nLogN";
            this.O_nLogN.Size = new System.Drawing.Size(98, 13);
            this.O_nLogN.TabIndex = 1;
            this.O_nLogN.TabStop = true;
            this.O_nLogN.Text = "Quick sort (NLogN)";
            this.O_nLogN.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.O_nLogN_LinkClicked);
            // 
            // O_n2
            // 
            this.O_n2.AutoSize = true;
            this.O_n2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.O_n2.Location = new System.Drawing.Point(12, 62);
            this.O_n2.Name = "O_n2";
            this.O_n2.Size = new System.Drawing.Size(96, 13);
            this.O_n2.TabIndex = 2;
            this.O_n2.TabStop = true;
            this.O_n2.Text = "Insertion sort (N^2)";
            this.O_n2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.O_n2_LinkClicked);
            // 
            // O_n3
            // 
            this.O_n3.AutoSize = true;
            this.O_n3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.O_n3.Location = new System.Drawing.Point(12, 111);
            this.O_n3.Name = "O_n3";
            this.O_n3.Size = new System.Drawing.Size(119, 13);
            this.O_n3.TabIndex = 3;
            this.O_n3.TabStop = true;
            this.O_n3.Text = "Matrix multiplicate (N^3)";
            this.O_n3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.O_n3_LinkClicked);
            // 
            // O_n4
            // 
            this.O_n4.AutoSize = true;
            this.O_n4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.O_n4.Location = new System.Drawing.Point(12, 160);
            this.O_n4.Name = "O_n4";
            this.O_n4.Size = new System.Drawing.Size(167, 13);
            this.O_n4.TabIndex = 4;
            this.O_n4.TabStop = true;
            this.O_n4.Text = "Function with O(n^4) process time";
            this.O_n4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.O_n4_LinkClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 235);
            this.Controls.Add(this.O_n4);
            this.Controls.Add(this.O_n3);
            this.Controls.Add(this.O_n2);
            this.Controls.Add(this.O_nLogN);
            this.Controls.Add(this.O_n);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Processes Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel O_n;
        private System.Windows.Forms.LinkLabel O_nLogN;
        private System.Windows.Forms.LinkLabel O_n2;
        private System.Windows.Forms.LinkLabel O_n3;
        private System.Windows.Forms.LinkLabel O_n4;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class SortValueEnteryPoint : Form
    {
        Button ok = new Button();

        int[] arr;
        Order order;
        public SortValueEnteryPoint(Order order,int[] arr, bool show)
        {
            InitializeComponent();

            this.arr = arr;

            this.order = order;

            int count = arr.Length;

            if (count % 10 == 0)
                count = count / 10;
            else
                count = count / 10 + 1;

            try
            {
                for (int i = 0; i < count; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        arr[i * 10 + j].GetHashCode();
                        TextBox _tmp = new TextBox();
                        _tmp.Size = new Size(30, 20);
                        _tmp.MaxLength = 3;
                        _tmp.Location = new Point((j) * 30 + 10, (i) * 20 + 10);
                        _tmp.TextChanged += new EventHandler(Text_Changed);
                        if (show)
                        {
                            try
                            {
                                _tmp.Text = arr[i * 10 + j].ToString();
                                _tmp.Enabled = false;
                                _tmp.Visible = true;
                            }
                            catch (Exception e)
                            {
                                MessageBox.Show(e.Message);
                            }
                        }
                        Controls.Add(_tmp);
                    }
                }
            }
            catch { }
            ok.Text = "Ok";
            ok.Location = new Point(233, Controls[Controls.Count - 1].Location.Y + 35);
            ok.Click += new System.EventHandler(Ok_Click);
            ok.Enabled = false;
            ok.Visible = !show;
            Controls.Add(ok);

            Button cnl = new Button();
            cnl.Text = show ? "Close" : "Cancel";
            cnl.Location = new Point(ok.Location.X - cnl.Size.Width - 10, ok.Location.Y);
            cnl.Click += new EventHandler(Cancel_Click);
            Controls.Add(cnl);

            Size = new Size(324, ok.Size.Height + ok.Location.Y + 30);
        }
        void Text_Changed(object sender, EventArgs e)
        {
            try
            {
                foreach (Control i in Controls)
                {
                    if (i is TextBox)
                    {
                        try
                        {
                            if (i.Text.Contains(' '))
                            {
                                i.ResetText();
                                throw new Exception();
                            }
                            Convert.ToInt16(i.Text);
                        }
                        catch
                        {
                            ok.Enabled = false;
                            return;
                        }
                    }
                }
                ok.Focus();
                ok.Enabled = true;
            }
            catch { }
        }
        void Ok_Click(object sender, EventArgs e)
        {
            try
            {
                int count = arr.Length;

                if (count % 10 == 0)
                    count = count / 10;
                else
                    count = count / 10 + 1;
                for (int i = 0; i < count; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        arr[i * 10 + j] = int.Parse((Controls[i * 10 + j] as TextBox).Text);
                    }
                }
            }
            catch { }

            double f = Environment.TickCount;
            switch (order)
            {
                case Order.n2:
                    InsertionSort.Sort(ref arr);
                    break;
                case Order.nLogN:
                    QuickSort.Sort(ref arr);
                    break;
                default:
                    MessageBox.Show("Oops ...");
                    break;
            }
            MessageBox.Show("Sorting numbers with insertion sort takes : " + ((double)(Environment.TickCount - f) / 1000).ToString() + " seconds .", "Notification ...", MessageBoxButtons.OK, MessageBoxIcon.Information);

            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
        void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        public int[] SortResult
        {
            get { return arr; }
        }
    }
}
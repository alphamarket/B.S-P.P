﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSProject_2
{
    class AddBytes
    {
        static public byte[] Add(byte[] b1, byte[] b2)
        {

            byte cry = 0;

            byte[] res = new byte[b1.Length];

            try
            {

                for (int i = b1.Length - 1; i >= 0; i--)
                {
                    res[i] = (byte)((b1[i] ^ b2[i]) ^ cry);

                    cry = (byte)((byte)(b1[i] & b2[i]) ^ (byte)(cry & (byte)(b1[i] ^ b2[i])));
                }
            }
            catch { }

            if (cry == 1)
            {
                byte[] tmp = new byte[b1.Length + 1];
                tmp[0] = 1;
                for (int i = 0; i < res.Length; i++)
                {
                    tmp[i + 1] = res[i];
                }
                res = tmp;
            }
          
            return res;
        }
    }
}

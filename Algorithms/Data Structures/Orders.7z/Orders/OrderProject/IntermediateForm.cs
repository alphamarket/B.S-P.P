﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public enum Order { n, n2, n3, n4, nLogN }
    internal partial class IntermediateForm : Form
    {
        static Order order;
        System.Threading.Thread tr = null;
        MatrixRC.MatrixCollection matrixcol;

        string Convert_Byte_String(byte[] b)
        {
            StringBuilder str = new StringBuilder();
            foreach (byte r in b)
            {
                str.Append(r.ToString());
            }
            return str.ToString();
        }
        public IntermediateForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            foreach (Panel i in Controls)
            {
                i.Visible = false;
                i.Location = new Point(0, 0);
            }
            switch (order)
            {
                case Order.n:
                    ByteForm obj = new ByteForm();
                    if (obj.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        byte[] res = AddBytes.Add(obj.Byte1, obj.Byte2);

                        MessageBox.Show(Convert_Byte_String(obj.Byte1) + " + " + Convert_Byte_String(obj.Byte2) + " = " + Convert_Byte_String(res));
                    }

                    throw new Exception();
                case Order.n3:

                    N3();

                    break;
                case Order.nLogN:

                    NLogN();

                    break;
                
                case Order.n2:

                    N2();

                    break;
                default:
                    MessageBox.Show("Oops!", "Oops ...!!!???");
                    break;
            }
        }

        private void NLogN()
        {
            N2FormArrayLengthCounter form = new N2FormArrayLengthCounter();

            if (form.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                throw new Exception();

            int[] list = new int[form.Count];

            SortValueEnteryPoint _s = new SortValueEnteryPoint(Order.nLogN, list, false);

            if (_s.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                list = _s.SortResult;

                System.Text.StringBuilder str = new StringBuilder();

                for (int i = 0; i < list.Length; i++)
                {
                    if (i != 0 && i % 50 == 0)
                        str.AppendLine(list[i].ToString());
                    else
                        str.Append(list[i].ToString() + "," + new string(' ', 4));

                }

                TextTheater text = new TextTheater(str.ToString());
                text.ShowDialog();
            }
            throw new Exception();
        }

        private void N2()
        {
            N2FormArrayLengthCounter form = new N2FormArrayLengthCounter();

            if (form.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                throw new Exception();

            int[] _foo = new int[form.Count];

            SortValueEnteryPoint _s = new SortValueEnteryPoint(Order.n2, _foo, false);

            if (_s.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _foo = _s.SortResult;

                System.Text.StringBuilder str = new StringBuilder();

                for (int i = 0; i < _foo.Length; i++)
                {
                    if (i != 0 && i % 50 == 0)
                        str.AppendLine(_foo[i].ToString());
                    else
                        str.Append(_foo[i].ToString() + "," + new string(' ', 4));

                }

                TextTheater text = new TextTheater(str.ToString());
                text.ShowDialog();
            }
            throw new Exception();
        }

        private void N3()
        {
            // Multiplicate a matrix
            MatrixRC obj = new MatrixRC();
            if (obj.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                matrixcol = obj.Matrixes;
            }

            foreach (MatrixRC.Matrix item in matrixcol)
            {
                MatrixInfoFeed tmp = new MatrixInfoFeed(item, false);
                if (tmp.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                {
                    this.Close();
                    return;
                }

                item.Value = tmp.MatrixValues;
            }

            double f = Environment.TickCount;

            MatrixRC.Matrix foo = MatrixMultiplicate.Calculate(matrixcol[0], matrixcol[1]);

            double s = Environment.TickCount;

            MatrixInfoFeed res = new MatrixInfoFeed(foo, true);

            res.ShowDialog();

            MessageBox.Show("Matrix multiplicated in : " + ((double)(s - f) / 1000).ToString() + " seconds .", "Notification ....", MessageBoxButtons.OK, MessageBoxIcon.Information);

            throw new Exception();
        }
        public static void ExecuteOrder(Order order)
        {
            try
            {
                IntermediateForm.order = order;
                IntermediateForm obj = new IntermediateForm();
                obj.Show();
            }
            catch { return; }
        }

        private void IntermediateForm_Load(object sender, EventArgs e)
        { }

        private void Calculate_Click(object sender, EventArgs e)
        {
            switch (order)
            {
                case Order.n3:

                    break;

                case Order.n4:

                    break;

                case Order.nLogN:

                    break;
            }
        }

        private void IntermediateForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (tr.IsAlive)
                    tr.Abort();
            }
            catch { }
        }
    }
}

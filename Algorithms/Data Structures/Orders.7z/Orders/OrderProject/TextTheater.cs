﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class TextTheater : Form
    {
        public TextTheater(string text)
        {
            InitializeComponent();
            richTextBox1.Text = text;
            richTextBox1.ReadOnly = true;
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

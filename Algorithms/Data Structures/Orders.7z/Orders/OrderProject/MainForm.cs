﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            //IntermediateForm.ExecuteOrder(Order.nLogN);

            //System.Diagnostics.Process.GetCurrentProcess().Kill();

        }

        private void O_n_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IntermediateForm.ExecuteOrder(Order.n);
        }

        private void O_n2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IntermediateForm.ExecuteOrder(Order.n2);
        }

        private void O_n3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IntermediateForm.ExecuteOrder(Order.n3);
        }

        private void O_nLogN_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            IntermediateForm.ExecuteOrder(Order.nLogN);
        }

        private void O_n4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Bana be MSDN init kardane array haye ba abade 4 bood be bala, be sourate dynamic, bayad dasti sorat begire, ke init kardane array'e 4 bodi, az order'e n^4 khahad bood :)", 
                "Notification ...", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            System.Diagnostics.Process foo = new System.Diagnostics.Process();
            
            System.Diagnostics.ProcessStartInfo lo = new System.Diagnostics.ProcessStartInfo("orl98.pdf");
            
            lo.UseShellExecute = true;
            
            lo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
            
            foo.StartInfo = lo;
            
            foo.Start();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
        }
    }
}

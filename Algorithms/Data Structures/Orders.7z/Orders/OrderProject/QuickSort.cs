﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSProject_2
{
    class QuickSort
    {
        static List<int> arr;
        public static void Sort(ref int[] array)
        {
            ToList(ref array);

            array = Sort(QuickSort.arr).ToArray();
        }

        private static void ToList(ref int[] array)
        {
            QuickSort.arr = new List<int>();

            foreach (int i in array)
            {
                QuickSort.arr.Add(i);
            }
        }


        public static List<int> Sort(List<int> arr)
        {
            try
            {
                List<int> l = new List<int>(), g = new List<int>(), e = new List<int>();

                if (arr.Count < 2)
                    return arr;

                DIV(arr, l, g, e);

                List<int> resultSet = new List<int>();

                l = Sort(l);

                g = Sort(g);

                resultSet.AddRange(l);

                resultSet.AddRange(e);

                resultSet.AddRange(g);

                return resultSet;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                return new List<int>();
            }
        }
        private static void DIV(List<int> arr, List<int> l, List<int> g,List<int> e)
        {
            int pivot = arr.Count / 2;

            int pivot_val = arr[pivot];

            foreach (int i in arr)
            {
                if (i < pivot_val)
                    l.Add(i);

                else if (i > pivot_val)
                    g.Add(i);

                else if (i == pivot_val)
                    e.Add(i);
            }
        }
        public static void Sort(int[] array, int low, int high)
        {
            if (low < high)
            {
                int middle = partition(array, low, high);
                Sort(array, low, middle - 1);
                Sort(array, middle + 1, high);
            }
        }

        static int partition(int[] array, int low, int high)
        {
            int middle;

            int x = array[low];
            int l = low;
            int r = high;
            while (l < r)
            {
                while ((array[l] <= x) && (l < high)) l++;
                while ((array[r] > x) && (r >= low)) r--;
                if (l < r)
                {
                    int temp = array[l];
                    array[l] = array[r];
                    array[r] = temp;
                }
            }
            middle = r;
            int temp1 = array[low];
            array[low] = array[middle];
            array[middle] = temp1;
            return middle;
        }
    }
}
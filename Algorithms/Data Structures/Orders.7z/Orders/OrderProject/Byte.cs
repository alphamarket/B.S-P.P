﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class ByteForm : Form
    {
        public ByteForm()
        {
            InitializeComponent();
            button1.Enabled = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            TextBox t = (TextBox)sender;
            try
            {
                int tmp = Convert.ToInt16(t.Text[t.Text.Length - 1].ToString());

                if (tmp != 0 && tmp != 1)
                    throw new Exception();
            }
            catch
            {
                try
                {
                    t.Text = t.Text.Remove(t.Text.Length - 1);
                    t.SelectionStart = t.Text.Length;
                }
                catch { }
            }

            foreach (Control i in Controls)
            {
                if (i is TextBox)
                    if (i.Text == "")
                    {
                        button1.Enabled = false;
                        return;
                    }
            }
            button1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }


        byte[] _bytes1, _bytes2;

        public byte[] Byte1
        {
            get { return _bytes1; }
        }
        public byte[] Byte2
        {
            get { return _bytes2; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Equalization();
            _bytes1 = new byte[textBox1.Text.Length];
            for (int i = 0; i < textBox1.Text.Length; i++)
                _bytes1[i] = (byte)Convert.ToInt16(textBox1.Text[i].ToString());

            _bytes2 = new byte[textBox2.Text.Length];
            for (int i = 0; i < textBox2.Text.Length; i++)
                _bytes2[i] = (byte)Convert.ToInt16(textBox2.Text[i].ToString());

            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void Equalization()
        {
            TextBox txt = textBox1.Text.Length < textBox2.Text.Length ? textBox1 : textBox2;
            TextBox tmp = new TextBox();
            foreach (Control i in Controls)
            {
                if (i is TextBox && i != txt)
                    tmp = i as TextBox;
            }
            while (txt.Text.Length < tmp.Text.Length)
                txt.Text = "0" + txt.Text;
        }
    }
}

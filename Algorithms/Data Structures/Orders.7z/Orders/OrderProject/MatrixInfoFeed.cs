﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class MatrixInfoFeed : Form
    {
        class Location
        {
            int x, y;
            TextBox text;
            public Location(TextBox text, int x, int y)
            {
                this.text = text;
                this.x = x;
                this.y = y;
            }

            public Location()
            {
                // TODO: Complete member initialization
            }
            public int X
            {
                get { return x; }
            }
            public int Y
            {
                get { return y; }
            }
            public string Text
            {
                get { return text.Text; }
            }
            public TextBox Object
            {
                get { return text; }
            }
        }

        class Values
        {
            List<Location> loc = new List<Location>();

            public void Add(Location loc)
            {
                this.loc.Add(loc);
            }

            public Location this[int i, int j]
            {
                get
                {
                    foreach (Location it in loc)
                    {
                        if (it.X == i && it.Y == j)
                            return it;
                    }
                    return new Location();
                }
            }
        }
        Values value = new Values();
        MatrixRC.Matrix tmp;
        Button ok = new Button();

        public MatrixInfoFeed(MatrixRC.Matrix Matrix, bool show)
        {
            InitializeComponent();

            tmp = Matrix;

            matrixvalues = new int[Matrix.MatrixSize.Width, Matrix.MatrixSize.Height];

            Point tmpLocation = new Point(10, 10);

            for (int i = 0; i < Matrix.MatrixSize.Height; i++)
            {
                for (int j = 0; j < Matrix.MatrixSize.Width; j++)
                {
                    TextBox _tmp = new TextBox();
                    _tmp.Size = new Size(30, 20);
                    _tmp.MaxLength = 3;
                    _tmp.Location = new Point((i) * 30 + 10, (j) * 20 + 10);
                    _tmp.TextAlign = HorizontalAlignment.Center;
                    _tmp.TextChanged += new EventHandler(Text_Changed);
                    if (show)
                    {
                        try
                        {
                            _tmp.Text = Matrix.Value[j, i].ToString();
                            _tmp.Enabled = false;
                            _tmp.Visible = true;
                        }
                        catch (Exception e)
                        {
                            MessageBox.Show(e.Message);
                        }
                    }
                    value.Add(new Location(_tmp, j, i));
                    Controls.Add(_tmp);
                }
            }

            ok.Text = "Ok";
            ok.Location = new Point(Controls[Controls.Count - 1].Location.X - 43, Controls[Controls.Count - 1].Location.Y + 35);
            ok.Click += new System.EventHandler(Ok_Click);
            ok.Enabled = false;
            ok.Visible = !show;
            Controls.Add(ok);

            Button cnl = new Button();
            cnl.Text = show ? "Close" : "Cancel";
            cnl.Location = new Point(ok.Location.X - cnl.Size.Width - 10, ok.Location.Y);
            cnl.Click += new EventHandler(Cancel_Click);
            Controls.Add(cnl);

            if (cnl.Location.X < value[0, 0].Object.Location.X)
            {
                foreach (Control i in Controls)
                {
                    i.Location = new Point(i.Location.X + Math.Abs(cnl.Location.X) + 7, i.Location.Y);
                }
            }

            Size = new Size(ok.Location.X + ok.Size.Width + 13, ok.Size.Height + ok.Location.Y + 30);

            if (show)
            {
                Text = "Matrix Multiplicate Result ...";
            }
        }

        void Text_Changed(object sender, EventArgs e)
        {
            foreach (Control i in Controls)
            {
                if (i is TextBox)
                {
                    try
                    {
                        if (i.Text.Contains(' '))
                        {
                            i.ResetText();
                            throw new Exception();
                        }
                        Convert.ToInt16(i.Text);
                    }
                    catch
                    {
                        ok.Enabled = false;
                        return;
                    }
                }
            }
            ok.Enabled = true;
        }

        void Ok_Click(object sender, EventArgs e)
        {
            CheckTextBox();

            for (int i = 0; i < tmp.MatrixSize.Height ; i++)
            {
                for (int j = 0; j < tmp.MatrixSize.Width; j++)
                {
                    try
                    {
                        matrixvalues[j, i] = int.Parse(value[j, i].Text);
                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(er.Message);
                        return;
                    }
                }
            }

            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void CheckTextBox()
        {
            foreach (Control i in Controls)
            {
                if (i is TextBox)
                {
                    try
                    {
                        Convert.ToInt16(i.Text);
                    }
                    catch
                    {
                        MessageBox.Show("Please enter only integer values!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i.Focus();
                        i.Text = "";
                        break;
                    }
                }
                if (i is Button)
                {
                    if (i.Text == "Ok")
                        i.Focus();
                }
            }
        }
        void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        int[,] matrixvalues;
        public int[,] MatrixValues
        {
            get { return matrixvalues; }
        }
    }
}
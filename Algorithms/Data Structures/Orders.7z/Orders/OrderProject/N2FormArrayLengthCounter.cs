﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class N2FormArrayLengthCounter : Form
    {
        private int count;
        public N2FormArrayLengthCounter()
        {
            InitializeComponent();
            numericUpDown1.Maximum = 400;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            count = Convert.ToInt16(numericUpDown1.Value);
            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        public int Count
        {
            get { return count; }
        }
    }
}
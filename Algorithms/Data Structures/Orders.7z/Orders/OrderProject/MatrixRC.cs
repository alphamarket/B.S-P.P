﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DSProject_2
{
    public partial class MatrixRC : Form
    {
        public MatrixRC()
        {
            InitializeComponent();
            button1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (f2.Text != s1.Text)
            {
                MessageBox.Show("Bode dovom'e matris aval bayad ba bode dovome matrise dovom bayad barabar bashe ...", "Arithmetic Error ...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f2.Focus();
                return;
            }
            matrC.Add(new Matrix(new System.Drawing.Size(int.Parse(f1.Text), int.Parse(f2.Text))));

            matrC.Add(new Matrix(new System.Drawing.Size(int.Parse(s1.Text), int.Parse(s2.Text))));

            DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }


        public class Matrix
        {
            Size size;
            
            private int[,] value;

            public Matrix(Size size)
            {
                this.size = size;
                value = new int[size.Width, size.Height];
            }

            public Matrix()
            {
            }

            public Size MatrixSize
            {
                get { return size; }
            }

            public int[,] Value
            {
                get { return value; }
                set { this.value = value; }
            }
        }

        public class MatrixCollection : System.Collections.IEnumerable
        {
            List<Matrix> tmp;
            public MatrixCollection()
            {
                tmp = new List<Matrix>();
            }
            public void Add(Matrix matrix)
            {
                tmp.Add(matrix);
            }
            public Matrix this[int index]
            {
                get
                {
                    return tmp[index];
                }
            }

            public System.Collections.IEnumerator GetEnumerator()
            {
                return tmp.GetEnumerator();
            }
        }
        MatrixCollection matrC=new MatrixCollection();
        public MatrixCollection Matrixes
        {
            get { return matrC; }
        }

        private void TextBoxes_TextChanged(object sender, EventArgs e)
        {
            foreach (Control i in Controls)
            {
                if (i is TextBox)
                {
                    try
                    {
                        if (i.Text.Contains(' '))
                        {
                            i.Text = "";
                            throw new Exception();
                        }
                        Convert.ToInt16(i.Text);
                    }
                    catch
                    {
                        button1.Enabled = false;
                        return;
                    }
                }
            }
            button1.Enabled = true;
        }
    }
}

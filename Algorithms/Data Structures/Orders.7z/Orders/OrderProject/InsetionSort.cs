﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSProject_2
{
    class InsertionSort
    {
        public static void Sort(ref int[] arrayNum)
        {
            int index, x;
            for (int j = 1; j < arrayNum.Length; j++)
            {
                index = arrayNum[j];
                x = j;

                while ((x > 0) && (arrayNum[x - 1] > index))
                {
                    arrayNum[x] = arrayNum[x - 1];
                    x = x - 1;
                }
                arrayNum[x] = index;
            }
        }
    }
}
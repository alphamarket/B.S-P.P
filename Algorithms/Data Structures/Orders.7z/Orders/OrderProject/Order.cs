﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSProject_2.Orders
{
    class Order
    {
        /// <summary>
        /// Find a string index in an array
        /// </summary>
        /// <param name="arr">source array</param>
        /// <param name="target">target string</param>
        /// <returns>index of first located place in array!</returns>
        public static int N(string[] arr, string target)
        {
            for (int i = 0; i < arr.Length; i++)
                if (arr[i] == target)
                    return i + 1;
            return 0;
        }

        public static void N2(ref double[] index)
        {
            for (int i = 0; i < index.Length; i++)
                for (int j = i; j < index.Length; j++)
                    if (index[i] < index[j])
                    {
                        double tmp = index[i];
                        index[i] = index[j];
                        index[j] = tmp;
                    }
        }

        public static void N3()
        {
        }

        public static void N4()
        {
        }
        public struct ObjForNLogN
        {
            public Int64 CountFornLogN;
            public double amntFornLogN;
            public System.Windows.Forms.ToolStripProgressBar p;
            public ObjForNLogN(Int64 obj1, double obj2,System.Windows.Forms.ToolStripProgressBar p)
            {
                CountFornLogN = obj1;
                amntFornLogN = obj2;
                this.p = p;
            }
        }
        static int count = 0;
        public static void nLogN(object obj)
        {
            ObjForNLogN Obj = (ObjForNLogN)obj;
            double start = Environment.TickCount;
            double x = Obj.amntFornLogN;
            for (int j = 0; j < Obj.CountFornLogN; j++)
            {
                Int64 i = Obj.CountFornLogN;
                while (i > 1)
                {
                    x = x + 4;
                    i = i / 2;
                }
                try
                {
                    if (count * (Obj.CountFornLogN / 100) == j) SetToolStrip(Obj.p);
                }
                catch (DivideByZeroException) { }
            }
            double stop = Environment.TickCount;
            count = 0;
            double time = (double.Parse((stop - start).ToString()) / 1000);
            System.Windows.Forms.MessageBox.Show("The metod returned result is : " + x + "\r\nAnd This process takes this amount of time : " + (time == 0 ? "less than 10 miliseconds" : time.ToString()), "Result ...", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
        }
        delegate void progress(System.Windows.Forms.ToolStripProgressBar p);
        static void SetToolStrip(System.Windows.Forms.ToolStripProgressBar p)
        {
            if (p.ProgressBar.InvokeRequired)
                p.ProgressBar.Invoke(new progress(SetToolStrip), new object[] { p });
            else
            {
                count++;
                p.PerformStep();
            }
        }
    }
}

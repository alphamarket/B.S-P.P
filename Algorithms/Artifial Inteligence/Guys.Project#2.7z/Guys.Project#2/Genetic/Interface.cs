﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Genetic;
namespace Interface
{
    public partial class iInterface : Form
    {
        System.Diagnostics.Process WaitForm = new System.Diagnostics.Process();
        Params wait = new Params();
        Label ZeroLabel = new Label();
        List<VarBlocks> vbList = new List<VarBlocks>();
        new Size DefaultSize { get; set; }

        public iInterface()
        {
            InitializeComponent();
            this.DefaultSize = new Size(this.Size.Width, this.Size.Height);
            this.FormClosing += new FormClosingEventHandler((sender, e) => { try { if (WaitForm != null && !WaitForm.HasExited) { WaitForm.Kill(); } } catch { } finally { System.Diagnostics.Process.GetCurrentProcess().Kill(); } });
        }

        private void iInterface_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Z:
                    randomizeBtn_Click(new object(), new EventArgs());
                    break;
                case Keys.P:
                    performanceBtn_Click(new object(), new EventArgs());
                    break;
                case Keys.D:
                    if (e.Control)
                    {
                        AddVarBtn_Click(new object(), new EventArgs());
                    }
                    break;
                case Keys.R:
                    if (e.Control)
                    {
                        if (this.vbList.Count != 0)
                        {
                            vbList[vbList.Count - 1].Dispose();
                            vbList.RemoveAt(this.vbList.Count - 1);
                            if (vbList.Count == 0)
                            {
                                ZeroLabel.Dispose();
                                return;
                            }
                            var vb = vbList[vbList.Count - 1];
                            ZeroLabel.Top = ((int)((vbList.Count - 1) / 10)) * (vb.Size.Height) + vb.Height / 2 + 10;
                            ZeroLabel.Left = vb.Left + vb.Width + 10;
                        }
                    }
                    break;
                case Keys.S:
                    if (e.Control)
                    {
                        Solve_Click(new object(), new EventArgs());
                    }
                    break;
                case Keys.C:
                    if (e.Control)
                    {
                        foreach (var ui in vbList)
                        {
                            ui.Dispose();
                        }
                        vbList.Clear();
                        ZeroLabel.Dispose();
                        this.Size = new Size(this.DefaultSize.Width, this.DefaultSize.Height);
                    }
                    break;
                case Keys.Escape:
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                    break;
            }
        }
        private void AddVarBtn_Click(object sender, EventArgs e)
        {
            VarBlocks vb = new VarBlocks();
            if (vbList.Count == 0)
            {
                vb.PlusSignVisible = false;
                vb.Left = 10;
                vb.Top = 10;
                vb.VariableName = "X0";
                vb.CreateControl();
                this.Controls.Add(vb);
                vbList.Add(vb);
            }
            else
            {
                vb.VariableName = "X" + vbList.Count;
                vb.Top = ((int)(vbList.Count / 10)) * (vb.Size.Height) + 10;
                if (vbList.Count % 10 == 0)
                {
                    vb.Left = 10;
                }
                else
                {
                    vb.Left = vbList[vbList.Count - 1].Left + vb.Size.Width;
                }
                vb.CreateControl();
                this.Controls.Add(vb);
                vbList.Add(vb);
            }
            ZeroLabel.Dispose();
            ZeroLabel = new Label();
            ZeroLabel.Text = " = 0";
            ZeroLabel.Top = ((int)((vbList.Count - 1) / 10)) * (vb.Size.Height) + vb.Height / 2 + 10;
            ZeroLabel.Left = vb.Left + vb.Width + 10;
            ZeroLabel.CreateControl();
            this.Controls.Add(ZeroLabel);

            if (ZeroLabel.Right + ZeroLabel.Size.Width  > this.Size.Width)
            {
                int pw = this.Width;
                this.Size = new Size(ZeroLabel.Right + ZeroLabel.Size.Width, this.Size.Height);
                this.Left -= Math.Abs(this.Width - pw) / 2;
            }

            if (ZeroLabel.Top + ZeroLabel.Size.Width > this.Size.Height)
            {
                int pt = this.Height;
                this.Size = new Size(this.Width, ZeroLabel.Top + ZeroLabel.Size.Width);
                this.Top -= Math.Abs(this.Height - pt) / 2;
            }
        }

        public void Solve_Click(object sender, EventArgs e)
        {
            if (this.vbList.Count == 0)
                return;

            Params p = new Params();

            if (p.ShowDialog() == DialogResult.Cancel)
                return;

            float[,] eq = new float[vbList.Count, 2];
            int j = 0;
            foreach (var i in vbList)
            {
                eq[j, 0] = i.TimesValue;
                eq[j++, 1] = i.PowValue;
            }
            object[] o = new object[]{
                (int)p.PopulationMount.Value,
                (int)p.MaxGeneration.Value,
                (float)(p.CrossoverProb.Value / p.CrossoverProb.Maximum),
                (float)(p.EliteRate.Value*p.PopulationMount.Value)/100,
                (float)(p.MutateProb.Value / p.MutateProb.Maximum),
                p.AcceptableRate
            };

            Genetic.Genetic genetic = new Genetic.Genetic(eq, (int)o[0], (int)o[1], (float)o[2], (float)o[3], (float)o[4]);
            System.Threading.Thread tr = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart((geneticHandler) =>
            {
                var g = geneticHandler as Genetic.Genetic;
                try
                {
                    int startTime = Environment.TickCount;
                    var solution = g.Run();
                    startTime = Environment.TickCount - startTime;

                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Elapsed time : " + new TimeSpan(startTime * 10000));
                    sb.AppendLine();
                    sb.AppendLine("Fitness : " + solution.ToString());
                    int k = 0;
                    foreach (var i in solution.Values)
                    {
                        sb.AppendFormat("{3}X{0:D2} : {2}{1}\r\n", k++, Math.Round(i, 5), (i < 0 ? "" : "+"), new string(' ', solution.ToString().Length - 5));
                    }
                    var result = new Result(g, sb.ToString(), null, this);
                    result.ShowDialog();
                    return;
                }
                catch (Exception err)
                {
                    using (StreamWriter sw = new StreamWriter("App.Error.log.txt"))
                    {
                        sw.WriteLine("Interface error info ...");
                        sw.WriteLine("Message : \r\n{0}", err.Message);
                        sw.WriteLine("Trace calls : \r\n{0}", err.StackTrace);
                        if (err.InnerException != null)
                        {
                            sw.WriteLine();
                            sw.WriteLine("Inner error info ...");
                            sw.WriteLine("Message : \r\n{0}", err.InnerException.Message);
                            sw.WriteLine("Trace calls : \r\n{0}", err.InnerException.StackTrace);
                        }
                    }
                    MessageBox.Show("Error happened...");
                    System.Diagnostics.Process.Start("App.Error.log.txt");
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
                finally
                {
                }
            }));
            tr.Start(genetic);
        }

        public void performanceBtn_Click(object sender, EventArgs e)
        {
            /*
            if (this.genetic != null)
                ;// new Performance(SelectionFunction.Method, this.genetic).Show();

             */
        }

        private void randomizeBtn_Click(object sender, EventArgs e)
        {
            Random random = new Random(Environment.TickCount);
            foreach (var i in this.vbList)
            {
                i.TimesValue = (float)Math.Round((-20 + random.NextDouble() * 40), 1);
                i.PowValue = (float)Math.Round((-10 + random.NextDouble() * 20), 1);
            }
        }
    }
}
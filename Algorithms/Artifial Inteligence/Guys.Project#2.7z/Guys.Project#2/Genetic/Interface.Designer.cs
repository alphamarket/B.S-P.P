﻿namespace Interface
{
    partial class iInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddVarBtn = new System.Windows.Forms.Button();
            this.Solve = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.performanceBtn = new System.Windows.Forms.Button();
            this.randomizeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddVarBtn
            // 
            this.AddVarBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddVarBtn.Location = new System.Drawing.Point(568, 23);
            this.AddVarBtn.Name = "AddVarBtn";
            this.AddVarBtn.Size = new System.Drawing.Size(75, 23);
            this.AddVarBtn.TabIndex = 0;
            this.AddVarBtn.TabStop = false;
            this.AddVarBtn.Text = "Add Variable";
            this.AddVarBtn.UseVisualStyleBackColor = true;
            this.AddVarBtn.Click += new System.EventHandler(this.AddVarBtn_Click);
            // 
            // Solve
            // 
            this.Solve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Solve.Location = new System.Drawing.Point(568, 61);
            this.Solve.Name = "Solve";
            this.Solve.Size = new System.Drawing.Size(75, 23);
            this.Solve.TabIndex = 0;
            this.Solve.TabStop = false;
            this.Solve.Text = "Solve";
            this.Solve.UseVisualStyleBackColor = true;
            this.Solve.Click += new System.EventHandler(this.Solve_Click);
            // 
            // performanceBtn
            // 
            this.performanceBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.performanceBtn.Location = new System.Drawing.Point(568, 102);
            this.performanceBtn.Name = "performanceBtn";
            this.performanceBtn.Size = new System.Drawing.Size(75, 23);
            this.performanceBtn.TabIndex = 1;
            this.performanceBtn.TabStop = false;
            this.performanceBtn.Text = "Performance";
            this.performanceBtn.UseVisualStyleBackColor = true;
            this.performanceBtn.Click += new System.EventHandler(this.performanceBtn_Click);
            // 
            // randomizeBtn
            // 
            this.randomizeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.randomizeBtn.Location = new System.Drawing.Point(568, 141);
            this.randomizeBtn.Name = "randomizeBtn";
            this.randomizeBtn.Size = new System.Drawing.Size(75, 23);
            this.randomizeBtn.TabIndex = 2;
            this.randomizeBtn.TabStop = false;
            this.randomizeBtn.Text = "Randomize";
            this.randomizeBtn.UseVisualStyleBackColor = true;
            this.randomizeBtn.Click += new System.EventHandler(this.randomizeBtn_Click);
            // 
            // iInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 181);
            this.Controls.Add(this.randomizeBtn);
            this.Controls.Add(this.performanceBtn);
            this.Controls.Add(this.Solve);
            this.Controls.Add(this.AddVarBtn);
            this.KeyPreview = true;
            this.Name = "iInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Interface";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.iInterface_KeyUp);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AddVarBtn;
        private System.Windows.Forms.Button Solve;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Button performanceBtn;
        private System.Windows.Forms.Button randomizeBtn;
    }
}
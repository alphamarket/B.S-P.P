﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Interface
{
     partial class Result : Form
    {
        public Result(Genetic.Genetic genetic, String result, System.Reflection.MethodInfo method, iInterface parent)
        {
            InitializeComponent();
            this.Location = new Point(0, 0);
            this.richTextBox1.Text = result;
            this.KeyPreview = true;
            this.richTextBox1.ReadOnly = true;
            this.KeyDown += new KeyEventHandler((sender, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.S:
                        parent.Solve_Click(new object(), new EventArgs());
                        break;
                    case Keys.P:
                        //new Performance(method, genetic).Show();
                        break;
                    case Keys.Z:
                        this.Close();
                        break;
                    default:
                        break;
                }
            });
        }
    }
}

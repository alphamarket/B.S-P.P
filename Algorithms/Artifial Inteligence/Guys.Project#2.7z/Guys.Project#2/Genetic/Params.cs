﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Interface
{
    public partial class Params : Form
    {
        public Params()
        {
            InitializeComponent();
            this.selectionFunction.Hide();
            /*Type type = typeof(Core.Genetic.Utils.Selection.Selectors);
            foreach (var i in type.GetMethods())
            {
                if (i.Name.ToLower().Contains("selection"))
                    this.selectionFunction.Items.Add(i.Name);
            }
            this.selectionFunction.SelectedIndex = 0;
             */
            this.acceptableRate.KeyDown += new KeyEventHandler(AcceptableRate_KeyDown);
        }

        void AcceptableRate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
                return;
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
                return;
            if ((sender as TextBox).Text.Length != 0)
            {
                if ((sender as TextBox).Text.Replace(".", "").Replace("+", "").Replace("-", "").Length > 3)
                {
                    e.SuppressKeyPress = true;
                    return;
                }
            }
            if (e.KeyCode == Keys.OemPeriod)
            {
                e.SuppressKeyPress = (sender as TextBox).Text.Contains(".");
                return;
            }
            if ((sender as TextBox).Text.Length == 0)
            {
                if (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract)
                {
                    e.SuppressKeyPress = false;
                    return;
                }
            }
            float tmp = 0F;
            e.SuppressKeyPress = !float.TryParse((sender as TextBox).Text + ((char)e.KeyValue).ToString(), out tmp);
        }

        public float AcceptableRate { get { return float.Parse(this.acceptableRate.Text); } }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close() ;
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }



    }
}

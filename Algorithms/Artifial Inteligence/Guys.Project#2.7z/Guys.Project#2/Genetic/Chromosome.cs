﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genetic
{
    class Chromosome
    {
        public float[] Values;
        public float Fitness;
        public Chromosome(int size)
        {
            Values = new float[size];
        }
        // ye copy as magadire in class migire
        public Chromosome Copy()
        {
            Chromosome chromosome = new Chromosome(Values.Length);
            for (int i = 0; i < Values.Length; i++)
            {
                chromosome.Values[i] = Values[i];
            }
            chromosome.Fitness = Fitness;
            return chromosome;
        }
        public override string ToString()
        {
            return Fitness.ToString();
        }
    }
}

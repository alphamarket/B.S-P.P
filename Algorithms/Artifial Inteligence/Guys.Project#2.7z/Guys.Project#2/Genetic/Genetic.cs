﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genetic
{
    class Genetic
    {
        public List<List<Chromosome>> History = new List<List<Chromosome>>();

        List<Chromosome> CurrentGeneration = new List<Chromosome>();
        List<Chromosome> NextGeneration = new List<Chromosome>();

        int PopulationCount;
        int GenerationLimit;
        float CrossoverPercent;
        float ElitistCount;
        float MutationPercent;
        float[,] Equation;
        Random CrossOverRandom = new Random(Environment.TickCount);
        Random MutationRandom = new Random(Environment.TickCount);
        Random CrossOverProbability = new Random(Environment.TickCount);
        Random MutationProbability = new Random(Environment.TickCount);
        Random ValueRandom = new Random(Environment.TickCount);
        Random SelectionRandom = new Random(Environment.TickCount);



        public Genetic(float[,] equation, int populationcount, int generationlimit, float crossoverpercent, float elitistcount, float mutationpercent)
        {
            if (equation.GetLength(1) > 2)
                throw new Exception();
            PopulationCount = populationcount;
            GenerationLimit = generationlimit;
            CrossoverPercent = crossoverpercent;
            ElitistCount = elitistcount;
            MutationPercent = mutationpercent;
            Equation = equation;
        }


        public Chromosome Run()
        {
            /*
             *
             * اینجا متغییر ها رو مقدار دهی میکنیم 
             * 
             */
            CrossOverRandom = new Random(Environment.TickCount);
            MutationRandom = new Random(Environment.TickCount);
            CrossOverProbability = new Random(Environment.TickCount);
            MutationProbability = new Random(Environment.TickCount);
            ValueRandom = new Random(Environment.TickCount);
            SelectionRandom = new Random(Environment.TickCount);
            CurrentGeneration = RandomizeGeneration();
            NextGeneration = new List<Chromosome>();
            History = new List<List<Chromosome>>();
            /*
             * generationCounter شمارنده ی نسل هاست
             */
            int generationCounter = 0;
            while (generationCounter++ < GenerationLimit)
            {
                /*
                 * فیتنس 
                 * CurrentGeneration 
                 * رو حساب میکنه
                 */
                Fitness();
                /*
                 * CurrentGeneration 
                 * رو بر حسب فیتنس سورت میکنه
                 */
                Sort();
                /*
                 * اگه الگوریتم به جواب رسید الگوریتم خاتمه مییابد
                 */ 
                if (HasReachTheGoal())
                {
                    /*
                     * CurrentGeneration
                     * به 
                     * History
                     * اضافه میشه
                     */ 
                    AddToHistory();
                    /*
                     * بهترین ند از نظر فیتنس رو برمیگردونه
                     */
                    return CurrentGeneration[0];
                }
                /*
                 * نخبه گرایی رو این تابع انجام میده
                 */ 
                InsertElitists();
                /*
                 * این تابع با استفاده از تابع 
                 * Selection
                 * اعضا رو وارد 
                 * NextGeneration
                 * میکنه
                 */ 
                InsertMembers();
                /*
                 * جهش اینجا اتفاق میوفته
                 */  
                Mutation();
                /*
                 * CurrentGeneration
                 * به 
                 * History
                 * اضافه میشه
                 */ 
                AddToHistory();
                /*
                 * NextGeneration 
                 * کپی میکنه تو
                 * CurrentGeneration
                 */ 
                SwapGeneration();
            }
            /*
             * بهترین ند از نظر فیتنس رو برمیگردونه
             */
            return CurrentGeneration[0];
        }

        private void IsDoingFine()
        {
            if (History.Count > 0 && History[0][0].Fitness < CurrentGeneration[0].Fitness)
                throw new Exception("Algorithm is not working fine ...");
        }

        /*
         * اگه الگوریتم به جواب رسید الگوریتم خاتمه مییابد
         */ 
        private bool HasReachTheGoal()
        {
            if (CurrentGeneration[0].Fitness <= 0.1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * این تابع با استفاده از تابع 
         * Selection
         * اعضا رو وارد 
         * NextGeneration
         * میکنه
         */ 
        private void InsertMembers()
        {
            while (NextGeneration.Count < CurrentGeneration.Count)
            {
                Chromosome[] chromosomes = Select();
                Crossover(chromosomes);
                for (int i = 0; i < chromosomes.Length; i++)
                {
                    if (NextGeneration.Count < CurrentGeneration.Count)
                        NextGeneration.Add(chromosomes[i]);
                }
            }
        }

        /*
         * NextGeneration 
         * کپی میکنه تو
         * CurrentGeneration
         */ 
        private void SwapGeneration()
        {
            CurrentGeneration = new List<Chromosome>();

            for (int i = 0; i < PopulationCount; i++)
            {
                CurrentGeneration.Add(NextGeneration[i].Copy());
            }
        }

        /*
         * CurrentGeneration
         * به 
         * History
         * اضافه میشه
         */ 
        private void AddToHistory()
        {
            List<Chromosome> list = new List<Chromosome>();
            for (int i = 0; i < CurrentGeneration.Count; i++)
            {
                list.Add(CurrentGeneration[i].Copy());
            }
            History.Add(list);
        }

        /*
         * جهش اینجا اتفاق میوفته
         */  
        private void Mutation()
        {
            for (int i = 0; i < NextGeneration.Count; i++)
            {
                if (MutationProbability.NextDouble() <= MutationPercent)
                {
                    int index = MutationRandom.Next(0, Equation.GetLength(1));
                    NextGeneration[i].Values[index] = ValueRandom.Next(-100, 100);
                }
            }
        }
        /*
         * عمل
         * Crossover
         * رو انجام میده
         */
        private void Crossover(Chromosome[] chromosomes)
        {
            if ((float)CrossOverProbability.NextDouble() <= CrossoverPercent)
            {
                for (int i = 0; i < chromosomes.Length - 1; i = i + 2)
                {
                    // ye pivote point entexab mikone
                    int pvot = CrossOverRandom.Next(0, chromosomes.Length);
                    // ta avale pivote point swap mikone
                    for (int j = 0; j < pvot; j++)
                    {
                        var tmp = chromosomes[i].Values[j];
                        chromosomes[i].Values[j] = chromosomes[i + 1].Values[j];
                        chromosomes[i + 1].Values[j] = tmp;
                    }
                }
            }
        }

        /*
         * نخبه گرایی رو این تابع انجام میده
         */ 
        private void InsertElitists()
        {
            // ye next generation jadid besaz
            NextGeneration = new List<Chromosome>();
            for (int i = 0; i < ElitistCount; i++)
            {
                NextGeneration.Add(CurrentGeneration[i].Copy());
            }
        }

        /*
         * CurrentGeneration 
         * رو بر حسب فیتنس سورت میکنه
         */
        private void Sort()
        {
            /*
             * 
             * Mitoonid az in ham estefade konid, soorate in O(n*log(n))ke bara 400 ta mishe 1040P[:)] mibashad ke khyli khube
             * 
             */
            CurrentGeneration.Sort(new Comparison<Chromosome>(sortDelegateFunction));

            /*
             * ya ye bubble sort ke az O(n*n) => ke bara 400 ta mishe 160000P(!!!!) mibashad ke khyli paiine
             *
            for (int i = 0; i < CurrentGeneration.Count; i++)
            {
                for (int j = i; j < CurrentGeneration.Count; j++)
                {
                    if (CurrentGeneration[i].Fitness > CurrentGeneration[j].Fitness)
                    {
                        Chromosome tmp = CurrentGeneration[i];
                        CurrentGeneration[i] = CurrentGeneration[j];
                        CurrentGeneration[j] = tmp;
                    }
                }
            }*/

            /*
             * Harkodom haratin on ro entexab konid 
             */
        }
        /*
         * نسل اولیه رو بطور رندم تولید میکنه
         */ 
        List<Chromosome> RandomizeGeneration()
        {
            Random random = new Random(Environment.TickCount);
            List<Chromosome> list = new List<Chromosome>();

            for (int i = 0; i < PopulationCount; i++)
            {
                Chromosome chromosome = new Chromosome(Equation.GetLength(0));
                for (int j = 0; j < Equation.GetLength(0); j++)
                {
                    chromosome.Values[j] = (-100)
                        + (float)random.NextDouble() * ((100) - (-100) + 1);
                    if (chromosome.Values[j] > float.MaxValue)
                        chromosome.Values[j] = float.MaxValue;
                    if (chromosome.Values[j] < float.MinValue)
                        chromosome.Values[j] = float.MinValue;
                }
                list.Add(chromosome);
            }
            return list;
        }
        /*
         * عملیات 
         * Select
         * روی 
         * CurrentGeneration
         * انجام میده, و در 
         * NextGeneration
         * میذاره
         */ 
        Chromosome[] Select()
        {
            int selectingRato = 20;

            Chromosome[]
                chromosome = new Chromosome[selectingRato],
                selected = new Chromosome[2];

            for (int i = 0; i < selectingRato; i++)
            {
                chromosome[i] = CurrentGeneration[SelectionRandom.Next(0, CurrentGeneration.Count - 1)].Copy();
            }

            Array.Sort(chromosome, new Comparison<Chromosome>(sortDelegateFunction));

            return new Chromosome[] { chromosome[0], chromosome[1] };
        }
        /*
         * این تابعی اییه که برا 
         * Sort 
         * کردن کروموزوم ها استفاده میشه و به صورت 
         * Delegate
         * به تابع
         * Sort
         * پاس داده میشه
         */
        int sortDelegateFunction(Chromosome c1, Chromosome c2)
        {
            if (float.IsNaN(c1.Fitness))
            {
                c2.Fitness = float.MaxValue;
            }
            if (float.IsNaN(c2.Fitness))
            {
                c2.Fitness = float.MaxValue;
            }
            if (c1.Fitness < c2.Fitness)
                return -1;
            if (c1.Fitness > c2.Fitness)
                return 1;
            return 0;
        }

        /*
         * فیتنس 
         * CurrentGeneration 
         * رو حساب میکنه
         */
        void Fitness()
        {
            for (int i = 0; i < CurrentGeneration.Count; i++)
            {
                float m = 0;
                int l = Equation.GetLength(0);
                for (int j = 0; j < Equation.GetLength(0); j++)
                {
                    m = m + (float)Math.Pow(CurrentGeneration[i].Values[j], Equation[j, 1]) * Equation[j, 0];
                }
                if (float.IsNaN((float)Math.Abs(m)))
                {
                    CurrentGeneration[i].Fitness = float.MaxValue;
                }
                else
                {
                    CurrentGeneration[i].Fitness = (float)Math.Abs(m);
                }
            }
        }
    }
}
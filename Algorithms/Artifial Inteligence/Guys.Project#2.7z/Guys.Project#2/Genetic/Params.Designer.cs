﻿namespace Interface
{
    partial class Params
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PopulationMount = new System.Windows.Forms.NumericUpDown();
            this.MaxGeneration = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.CrossoverProb = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.MutateProb = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.EliteRate = new System.Windows.Forms.NumericUpDown();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.selectionFunction = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.acceptableRate = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.PopulationMount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxGeneration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CrossoverProb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MutateProb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EliteRate)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter population mount : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Max. number of generation :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Probability of crossover phenomenona :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(187, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Probability of mutation phenomenona :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Elite selection rate :";
            // 
            // PopulationMount
            // 
            this.PopulationMount.Location = new System.Drawing.Point(274, 11);
            this.PopulationMount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.PopulationMount.Name = "PopulationMount";
            this.PopulationMount.Size = new System.Drawing.Size(120, 20);
            this.PopulationMount.TabIndex = 2;
            this.PopulationMount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PopulationMount.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // MaxGeneration
            // 
            this.MaxGeneration.Location = new System.Drawing.Point(274, 50);
            this.MaxGeneration.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.MaxGeneration.Name = "MaxGeneration";
            this.MaxGeneration.Size = new System.Drawing.Size(120, 20);
            this.MaxGeneration.TabIndex = 3;
            this.MaxGeneration.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MaxGeneration.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(400, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "%";
            // 
            // CrossoverProb
            // 
            this.CrossoverProb.Location = new System.Drawing.Point(274, 88);
            this.CrossoverProb.Name = "CrossoverProb";
            this.CrossoverProb.Size = new System.Drawing.Size(120, 20);
            this.CrossoverProb.TabIndex = 4;
            this.CrossoverProb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CrossoverProb.Value = new decimal(new int[] {
            75,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(400, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "%";
            // 
            // MutateProb
            // 
            this.MutateProb.Location = new System.Drawing.Point(274, 129);
            this.MutateProb.Name = "MutateProb";
            this.MutateProb.Size = new System.Drawing.Size(120, 20);
            this.MutateProb.TabIndex = 5;
            this.MutateProb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MutateProb.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(400, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "%";
            // 
            // EliteRate
            // 
            this.EliteRate.Location = new System.Drawing.Point(274, 172);
            this.EliteRate.Name = "EliteRate";
            this.EliteRate.Size = new System.Drawing.Size(120, 20);
            this.EliteRate.TabIndex = 6;
            this.EliteRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EliteRate.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SubmitBtn.Location = new System.Drawing.Point(319, 293);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(76, 23);
            this.SubmitBtn.TabIndex = 0;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CancelBtn.Location = new System.Drawing.Point(238, 293);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(76, 23);
            this.CancelBtn.TabIndex = 1;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Selection funtion : ";
            // 
            // selectionFunction
            // 
            this.selectionFunction.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.selectionFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectionFunction.FormattingEnabled = true;
            this.selectionFunction.Location = new System.Drawing.Point(182, 253);
            this.selectionFunction.Name = "selectionFunction";
            this.selectionFunction.Size = new System.Drawing.Size(213, 21);
            this.selectionFunction.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 216);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Acceptable rate for chromosome :";
            // 
            // acceptableRate
            // 
            this.acceptableRate.Location = new System.Drawing.Point(274, 211);
            this.acceptableRate.Name = "acceptableRate";
            this.acceptableRate.Size = new System.Drawing.Size(120, 20);
            this.acceptableRate.TabIndex = 7;
            this.acceptableRate.Text = "0.1";
            this.acceptableRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Params
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 329);
            this.Controls.Add(this.acceptableRate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.selectionFunction);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.EliteRate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.MutateProb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CrossoverProb);
            this.Controls.Add(this.MaxGeneration);
            this.Controls.Add(this.PopulationMount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Params";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Algorithm Params";
            ((System.ComponentModel.ISupportInitialize)(this.PopulationMount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxGeneration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CrossoverProb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MutateProb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EliteRate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Button CancelBtn;
        public System.Windows.Forms.NumericUpDown PopulationMount;
        public System.Windows.Forms.NumericUpDown MaxGeneration;
        public System.Windows.Forms.NumericUpDown CrossoverProb;
        public System.Windows.Forms.NumericUpDown MutateProb;
        public System.Windows.Forms.NumericUpDown EliteRate;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.ComboBox selectionFunction;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox acceptableRate;
    }
}
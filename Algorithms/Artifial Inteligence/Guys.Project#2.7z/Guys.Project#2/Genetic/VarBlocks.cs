﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Interface
{
    public partial class VarBlocks : UserControl
    {
        public VarBlocks()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Get or Set if the plus sign is visible or not
        /// </summary>
        public bool PlusSignVisible
        {
            get
            {
                return plusSign.Visible;
            }
            set
            {
                plusSign.Visible = value;
            }
        }
        /// <summary>
        /// Get or Set variable's name
        /// </summary>
        public String VariableName
        {
            get
            {
                return VName.Text;
            }
            set
            {
                VName.Text = value;
            }
        }
        /// <summary>
        /// Get or Set variable's times factor value
        /// </summary>
        public float TimesValue
        {
            get
            {
                return textBox1.Text != "" ? float.Parse(textBox1.Text) : 1;
            }
            set
            {
                textBox1.Text = value.ToString();
            }
        }
        /// <summary>
        /// Get or Set variable's times factor value
        /// </summary>
        public float PowValue
        {
            get
            {
                return textBox2.Text != "" ? float.Parse(textBox2.Text) : 1;
            }
            set
            {
                textBox2.Text = value.ToString();
            }
        }

        private void textBoxes_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
                return;
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
                return;
            if ((sender as TextBox).Text.Length != 0)
            {
                if((sender as TextBox).Text.Replace(".","").Replace("+","").Replace("-","").Length>3)
                {
                    e.SuppressKeyPress = true;
                    return;
                }
            }
            if (e.KeyCode == Keys.OemPeriod)
            {
                e.SuppressKeyPress = (sender as TextBox).Text.Contains(".");
                return;
            }
            if ((sender as TextBox).Text.Length == 0)
            {
                if (e.KeyCode == Keys.OemMinus || e.KeyCode == Keys.Subtract)
                {
                    e.SuppressKeyPress = false;
                    return;
                }
            }
            float tmp = 0F;
            e.SuppressKeyPress = !float.TryParse((sender as TextBox).Text + ((char)e.KeyValue).ToString(), out tmp);
        }
    }
}

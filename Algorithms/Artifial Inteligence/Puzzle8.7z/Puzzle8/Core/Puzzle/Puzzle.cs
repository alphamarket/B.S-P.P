﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Extentions;
using System.IO;
namespace Core.Logic
{
    using Index = Int32;
    using Value = Int32;
    public class Puzzle : ICloneable
    {
        #region PROPERTIES
        /// <summary>
        /// Get puzzle current state
        /// </summary>
        public List<Value> States { get; set; }
        /// <summary>
        /// Get size of puzzle
        /// </summary>
        public uint Size { get; protected set; }
        /// <summary>
        /// Get blank index value
        /// </summary>
        public Index BlankIndex
        {
            get
            {
                var result = new List<Index>(
                                            this.States.Select<int, int>((value, index)
                                            =>
                                            {
                                                if (value == 0)
                                                    return index;
                                                return -1;
                                            }).
                                            Where<int>((value) => { return value != -1; })
                                          );
                return result[0];
            }
        }
        #endregion

        #region PUBLICS
        /// <summary>
        /// Adjust the new instance of puzzle with new puzzle peace info collection
        /// </summary>
        /// <param name="puzzle">puzzle peace info collection</param>
        public Puzzle(ICollection<Value> puzzle)
            : this(puzzle.Count)
        {
            this.States.Clear();
            this.States.AddRange(puzzle);
        }
        /// <summary>
        /// Initialize new instace of puzzle
        /// </summary>
        /// <param name="size">size of puzzle</param>
        public Puzzle(Value size)
        {
            this.States = new List<Value>();
            this.Size = (uint)size;
            this.Shuffle();
        }
        /// <summary>
        /// Shuffle a new puzzle
        /// </summary>
        public void Shuffle()
        {
            this.States.Clear();
            Random random = new Random(Environment.TickCount);
            // initialize all states to cooresponded index value
            for (Index i = 0; i < this.Size; i++)
            {
                this.States.Add(i);
            }
            // shuffle the states
            for (int i = 0; i < this.Size - 1; i++)
            {
                this.States.Swap<int>(i, random.Next(i + 1, (Value)this.Size));
            }
            this.MakeSolvable();
        }
        /// <summary>
        /// Binds each of states to an specific values
        /// </summary>
        /// <typeparam name="T">Types of values</typeparam>
        /// <param name="binds">Collection to bind</param>
        public void Bind<T>(ICollection<T> bounds)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Check if the current state of puzzle is solveable or not
        /// </summary>
        /// <returns>returns true if the puzzle if solvable;otherwise false</returns>
        public bool IsSolvable()
        {
            int isSolvable = 0;
            for (int i = 0; i < this.Size; i++)
                for (int j = i + 1; j < this.Size; j++)
                    if (j != this.BlankIndex && this.States[i] > this.States[j])
                        isSolvable++;
            return isSolvable % 2 == 0;
        }
        /// <summary>
        /// Makes the current state of puzzle solvable
        /// </summary>
        public void MakeSolvable()
        {
            if (!this.IsSolvable())
            {
                int k = this.States[(this.BlankIndex == 8) ? this.BlankIndex - 2 : this.BlankIndex + 1];
                this.States[(this.BlankIndex == 8) ? this.BlankIndex - 2 : this.BlankIndex + 1] = this.States[(this.BlankIndex == 0) ? this.BlankIndex + 2 : this.BlankIndex - 1];
                this.States[(this.BlankIndex == 0) ? this.BlankIndex + 2 : this.BlankIndex - 1] = k;
            }
        }
        /// <summary>
        /// Get unique hash code for current states
        /// </summary>
        /// <returns>calcuated hash code</returns>
        public new float GetHashCode()
        {
            float value = 0;
            for (int i = 0; i < this.Size; i++)
            {
                value = value + (float)Math.Exp(this.States[i] + 1) * (i + 1);
            }
            // normalizing the value
            return (float)Math.Floor(value * 100); 
        }

        public void Stream(TextWriter sw)
        {
            for (int h = 0; h < this.Size; h++)
            {
                if (h != 0 && h % Math.Sqrt((double)this.Size) == 0)
                    sw.WriteLine();
                string tmp = String.Format("{0} ", this.States[h] != 0 ? this.States[h].ToString() : " ");
                sw.Write(tmp);
            }
            sw.WriteLine();
        }
        #endregion

        #region ICloneable Members
        /// <summary>
        /// Get new cloned instance of current puzzle states
        /// </summary>
        /// <returns>An object type of Core.Puzzle.Puzzle</returns>
        public object Clone()
        {
            return new Puzzle(this.States);
        }
        #endregion
    }
}

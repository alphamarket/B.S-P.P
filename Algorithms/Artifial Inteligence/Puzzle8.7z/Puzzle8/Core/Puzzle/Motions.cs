﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Extentions;
namespace Core.Logic
{
    using Index = Int32;
    using Value = Int32;
    public class Motions : ICloneable
    {
        #region ENUMERATIONS
        public enum Direction { Up, Left, Down, Right };
        #endregion

        #region PROPERTIES
        /// <summary>
        /// Bounded puzzle to current motion operations
        /// </summary>
        public Puzzle Puzzle { get; protected set; }
        #endregion

        #region PUBLICS
        /// <summary>
        /// Bound a motion to a puzzle
        /// </summary>
        /// <param name="puzzle">Target puzzle to bound</param>
        public Motions(Puzzle puzzle)
        {
            this.Puzzle = puzzle;
        }
        /// <summary>
        /// check if the movement of index puzzle to the given directio is legal
        /// </summary>
        /// <param name="index">Target index</param>
        /// <param name="direction">Target Direction</param>
        /// <returns>returns true if the movement is legal; otherwise false</returns>
        public bool CanMove(Index index, Direction direction)
        {
            var sqrt = Math.Sqrt((double)this.Puzzle.Size);

            switch (direction)
            {
                case Direction.Up:
                    return index - sqrt > -1;
                case Direction.Left:
                    return index % sqrt != 0;
                case Direction.Down:
                    return index + sqrt < this.Puzzle.Size;
                case Direction.Right:
                    return index % sqrt != sqrt - 1;
                default:
                    return false;
            }
        }
        /// <summary>
        /// Check the legality of the blank state movement toward the direction
        /// </summary>
        /// <param name="direction">Target direction</param>
        /// <returns>returns true if the movement is legal; otherwise false</returns>
        public bool CanBlankMove(Direction direction)
        {
            return this.CanMove(this.Puzzle.BlankIndex, direction);
        }
        /// <summary>
        /// Get near by state of given state
        /// </summary>
        /// <param name="index">Target state to determine the near by states</param>
        /// <param name="direction">Target direction</param>
        /// <returns>A pair key value [ Index , Value ]</returns>
        public KeyValuePair<Index, Value> GetNearByState(Index index, Direction direction, bool throwException)
        {
            if (!this.CanMove(index, direction))
            {
                if (throwException)
                    throw new ApplicationException(String.Format("There is no near by state of index [{0}] in {1} direction", index, direction));
                else
                    return new KeyValuePair<int, int>(-1, -1);
            }

            var sqrt = (int)Math.Sqrt((double)this.Puzzle.Size);
            try
            {
                switch (direction)
                {
                    case Direction.Up:
                        return new KeyValuePair<int, int>(index - sqrt, this.Puzzle.States[index - sqrt]);
                    case Direction.Left:
                        return new KeyValuePair<int, int>(index - 1, this.Puzzle.States[index - 1]);
                    case Direction.Down:
                        return new KeyValuePair<int, int>(index + sqrt, this.Puzzle.States[index + sqrt]);
                    case Direction.Right:
                        return new KeyValuePair<int, int>(index + 1, this.Puzzle.States[index + 1]);
                }
            }
            catch { }
            return new KeyValuePair<int, int>(-1, -1);
        }
        /// <summary>
        /// Get near by state of given state
        /// </summary>
        /// <param name="index">Target state to determine the near by states</param>
        /// <returns>A pair key value [ Index , Value ]</returns>
        public ICollection<KeyValuePair<Index, Value>> GetAllNearByStates(Index index)
        {
            List<KeyValuePair<Index, Value>> list = new List<KeyValuePair<int, int>>();
            foreach (var i in Enum.GetNames(typeof(Direction)))
            {
                Direction dir = (Direction)Enum.Parse(typeof(Direction), i);
                var j = this.GetNearByState(index, dir, false);
                if (j.Key != -1)
                    list.Add(j);
            }
            return list;
        }
        /// <summary>
        /// Swap two states in related direction
        /// </summary>
        /// <param name="index">Target index</param>
        /// <param name="direction">states in target direction</param>
        /// <returns>True if the movement is done successfully;otherwise false</returns>
        public bool Move(Index index, Direction direction)
        {
            if (!this.CanMove(index, direction))
                return false;

            this.Puzzle.States.Swap<Value>(index, this.GetNearByState(index, direction, true).Key);
            return true;
        }
        /// <summary>
        /// Move blank state to given direction
        /// </summary>
        /// <param name="direction">Target direction</param>
        /// <returns>True if the movement is done successfully;otherwise false</returns>
        public bool MoveBlank(Direction direction)
        {
            return this.Move(this.Puzzle.BlankIndex, direction);
        }
        /// <summary>
        /// check if the puzzle has reached the goal
        /// </summary>
        /// <param name="finalPuzzle">final possition of puzzle's states</param>
        /// <returns>returns true if the puzzle's states has reached the target states</returns>
        public bool IsReachedGaol(Puzzle finalPuzzle)
        {
            for (int i = 0; i < this.Puzzle.Size; i++)
            {
                if (this.Puzzle.States[i] != i + 1 && i != this.Puzzle.BlankIndex)
                    return false;
            }
            return true;
        }
        /// <summary>
        /// Moves an block to nearby blank block
        /// </summary>
        /// <param name="index">Target block to move into blank space</param>
        /// <returns>returns true if the movement is done; otherwise false.</returns>
        public bool MoveToBlank(Index index)
        {
            foreach (var i in Enum.GetNames(typeof(Direction)))
            {
                Direction dir = (Direction)Enum.Parse(typeof(Direction), i);
                var j = this.GetNearByState(index, dir, false);
                if (j.Key == this.Puzzle.BlankIndex)
                {
                    this.Move(index, dir);
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// Get unique hash value to current contained puzzle states
        /// </summary>
        /// <returns></returns>
        public new float GetHashCode()
        {
            return Puzzle.GetHashCode();
        }
        #endregion

        #region ICloneable Members

        public object Clone()
        {
            return new Motions(this.Puzzle.Clone() as Puzzle);
        }

        #endregion
    }
}
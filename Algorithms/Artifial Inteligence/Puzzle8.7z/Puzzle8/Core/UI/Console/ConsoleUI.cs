﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.AI;
using Core.Logic;
namespace Core.UI.Console
{
    public class ConcoleUI
    {
        public void Run(string[] args)
        {
            var puzzle = new Puzzle(9);
            o("Puzzle created ...");
            int ctop = System.Console.CursorTop;
        __DRAW_PUZZLE:
            DrawPuzzle(puzzle, ctop);
            o();
            var motions = new Motions(puzzle);
            o("Motions bounded to puzzle ...");
            try
            {
                while (true)
                {
                    if (motions.IsReachedGaol(new Puzzle(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 0 })))
                    {
                        o("you have solved the puzzle ...");
                        return;
                    }
                    var dir = KybrdBound();
                    dir = getReverseDirection(dir);
                    if (motions.MoveBlank(dir))
                        goto __DRAW_PUZZLE;
                }
            }
            catch (SolveInteruptException)
            {
                o("Solve hot-key initiated ...");
                Solve s = new Solve(motions);
                o("Initiating solving process ...");
                int start_tick = Environment.TickCount;
                var solu = s.Initiate();
                System.Console.WriteLine("Puzzle solved in {0} With {1} moves.", new TimeSpan((Environment.TickCount - start_tick) * 10000), solu.Count);
                System.Console.CursorVisible = false;
                int tmp_ctop = System.Console.CursorTop;
                foreach (var i in solu)
                {
                    if (motions.MoveBlank(getReverseDirection(i.Value)))
                    {
                        DrawPuzzle(puzzle, ctop);
                        System.Threading.Thread.Sleep(300);
                    }
                }
                System.Console.CursorTop = tmp_ctop;
                System.Console.CursorLeft = 0;
                o("Printing solution is done ...");
            }
        }

        private void DrawPuzzle(Puzzle puzzle, int ctop)
        {
            System.Console.CursorTop = ctop;
            System.Console.CursorLeft = 0;
            var ccolor = System.Console.ForegroundColor;
            System.Console.ForegroundColor = System.ConsoleColor.White;
            for (int i = 0; i < puzzle.Size; i++)
            {
                if (i != 0 && i % 3 == 0)
                    o();
                if (puzzle.States[i] == 0)
                {
                    System.Console.Write("  ");
                    continue;
                }
                System.Console.Write("{0} ", puzzle.States[i]);
            }
            System.Console.ForegroundColor = ccolor;
        }

        protected Motions.Direction getReverseDirection(Motions.Direction dir)
        {
            switch (dir)
            {
                case Motions.Direction.Up:
                    dir = Motions.Direction.Down;
                    break;
                case Motions.Direction.Left:
                    dir = Motions.Direction.Right;
                    break;
                case Motions.Direction.Down:
                    dir = Motions.Direction.Up;
                    break;
                case Motions.Direction.Right:
                    dir = Motions.Direction.Left;
                    break;
            }
            return dir;
        }
        protected Motions.Direction KybrdBound()
        {
            while (true)
            {
                var rk = System.Console.ReadKey(true);
                switch (rk.Key)
                {
                    case System.ConsoleKey.C:
                        if (rk.Modifiers == System.ConsoleModifiers.Control)
                            System.Diagnostics.Process.GetCurrentProcess().Kill();
                        break;
                    case System.ConsoleKey.UpArrow:
                        return Motions.Direction.Up;
                    case System.ConsoleKey.DownArrow:
                        return Motions.Direction.Down;
                    case System.ConsoleKey.RightArrow:
                        return Motions.Direction.Right;
                    case System.ConsoleKey.LeftArrow:
                        return Motions.Direction.Left;
                    case System.ConsoleKey.S:
                        throw new SolveInteruptException();
                    default:
                        break;
                }
            }
        }
        protected void o()
        {
            this.o("");
        }
        protected void o(string str)
        {
            System.Console.WriteLine(str);
        }
    }
}

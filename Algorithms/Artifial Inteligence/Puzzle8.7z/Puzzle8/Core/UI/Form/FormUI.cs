﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Core.AI;
using Core.Logic;
namespace Core.UI.Form
{
    public partial class FormUI : System.Windows.Forms.Form
    {
        /**
         * Protected global instances
         */
        /// <summary>
        /// Get or Set puzzle instance used in this form 
        /// </summary>
        protected Puzzle puzzle { get; set; }
        /// <summary>
        /// Get or Set bounded puzzle motions' instance
        /// </summary>
        protected Motions motions { get; set; }
        /// <summary>
        /// A hash table for blocks; 
        /// The key would be block's index in 'this.Controls' collection;
        /// The value would be the taget controller
        /// </summary>
        protected System.Collections.Hashtable BlockMaps = new System.Collections.Hashtable();
        /// <summary>
        /// Thread used for solving puzzle
        /// </summary>
        protected System.Threading.Thread SolveThread = null;
        /// <summary>
        /// Construct a FormUI
        /// </summary>
        /// <param name="puzzle_size">
        /// Define the size of the puzzle
        /// </param>
        public FormUI(int puzzle_size)
        {
            // make sure we have a square puzzle 
            puzzle_size = (int)Math.Pow((int)Math.Sqrt(puzzle_size), 2);
            /**
             * Initializing puzzle instances
             */
            do
            {
                this.puzzle = new Puzzle(puzzle_size);
            } 
            while (!this.puzzle.IsSolvable());
            
            this.motions = new Motions(puzzle);
            /**
             * Initializing the form
             */ 
            InitializeComponent();
            /**
             * Initializing form's attributes
             */ 
            this.KeyPreview = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Try to solve the puzzle ...";
            /**
             * Draw the puzzle 
             */ 
            DrawPuzzle(this.puzzle);
            /**
             * A trigger on form  closing ...
             */ 
            this.FormClosing += new FormClosingEventHandler((sender, e) =>
            {
                // Kill the current process
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            });
            /**
             * A keydown event handler on form
             */ 
            this.KeyDown += new KeyEventHandler((sender, e) =>
            {
                switch (e.KeyCode)
                {
                        // The exit key
                    case Keys.Escape:
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        break;
                        // Shuffle the puzzle
                    case Keys.R:
                        // Reguardless of SolveThread's status Abort the SolveThread
                        // And ignore if any exception happens
                        try { this.SolveThread.Abort(); }
                        catch { }
                        // Shuffle the puzzle, initialized in FormUI's Ctor
                        this.puzzle.Shuffle();
                        // Re-Draw the puzzle 
                        DrawPuzzle(this.puzzle);
                        break;
                        // Solve the puzzle
                    case Keys.S:
                        if (e.Control)
                        {
                            // Create a thread
                            this.SolveThread = new System.Threading.Thread(new System.Threading.ThreadStart(() =>
                            {
                                /**
                                 * We are in a thread; so we need to invoke controller everytime 
                                 * we want to work with a controller!
                                 */
                                this.Invoke(new Action(() => { this.Enabled = false; }));
                                // create a solve instance
                                Solve s = new Solve(this.motions);
                                this.Invoke(new Action(() => { this.Text = "Solving the puzzle ..."; }));
                                int start_tick = Environment.TickCount;
                                // initiate the search procedure 
                                Queue<KeyValuePair<int, Core.Logic.Motions.Direction>> solu = s.Initiate();
                                // the Latest controller is a label
                                this.Invoke(new Action(() => { this.Controls[this.Controls.Count - 1].Text += String.Format("\r\n## Puzzle solved in {0} with {1} moves.", new TimeSpan((Environment.TickCount - start_tick) * 10000), solu.Count); }));
                                // inform the user
                                MessageBox.Show("Puzzle solved ...");
                                this.Invoke(new Action(() =>
                                {
                                    this.Activate(); 
                                    this.Text = "Puzzle solved ...";
                                }));
                                this.Invoke(new Action(() => { this.Enabled = true; })); 
                                // for every steps in given result queue
                                foreach (var i in solu)
                                {
                                    /*
                                     * get currently step's related block instance
                                     * with a identify key from BlockMaps hash table
                                     */
                                    var btn = (Button)this.BlockMaps[i.Key];
                                    // Initiate a click event simulator with passing the realated parameters
                                    btn.Invoke(new EventHandler(btn_Click),btn, new EventArgs());
                                    // Standby for sometime to show
                                    System.Threading.Thread.Sleep(300);
                                }
                            }));
                            // Initiate the thread
                            this.SolveThread.Start();

                        }
                        break;
                }
            });
        }
        /// <summary>
        /// Draw the given puzzle using controllers 
        /// </summary>
        /// <param name="puzzle">Puzzle to draw</param>
        protected void DrawPuzzle(Puzzle puzzle)
        {
            // clear the currently existance controller
            this.Controls.Clear();
            // clear the priviouse block maps
            BlockMaps.Clear();
            // for the size of the given puzzle 
            for (int i = 0; i < puzzle.Size; i++)
            {
                // create new blocks
                var btn = new Button();
                btn.Name = i.ToString();
                btn.Text = puzzle.States[i].ToString();
                // register to block maps
                BlockMaps.Add(int.Parse(btn.Text), btn);
                /**
                 * Define the location of the currently created block on the board
                 */ 
                if (this.Controls.Count != 0)
                {
                    var lastController = this.Controls[this.Controls.Count - 1];
                    if (i != 0 && i % Math.Sqrt(puzzle.Size) == 0)
                    {
                        btn.Top = lastController.Top + lastController.Size.Height + 20;
                        btn.Left = 20;
                    }
                    else
                    {
                        btn.Top = lastController.Top;
                        btn.Left = lastController.Left + lastController.Size.Width + 20;
                    }
                }
                else
                {
                    btn.Top = 20;
                    btn.Left = 20;
                }
                // define the size of the block
                btn.Size = new Size(100, 100);
                // if the currently created block 
                // is the blank block; invisible it.
                if (puzzle.States[i] == 0)
                    btn.Visible = false;
                // bind to a click event hanlder
                btn.Click += new EventHandler(btn_Click);
                // register the controller in the form
                this.Controls.Add(btn);
            }
            // a label for output the status
            Label l = new Label();
            // define the label's size
            l.Size = new Size(300, 40);
            // dynamic definition of localtion of the label according to the privious controller's location
            l.Location = new Point(20, this.Controls[this.Controls.Count - 1].Top + this.Controls[this.Controls.Count - 1].Height + 20);
            // output some info on the label
            l.Text = "1) Press 'R' to shuffle the puzzle.\r\n2) Press 'Ctrl+S' to solve the puzzle.";
            // register the label
            this.Controls.Add(l);
            // dynamic definition of size of the form according to the privious controller's location(i.e Ouput Label's location) 
            this.Size = new Size(this.Controls[(int)Math.Sqrt(puzzle.Size) - 1].Left + this.Controls[(int)Math.Sqrt(puzzle.Size) - 1].Width + 30,
                this.Controls[this.Controls.Count - 1].Top + this.Controls[this.Controls.Count - 1].Height + 50);
        }
        /// <summary>
        /// initiated when a block clicked
        /// </summary>
        /// <param name="sender">the block object</param>
        /// <param name="e">the calling event(i.e click)</param>
        protected void btn_Click(object sender, EventArgs e)
        {
            // fetch the objective puzzle status array
            int[] goal = this.GetPuzzleGoalArray(this.puzzle); 
            // if the puzzle solved? do nothing
            if (this.motions.IsReachedGaol(new Puzzle(goal)))
            {
                return;
            }
            // fetch the block's instance
            Button btn = sender as Button;
            // fetch the block's id
            int state_id = int.Parse(btn.Text);
            // fetch the blank block's index
            int blnk_index = this.puzzle.BlankIndex;
            // if a legal movement using the clicked block can happen? 
            // Initiate the movement & Visiualize the movement
            if (this.motions.MoveToBlank(int.Parse(btn.Name)))
            {
                /**
                 * Update BlockMaps hashtable's data 
                 */ 
                BlockMaps[state_id] = this.Controls[blnk_index];
                // Redefine the blank block's instance
                BlockMaps[0] = btn;
                /**
                 * Update involved blocks' data
                 */ 
                this.Controls[blnk_index].Text = state_id.ToString();
                this.Controls[blnk_index].Visible = true;
                btn.Text = "0";
                btn.Visible = false;
            }
            /**
             * If resualt of the previous movement is the goal objective
             * Inform the user
             */ 
            if (this.motions.IsReachedGaol(new Puzzle(goal)))
            {
                MessageBox.Show("Congratulations! You have solved the puzzle ...");
            }
        }
        /// <summary>
        /// Get a sample of goal array
        /// </summary>
        /// <param name="puzzle">The target puzzle</param>
        /// <returns>Goal array</returns>
        protected int[] GetPuzzleGoalArray(Puzzle puzzle)
        {
            int[] goal = new int[puzzle.Size];
            for (int i = 0; i < puzzle.Size - 1; i++)
            {
                goal[i] = i + 1;
            }
            // the latest block should be blank
            goal[puzzle.Size - 1] = 0;
            return goal;
        }
    }
}

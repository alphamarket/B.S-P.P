﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Core.DataStructures.Sorting
{
    public class BinaryQueue<T> : IEnumerable<T>, IDisposable
    {
        protected Comparison<T> Comparer { get; set; }

        internal System.Collections.ArrayList StorageArrayList { get; set; }

        public BinaryQueue(Comparison<T> comparerFunc)
        {
            this.Comparer = comparerFunc;
            this.StorageArrayList = new System.Collections.ArrayList();
        }

        #region ICollection<T> Members

        public void Enqueue(T item)
        {
            if (this.StorageArrayList.Count == 0)
            {
                this.StorageArrayList.Add(item);
                return;
            }
            int left = 0,
                right = this.StorageArrayList.Count - 1,
                pvot = this.StorageArrayList.Count / 2;
            if (this.Comparer((T)this.StorageArrayList[left], item) >= 0)
            {
                this.StorageArrayList.Insert(left, item);
                return;
            }
            if (this.Comparer((T)this.StorageArrayList[right], item) <= 0)
            {
                this.StorageArrayList.Add(item);
                return;
            }
            int cpr_result = 0;
            while (left < right)
            {
                cpr_result = this.Comparer((T)this.StorageArrayList[pvot], item);
                if (cpr_result > 0)
                {
                    right = pvot - 1;
                }
                else if (cpr_result < 0)
                {
                    left = pvot + 1;
                }
                else
                {
                    break;
                }
                pvot = (right + left) / 2;
            }
            if (this.Comparer((T)this.StorageArrayList[pvot], item) < 0)
                this.StorageArrayList.Insert(pvot + 1, item);
            else
                this.StorageArrayList.Insert(pvot, item);
        }

        public T Dequeue()
        {
            if (this.StorageArrayList.Count == 0)
                throw new Exception("The queue is empty ...");

            T dq = (T)this.StorageArrayList[0];
            this.StorageArrayList.RemoveAt(0);
            
            return dq;
        }

        public void Clear()
        {
            this.StorageArrayList.Clear();
        }

        public bool Contains(T item)
        {

            if (this.StorageArrayList.Count == 0)
            {
                return false;
            }
            int left = 0,
                right = this.StorageArrayList.Count - 1,
                pvot = this.StorageArrayList.Count / 2;
            if (this.Comparer((T)this.StorageArrayList[left], item) == 0)
            {
                return true;
            }
            if (this.Comparer((T)this.StorageArrayList[right], item) == 0)
            {
                return true;
            }
            int cpr_result = 0;
            while (left < right)
            {
                cpr_result = this.Comparer((T)this.StorageArrayList[pvot], item);
                if (cpr_result > 0)
                {
                    right = pvot - 1;
                }
                else if (cpr_result < 0)
                {
                    left = pvot + 1;
                }
                else
                {
                    return true;
                }
                pvot = (right + left) / 2;
            }
            return false;
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            this.StorageArrayList.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this.StorageArrayList.Count; }
        }

        public bool IsReadOnly
        {
            get { return this.StorageArrayList.IsReadOnly; }
        }

        public bool Remove(T item)
        {
            if (this.StorageArrayList.Count == 0)
            {
                return false;
            }
            int left = 0,
                right = this.StorageArrayList.Count - 1,
                pvot = this.StorageArrayList.Count / 2;
            if (this.Comparer((T)this.StorageArrayList[left], item) == 0)
            {
                this.StorageArrayList.RemoveAt(left);
                return true;
            }
            if (this.Comparer((T)this.StorageArrayList[right], item) == 0)
            {
                this.StorageArrayList.RemoveAt(right);
                return true;
            }
            int cpr_result = 0;
            while (left < right)
            {
                cpr_result = this.Comparer((T)this.StorageArrayList[pvot], item);
                if (cpr_result > 0)
                {
                    right = pvot - 1;
                }
                else if (cpr_result < 0)
                {
                    left = pvot + 1;
                }
                else
                {
                    this.StorageArrayList.RemoveAt(pvot);
                    return true;
                }
                pvot = (right + left) / 2;
            }
            return false;
        }

        #endregion

        #region IEnumerable<T> Members

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return (IEnumerator<T>)this.StorageArrayList.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.StorageArrayList.GetEnumerator();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            this.StorageArrayList.Clear();
        }

        #endregion
    }
}
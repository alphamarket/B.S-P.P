﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Core.Utils
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler((sender, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.Escape:
                        button1_Click(new object(), new EventArgs());
                        break;
                    default:
                        break;
                }
            });
            foreach (var i in this.Controls)
            {
                if (i is ComboBox)
                    (i as ComboBox).SelectedIndex = 1;
            }
            foreach (var i in this.groupBox1.Controls)
            {
                if (i is ComboBox)
                    (i as ComboBox).SelectedIndex = 1;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void GeneralPlaySound_SelectedIndexChanged(object sender, EventArgs e)
        {
            groupBox1.Enabled = this.GeneralPlaySound.SelectedIndex != 0;

            foreach (var i in this.groupBox1.Controls)
            {
                if (i is ComboBox && i != sender)
                    (i as ComboBox).SelectedIndex = this.GeneralPlaySound.SelectedIndex;
            }
        }
    }
}

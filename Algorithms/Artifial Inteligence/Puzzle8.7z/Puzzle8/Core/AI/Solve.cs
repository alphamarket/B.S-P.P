﻿#define VERBOSE_OUTPUT
#undef VERBOSE_OUTPUT
using System;
using System.Collections.Generic;
using Strib.Heap;
using System.IO;
namespace Core.AI
{
    /// <summary>
    /// A proper class to solve a puzzle with known initial states
    /// </summary>
    public class Solve
    {
        #region SUB-CLASSES
        /// <summary>
        /// An internal usage to contains the route path to root.
        /// </summary>
        public class Node
        {
            /// <summary>
            /// Set or get current puzzle states as Core.Logic.Motions objective
            /// </summary>
            public Core.Logic.Motions Value { get; set; }

            /// <summary>
            /// The parent states that leads the parent objective to current status
            /// </summary>
            public Node Parent { get; set; }
            
            /// <summary>
            /// Get the current status deepening value
            /// </summary>
            public int Depth { get { return Parent == null ? 0 : Parent.Depth + 1; } }

            /// <summary>
            /// Indicator that the current state is a root node or not
            /// </summary>
            public bool IsRoot { get { return this.Parent == null; } }

            /// <summary>
            /// Specifies the action that lead the parent node's state to current state
            /// </summary>
            public KeyValuePair<int, Core.Logic.Motions.Direction> Action { get; set; }

            /// <summary>
            /// Contruct a node objective
            /// </summary>
            /// <param name="value">The current status of puzzle as Core.Logic.Motions objective</param>
            /// <param name="parent">The parent node of current one</param>
            /// <param name="action">The action that binds the parent status to current one</param>
            public Node(Core.Logic.Motions value, Node parent, KeyValuePair<int, Core.Logic.Motions.Direction> action)
            {
                this.Value = value;
                this.Parent = parent;
                this.Action = action;
            }
        }
        #endregion

        #region PROECTEDES
        
        #region PROPERTIES

        /// <summary>
        /// Get or set the count of nodes that encounter the closed status
        /// </summary>
        protected int ClosedMeet { get; set; }
        /// <summary>
        /// Get or set the total count of expanded node!
        /// </summary>
        protected int TotalExpanded { get; set; }
        /// <summary>
        /// A queue to contain the node's sequence
        /// </summary>
        protected Core.DataStructures.Sorting.BinaryQueue<Node> Queue = new Core.DataStructures.Sorting.BinaryQueue<Node>(null);

        /// <summary>
        /// A flag lis to contain the closed list of node sequence workflow
        /// </summary>
        protected List<float> ClosedList = new List<float>();
        
        #endregion

        #region METHODS

        /// <summary>
        /// Push the motion object to closed list object
        /// </summary>
        /// <param name="motion">The visited motion or puzzle state</param>
        protected void PutToCloseList(Core.Logic.Motions motion)
        {
            ClosedList.Add(motion.GetHashCode());
        }

        #endregion

        #endregion

        #region PUBLICS

        #region PROPERTIES

        /// <summary>
        /// Contains a cloned value of initial value of puzzle's state
        /// </summary>
        public Core.Logic.Motions InitialState { get; protected set; }

        #endregion

        #region METHODS

        /// <summary>
        /// calculates the manhaten heuristic values for given nodes
        /// </summary>
        /// <param name="motion">Node to calculate</param>
        /// <returns>calculated value!</returns>
        public static int ManhatenHeuristic(Node motion)
        {
            int heuristic = 0;
            int sqrt = (int)Math.Sqrt((double)motion.Value.Puzzle.Size);
            for (int i = 0; i < motion.Value.Puzzle.Size; i++)
            {
                int state = motion.Value.Puzzle.States[i];
                if (i == motion.Value.Puzzle.BlankIndex)
                    state = 9;
                if (i != state - 1)
                    heuristic++;
                int w = (int)Math.Abs((double)(i % 3 - (state - 1) % 3)) + (int)Math.Abs((double)((int)i / 3 - (int)((state - 1) / 3)));
                heuristic = heuristic + w;
            }
            return heuristic + motion.Depth;
        }

        /// <summary>
        /// Construct the solve object
        /// </summary>
        /// <param name="InitialState">Puzzle's initial state</param>
        public Solve(Core.Logic.Motions InitialState)
        {
            this.InitialState = InitialState.Clone() as Core.Logic.Motions;
        }
        /// <summary>
        /// Initiate the solvation
        /// </summary>
        /// <returns>Queue of steps to solve puzzle</returns>
        public Queue<KeyValuePair<int, Core.Logic.Motions.Direction>> Initiate()
        {
            Queue = new Core.DataStructures.Sorting.BinaryQueue<Node>(
                   new Comparison<Node>((motion1, motion2) =>
                   {
                       if (motion1 == null || motion2 == null)
                           return 1;
                       int m1 = Solve.ManhatenHeuristic(motion1),
                           m2 = Solve.ManhatenHeuristic(motion2);

                       if (m1 < m2)
                           return -1;
                       if (m1 == m2)
                           return 0;
                       return 1;
                   })
                   );

            this.Queue.Enqueue(new Node(this.InitialState, null, new KeyValuePair<int, Core.Logic.Motions.Direction>()));
#if VERBOSE_OUTPUT
            int StartTime = Environment.TickCount;
#endif
            while (this.Queue.Count != 0
#if VERBOSE_OUTPUT
                && TotalExpanded++ <= int.MaxValue
#endif
)
            {
                Node motion = this.Queue.Dequeue();

                if (this.ClosedList.Contains(motion.Value.GetHashCode())
#if VERBOSE_OUTPUT 
                    && ClosedMeet++ <= int.MaxValue
#endif
)
                    continue;

                foreach (var i in Enum.GetNames(typeof(Core.Logic.Motions.Direction)))
                {
                    var tmp = motion.Value.Clone() as Core.Logic.Motions;

                    var dir = (Core.Logic.Motions.Direction)Enum.Parse(typeof(Core.Logic.Motions.Direction), i);

                    if (tmp.CanBlankMove(dir))
                    {
                        if (tmp.IsReachedGaol(new Core.Logic.Puzzle(new[] { 1, 2, 3, 4, 5, 6, 7, 8, 0 })))
                        {
                            Queue<KeyValuePair<int, Core.Logic.Motions.Direction>> queue = new Queue<KeyValuePair<int, Core.Logic.Motions.Direction>>();
#if VERBOSE_OUTPUT
                            PrintColory("Puzzle solved at ",DateTime.Now);
                            PrintColory("Closed list count ", ClosedList.Count);
                            PrintColory("Head list count ", this.Queue.Count);
                            PrintColory("Closed meet count ", this.ClosedMeet);
                            PrintColory("Total expand count ", this.TotalExpanded);
                            PrintColory("Elapsed time ", new TimeSpan((Environment.TickCount - StartTime) * 10000));
                            Console.WriteLine();
                            Console.Beep();
                            tmp.Puzzle.Stream(Console.Out);
#endif
                            Node tmpN = new Node(tmp, motion, new KeyValuePair<int, Core.Logic.Motions.Direction>(tmp.GetNearByState(tmp.Puzzle.BlankIndex, dir, false).Value, (Core.Logic.Motions.Direction)(((int)dir + 2) % 4)));
#if VERBOSE_OUTPUT
                            using (TextWriter sw = new StreamWriter(@"ans.txt"))
                            {
#endif
                            Stack<KeyValuePair<int, Core.Logic.Motions.Direction>> stack = new Stack<KeyValuePair<int, Core.Logic.Motions.Direction>>();
#if VERBOSE_OUTPUT
                                Stack<String> s = new Stack<string>();
#endif
                            while (!tmpN.IsRoot)
                            {

#if VERBOSE_OUTPUT
                                    s.Push(String.Format("Move [{0}] to {1}", tmpN.Action.Key, tmpN.Action.Value));
                                    tmpN.Value.Puzzle.Stream(sw);
                                    sw.WriteLine();
#endif
                                stack.Push(tmpN.Action);
                                tmpN = tmpN.Parent;
                            }
#if VERBOSE_OUTPUT
                                PrintColory("Answer found in depth ", stack.Count);
#endif
                            while (stack.Count > 1)
                            {
                                queue.Enqueue(stack.Pop());
#if VERBOSE_OUTPUT
                                    sw.WriteLine(s.Pop());
#endif
                            }
#if VERBOSE_OUTPUT
                            }   
                            System.Diagnostics.Process.Start("ans.txt");  
#endif
                            return queue;
                        }
                        // get demaneded movement objective to make the proper movement
                        var action = tmp.GetNearByState(tmp.Puzzle.BlankIndex, dir, false);
                        // initiate the movement
                        tmp.MoveBlank(dir);
                        // if the action.Key be saved the value of action is the index of the Status
                        // if the action.Value be saved the value would be the actual human-friendly value of status' value
                        this.Queue.Enqueue(new Node(tmp, motion, new KeyValuePair<int, Core.Logic.Motions.Direction>(action.Value, (Core.Logic.Motions.Direction)(((int)dir + 2) % 4))));
                    }
                }
                this.PutToCloseList(motion.Value);
            }
            this.Queue.Dispose();
            return null;
        }
        #endregion

        #endregion

        #region PRIVATES

        /// <summary>
        /// A handy function to print colory text in console when the algorithm runs as verbose output mode
        /// </summary>
        /// <param name="message">Message to print</param>
        /// <param name="value">Related object to message</param>
        private void PrintColory(String message, object value)
        {
            var tmpColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(message);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(value);
            Console.ForegroundColor = tmpColor;
        }
        
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Core.Sounds
{
    public static class Sound
    {
        public static void Play(String address)
        {
            try
            {
                WMPLib.WindowsMediaPlayer a = new WMPLib.WindowsMediaPlayer();
                a.URL = (address);
            }
            catch(Exception)
            {
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.DataStructures.Sorting;

namespace iTest
{
    class Program
    {
        static void Main(string[] args)
        {
        __RESTART:
            int size = 10;
            int[] lst = new int[size];// { -10, 2, 4, 5, 7, 10 };
            Random r = new Random(Environment.TickCount);
            for (int i = 0; i < lst.Length; i++)
            {
                lst[i] = r.Next(-1000, 1000);
                Console.WriteLine(lst[i]);
            }
            Console.WriteLine();
        __RESORT:
            BinaryQueue<int> bq = new BinaryQueue<int>(new Comparison<int>((a, b) => { if (a < b)return -1; if (a > b)return 1; return 0; }));
            for (int i = 0; i < lst.Length; i++)
            {
                bq.Enqueue(lst[i]);
            }
            PrintBQ(bq);
            int index = r.Next(0,lst.Length-1);
            index = 0;
            Console.WriteLine("Removing item [{0}] = {1} : C = {2}", index, lst[index], bq.Contains(lst[index]));
            bq.Remove(lst[index]);
            Console.WriteLine(bq.Contains(lst[index]) ? "1" : "0");
            PrintBQ(bq);
            Console.WriteLine();
            while (bq.Count!=0)
            {
                Console.WriteLine(bq.Dequeue());
            }
            var rk = Console.ReadKey(true);
            if (rk.Key == ConsoleKey.R)
                goto __RESORT;
            if (rk.Key == ConsoleKey.X)
                goto __RESTART;
        }

        private static void PrintBQ(BinaryQueue<int> bq)
        {
            foreach (var i in bq)
            {
                Console.WriteLine(i);
            }
        }
    }
}

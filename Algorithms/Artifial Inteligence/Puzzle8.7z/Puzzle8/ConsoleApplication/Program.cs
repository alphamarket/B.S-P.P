﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.AI;
using Core.Logic;
namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
        __BEGINNING:
            Console.Clear();
            new Core.UI.Console.ConcoleUI().Run(args);
            var rk = Console.ReadKey(true);
            if (rk.Modifiers == ConsoleModifiers.Control && rk.Key == ConsoleKey.R)
                goto __BEGINNING;
        }
    }
}

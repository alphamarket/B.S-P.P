# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.9)
# Database: spandan
# Generation Time: 1390-08-06 07:35:50 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table craftsmen
# ------------------------------------------------------------

CREATE TABLE `craftsmen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table gallery
# ------------------------------------------------------------

CREATE TABLE `gallery` (
  `machine` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  KEY `machine` (`machine`),
  CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`machine`) REFERENCES `machines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table machines
# ------------------------------------------------------------

CREATE TABLE `machines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `plaque` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `tip` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `fueltype` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `capacity` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `cylinder` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `axle` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `tires` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `motorserial` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `Chassis` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `fuelcard` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Status` (`status`),
  CONSTRAINT `machines_ibfk_1` FOREIGN KEY (`status`) REFERENCES `status` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table machineusages
# ------------------------------------------------------------

CREATE TABLE `machineusages` (
  `machine` int(11) NOT NULL,
  `project` int(11) NOT NULL,
  `startdate` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `enddate` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  KEY `machine` (`machine`),
  KEY `project` (`project`),
  CONSTRAINT `machineusages_ibfk_2` FOREIGN KEY (`project`) REFERENCES `projects` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `machineusages_ibfk_1` FOREIGN KEY (`machine`) REFERENCES `machines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table projects
# ------------------------------------------------------------

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table servicedetails
# ------------------------------------------------------------

CREATE TABLE `servicedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service` int(11) NOT NULL,
  `servicetype` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `discriptions` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service` (`service`),
  KEY `servicetype` (`servicetype`),
  KEY `id` (`id`),
  CONSTRAINT `servicedetails_ibfk_2` FOREIGN KEY (`servicetype`) REFERENCES `servicetypes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `servicedetails_ibfk_1` FOREIGN KEY (`service`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table services
# ------------------------------------------------------------

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine` int(11) NOT NULL,
  `date` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `discriptions` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `machine` (`machine`),
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`machine`) REFERENCES `machines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table servicetypes
# ------------------------------------------------------------

CREATE TABLE `servicetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table sparepieces
# ------------------------------------------------------------

CREATE TABLE `sparepieces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `stockroomcode` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table status
# ------------------------------------------------------------

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table t_events
# ------------------------------------------------------------

CREATE TABLE `t_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine` int(11) NOT NULL,
  `date` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `message` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `machine` (`machine`),
  CONSTRAINT `t_events_ibfk_1` FOREIGN KEY (`machine`) REFERENCES `machines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table t_machineinfo
# ------------------------------------------------------------

CREATE TABLE `t_machineinfo` (
  `machine` int(11) NOT NULL,
  `techid` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`machine`,`techid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table t_servicecrafts
# ------------------------------------------------------------

CREATE TABLE `t_servicecrafts` (
  `service` int(11) NOT NULL,
  `craftsman` int(11) NOT NULL,
  PRIMARY KEY (`service`,`craftsman`),
  KEY `craftsman` (`craftsman`),
  CONSTRAINT `t_servicecrafts_ibfk_2` FOREIGN KEY (`craftsman`) REFERENCES `craftsmen` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `t_servicecrafts_ibfk_1` FOREIGN KEY (`service`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table t_technicalinfo
# ------------------------------------------------------------

CREATE TABLE `t_technicalinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table t_users
# ------------------------------------------------------------

CREATE TABLE `t_users` (
  `user` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `pass` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;



# Dump of table v_craftsman0
# ------------------------------------------------------------

CREATE TABLE `v_craftsman0` (
   `service` INT(11) NOT NULL,
   `craftsmen` VARCHAR(341) DEFAULT NULL
) ENGINE=MyISAM;



# Dump of table v_events
# ------------------------------------------------------------

CREATE TABLE `v_events` (
   `id` INT(11) NOT NULL DEFAULT '0',
   `machine` INT(11) NOT NULL,
   `date` VARCHAR(255) NOT NULL,
   `message` TEXT NOT NULL,
   `name` VARCHAR(255) NOT NULL
) ENGINE=MyISAM;



# Dump of table v_machines
# ------------------------------------------------------------

CREATE TABLE `v_machines` (
   `id` INT(11) NOT NULL DEFAULT '0',
   `name` VARCHAR(255) NOT NULL,
   `color` VARCHAR(255) DEFAULT NULL,
   `plaque` VARCHAR(255) DEFAULT NULL,
   `tip` VARCHAR(255) DEFAULT NULL,
   `image` VARCHAR(255) DEFAULT NULL,
   `fueltype` VARCHAR(255) DEFAULT NULL,
   `capacity` VARCHAR(255) DEFAULT NULL,
   `cylinder` VARCHAR(255) DEFAULT NULL,
   `axle` VARCHAR(255) DEFAULT NULL,
   `tires` VARCHAR(255) DEFAULT NULL,
   `motorserial` VARCHAR(255) DEFAULT NULL,
   `chassis` VARCHAR(255) DEFAULT NULL,
   `fuelcard` VARCHAR(255) DEFAULT NULL,
   `statusid` INT(11) NOT NULL DEFAULT '0',
   `status` VARCHAR(255) NOT NULL
) ENGINE=MyISAM;



# Dump of table v_servicedetails
# ------------------------------------------------------------

CREATE TABLE `v_servicedetails` (
   `id` INT(11) NOT NULL DEFAULT '0',
   `service` INT(11) NOT NULL,
   `servicetype` INT(11) NOT NULL,
   `cost` INT(11) NOT NULL,
   `discriptions` TEXT NOT NULL,
   `name` VARCHAR(255) NOT NULL
) ENGINE=MyISAM;



# Dump of table v_services
# ------------------------------------------------------------

CREATE TABLE `v_services` (
   `id` INT(11) NOT NULL DEFAULT '0',
   `machine` INT(11) NOT NULL,
   `date` VARCHAR(255) NOT NULL,
   `discriptions` TEXT NOT NULL,
   `craftsmen` VARCHAR(341) DEFAULT NULL,
   `totalprice` INT(11) DEFAULT NULL
) ENGINE=MyISAM;





# Replace placeholder table for v_servicedetails with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_servicedetails`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_servicedetails`
AS select
   `sd`.`id` AS `id`,
   `sd`.`service` AS `service`,
   `sd`.`servicetype` AS `servicetype`,
   `sd`.`cost` AS `cost`,
   `sd`.`discriptions` AS `discriptions`,
   `st`.`name` AS `name`
from (`servicedetails` `sd` join `servicetypes` `st` on((`sd`.`servicetype` = `st`.`id`)));


# Replace placeholder table for v_services with correct view syntax
# ------------------------------------------------------------

DELIMITER ;;

/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 FUNCTION `totalprice`(service_id int) RETURNS int(11)
BEGIN
    declare tp int;
    select SUM(cost) into tp
    from   servicedetails
    where  service = service_id
    group by service;
    return tp;
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;

DELIMITER ;

DROP TABLE `v_services`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_services`
AS select
   `s`.`id` AS `id`,
   `s`.`machine` AS `machine`,
   `s`.`date` AS `date`,
   `s`.`discriptions` AS `discriptions`,
   `v`.`craftsmen` AS `craftsmen`,
   `totalprice`(`s`.`id`) AS `totalprice`
from (`v_craftsman0` `v` join `services` `s` on((`v`.`service` = `s`.`id`)));


# Replace placeholder table for v_craftsman0 with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_craftsman0`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_craftsman0`
AS select
   `sc`.`service` AS `service`,group_concat(`c`.`name` separator ',') AS `craftsmen`
from (`t_servicecrafts` `sc` join `craftsmen` `c` on((`sc`.`craftsman` = `c`.`id`))) group by `sc`.`service`;


# Replace placeholder table for v_events with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_events`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_events`
AS select
   `t1`.`id` AS `id`,
   `t1`.`machine` AS `machine`,
   `t1`.`date` AS `date`,
   `t1`.`message` AS `message`,
   `t2`.`name` AS `name`
from (`t_events` `t1` join `machines` `t2` on((`t1`.`machine` = `t2`.`id`)));


# Replace placeholder table for v_machines with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_machines`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_machines`
AS select
   `m`.`id` AS `id`,
   `m`.`name` AS `name`,(case when isnull(`m`.`color`) then 'نامشخص' else `m`.`color` end) AS `color`,(case when isnull(`m`.`plaque`) then 'نامشخص' else `m`.`plaque` end) AS `plaque`,(case when isnull(`m`.`tip`) then 'نامشخص' else `m`.`tip` end) AS `tip`,(case when isnull(`m`.`image`) then 'box.jpg' else `m`.`image` end) AS `image`,(case when isnull(`m`.`fueltype`) then 'نامشخص' else `m`.`fueltype` end) AS `fueltype`,(case when isnull(`m`.`capacity`) then 'نامشخص' else `m`.`capacity` end) AS `capacity`,(case when isnull(`m`.`cylinder`) then 'نامشخص' else `m`.`cylinder` end) AS `cylinder`,(case when isnull(`m`.`axle`) then 'نامشخص' else `m`.`axle` end) AS `axle`,(case when isnull(`m`.`tires`) then 'نامشخص' else `m`.`tires` end) AS `tires`,(case when isnull(`m`.`motorserial`) then 'نامشخص' else `m`.`motorserial` end) AS `motorserial`,(case when isnull(`m`.`Chassis`) then 'نامشخص' else `m`.`Chassis` end) AS `chassis`,(case when isnull(`m`.`fuelcard`) then 'نامشخص' else `m`.`fuelcard` end) AS `fuelcard`,
   `s`.`id` AS `statusid`,
   `s`.`name` AS `status`
from (`machines` `m` join `status` `s` on((`s`.`id` = `m`.`status`)));

--
-- Dumping routines (PROCEDURE) for database 'spandan'
--
DELIMITER ;;

# Dump of PROCEDURE machinex
# ------------------------------------------------------------

/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `machinex`(IN machine_id int)
BEGIN
     select *
     from services
     where machine =  machine_id;
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
# Dump of PROCEDURE sp_machine_history_between_date
# ------------------------------------------------------------

/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `sp_machine_history_between_date`(IN mid int, IN sdate varchar(255) charset utf8 collate utf8_persian_ci, IN edate varchar(255) charset utf8 collate utf8_persian_ci)
BEGIN
      select  s.date, st.name, sd.cost
      from   (servicedetails sd  inner join   servicetypes st  on  sd.servicetype = st.id) inner join  services s  on  s.id = sd.service
      where    (s.date between sdate  and edate) and (s.machine =  mid)
      order by s.date DESC, sd.id DESC;
      
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
DELIMITER ;

--
-- Dumping routines (FUNCTION) for database 'spandan'
--
DELIMITER ;;

# Dump of FUNCTION fnc_machine_history_between_date_totalprice
# ------------------------------------------------------------

/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 FUNCTION `fnc_machine_history_between_date_totalprice`(mid int, sdate varchar(255), edate varchar(255) ) RETURNS int(11)
BEGIN
    declare tp int;
    select SUM(cost) into tp
    from   servicedetails  sd   inner join   services s   on  sd.service = s.id
    where  (s.machine = mid) and (s.date between sdate and edate)
    group by machine;
    return tp;
    
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
# Dump of FUNCTION rssx
# ------------------------------------------------------------

/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 FUNCTION `rssx`(x int) RETURNS varchar(255) CHARSET latin1
BEGIN
      DECLARE cnn varchar(255);
      SELECT  group_concat(name) INTO cnn
      FROM `t_servicecrafts` sc inner join `craftsmen` c on sc.craftsman = c.id
      where service = x
      group by service;
      return cnn;
END */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
# Dump of FUNCTION totalprice
# ------------------------------------------------------------

DELIMITER ;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

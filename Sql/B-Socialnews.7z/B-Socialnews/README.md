socialnews
==========

An early socialnews site for dummies.

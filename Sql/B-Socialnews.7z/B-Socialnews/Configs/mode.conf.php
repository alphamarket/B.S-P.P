<?php
	define('DEBUG', 1);
	define('DB_SUCCESS_SHOW', 0);
	define('DEVELOPING', 1);
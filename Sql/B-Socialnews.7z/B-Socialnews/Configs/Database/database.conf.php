<?php

	$db_host = "localhost";
    
	$db_user = "root";
    
	$db_name = "socialnews";
    
	$db_pass = "root";

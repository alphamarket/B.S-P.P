<?php
	$includePath=array(
		realpath('./Configs'),
		realpath('./Libs'),
		realpath('./Security'),
		realpath('./Privates'),
		realpath('./Publics'),
		get_include_path()
	);
	
	set_include_path(implode(PATH_SEPARATOR, $includePath));
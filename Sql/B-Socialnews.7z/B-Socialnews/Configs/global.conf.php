<?php
	define('BASE_URL', "http://localhost/B-Socialnews/");
	define('PURE_URL', 'http://localhost/');
	require_once 'mode.conf.php';
	
	/*function __autoload($load){
		try{
			require_once '../Libs/'.$load.'.php';
		}catch (Exception $e){
			$_POST['Error']=$e;
			Redirect::RedirectURL(APPLICATION_PATH.'Publics\Error.php');
		}
	}*/
	
	$User_Type = array(
		'SuperAdmin' => 1,
		'Admin' => 2,
		'Standard' => 3,
		'Visitor' => 4,
		'Developer' => 0,
	);
	
	
	
	function Create_Error_String($text, $error, $errorColor='red'){
		return '<center><fieldset style="background-color:white">'.$text."<span style='color:".$errorColor."'>".$error.'</span></fieldset></center>';
	}
	
	function Create_Ajax_Loader_Img($title){
		return "<img src='".BASE_URL."/Styles/Images/ajax-loader.gif' alt='$title' width='20px' height='20px' style='margin:0 0 -5px 3px;' title='$title'/>";
	}
	
	function Create_Ajax_Success_Img($title){
		return "<img src='".BASE_URL."/Styles/Images/success.gif' alt='$title' width='20px' height='20px' style='margin:0 0 -5px 3px;' title='$title'/>";
	}
	
	function Create_Ajax_Failure_Img($title){
		return "<img src='".BASE_URL."/Styles/Images/failure-delete.png' alt='$title' width='20px' height='20px' style='margin:0 0 -5px 3px;' title='$title'/>";	
	}
	
	function Create_jQuery_Close_Img($title){
		return "<img id='img-".md5($title.date(M-d-Y))."' alt='Close' src='".BASE_URL."/Styles/Images/failure-delete.png' width='20px' height='20px' style='float:right;cursor:pointer;margin:0px;' title='$title' />";
	}
	
	function mysql_log_ExeQuery($query,$log_it=false){
		$err=null;
		
		$res = mysql_query($query) or ( $err = mysql_error());
		
		if($log_it):
			if(!isset($_SESSION))
				session_start();
			
			$user=null;
			
			if(isset($_SESSION['USER']))
				$user_id=User::RestoreFromSession()->User_Id;
			else 
				$user_id='0';
				
			$_query=mysql_escape_string($query);
			
			$err=mysql_escape_string($err);
			
			$date=date("M-d-Y H:i:s");
			
			$failed=($err!='');
			
			$log="INSERT INTO t_logs SET
					query_exe_user_id='$user_id',
					query_time='$date',
					query='$_query',
					failed='$failed',
					result='$err'
					";
			
			mysql_query($log) or die(mysql_error());
		endif;
		
		return $res;
	}
	
	function imysql_connect(){
		
		global $db_host, $db_user, $db_pass, $db_name;
		
		mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
	}
	

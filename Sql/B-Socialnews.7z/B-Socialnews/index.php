<?php 
	require_once 'Configs/global.conf.php';
	require_once 'Configs/includepath.php';
	require_once 'Configs/Database/database.conf.php';
	require_once 'Libs/User.php';
	session_start();
	/*global $db_host, $db_user, $db_pass, $db_name;
		
	$user=User::Serialize($_SESSION['USER']);
	$db = mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
	mysql_select_db($db_name,$db) or die(mysql_error());
	$query = "call generatePassinfo($user->Id,'admin',null )";
	$res = mysql_query($query) or die(mysql_error());
	$res=mysql_fetch_array($res,MYSQL_NUM) or die('error');
	mysql_close();
	echo $res[0];
	die();*/
?>
<html>
	<head>
		<title>
			Index
		</title>
		
		<link rel="stylesheet" href="Styles/Sheets/Default.css" type="text/css" />
		<link rel="stylesheet" href="Styles/Sheets/Index.css" type="text/css" />
		<link rel="stylesheet" href="Styles/Sheets/Header-Login-out.css" type="text/css" />
		<link rel="stylesheet" href="Styles/Sheets/Show-news.css" type="text/css" />
		
		<script type="text/javascript" src="Javascript/jquery-1.7.min.js"></script>
		<?php if(!User::IsLoggedIn()):?>
			<script type="text/javascript" src="Publics/Generics/Scripts/Join.ready.js"></script>
			<script type="text/javascript" src="Javascript/conf.js"></script>
		<?php endif;?>
	</head>
	<body>
		<div class='container'>
			<?php include 'Publics/Generics/header.php';?>
			<div style="border: 1px solid black;margin:10px;padding:5px;">
				<img id="purpose-top-img" src="Styles/Images/hpyfc.jpg" style="margin:-5px;margin-bottom:5px;">
				<?php
				/*
					echo '<pre>';				
						print_r($_SESSION);
					echo '</pre>';
				*/
					if(User::IsLoggedIn()){
						include_once 'index.news-page.php';
					}else{
						include_once 'purpose.php';
					}
				?>
				<div class="clear"></div>
			</div>
			<?php include 'Publics/Generics/footer.php';?>
		</div>
	</body>
</html>

<?php
	class Redirect{
		
		private static $Series = array();
		
		private static $Count = 0;
		/**
		 * 
		 * redirect to target page and save the current url as direct history
		 * @param string $URL
		 */
		public static function Redirect_URL($URL){
			/**
		 	*  Add current page to redirect history.
		 	*  Increase history counter.
		 	*/
			Redirect::$Series[Redirect::$Count++] = realpath(__FILE__);
			/**
			 * Redirect to target page
			 */
			header('location: '.$URL.'');
		}
		/**
		 * 
		 * Get address of last directed url by this class
		 * @param int $last
		 */
		public static  function Get_Last_URL($last){
			if(Redirect::$Count==0)
				Redirect::Redirect_URL(BASE_URL.'/index.php');
			if(is_int($last))
			{
				$count=Redirect::Get_Redirected_Count()-$last;
				return Redirect::$Series[$count];	
			}
		}
		/**
		 * 
		 * Get directed url counter amount
		 */
		public static function Get_Redirected_Count(){
			return Redirect::$Count;
		}
	}
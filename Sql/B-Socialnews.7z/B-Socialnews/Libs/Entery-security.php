<?php
	class Entery_Security{
		
		private static $voilent_chars = array(
												"'",
												'"',
											);
			
		private static $equ_char = array(
											"\\'",
											'\\"',				
										);
										
		// secure entery string in order to enter to database
		public static function Security_Push($string) {
			// searches for voilent chars and replace them to apropreate chars
			return str_replace(Entery_Security::$voilent_chars, Entery_Security::$equ_char, $string);
		}
		// release string form it's secure format that converted in >> function Security_Push($string) << function
		public static function Security_Pop($string){
			// searches for secure chars and release them from them secure format
			return str_replace(Entery_Security::$equ_char, Entery_Security::$voilent_chars, $string);
		}
	}
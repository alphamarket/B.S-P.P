<?php
	class User{
		public $Name;
		public $Logged;
		public $User_Type;
		public $User_Id;
		public function Logout(){
			$this->Logged(false);
		}
		public function Login(){
			$this->Logged(true);
		}
		private function Logged($value){
			$_SESSION['LOGGED']=$value;
			$this->Logged=$value;
		}
		public function __construct($id, $name, $uType, $logged=true){
			$this->Id=$id;
			$this->Logged($logged);
			$this->Name=$name;			
			$this->User_Type=$uType;
		}
		public static function  IsLoggedIn(){
			return isset($_SESSION['LOGGED']) && $_SESSION['LOGGED'];
		}
		public static function Serialize($userOBJ){
			return new User($userOBJ->Id, $userOBJ->Name, $userOBJ->User_Type, $userOBJ->Logged);
		}
		public  static function RestoreFromSession(){
			if(User::IsInitialized())
				return User::Serialize($_SESSION['USER']);
			return null;
		}
		public static function IsInitialized(){
			return User::IsLoggedIn() && isset($_SESSION['USER']);
		}
	}
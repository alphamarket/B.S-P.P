<?php
//	class Session {
//		
//		public static function Is_Session_started() {
//			return strlen(session_id())==0;
//		}
//		
//		public static function Session_start(){
//			if(!Session::Is_Session_started())
//				session_start();
//		}
//		
//		public static function Set_session($key, $value){
//			Session::Session_start();
//			$_SESSION[$key]=value;
//		}
//		
//		public static function Read_session($key){
//			Session::Session_start();
//			return $_SESSION[$key];
//		}
//		
//		public static function Isset_Key($key){
//			return isset($_SESSION[$key]);
//		}
//		
//		public static function Unset_key($key){
//			Session::Session_start();
//			unset($_SESSION[$key]);
//		}
//	}
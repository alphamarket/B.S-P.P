/**
 * 
 */

var BASE_URL = 'http://socialnews.local/';
var PURE_URL = 'http://socialnews.local/';


var Escape_keyCode = 27;

var Enter_keyCode = 13;

var Zero_keyCode = 48;

var Nine_keyCode = 57; 

var A_keyCode = 65;

var Z_keyCode = 90;

/**
 * 
 * @param $e keyPress object
 * @returns true if the pressed key demonestrate characteral visual object
 */

function Is_Character($e){
	var ck = $e.keyCode;
	return (ck>=Zero_keyCode && ck<=Nine_keyCode) || (ck>=A_keyCode && ck<=Z_keyCode);
}

function Is_Numbers(evt)
{
    var e = event || evt; // for trans-browser compatibility
    var charCode = e.which || e.keyCode;

    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

function htmlEscape(text,htmlCode){
	if(htmlCode){
		return text;
		return text.replace(/[ < > ]/g, 
				function(match, pos, originalText){
					switch(match){
						case "<":
							return "<";
						case ">":
							return ">";
						default:
							return match;
					}
				}
		);
	}else{
		return text.replace(/[ < > " \ \ \r\n \n ]/g, 
				function(match, pos, originalText){
					switch(match){
						case "<":
							return "&lt;";
						case ">":
							return "&gt;";
						case "&":
							return "&amp;";
						case "\"":
							return "&quot;";
						case " ":
							return "&nbsp;";
						case "\n":
							return "<br />";
						default:
							return match;
					}
				}
		);
	}
}

function Create_Ajax_Loader_Img($title){
	return '<img src="'+BASE_URL+'/Styles/Images/ajax-loader.gif" alt="'+$title+'" width="20px" height="20px" style="margin:0 0 -5px 3px;" title="'+$title+'"/>';
}

function Create_Ajax_Success_Img($title){
	return '<img src="'+BASE_URL+'/Styles/Images/success.gif" alt="'+$title+'" width="20px" height="20px" style="margin:0 0 -5px 3px;" title="'+$title+'"/>';
}

function Create_Ajax_Failure_Img($title){
	return '<img src="'+BASE_URL+'/Styles/Images/failure-delete.png" alt="'+$title+'" width="20px" height="20px" style="margin:0 0 -5px 3px;" title="'+$title+'"/>';	
}

function Create_jQuery_Close_Img($title){
	return '<img id="img-'+$title.lenght+'" alt="Close" src="'+BASE_URL+'/Styles/Images/failure-delete.png'+'" width="20px" height="20px" style="float:right;cursor:pointer;margin:0px;" title="'+$title+'" />';
}

String.prototype.contains = function(it) { return this.indexOf(it) != -1; };

function object2String(obj) {
    var val, output = "";
    if (obj) {    
        output += "{";
        for (var i in obj) {
            val = obj[i];
            switch (typeof val) {
                case ("object"):
                    if (val[0]) {
                        output += i + ":" + array2String(val) + ",";
                    } else {
                        output += i + ":" + object2String(val) + ",";
                    }
                    break;
                case ("string"):
                    output += i + ":'" + escape(val) + "',";
                    break;
                default:
                    output += i + ":" + val + ",";
            }
            output+='<br />';
        }
        output = output.substring(0, output.length-1) + "}";
    }
    return output;
}

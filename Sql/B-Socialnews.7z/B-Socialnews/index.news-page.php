<div id="news-lst-section" >
<?php
	if(User::IsLoggedIn()):
		global $db_host, $db_user, $db_pass, $db_name;
		
		$query='call NewsSummeryList(35)';
		
		$db=mysql_connect($db_host, $db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name,$db) or die(mysql_error());
		
		$result=mysql_log_ExeQuery($query) or die(mysql_error());
		
		$row=mysql_fetch_assoc($result);
		
		while(isset($row) && $row!=null):
?>
			<div id="news-row-<?php echo $row['news_id']?>" style="margin-top:5px;border:1px dotted black;padding:10px;">
				<div id="pre-body">
					<?php if(isset($row['tnail_address']) && $row['tnail_address']!=null):?>
					<span id="news-image-<?php echo $row['news_id']; ?>" style="padding: 15px!important;">
						<img class="news-summery-img" id="image-<?php echo $row['news_id']; ?>" src="<?php echo $row['tnail_address']?>" vspace="20px"/>
					</span>
					<?php endif;?>
					<div id="news-header" style="display:inline;">
						<h1 style="display:inline;">
							<a href="<?php echo BASE_URL.'/Publics/Generics/Show-news.php?t='.urlencode($row['topic'])."&id=".$row['news_id']?>" id='new-link-<?php echo $row['id']?>' target="_new"><?php echo $row['topic']?></a>
						</h1><br />
						<span style="font-size: small;color:gray">
							Posted by <?php echo $row['user']?> <i>at <?php echo $row['post_date'];?></i>
						</span>
					</div>
					
					<p id="main-summery" style="width: 720px;display:block;text-align: justify;margin-left:110px;"> 
						<i>
							<?php
								echo $row['summery'];
							?>
						</i>
					</p>
					<br />
				</div>
<!--				<hr style="width: 60%;color:gray;margin:20px auto 20px auto;" />-->
				<div class="clear"></div>
			</div>
<?php 
			$row=mysql_fetch_assoc($result);
		endwhile;
	else:
		Redirect::Redirect_URL('index.php');
	endif;
?>
</div>
<script type="text/javascript">
<!--
	$(document).ready(function(){
		$('img.news-summery-img').hide().css('width','100px').fadeIn(1700);
	});
//-->
</script>
	

<?php 
	require_once 'includes.inc.php';
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<title>Login</title>
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Default.css'?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Header-Login-out.css'?>" type="text/css" />
		<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/jquery-1.7.min.js'?>"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('input[type="text"]:first').focus();
			});
		</script>
		<style type="text/css">
			div.mrgin{
				margin-top:300px;	
				width: 600px;
			}
		</style>
	</head>
	<body>
		<div class='container mrgin'>
			<?php include 'Login.inner.php'?>
		</div>
	</body>
</html>
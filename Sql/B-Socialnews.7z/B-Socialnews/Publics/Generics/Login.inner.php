<div class='login'>
	<fieldset>
		<ul style="list-style-type: circle; color:<?php echo isset($_SESSION['LOGINERR'])?'red':'gray;'?>">
			<li>
				<?php
					 if(isset($_SESSION['LOGINERR']))
					 {
					 	echo 'Username or password is wrong!';
					 }
					 else
					 {
					 	echo 'Enter your username and password!';	
					 }
					 unset($_SESSION['LOGINERR']);
				?>
			</li>
		</ul>
		<form class="loginFRM" action="<?php echo BASE_URL.'/Privates/Generics/Login.php'; ?>" method="post">
			<input type="hidden" name="redir" value="<?php 
					if(isset($_SESSION['redir'])) 
						echo $_SESSION['redir'];
					else
						echo PURE_URL.$_SERVER['PHP_SELF'];
					unset($_SESSION['redir']);
				 ?>"/>
			<label>Enter your username :</label>
			<input type="text" name="user" maxlength="20"/>
			<br />
			<label>Enter your password :</label>
			<input type="password" name="pass" maxlength="50"/><br />
			<input id="submit" type="submit" name="submit" value="Login" />
			<input id="cancel" type="button" value="Cancel" style="display: none"/>
		</form>
	</fieldset>
</div>
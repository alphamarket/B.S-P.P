<div class='join'>
	<fieldset>
		<form class="joinFRM" action="<?php echo BASE_URL;?>/Privates/Generics/Join.php" method="post">
			<input type="hidden" name="redir" value="<?php echo PURE_URL.$_SERVER['PHP_SELF']; ?>">
			<label>Enter your username :</label>
			<input id="User" type="text" name="user" maxlength="20"/>
			<span class="ExstUser" style="color:red;display:none">This user already exists!</span>
			<br />
			<label>Enter your password :</label>
			<input id="Pass" type="password" name="pass" maxlength="50"/>
			<span class="WRGPass" style="color:red;display:none">Your passwords do not match!</span>
			<br />
			<label>Confirm your password :</label>
			<input id="ConfPass" type="password" name="confpass" maxlength="50"/>
			<span class="WRGPass" style="color:red;display:none">Your passwords do not match!</span>
			<br />
			<label>Your user type :</label>
			<select name='type' id='Type' style="width: 157px;">
				<?php
					global $User_Type;

					foreach($User_Type as $key => $value)
						echo "<option ".($key=='Standard'?'selected="selected"':'')."value='$key'>$key</option>";
				?>
			</select>
			<br />
			<span id='PassInfoErea'>
				<label>Enter passed information from invitor : </label>
				<input id="PassInfo" type="password" maxlength="15" name="passinfo"/>
				<span id='WRGPassInfo' style="color:red;">*</span>
				<br />
				<label id='PassInfoTxt' style="color:red;width:500px;">*&nbsp;&nbsp;&nbsp;&nbsp;Fill it only if you are signing for non standard and visitor usertype<br /></label>
			</span>
			<input id="submit" type="submit" name="submit" value="Join" />
			<input id="cancel" type="button" value="Cancel" style="display: none"/>
		</form>
	</fieldset>
</div>
<script type="text/javascript">
	<?php include 'Scripts/Join.inner.js'; ?>
</script>

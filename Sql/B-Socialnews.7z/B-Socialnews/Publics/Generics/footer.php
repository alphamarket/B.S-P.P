<div class="clear"></div>
<div id="footer">
	&copy;Programmed by dariush hasanpoor.
</div>
<?php
	require_once 'includes.inc.php';
	session_start();
	if (!(isset($_GET) && isset($_GET['t'])))
		Redirect::Redirect_URL(BASE_URL);
	if(!User::IsLoggedIn())
		Redirect::Redirect_URL('Login.php?redir='.$_SERVER['PHP_SELF']);
?>
<html>
	<head>
		<title>
			<?php echo $_GET['t'] ?>
		</title>
		<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/jquery-1.7.min.js'?>";></script>
		<link rel="stylesheet" href="../../Styles/Sheets/Default.css" type="text/css" />
		<link rel="stylesheet" href="../../Styles/Sheets/Header-Login-out.css" type="text/css" />
		<link rel="stylesheet" href="../../Styles/Sheets/Comments.css" type="text/css" />
		<script type="text/javascript">
			<?php 
				include_once '../../Javascript/conf.js';
				include_once 'Scripts/Show-news.js';
				include_once '../../Javascript/Plugins/autoGrow.js';
				include_once '../../Javascript/Plugins/jConf.js';
			?>
			$(document).ready(function(){
				$('textarea').autoGrow();
			});
		</script>
		<style type="text/css">
			<?php 
				include_once '../../Styles/Sheets/Show-news.css';
			?>
		</style>
		<?php if(!User::IsLoggedIn()):?>
			<script type="text/javascript" src="<?php echo 'Scripts/join.ready.js'?>"></script>
		<?php endif;?>
	</head>
	<body>
		<div class='container'>
			<?php include 'header.php';?>
			<div style="border: 1px solid black;margin:10px;padding:5px;">
				<?php include_once 'Show-news.inner.php';?>
			</div>
			<?php 
				if(User::IsLoggedIn())
					include_once '../../Privates/User/Commenting/Commet-news.php';
			?>
			<div class="clear"></div>
			<?php include 'footer.php';?>
		</div>
	</body>
</html>
<?php unset($_GET);?>
<?php 
	require_once 'includes.inc.php';
	session_start();
	if(!isset($_SESSION['MSG'])){
		Redirect::Redirect_URL(Redirect::Get_Last_URL(1));
	}
?>
<html>
	<head>
  		<meta http-equiv="refresh" content="1; url=
  		<?php 
  			if(isset($_SESSION['redir']))
  				echo $_SESSION['redir'];
  			else 
  				echo BASE_URL.'/index.php';
  		?>">
		<title>
			Registration confirmation
		</title>
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Default.css'?>" type="text/css" />
		<style type="text/css">
			div.msg{
				margin-top:200px;
				height: 300px;					
			}
			div.msg p{
				margin-top:120px;
			}
		</style>
	</head>
	<body style="background-color: graytext;">
		<div class='container msg'>
			<p>
				<strong>
					<i>
						<?php 
							echo '<center><span style="color:green">'.$_SESSION['MSG'].'</span>';
							echo "<br /> if you are not redirected automatically in few moment <a href='".$_SESSION['redir']."'>click here</a></center>";
							unset($_SESSION['MSG']);
							unset($_SESSION['redir']);						
						?>
						
					</i>
				</strong>
			</p>
		</div>
	</body>
</html>
<ul id="header">
	<li>	
		<a href="<?php echo BASE_URL; ?>" title="goto home page">Home</a> 
	</li>
	<!-- NON-LOGGEDIN SECTION -->
	<?php if(!User::IsLoggedIn()):?>
    <li id="login">	<!-- <?php echo BASE_URL;?>/Publics/login.php -->
    	<a id="Login" href="#" title="Open login form">Login</a> 
	</li>
    <li id="logout">	
    	<a id="Join" href="#" title="Open join form">Join</a>
	</li>
	<li>
		<a id="privacy" href="#">Privacy Policy</a>
	</li>
	<!-- REGISTERED USERS SECTION -->
	<?php else:
		  $user = User::Serialize($_SESSION['USER']); 
		  if ($user->User_Type!="Standard" && $user->User_Type!="Visitor"):
	?>
	<li>
		<a href="<?php echo BASE_URL;?>/Publics/User/Privileges/Add-user.php">Add User</a>
	</li>
	<li>
		<a href="<?php echo BASE_URL;?>/Publics/User/Privileges/Add-news.php">Add News</a>
	</li>
	<?php if($user->User_Type=='Developer'): ?>
	<li>
		<a href="<?php echo BASE_URL;?>/Publics/User/<?php echo $user->User_Type;?>/Modiration.php">Modiration</a>
	</li>
	<?php 
		endif; 
		/* echo 
			'<li>
				<a href="<?php echo BASE_URL;?>/Publics/User/Privileges/Last-updates.php">Last Updates</a>
			</li>'; */
	?>
	
	<?php endif; endif;?>
	<li id="loggedbar">
			<?php
				$user=User::RestoreFromSession();
				if(User::IsLoggedIn()){
					$var = "<span style='font-variant: small-caps'>Welcome </span><a href =".BASE_URL."/Publics/User/Generics/Edit-user.php?id=".$user->Id."&type=".$user->User_Type." id='UserInfo' style='cursor:pointer;font-variant: normal!important' title='$user->User_Type'>$user->Name</a> [ <a id='logout' href='".BASE_URL."/Privates/Generics/Logout.php' title='Click here to logout.'>Logout</a> ]";
					echo "<span style='color:#6AADE3;display: inline;float:right'>"; 
					echo $var;
					echo '</span>';
				}
			?>
	</li>
</ul>
<?php if(!User::IsLoggedIn())require_once 'Login.inner.php';?>
<?php if(!User::IsLoggedIn())require_once 'Join.inner.php';?>


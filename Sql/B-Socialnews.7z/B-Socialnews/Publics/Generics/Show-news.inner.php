<?php
	include_once 'includes.inc.php';
	
	if(!isset($_GET) || !isset($_GET['t']) || !isset($_GET['id'])){
		echo Create_Error_String(Create_Ajax_Failure_Img('Not appropriate news.').'<span style="margin-left:5px" >Error : </span>', 'No appropriate news is selected ...');
		die();
	}
	$t=mysql_escape_string($_GET['t']);
	
	$id=mysql_escape_string($_GET['id']);
	
	$query = "SELECT * FROM t_news,t_users WHERE t_users.user_id=t_news.user_id and topic='$t' AND news_id='$id'";
		
	global $db_host, $db_user, $db_pass, $db_name;
	
	mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
	
	mysql_select_db($db_name) or die(mysql_error());
	
	$res=mysql_log_ExeQuery($query) or die(mysql_error());
		
	if(mysql_affected_rows()!=1)
	{
		echo Create_Error_String('Error : ', 'There is no news to show.');
		die();
	}	
		
	
	$res=mysql_fetch_assoc($res);
?>
	<div id="news-header"   style="display:inline!important">
		<?php if($res['user_id']==$user->Id) : ?><a href="#" class="delete-news" style='float:right!important;' id="delete-news-<?php echo $res['news_id'];?>"><img alt="delete" src="<?php echo BASE_URL.'/Styles/Images/del.png'?>" title='delete the news'></a><?php endif;?>
		<script>
			$('a#delete-news-<?php echo $res['news_id'];?>').click(function()
			{
				$.ajax({
					url:  BASE_URL+'/Privates/Generics/Show-news.functions.php',
					type: 'post',
					data: 'function=delete-news&ajax=1&nid=<?php echo $res['news_id'];?>',
					success:function(data){
						if(data=='1'){
							window.setTimeout("alert('The news has been deleted');window.location = BASE_URL;",500); 
						}else{
							window.setTimeout("alert('Something went wrong please try again')",1000);
						}
					},
					error:function(data,data1,data2){
						$('div#single-comment-'+id).fadeIn(300);
						window.setTimeout("alert('Something went wrong please try again : "+data1+" >> "+data2+"')",1000);
					}
				});
			});
		</script>
		<h1 style="display:inline;">
			<?php echo $res['topic']?>
		</h1><br/>
		<span style="font-size: small;color:gray">
			Posted by <?php echo $res['user']?> <i>at <?php echo $res['post_date']?></i>
		</span>
	</div>
	
	<div id="pre-body">
		<span id="news-image-<?php echo $res['news_id']; ?>">
			<img id="news-summery-img" id="image-<?php echo $res['id']; ?>" width="300px" height="300px" src="<?php echo $res['pic_address']?>" />
		</span>
		<div id="news-summery">
			<h1 style="color:black;display:inline;text-align:justify;">The Summery</h1>
			<hr id="sumery-sep"/>
			<p id="main-summery"> 
				<?php echo $res['summery']?>
			</p>
		</div>
	</div>
	<div class="clear"></div>
	<div id="ins-body">
		<div id="new-body" style="text-align:justify;">
			<h1 style="color:black;display:inline">The Body</h1>
			<hr id="body-sep"/>
			<p id="main-body">
				<?php echo $res['body'];?>
			</p>
		</div>
	</div>
	<div class="clear"></div>
	<a href="#header" style="font-variant:small-caps;background-attachment: scroll;">Back To Top</a>
	
	
	
	
	

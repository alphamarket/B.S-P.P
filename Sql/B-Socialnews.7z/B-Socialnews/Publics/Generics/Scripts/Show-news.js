/**
 * 
 */
if($){
	$(document).ready(function(){
		var sum=$('p#main-summery').html();
		
	});
}
/**
 * This JS file will use in 'index.php' file
 */
if($){
	$(document).ready(function(){
		/*
		 * First init of elements
		 */		
		$('div.login').hide();
		$('div.join').hide();
		// hide join's submit botton in order to disable violent submit access to related php file.
		$('div.join form.joinFRM input#submit').hide();
		$('div.join form.joinFRM span#PassInfoErea').hide();
		// shift join's form cancel bottom to right in place of hided submit bottom.
		$('div.join form.joinFRM input#cancel').css("margin-right", "87px");
		
		/*
		 * Events related with page's elements
		 */
		
		/**
		 * For login menu click
		 */
		$('div.login form.loginFRM input#cancel').show().click(function(){
			$('a#Login').click();
		});
		$('a#Login').click(function(){
			$('div.join').slideUp('medium');
			$('div.login').slideToggle('medium');
		});
		
		/**
		 * For join menu click
		 */
		$('div.join form.joinFRM input#cancel').show().click(function(){
			$('a#Join').click();
		});
		$('a#Join').click(function(){
			$('div.login').slideUp('medium');
			$('div.join').slideToggle('medium');
		});
	});
}
/**
 * 
 */
$('div.container div.join form.joinFRM select[name="type"]').keyup(function($e){
	if($e.keyCode==Enter_keyCode){
		if(All_Ele_Are_Cool()){
			$('div.container div.join form.joinFRM').submit();
		}
	}
});
$('div.container div.join form.joinFRM').submit(function($e){
	$e.preventDefault();
    var $i="";
    jQuery.each($(this).serializeArray(), function(i, field){
	    switch(i){
	    	case 0:
	    		$i=$i+"redir=";
		    	break;
	    	case 1:
	    		$i=$i+"&invite=";
		      	break;
	      	case 2:
	      		$i=$i+"&user=";
		      	break;
	      	case 3:
	      		$i=$i+"&pass="
		      	break;
	      	case 4:
	      		$i=$i+"&confpass=";
		      	break;
	      	case 5:
	      		$i=$i+"&type=";
		      	break;
	      	case 6:
		      	$i=$i+"&mailit=";
		      	break;
		    default:
			    alert("[ "+i+" ] "+field.value);
		    	break;
		}
	    $i=$i+field.value;
    });
	$('div.join form.joinFRM label#MSG').html(Create_Ajax_Loader_Img('Submitting the user!')+"<span style='margin-left:10px;'>Submitting the user ...</span>").css("color","gray").show('medium');
    
	$.ajax({
		url: '../../../Privates/Generics/Join.php',
		type: 'post',
		data: $i+'&ajax=1',
		success: function(data){
			data=data.split('&');
			var IMG = Create_Ajax_Success_Img('The submittion successed!');
			$('div.join form.joinFRM label#MSG').css('color','green');	
			if(data[0]==0){
				$('div.join form.joinFRM label#MSG').css('color','red');	
				IMG = Create_Ajax_Failure_Img('The submittion failed!');
			}
			$('div.join form.joinFRM label#MSG').html(IMG+data[1]).show('medium');

			update_Recently_User_Section();
		}
	});
	return false;
});
function update_Recently_User_Section(){
	$('div#recentlyJoin').hide('medium').html(Create_Ajax_Loader_Img('Updating table')+'<span style="color:gray;font-variant:small-caps;margin:10 0 auto 3px;">Updating table ...!').show('medium');
	$.ajax({
		url: '../../../Privates/User/Privileges/Add-user.recently-refresh.php',
		type: 'post',
		data: 'ajax=1',
		success: function(data){
			$('div#recentlyJoin').html(data);
		}
	});
}
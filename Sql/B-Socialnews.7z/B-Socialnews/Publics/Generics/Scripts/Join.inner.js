	/**
	 * Htmls for join form's status 
	 */
	var b_username=false, b_password=false, b_passinfo=false;
	
	var CancelBTNPos="87px";
	
	/**
	 * check if values of password inputs are equal or not! and show the results.
	 */
	$('div.join form.joinFRM input#Pass').keyup(function(){
		if($('div.join form.joinFRM input#ConfPass').val().length!=0)
		{
			$('div.join form.joinFRM input#ConfPass').keyup();
		}
	}).keydown(function(){$('div.join form.joinFRM input#ConfPass').keydown();});
	/**
	 * function for password confirmation keyup event.
	 */
	$('div.join form.joinFRM input#ConfPass').keyup(function(){
		/**
		 * retrive value of password inputs
		 */
		var pass_1= $('div.join form.joinFRM input#Pass').val();
		var pass_2= $('div.join form.joinFRM input#ConfPass').val();
		/**
		 * doing checking proccess
		 */
		if((pass_1.length!=0 || pass_2.length!=0) && pass_1 != pass_2)
		{
			$('div.join form.joinFRM span.WRGPass').html(Create_Ajax_Failure_Img('Passwords do not match!')).show();
			$('div.join form.joinFRM input#submit').hide();
			$('div.join form.joinFRM input#cancel').css("margin-right", CancelBTNPos);
		}
		else if((pass_1.length!=0 || pass_2.length!=0) && pass_1 == pass_2)
		{
			$('div.join form.joinFRM span.WRGPass').html(Create_Ajax_Success_Img('Password matched!')).show();
			b_password=true;
			Show_submit(All_Ele_Are_Cool());
			return;
			
		}
		else if(pass_1.length==0 && pass_2.length==0)
		{
			TITLE_IMG = '';
			$('div.join form.joinFRM span.WRGPass').html('').show();
		}
		b_password=false;
		Show_submit(false);
	});
	
	/**
	 * function for username textbox blur event.
	 */
	$('div.join form.joinFRM input#User').blur(function(){
		/**
		 * Turn on ajax loader here ...
		 */
		
		var username=$('div.join form.joinFRM input#User').val();
		if(username.length!=0){
			$('div.join form.joinFRM span.ExstUser').html(Create_Ajax_Loader_Img('Check for username!')).show();
			
			$.ajax({
				url: BASE_URL+'/Privates/Generics/Join.checkuser.php',
				type: 'post',
				data: 'userAjax=1&user='+username,
				success: function(data){
					/**
					 * In here ajax loder image will lifted and replaces with Cool or Bad user image.
					 */
					if(data == '1')
					{
						$('div.join form.joinFRM span.ExstUser').html(Create_Ajax_Success_Img('Valid username!')).show();
						b_username=true;
						Show_submit(All_Ele_Are_Cool());
					}
					else
					{
						$('div.join form.joinFRM input#submit').hide();
						$('div.join form.joinFRM input#cancel').css('margin-right', '50px');;
						$('div.join form.joinFRM span.ExstUser').html(Create_Ajax_Failure_Img('Invalid username or this username already exists')).show();
						b_username=false;
						Show_submit(false);
					}
				}
			});
		}
		else
		{
			TITLE_IMG = '';
			$('div.join form.joinFRM span.ExstUser').html('').hide();
		}
	});
	$('div.join form.joinFRM input#PassInfo').blur(function(){
		if(PassInfoNeeded()){
			var passinfo=$(this).val();
			
			if(passinfo.length==15){
				$('div.join form.joinFRM span#PassInfoErea span#WRGPassInfo').html(Create_Ajax_Loader_Img('Check for pass information correctness!')).show();
				
				$.ajax({
					url: BASE_URL+'/Privates/User/Privileges/Add-user.passinfo.inner.php',
					type: 'post',
					data: 'ajax=1&function=check&passinfo='+passinfo+'&type='+$('div.join form.joinFRM select#Type').val(),
					success: function(data){
						if(data=='1'){
							b_passinfo=true;
							$('div.join form.joinFRM span#WRGPassInfo').html(Create_Ajax_Success_Img('Cool to go!')).show();
							// Show submit botton if everythings are cool to go!
							Show_submit(All_Ele_Are_Cool());
						}else if(data=='0'){
							b_passinfo=false;$('div.join form.joinFRM span#WRGPassInfo').html(Create_Ajax_Failure_Img('Invalid Passinfo!')).show();
							Show_submit(false);
						}else{
							$('div.join form.joinFRM input#PassInfo').val('');
							b_passinfo=false;$('div.join form.joinFRM span#WRGPassInfo').html(Create_Ajax_Failure_Img('Invalid Passinfo!')).show();
							Show_submit(false);
						}
					}
				});
			}else{
				if(passinfo.length!=0){
					b_passinfo=false;
					$('div.join form.joinFRM span#WRGPassInfo').html(Create_Ajax_Failure_Img('Invalid Passinfo!')).show();
					Show_submit(false);
				}
			}
		}else{
			b_passinfo=true;
			Show_submit(All_Ele_Are_Cool());
		}
	});
	/**
	 * Checks if all elements inside joinFRM are cool to go or not
	 * 
	 * @returns true if all is cool; otherwise false
	 */
	function All_Ele_Are_Cool(){
		return b_username && b_password && (!PassInfoNeeded() || b_passinfo);			
	}
	
	/**
	 * catch onchange event on usertype select changed.
	 */
	$('div.join form.joinFRM select#Type').change(function(){
		if(PassInfoNeeded()){
			$('div.join form.joinFRM span#PassInfoErea').slideDown('medium');
			b_passinfo=false;
			$('div.join form.joinFRM input#PassInfo').blur();
			Show_submit(All_Ele_Are_Cool());
		}else{
			$('div.join form.joinFRM span#PassInfoErea').slideUp('medium');
			b_passinfo=true;
			Show_submit(All_Ele_Are_Cool());
		}
	});
	/**
	 * checks if this for needs PassInfo from invitor or not?
	 * @returns {Boolean}
	 */
	function PassInfoNeeded(){
		switch($('div.join form.joinFRM select#Type').val()){
			case 'SuperAdmin':
			case 'Admin':
			case 'Developer':
				return true;
			case 'Standard':
			case 'Visitor':
			default:
				$('div.join form.joinFRM input#PassInfo').val('');
				$('div.join form.joinFRM span#WRGPassInfo').html('');
				return false;
		}
	}
	/**
	 * show/hide essential form's elements
	 * @param $show boolian whether to show or not.
	 */
	function Show_submit($show){
		if($show){
			// indicate that this is a cool form!
			$('<input id="coolFRM" type="hidden" name="cool" value="true" />').insertAfter('div.join form.joinFRM input#PassInfo');
			// Make form's submit botton available to launch!
			$('div.join form.joinFRM input#submit').show();
			// shift cancel bottom to left and make room for submit bottom
			$('div.join form.joinFRM input#cancel').css('margin-right', '10px');
		}else{
			// Fuck, this is shit is a bad form!
			$('div.join form.joinFRM input#coolFRM').remove();
			// Hide form's submit botton!
			$('div.join form.joinFRM input#submit').hide();
			// shift cancel bottom to left and make room for submit bottom
			$('div.join form.joinFRM input#cancel').css('margin-right', CancelBTNPos);
		}
	}
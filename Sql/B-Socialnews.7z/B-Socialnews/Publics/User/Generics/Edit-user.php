<?php
	require_once '../includes.inc.php';
	
	session_start();
		
	if(!User::IsLoggedIn())
		Redirect::Redirect_URL('Login.php?redir='.$_SERVER['PHP_SELF']);
	
	$user=User::RestoreFromSession();
		
	// only each user can edit their profile	
	if(!isset($_GET) && $user->Id!=$_GET['id'] && !isset($_POST['user_id']))
		Redirect::Redirect_URL(BASE_URL);
		
	imysql_connect();
	
	$res = mysql_fetch_assoc(mysql_query('SELECT * FROM t_users WHERE user_id='.$user->Id)) or die(mysql_error());
	
	$wng_newpass = false;
	$wng_confpass = false;
	
	if(isset($_POST['submit']))
	{
		if(md5($_POST['current-pass'])!=$res['pass'])
			$wng_confpass=true;
		if ($_POST['conf-pass']!=$_POST['new-pass'])
			$wng_newpass=true;
		if(!$wng_confpass && !$wng_newpass){
			$query = "UPDATE `t_users` SET pass='".md5($_POST['conf-pass'])."' where user_id=".$res['user_id'];
			mysql_query($query) or die(Create_Error_String('Error : ',mysql_error()));
			echo Create_Error_String('Result : ','Your account Info has been stored successfully ...','green');
		}
		unset($_POST);
	}
	
	
?>
<html>
	<head>
		<title>
			<?php echo $user->Name ?>
		</title>
			<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Default.css'?>" type="text/css" />
			<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Index.css'?>" type="text/css" />
			<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Header-Login-out.css'?>" type="text/css" />
			<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Development-Moderation-Print-Style.css'?>" type="text/css" media='print'/>
			<link rel="alternative stylesheet" type="text/css" href="<?php echo BASE_URL.'/Styles/Sheets/Development-Moderation-Print-Style.css'?>" media="screen" title="Print Preview" />

			<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/jquery-1.7.min.js'?>"></script>
			<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/conf.js'?>"></script>
			<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/Plugins/autoGrow.js'?>"></script>
			<style>
				div.edit form.editFRM
				{
					width:800px;
				}
				div.edit form.editFRM label
				{
					float:left;
					width: 300px;
				}
				div.edit form.editFRM select,div.edit form.editFRM input
				{
					width: 200px;
				}
				
			</style>
	</head>
	<body>
		<div class='container'>
			<?php include '../../Generics/header.php';?>
			<div class='edit'>
				<fieldset>
					<form class="editFRM" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						<input type="hidden" name="user_id" value="<?php echo $res['user_id'] ?>">
						<p><label>Username :</label><input id="User" disabled='disabled' type="text" name="user" maxlength="20" value='<?php echo $res['user'] ?>'/></p>
						
						<p><label>Enter your current password :</label><input id="Current-Pass" type="password" name="current-pass" maxlength="50"/><span class="WRG-crntPass" style="color:red;<?php echo $wng_confpass?'':'display:none'?>">Your passwords do not match!</span></p>
						
						<p><label>Enter your new password :</label><input id="new-Pass" type="password" name="new-pass" maxlength="50"/><span class="WRG-newPass" style="color:red;<?php echo $wng_newpass?'':'display:none'?>">Your passwords do not match!</span></p>
						
						<p><label>Confirm your new password :</label><input id="ConfPass" type="password" name="conf-pass" maxlength="50"/><span class="WRG-newPass" style="color:red;<?php echo $wng_newpass?'':'display:none'?>">Your passwords do not match!</span></p>
						<p><label>Your user type is :</label>
						<select name='type' id='Type' disabled='disabled'>
							<?php
								global $User_Type;

								foreach($User_Type as $key => $value)
									if($key == $user->User_Type)
									{
										echo "<option ".($key=='Standard'?'selected="selected"':'')."value='$key'>$key</option>";
										break;
									}
							?>
						</select>
						</p>
						<p><label style="visibility:hidden">Submit</label><input id="submit" type="submit" name="submit" value="Update" style="margin-right:7px;"/></p>
					</form>
				</fieldset>
			</div>
			[ <a id="deluser" style="Color:red" href="<?php echo "id=".$user->Id."&type=".$user->User_Type; ?>">Delete your account</a> ]
			<script>
				$('a#deluser').click(function($e){
					$e.preventDefault();
					
					$('span#recent-op-label').html(Create_Ajax_Loader_Img('Deleting user')+"<span style='margin-left:10px;'>Deleting user ...</span>").css("color","gray").show('medium');
					
					$.ajax({
						url: BASE_URL+'/Privates/User/Privileges/Deleted-user.php',
						type: 'post',
						data: 'ajax=1&'+$(this).attr('href'),
						success: function(data){
							var i=data.split('&');
							if(i[0]=='1'){
								window.setTimeout("alert('Your account has been deleted successfully!');window.location=BASE_URL+'/Privates/Generics/Logout.php'");
							}else {
								alert('something wents wrong!'+data);
							}
						}
					});
				});
			</script>
			<div class="clear"></div>
			<?php include '../../Generics/footer.php';?>
		</div>
	</body>
</html>

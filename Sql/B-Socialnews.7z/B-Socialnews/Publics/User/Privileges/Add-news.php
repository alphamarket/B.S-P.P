<?php
	include_once '../../../Privates/User/Privileges/Add-news.inner.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<link rel="stylesheet" href="../../../Styles/Sheets/Default.css" type="text/css" />
		<link rel="stylesheet" href="../../../Styles/Sheets/Header-Login-out.css" type="text/css" />
		<script type="text/javascript" src="../../../Javascript/jquery-1.7.min.js"></script>
		<script type="text/javascript" src="../../../Javascript/conf.js"></script>
		<title>Add News</title>
		<style type="text/css">
			div.container form label{
				margin-bottom: 10px;				
				width: 200px;
			}
			div.container form p, div.container div#Cat-Section p{
				width: 700px;				
			}
			div.container form input, div.container form textarea, div.container form select{
				min-width: 400px;
				float: right;	
			}
			div.container form textarea{
				width: 690px!important;	
				margin-bottom: 10px;
			}
			div.container form select{
				min-width: 200px!important;
				margin-right: 205px!important;
			}
			div.container form input[type="submit"],div.container form input[type="reset"]{
	
				min-width: 70px!important;
				width: 120px;
				height: 35px;
				display: block;
				background-color:#12cf;
				color: black;
				border:1px solid black;
				margin-left:5px;
			}			
			div.container form#Add-news input[type="file"]{
				/*background-image: url("../../../Styles/Images/botton.png");
				border:1px dotted gray;
				background-repeat: repeat-x;*/
				padding:5px;
				margin-top:-5px;
				color: gray;
			}
			div.container div.form-container form#Add-news select option{	
				color:black;
			}
			div.container div.form-container form#Add-news select option[value='-1']{		
				color:gray!important;
			}
			div.container form input[type='checkbox']{
				float:left;
				min-width: 20px;
				margin-left:-5px;
			}
			<?php include_once '../../../Styles/Sheets/jConf.css';?>
		</style>
		<script type="text/javascript">
			<?php include_once '../../../Privates/User/Privileges/Scripts/Add-news.js';?>
			<?php include_once '../../../Javascript/Plugins/jConf.js';?>
			<?php include_once '../../../Javascript/Plugins/autoGrow.js';?>
			$(document).ready(function(){
				$('textarea').autoGrow();
			});
		</script>
	</head>
	<body>
		<div class="container">
			<?php include '../../Generics/header.php';?>
			<div class="form-container">

				<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" id="Add-news" enctype="multipart/form-data">
					<p>
						<label>Enter news's topic :</label>
						<input type="text" maxlength="255" name="topic" style="font-variant:small-caps;text-transform: capitalize;" />
						<span id="check-news-topic" style="float:right;margin:3px 5px -5px 5px;"><!-- Ajax check if this topic exist in database or not --></span>
					</p>
					<p>
						<label>Select news's category :</label>
						<select name="category" style="color:gray" >
							<?php 
								Ajax_Update_Category_Combo('t_category');
							?>
						</select>
					</p>
					<p>
						<label>Enter news's summery :</label>
						<textarea rows="5" cols="45" name="summery"></textarea>
					</p>
					<p>
						<label>Enter news's body :</label>
						<textarea rows="10" cols="85" name="body"></textarea>
					</p>
					<p>
						<label>Uploud news's thumbnail :</label>
						<input type="file" name="tnail" style="margin-top:-3px;">
					</p>
					<p style="margin-top:15px;">
						<label>Select news's status :</label>
						<select name="status" style="color:gray">
							<?php 
								Ajax_Update_Category_Combo('t_post_status');
							?>
						</select>
					</p>
					<p style="margin-top:15px;">
						<input type="checkbox" name="contains-html" /><span style='cursor:pointer;' onclick="Contains_Html()">This document contains html charateres.</span>
					</p>
					<p style="margin-top:15px;">
						<input type="submit" name="submit" value="Launch the news" style="display: none">
						<input type="reset">
					</p>
				</form>
				<div class="clear"></div>
				<!-- 
				<hr style="width: 60%;color:gray;" />
				
				<a id="review-news-link" style="margin: 10px;cursor:pointer">Review the news</a>
				
				<div id="review-section" style="border:1px solid black;margin:10px;min-height: 30px;display:none">
				
					<img id="colapse-rev-section" alt="Close" src="<?php echo BASE_URL.'/Styles/Images/failure-delete.png';?>" width="20px" height="20px" style="float:right;cursor:pointer;margin:5px;" title="Close section" />
				
					<div id="whole-news" style="padding-left:15px;">
				
						<label id="news-header" style="font-variant: small-caps;text-align: justify;text-transform: capitalize;font-size:large;"></label>
				
						<center><label id="news-summery" style="max-width:610px;ont-variant: small-caps;color:gray;text-align: justify;"></label></center><br />
				
						<label id="news-body" style="margin-top:10px;margin-bottom:10px;text-align: justify;"></label>
				
					</div>
				</div>
				 -->
				
				<script type="text/javascript">
//					var newsSec='div.container div#review-section div#whole-news ';
//					
//					$('div.container a#review-news-link').click(function(){
//						$('div.container div#review-section').show('medium');
//						$(this).hide('medium');
//					});
//					$('div.container div#review-section img#colapse-rev-section').click(function(){
//						$(this).parent().hide('medium');
//						$('div.container a#review-news-link').show('medium');
//					});
//					$('div.container div.form-container form#Add-news input[name="topic"]').keyup(function(){
//						updateNewsTopicReview();
//					});
//					$('div.container div.form-container form#Add-news textarea[name="summery"]').keyup(function(){
//						updateNewsSummeryReview();
//					});
//					$('div.container div.form-container form#Add-news textarea[name="body"]').keyup(function(){
//						updateNewsBodyReview();
//					});
//
//					function updateNewsSummeryReview(){
//						if($('div.container div.form-container form#Add-news input[type="checkbox"]').attr('checked')!='checked')
//							$(newsSec+'label#news-summery').html('<p style="margin:20px;">'+htmlEscape($(this).val(),false)+'</p>');
//						else
//							$(newsSec+'label#news-summery').html('<p style="margin:20px;"><pre style="font-family:Arian">'+htmlEscape($(this).val(),true)+"</pre></p>");
//					}
//
//					function updateNewsBodyReview(){
//						if($('div.container div.form-container form#Add-news input[type="checkbox"]').attr('checked')!='checked')
//							$(newsSec+'label#news-body').html(htmlEscape($(this).val(),false));
//						else
//							$(newsSec+'label#news-body').html("<pre style='font-family:Arian'>"+htmlEscape($(this).val(),true)+"</pre>");
//					}
//
//					function updateNewsTopicReview(){
//						$(newsSec+'label#news-header').html('<p><strong style="text-trnasform:capitalize;color:gray;">'+$(this).val()+'</strong></p>');
//					}
//					
//
//					function Contains_Html(){
//						if($('form#Add-news input[type="checkbox"]').attr('checked')=="checked")
//							$('form#Add-news input[type="checkbox"]').removeAttr('checked');
//						else
//							$('form#Add-news input[type="checkbox"]').attr('checked','checked');
//						updateNewsTopicReview();
//						updateNewsSummeryReview();
//						updateNewsBodyReview();
//					}
				</script>
			</div>
			
			<?php if($user->User_Type=='SuperAdmin' || $user->User_Type=='Developer'):?>
				<?php include '../../../Privates/User/Privileges/Add-news.categories.php'?>
				<?php include '../../../Privates/User/Privileges/Add-news.status.php'?>
			<?php endif;?>
			
			<?php include '../../Generics/footer.php';?>
		</div>
	</body>
</html>

<?php 
	require_once '../includes.inc.php';
	session_start();
	$user=User::Serialize($_SESSION['USER']);
	if(!User::IsLoggedIn() || $_SESSION['USER']->User_Type=='Standard' || $_SESSION['USER']->User_Type=='Visitor')
		Redirect::Redirect_URL(BASE_URL);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>
			Add User
		</title>
		
		<link rel="stylesheet" href="../../../Styles/Sheets/Default.css" type="text/css" />
		<link rel="stylesheet" href="../../../Styles/Sheets/Header-Login-out.css" type="text/css" />
		<script type="text/javascript" src="../../../Javascript/jquery-1.7.min.js"></script>
		<script type="text/javascript" src="../../../Javascript/conf.js"></script>
		<style type="text/css">
			fieldset#gpassField span.float-left{
				float:left;
				width: 400px;
				display:inline;	
			}
			table#recent-users{
				border: 1px solid #000;	
				border-bottom: 0px;				
			}
			table#recent-users td{
				width: 200px;
				color: #09C;
				border-bottom: 1px solid black;
			}
		</style>
		<script type="text/javascript">
			if($){
				$(document).ready(function(){
					$('div#URight').hide();
					$('div.join form.joinFRM input#submit').hide();
					$('div.join form.joinFRM span#PassInfoErea').hide();
					// shift join's form cancel bottom to right in place of hided submit bottom.
					$('div.join form.joinFRM input#cancel').css("margin-right", "87px");
					$('div#PassInfo_div fieldset#gpassField span#gPassOptions').hide();
					$('fieldset#gpassField').hide();
					$('div#join form#joinFRM label#MSG').hide();
				});
			}
		</script>
	</head>
	<body>
		<div class='container'>
			<?php include '../../Generics/header.php';?>
			<div style="border: 1px solid black;margin:10px;padding:5px;clear:both;height: auto;">
				<p style="display:inline;">Accourding to user privilege you add users </p><a class="KnowRIT" style="cursor: pointer;">[ Know your other rights ]</a>
				<div id='URight' style="display:hidden; margin-top:-14px;margin-bottom: -10px;">
					<ul style="font-variant: small-caps;">
						<li>You can add users.</li>
						<li>You can delete users.</li>
						<li>You can modirate users activity.</li>
						<li>You can denote users.</li>
						<li style="list-style-type: none"><a class="KnowRIT" style="cursor:pointer;display:none;">[ Collapse ]</a></li>
					</ul>
				</div>
				<script type="text/javascript">
					$('a.KnowRIT').click(function(){
						$('div#URight').slideToggle('medium');
						$('a.KnowRIT').slideToggle('medium');
					});
				</script>
			<hr style="width:60%;margin:20px auto 20px auto;" />
			<div class='join'>
				<form class="joinFRM" id="Add-user-php-JoinFRM" action="<?php echo BASE_URL.'/Privates/Generics/Join.php';?>" method="post" style="margin-bottom:0px;">
					<input type="hidden" name="redir" value="<?php echo PURE_URL.$_SERVER['PHP_SELF']; ?>" />
					<input type="hidden" name="invite" value="true" />
					<p><label>Enter username :</label><input id="User" type="text" name="user" maxlength="20"/><span class="ExstUser" style="color:red;display:none">This user already exists!</span></p>
					<p><label>Enter password :</label><input id="Pass" type="password" name="pass" maxlength="50"/><span class="WRGPass" style="color:red;display:none">Your passwords do not match!</span></p>
					<p><label>Confirm the password :</label><input id="ConfPass" type="password" name="confpass" maxlength="50"/><span class="WRGPass" style="color:red;display:none">Your passwords do not match!</span></p>
					<p>
						<label>Select user type :</label>
						<select name='type' id='_Type' style="width: 157px;">
							<?php
								$User_Type = array(
										'SuperAdmin' => 1,
										'Admin' => 2,
										'Standard' => 3,
										'Visitor' => 4,
										'Developer' => 0,
									);
							?>
							<?php if($user->User_Type=='SuperAdmin' || $user->User_Type=='Developer'):?>
								<option value="SuperAdmin">SuperAdmin</option>
								<option value="Admin">Admin</option>
								<option value="Developer">Developer</option>
							<?php endif;?>
							<option selected="selected" value="Standard">Standard</option>
							<option value="Visitor">Visitor</option>
						</select>
					</p>
					
					
					<p>
						<input type="checkbox" name="mailit" value="checked" checked="checked" style="margin-left:50px;"/>Mail username and password.
					</p>
					
					<label id="MSG" style="color:gray;margin-top:10px;width: 600px;"><?php 
						if(isset($_SESSION['MSG'])){
							echo $_SESSION['MSG']; 
							unset($_SESSION['MSG']);
						}else{
							echo 'Hit Enter when you have all green, to submit';
						}?>
					</label>
					
					<input id="submit" type="submit" name="submit" style="visibility: collapse;" value="Join" />
					
				</form>
				<div class="clear"></div>
				<script type="text/javascript">
					<?php include '../../../Publics/Generics/Scripts/Join.inner.js'; ?>
					<?php include '../../../Publics/Generics/Scripts/Add-user.js';?>
				</script>
			</div>
		</div>
		
		
			<?php if($user->User_Type=='Developer' || $user->User_Type=='SuperAdmin'): ?>
		
				<hr style="width:60%" />
		
				<?php include '../../../Privates/User/Privileges/Add-user.passinfo.php';?>
		
			<?php endif;?>		
			<span id="recently-user-update-place">
				<?php include '../../../Privates/User/Privileges/Add-user.recently.php'?>
			</span>
			<div class="clear"></div>
			<?php include '../../Generics/footer.php';?>
		</div>
	</body>
</html>
<?php
	require_once '../../../Configs/global.conf.php';
	require_once '../../../Libs/Redirect.php';
	require_once '../../../Configs/Database/database.conf.php';
	require_once '../../../Libs/User.php';
	
	global $db_host, $db_user, $db_name, $db_pass;
	
<?php
	// DONE: why this fucking code does not working as this predected!!??
	
	require_once '../includes.inc.php';
	
	if(isset($_POST) && isset($_POST['ajax'])){
		if(isset($_POST['function'])){
			switch (strtolower($_POST['function'])) {
				case 'query_on_demand':
					Query_On_Demand($_POST['q']);
				break;
				case 'show_logs':
					Show_Logs();
				default:
					;
				break;
			}
		}else{
			echo 'not function has been setted.';
		}
		unset($_POST);
		die();
	}
	
	function Query_On_Demand($query){
		require_once '../../../Configs/Database/database.conf.php';
		global $db_host,$db_name;
		mysql_close();
		$db=mysql_connect($db_host, 'justreader', '8E2BKRhuCptN9mhT') or die(mysql_error());
		
		mysql_select_db($db_name,$db) or die(mysql_error());
		
		$res = mysql_query($query) or 
			die(Create_Error_String('Your query has some error : ', mysql_errno()==1142?'Query execution denied!':mysql_error().'@'.mysql_errno()));
		
		
		$raw_res = mysql_fetch_array($res,MYSQL_ASSOC);
		mysql_close();
		
		if(!isset($raw_res) || $raw_res==null)
			die(Create_Error_String('Query result: ', 'No result comes out.','green'));
		
		$arr=array_keys($raw_res);
?>
		<table  cellpadding="3px" cellspacing="0" border="1px solid black">
		 	<thead >
				  <tr style='background-color:#C9C9C9'>
<?php 
					foreach ($arr as $key=>$value) {
						echo "<th>$value</th>";
					}
?>
				  </tr>
		 	</thead>
		 	<tbody>
<?php 
					$even=false;
					while(isset($raw_res) && $raw_res!=null){
						echo '<tr style="background-color:'.($even?'#C9C9C9':'white').'">';
						foreach ($raw_res as $value) {
							echo "<td>$value</td>";
						}
						echo '</tr>';
						$even=!$even;
						$raw_res=mysql_fetch_array($res,MYSQL_ASSOC);
					}
?>
		 	</tbody>  
		</table>
<?php 
	}
	
	function Show_Logs(){
		$top=(strlen($_POST['top-limit'])==0?$_POST['log_count']:$_POST['top-limit']);
		$bot=(strlen($_POST['bottom-limit'])==0?$_POST['log_count']-($_POST['log_count']>25?25:$_POST['log_count']):$_POST['bottom-limit']);
		$limit="LIMIT $bot,$top";
		$order="ORDER BY db_log_id ".$_POST['sort'];
		$where='';
		if(strlen($_POST['where'])!=0 || $_POST['failed']!='%')
			$where="WHERE ".$_POST['where'].(strlen($_POST['where'])!=0?" AND ":"").($_POST['failed']=='%'?"":'failed='.$_POST['failed']);
		$query="SELECT * FROM t_logs $where $order $limit";	
		Query_On_Demand($query);
	}

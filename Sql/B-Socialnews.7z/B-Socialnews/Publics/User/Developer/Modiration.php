<?php 
	require_once '../includes.inc.php';
	session_start();
	$user=User::RestoreFromSession();
	if(!User::IsLoggedIn() || strtolower($user->User_Type)!='developer')
		Redirect::Redirect_URL(BASE_URL);
?>
<html>
	<head>
		<title>
			Index
		</title>
		
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Default.css'?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Index.css'?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Header-Login-out.css'?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Show-news.css'?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASE_URL.'/Styles/Sheets/Development-Moderation-Print-Style.css'?>" type="text/css" media='print'/>
		<link rel="alternative stylesheet" type="text/css" href="<?php echo BASE_URL.'/Styles/Sheets/Development-Moderation-Print-Style.css'?>" media="screen" title="Print Preview" />

		<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/jquery-1.7.min.js'?>"></script>
		<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/conf.js'?>"></script>
		<script type="text/javascript" src="<?php echo BASE_URL.'/Javascript/Plugins/autoGrow.js'?>"></script>
		<style type="text/css">
			div#query-result td{
				max-height: 50px;	
			}
		</style>
	</head>
	<body>
		<div class='container'>
			<?php include '../../../Publics/Generics/header.php';?>
			<div class='form-container'>
				<div><a style='cursor: pointer;display:none' id='open-logs' >Open logs</a></div>
				<script type="text/javascript">
					$('a#open-logs').click(function(){
						$('div#log-section').slideToggle();
					});
				</script>
				<div class='form-container' id='log-section' style='display:none;'>
					<!--<p style='text-transform:lowercase;'>
					 	<span style='text-transform: uppercase;color:red'>TODO:</span> PUT SOME MOVEMENT OPTIONS IN THIS SECTION LIKE 
					 	<span style='color:green;font-variant:small-caps;'>LIMIT, DESC OR ASC, MATCHS QUERIES, JUST FAILURE QUERIES</span> and so on.
					</p>-->
					<?php 
						imysql_connect();
						
						$count = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM t_logs'), MYSQL_NUM) or die(mysql_error());
						
						$count=$count[0];
						
						$count_len = strlen((string)$count);
					?>
					<form name='log-setting-form'>
						<input type="hidden" value="<?php echo $count;?>" name="log_count" />
						<input type='text' name='bottom-limit' onkeypress="return Is_Numbers()" maxlength="<?php echo $count_len?>"/>
						<label> &lt; Recode limit &lt; </label>
						<input type='text' name='top-limit' onkeypress="return Is_Numbers()" maxlength="<?php echo $count_len?>"/> Log table's row count : <?php echo $count;?><br />
						<label> WHERE : </label><input type='text' name='where' style='width:500px;' />
						<fieldset>
							<legend>Sort mode</legend>
							<input type="radio" name='sort' value='Asc'><a style='cursor: pointer;color:black' onclick="$(this).prev().click();">Ascending</a><br />
							<input type='radio' name='sort' checked='checked' value='Desc'><a style='cursor: pointer;color:black' onclick="$(this).prev().click();">Descending</a> 
						</fieldset>
						<fieldset>
							<legend>Faileds type</legend>
							<input type="radio" name='failed' value='1' /><a style='cursor: pointer;color:black' onclick="$(this).prev().click();">Just failures</a><br />
							<input type='radio' name='failed' value='0' /><a style='cursor: pointer;color:black' onclick="$(this).prev().click();">Just Successeds</a><br />
							<input type='radio' name='failed' checked='checked' value='%' /><a style='cursor: pointer;color:black' onclick="$(this).prev().click();">All</a>
						</fieldset>
						<span></span>
					</form>
					<script type="text/javascript">
						$('form[name="log-setting-form"] input[type="radio"]').click(function(){
							launchLogRequest();
						}).attr('onchange','launchLogRequest()');
						
						$('form[name="log-setting-form"] input[type="text"]').blur(function(){
							launchLogRequest();
						});
						$l=false;
						function launchLogRequest(){
							if(!$l){
								$l=!$l;
								return;
							}
							$l=!$l;
							$('form[name="log-setting-form"] span')
								.fadeOut(200)
								.html(Create_Ajax_Loader_Img('Wait until query executed ...')+'Launching query ...')
								.fadeIn(200);
							
							$.ajax({
								url:'<?php echo PURE_URL.dirname($_SERVER['PHP_SELF']).'/Modiration.inner.php'?>',
								type: 'post',
								data: 'ajax=1&function=show_logs&'+$('form[name="log-setting-form"]').serialize(),
								success:function(data){
									$('form[name="log-setting-form"] span')
										.fadeOut(200)
										.html(Create_Ajax_Success_Img('Wait until query executed ...')+'<span style="color:green">Query execution process is done.</span>')
										.fadeIn(200);
									$('div#query-result').html(data);
								}
							});
						}
						
					</script>
				</div>
				<div><a style='cursor: pointer;' id='open-tables'>Open tables list</a></div>
				<script type="text/javascript">
					$('a#open-tables').click(function(){
						$('div#tables-list').slideToggle();
					});
				</script>
				<div id='tables-list' class='form-container' style='display:none;padding:0px!important;border:1px solid black;margin-left:10px;'>
				<?php 
					imysql_connect();
					$res= mysql_query('Show TABles') or die(mysql_error());
					$even=false;
					$row = mysql_fetch_array($res);
					while(isset($row) && $row!=null){
						
						echo "<div style='background-color:".($even?'white':'lightgray').";padding:5px;'>$row[0]</div>";
						
						$even=!$even;
						
						$row = mysql_fetch_array($res);
					}
				?>
				</div>
				<div><a style='cursor: pointer;' id='query-ondemand'>Open query on demands [ only read query ]</a></div>
				<script type="text/javascript">
					$('a#query-ondemand').click(function(){
						$('div#query-ondemand-section').slideToggle();
					});
				</script>
				<div id='query-ondemand-section' class='form-container' style='display:none;'>
					<form name='query-form' action='<?php echo $_SERVER['PHP_SELF']?>' method="post">
						<textarea name='query' rows='3'  onkeypress="
							if(($('div#query-ondemand-section form[name=\'query-form\'] p#query-launch-state').html())!='Hit <a>Ctrl + Enter</a> to launch the query.')
								$('div#query-ondemand-section form[name=\'query-form\'] p#query-launch-state').html('Hit <a>Ctrl + Enter</a> to launch the query.');"
								 style='width:795px;'></textarea>
						<noscript>
							<input type='submit' value='Do Query' name='submit' />
						</noscript>
						<p style="color:gray;float:right;" id='query-launch-state'>Hit <a>Ctrl + Enter</a> to launch the query.</p>
					</form>
				</div>
				<script type="text/javascript">
					$('div#query-ondemand-section form[name="query-form"] textarea[name="query"]')
							.autoGrow()
							.css('color','gray')
							.val('Enter your demanded query in here.')
					.blur(function(){

						if(($(this).val()).length==0 || $(this).val()=='Enter your demanded query in here.')
							$(this).val('Enter your demanded query in here.').css('color','gray');

					}).keyup(function($e){

						var query = ($(this).val()).trim();
							
						/*
						 * check on if query is a onlyread query!?
						 */
						if($e.ctrlKey && $e.keyCode==Enter_keyCode && query.lenght!=0){

							$('div#query-ondemand-section form[name="query-form"] p#query-launch-state')
								.fadeOut(200)
								.html(Create_Ajax_Loader_Img('Wait until query executed ...')+'Launching query ...')
								.fadeIn(200);
							
							// TODO: improve searching for voilent statement;
							switch(true){
								case query.toLowerCase().contains('delete'):
								case query.toLowerCase().contains('insert'):
								case query.toLowerCase().contains('update'):
									//alert('Invalid query! the query cannot contains non-select statement');
									//return;
									break;
							}

							//alert('ajax request launched ... q:'+query);
							
							// put result into div#query-result

							$.ajax({
								url:'<?php echo PURE_URL.dirname($_SERVER['PHP_SELF']).'/Modiration.inner.php'?>',
								type:'post',
								data:'ajax=1&function=query_on_demand&q='+query,
								success:function(data){
									$('div#query-ondemand-section form[name="query-form"] p#query-launch-state')
										.fadeOut(200)
										.html(Create_Ajax_Success_Img('Wait until query executed ...')+'<span style="color:green">Query execution process is done.</span>')
										.fadeIn(200);
									$('div#query-result').html(data);
								}
							});
						}
						
					}).click(function(){

						if($(this).val()=='Enter your demanded query in here.')
							$(this).val('').css('color','black');
						else
							$(this).css('color','black');

					});
				</script>
			</div>
			<?php include '../../../Publics/Generics/footer.php';?>
		</div>
	</body>
	<center><div id='query-result' style='margin-top:35px;'></div></center>
</html>
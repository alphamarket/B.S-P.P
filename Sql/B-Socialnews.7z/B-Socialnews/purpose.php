<div style="float: left; text-align:justify; width: 400px;margin:15px;">
	<p>
		This is a community that every body can tell others about any thing! any thing at all!
		Any news in any area! locallity and can argu about any news! todays is news time!
		If you have something to say and not signed yet please join us.
	</p>
	<p>
		This site is a free community site that can link every posible situation to another.
		ofcourse your privacy would be safe with us.
	</p>
	<p>
		Sociaty needs to be discussed, argued, things that happen around us are affecting our life, 
		we need to be aware of them.
	</p>
	<p>
		At the end you are welcome to this commiunity and we hope that you enjoy your freedom here.
	</p>
</div>
<div style="float: right; text-align:justify; width: 400px;margin:15px;">
	<div id="rand-news">
		<a id="see-rand-topic" href="#">See some random topic ...</a>
		<div id="rand-topic"></div>
	</div>
</div>
<script type="text/javascript">
<!--
	$('div#rand-news a#see-rand-topic').click(function(){
		$(this).hide();
		$('div#rand-news div#rand-topic').
			html(Create_Ajax_Loader_Img('Generating random topic to show ...')+
					'<span style="color:gray;margin-left:10px;">Loading some topics from database</span>').show();
	
		$.ajax({
			url: './Privates/Generics/random-news.php',
			type:'post',
			data:'count=5',
			success:function(data){
				$('div#rand-news div#rand-topic').html(data).hide().fadeIn(1200).css('padding','5px');
				$(Create_jQuery_Close_Img('Close random topic section')).insertBefore('div#rand-news div#rand-topic div:first')
					.click(function(){
						$('div#rand-news div#rand-topic').fadeOut(700).html('');
						$('div#rand-news a#see-rand-topic').fadeIn(800);
					});
			}	
		});
	});
//-->
</script>

<?php
die('file invoked ...');
	$db = mysql_connect('localhost','root','root') or die(mysql_error());
echo 'connection passed ...';
	mysql_select_db('socialnews',$db) or die(mysql_error());
echo 'database selected ...';
	$uqery = 'Call generatePassinfo(36,'admin',null )';
echo 'query generated ...';
	mysql_query($query) or die(mysql_error());
echo 'query executed ...';

-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 15, 2012 at 04:27 PM
-- Server version: 5.5.24
-- PHP Version: 5.3.10-1ubuntu3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `socialnews`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddNews`(_topic varchar(255),_user varchar(20),_category int(10) unsigned,_summery text,_body text,_post_date varchar(20),_post_status varchar(20),_pic_address text,_tnail_address text)
begin INSERT INTO t_news SET topic=_topic, user_id=_user,category=_category,summery=_summery,body=_body,post_date=_post_date,post_status=_post_status,pic_address=_pic_address,tnail_address=_tnail_address;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CheckForLike`(_comment_id int(255), _user_id int(11) unsigned)
begin SELECT count(*) as liked FROM t_users_comments WHERE comment_id=_comment_id and user_id=_user_id;end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteComment`(_user_id int(10),_comment_id int(255))
begin DELETE FROM t_comments WHERE comment_id=_comment_id AND user_id=_user_id; end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditComment`(_comment_id int(255),_new_comment text)
begin UPDATE t_comments SET comment=_new_comment WHERE comment_id=_comment_id; end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GeneratePassInfo`(creater_user_id int(10) unsigned,for_type varchar(10), expire_date varchar(10))
begin declare passinfo varchar(20) DEFAULT substring(md5(floor(RAND()*1000)),1,20);while(exists(select * from t_admin_users_p where pass = passinfo)) DO set passinfo =  substring(md5(floor(RAND()*1000)),1,20); end while; INSERT INTO t_admin_users_p VALUES ( passinfo , for_type , creater_user_id , CURDATE() , expire_date ); select passinfo; end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLikeCount`( _comment_id int(255))
begin SELECT count(*) as count FROM t_users_comments WHERE comment_id=_comment_id;end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `IsValidUser`(username varchar(20),password varchar(50), out isvalid boolean,out userid int(10), out usertype varchar(10))
begin select user_id,type into userid, usertype from t_users where user=username and pass = password; if(usertype is null) then set isvalid=false; else  set isvalid=true; end if;   end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `LikeComment`(_comment_id varchar(255),_user_id int(10) unsigned)
begin INSERT INTO t_users_comments VALUES ( _comment_id, _user_id );end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `NewsSummeryList`(summery_max_words_count int)
begin select news_id,topic,user,CONCAT(SUBSTRING_INDEX(summery,' ',summery_max_words_count),' ...') as summery,post_date,tnail_address from t_news,t_users where t_users.user_id=t_news.user_id order by news_id desc; end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SubmitComment`(_news_id int(20),_user_id int(10),_comment text)
begin
INSERT INTO t_comments SET news_id=_news_id, user_id=_user_id,comment=_comment;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UnlikeComment`( _comment_id int(255),_user_id int(10) unsigned)
begin DELETE FROM t_users_comments WHERE comment_id=_comment_id and user_id=_user_id; end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `t_admin_users_p`
--

CREATE TABLE IF NOT EXISTS `t_admin_users_p` (
  `pass` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `type` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `set_date` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  `expire_date` varchar(10) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`pass`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `t_category`
--

CREATE TABLE IF NOT EXISTS `t_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=57 ;

--
-- Dumping data for table `t_category`
--

INSERT INTO `t_category` (`category_id`, `name`) VALUES
(56, 'Academic'),
(50, 'Action'),
(52, 'Love Story'),
(53, 'Social'),
(51, 'Tragic');

-- --------------------------------------------------------

--
-- Table structure for table `t_comments`
--

CREATE TABLE IF NOT EXISTS `t_comments` (
  `comment_id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` bigint(20) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `comment` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `news_id` (`news_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `t_comments`
--

INSERT INTO `t_comments` (`comment_id`, `news_id`, `user_id`, `comment`) VALUES
(9, 1, 8, 'This is a comment for testing'),
(10, 1, 36, 'Testing for apachtop app performance...'),
(12, 14, 8, 'NEW COMMENT ...'),
(13, 14, 8, 'New comment');

-- --------------------------------------------------------

--
-- Table structure for table `t_cracking`
--

CREATE TABLE IF NOT EXISTS `t_cracking` (
  `crack_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_id` int(10) unsigned NOT NULL,
  `crack_date` text NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`crack_id`),
  UNIQUE KEY `log_id` (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_logs`
--

CREATE TABLE IF NOT EXISTS `t_logs` (
  `db_log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `query_exe_user_id` int(10) unsigned NOT NULL,
  `query_time` text COLLATE utf8_persian_ci NOT NULL,
  `query` text CHARACTER SET utf16 COLLATE utf16_persian_ci NOT NULL,
  `failed` tinyint(1) NOT NULL,
  `result` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`db_log_id`),
  KEY `failed` (`failed`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=126 ;

--
-- Dumping data for table `t_logs`
--

INSERT INTO `t_logs` (`db_log_id`, `query_exe_user_id`, `query_time`, `query`, `failed`, `result`) VALUES
(80, 0, 'Jun-30-2012 21:59:06', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(81, 0, 'Jun-30-2012 22:46:47', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(82, 0, 'Jul-01-2012 02:31:54', 'INSERT INTO t_users (user, pass, type) VALUES ('''', ''d41d8cd98f00b204e9800998ecf8427e'', '''')', 0, ''),
(83, 0, 'Jul-01-2012 02:32:08', 'INSERT INTO t_users (user, pass, type) VALUES (''foo'', ''acbd18db4cc2f85cedef654fccc4a4d8'', ''Standard'')', 0, ''),
(84, 0, 'Jul-01-2012 02:32:12', 'call IsValidUser(''foo'',''acbd18db4cc2f85cedef654fccc4a4d8'',@isvalid,@id,@type);', 0, ''),
(85, 0, 'Jul-01-2012 02:35:03', 'INSERT INTO t_users (user, pass, type) VALUES (''foo'', ''acbd18db4cc2f85cedef654fccc4a4d8'', ''Standard'')', 0, ''),
(86, 0, 'Jul-01-2012 02:35:06', 'call IsValidUser(''foo'',''acbd18db4cc2f85cedef654fccc4a4d8'',@isvalid,@id,@type);', 0, ''),
(87, 0, 'Jul-01-2012 03:20:47', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(89, 0, 'Jul-01-2012 03:21:29', 'call IsValidUser(''a'',''0cc175b9c0f1b6a831c399e269772661'',@isvalid,@id,@type);', 0, ''),
(90, 0, 'Jul-01-2012 03:21:35', 'call IsValidUser(''a'',''8ce4b16b22b58894aa86c421e8759df3'',@isvalid,@id,@type);', 0, ''),
(91, 0, 'Jul-01-2012 03:22:09', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(92, 0, 'Jul-01-2012 03:22:32', 'INSERT INTO t_users (user, pass, type) VALUES (''B'', ''92eb5ffee6ae2fec3ad71c777531578f'', ''Standard'')', 0, ''),
(93, 0, 'Jul-01-2012 03:22:39', 'call IsValidUser(''b'',''92eb5ffee6ae2fec3ad71c777531578f'',@isvalid,@id,@type);', 0, ''),
(94, 0, 'Jul-01-2012 03:22:57', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(95, 0, 'Jul-01-2012 03:23:07', 'INSERT INTO t_users (user, pass, type) VALUES (''b'', ''92eb5ffee6ae2fec3ad71c777531578f'', ''SuperAdmin'')', 0, ''),
(96, 0, 'Jul-01-2012 03:23:14', 'call IsValidUser(''b'',''92eb5ffee6ae2fec3ad71c777531578f'',@isvalid,@id,@type);', 0, ''),
(97, 0, 'Jul-01-2012 03:24:40', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(98, 0, 'Jul-01-2012 03:41:03', 'call IsValidUser(''b'',''92eb5ffee6ae2fec3ad71c777531578f'',@isvalid,@id,@type);', 0, ''),
(99, 0, 'Jul-01-2012 03:46:33', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(100, 0, 'Jul-01-2012 03:46:44', 'call IsValidUser(''a'',''0cc175b9c0f1b6a831c399e269772661'',@isvalid,@id,@type);', 0, ''),
(101, 0, 'Jul-01-2012 03:46:49', 'call IsValidUser(''A'',''8ce4b16b22b58894aa86c421e8759df3'',@isvalid,@id,@type);', 0, ''),
(102, 0, 'Jul-01-2012 03:46:59', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(103, 0, 'Jul-01-2012 03:47:43', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(104, 0, 'Jul-01-2012 04:14:37', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(105, 0, 'Jul-01-2012 04:14:40', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(106, 0, 'Jul-01-2012 04:14:44', 'call IsValidUser(''admin'',''df26179a4bac4e344bfe92b3c1c7a616'',@isvalid,@id,@type);', 0, ''),
(107, 0, 'Jul-01-2012 04:17:35', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(108, 0, 'Jul-01-2012 04:23:20', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(109, 0, 'Jul-01-2012 04:25:22', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(110, 0, 'Jul-01-2012 05:40:52', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(111, 0, 'Jul-01-2012 05:41:03', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(112, 0, 'Jul-11-2012 13:53:54', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(113, 0, 'Jul-11-2012 13:54:47', 'INSERT INTO t_users (user, pass, type) VALUES (''a'', ''0cc175b9c0f1b6a831c399e269772661'', ''Standard'')', 0, ''),
(114, 0, 'Jul-11-2012 13:54:56', 'call IsValidUser(''a'',''0cc175b9c0f1b6a831c399e269772661'',@isvalid,@id,@type);', 0, ''),
(115, 0, 'Jul-11-2012 13:55:16', 'call IsValidUser(''admin'',''eb184cc3e4469723f6afda6b176ebb49'',@isvalid,@id,@type);', 0, ''),
(116, 0, 'Jul-11-2012 13:55:19', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(117, 0, 'Jul-11-2012 17:32:52', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(118, 0, 'Jul-12-2012 03:15:42', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(119, 0, 'Jul-13-2012 03:17:41', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(120, 0, 'Jul-13-2012 03:17:52', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(121, 0, 'Jul-13-2012 03:19:19', 'call IsValidUser(''admin'',''d41d8cd98f00b204e9800998ecf8427e'',@isvalid,@id,@type);', 0, ''),
(122, 0, 'Jul-13-2012 03:19:22', 'call IsValidUser(''admin'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(123, 0, 'Jul-13-2012 03:19:35', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, ''),
(124, 0, 'Jul-15-2012 09:11:50', 'call IsValidUser(''admin'',''d41d8cd98f00b204e9800998ecf8427e'',@isvalid,@id,@type);', 0, ''),
(125, 0, 'Jul-15-2012 09:12:23', 'call IsValidUser(''dariush'',''21232f297a57a5a743894a0e4a801fc3'',@isvalid,@id,@type);', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `t_news`
--

CREATE TABLE IF NOT EXISTS `t_news` (
  `news_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `category` int(10) unsigned NOT NULL,
  `summery` text COLLATE utf8_persian_ci NOT NULL,
  `body` text COLLATE utf8_persian_ci NOT NULL,
  `post_date` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `expire_date` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `post_status` int(11) NOT NULL,
  `pic_address` text COLLATE utf8_persian_ci,
  `tnail_address` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`news_id`),
  UNIQUE KEY `topic` (`topic`),
  KEY `user` (`user_id`),
  KEY `category` (`category`),
  KEY `post_status` (`post_status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `t_news`
--

INSERT INTO `t_news` (`news_id`, `topic`, `user_id`, `category`, `summery`, `body`, `post_date`, `expire_date`, `post_status`, `pic_address`, `tnail_address`) VALUES
(1, 'Symfony2 and HTTP Fundamentals', 8, 56, 'Congratulations! By learning about Symfony2, you''re well on your way towards being a more productive,<br />\r\nwell-rounded and popular web developer (actually, you''re on your own for the last part). Symfony2 is<br />\r\nbuilt to get back to basics: to develop tools that let you develop faster and build more robust applications,<br />\r\nwhile staying out of your way. Symfony is built on the best ideas from many technologies: the tools and<br />\r\nconcepts you''re about to learn represent the efforts of thousands of people, over many years. In other<br />\r\nwords, you''re not just learning "Symfony", you''re learning the fundamentals of the web, development<br />\r\nbest practices, and how to use many amazing new PHP libraries, inside or independent of Symfony2. So,<br />\r\nget ready.<br />\r\nTrue to the Symfony2 philosophy, this chapter begins by explaining the fundamental concept common<br />\r\nto web development: HTTP. Regardless of your background or preferred programming language, this<br />\r\nchapter is a must-read for everyone.', 'Creating the Front Controller<br />\r\nYou''re about to take a big step with the application. With one file handling all requests, you can<br />\r\ncentralize things such as security handling, configuration loading, and routing. In this application,<br />\r\nindex.php must now be smart enough to render the blog post list page or the blog post show page based<br />\r\non the requested URI:<br />\r\nAs a front controller, index.php has taken on an entirely new role, one that includes loading the<br />\r\ncore libraries and routing the application so that one of the two controllers (the list_action() and<br />\r\nshow_action() functions) is called. In reality, the front controller is beginning to look and act a lot like<br />\r\nSymfony2''s mechanism for handling and routing requests.<br />\r\nAnother advantage of a front controller is flexible URLs. Notice that the URL to the blog post show<br />\r\npage could be changed from /show to /read by changing code in only one location. Before, an<br />\r\nentire file needed to be renamed. In Symfony2, URLs are even more flexible.<br />\r\nBy now, the application has evolved from a single PHP file into a structure that is organized and allows<br />\r\nfor code reuse. You should be happier, but far from satisfied. For example, the "routing" system is<br />\r\nfickle, and wouldn''t recognize that the list page (/index.php) should be accessible also via / (if Apache<br />\r\nrewrite rules were added). Also, instead of developing the blog, a lot of time is being spent working on<br />\r\nthe "architecture" of the code (e.g. routing, calling controllers, templates, etc.). More time will need to<br />\r\nbe spent to handle form submissions, input validation, logging and security. Why should you have to<br />\r\nreinvent solutions to all these routine problems?<br />\r\nAdd a Touch of Symfony2<br />\r\nSymfony2 to the rescue. Before actually using Symfony2, you need to make sure PHP knows how to find<br />\r\nthe Symfony2 classes. This is accomplished via an autoloader that Symfony provides. An autoloader is a<br />\r\ntool that makes it possible to start using PHP classes without explicitly including the file containing the<br />\r\nclass.So, even if the user goes to /index.php/show, the application is intelligent enough to route the request<br />\r\nthrough show_action().<br />\r\nThe Response object gives flexibility when constructing the HTTP response, allowing HTTP headers<br />\r\nand content to be added via an object-oriented interface. And while the responses in this application are<br />\r\nsimple, this flexibility will pay dividends as your application grows.<br />\r\nThe Sample Application in Symfony2<br />\r\nThe blog has come a long way, but it still contains a lot of code for such a simple application. Along the<br />\r\nway, we''ve also invented a simple routing system and a method using ob_start() and ob_get_clean()<br />\r\nto render templates. If, for some reason, you needed to continue building this "framework" from scratch,<br />\r\nyou could at least use Symfony''s standalone Routing5 and Templating6 components, which already solve<br />\r\nthese problems.<br />\r\nInstead of re-solving common problems, you can let Symfony2 take care of them for you. Here''s the same<br />\r\nsample application, now built in Symfony2:', '05/24/2012', NULL, 7, 'http://localhost/B-Socialnews/Styles/Images/Uploaded/Original/2b6073eb4598f9a3f480d7809d79b9dfjpg1337813008', 'http://localhost/B-Socialnews/Styles/Images/Uploaded/ThumbNail/e5c5cf9e7ad6fdba643e03e29c43993a1337813008'),
(14, 'Test for new procedure funcionality', 8, 53, 'This is a test.', 'this is a test.', '07/01/2012', NULL, 7, 'http://localhost/B-Socialnews/Styles/Images/Uploaded/Original/e4d138c38b297e1bdf817cc00ef79d94jpg1341089802', 'http://localhost/B-Socialnews/Styles/Images/Uploaded/ThumbNail/abfb8217d83a46b0f4d44910a37147c21341089802');

-- --------------------------------------------------------

--
-- Table structure for table `t_post_status`
--

CREATE TABLE IF NOT EXISTS `t_post_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`status_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `t_post_status`
--

INSERT INTO `t_post_status` (`status_id`, `name`) VALUES
(9, 'Deleted'),
(8, 'Private'),
(7, 'Public');

-- --------------------------------------------------------

--
-- Table structure for table `t_users`
--

CREATE TABLE IF NOT EXISTS `t_users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `pass` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `type` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci ROW_FORMAT=COMPACT AUTO_INCREMENT=37 ;

--
-- Dumping data for table `t_users`
--

INSERT INTO `t_users` (`user_id`, `user`, `pass`, `type`) VALUES
(8, 'dariush', '21232f297a57a5a743894a0e4a801fc3', 'Developer'),
(23, 'Super Admin', '21232f297a57a5a743894a0e4a801fc3', 'SuperAdmin'),
(25, 'Visitor', '21232f297a57a5a743894a0e4a801fc3', 'Visitor'),
(26, 'Standard', '21232f297a57a5a743894a0e4a801fc3', 'Standard'),
(36, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `t_users_comments`
--

CREATE TABLE IF NOT EXISTS `t_users_comments` (
  `comment_id` int(255) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`comment_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_users_comments`
--

INSERT INTO `t_users_comments` (`comment_id`, `user_id`) VALUES
(9, 8),
(10, 8),
(12, 8),
(13, 8),
(9, 36),
(10, 36),
(12, 36);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_admin_users_p`
--
ALTER TABLE `t_admin_users_p`
  ADD CONSTRAINT `t_admin_users_p_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_comments`
--
ALTER TABLE `t_comments`
  ADD CONSTRAINT `t_comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_comments_ibfk_2` FOREIGN KEY (`news_id`) REFERENCES `t_news` (`news_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_cracking`
--
ALTER TABLE `t_cracking`
  ADD CONSTRAINT `t_cracking_ibfk_1` FOREIGN KEY (`log_id`) REFERENCES `t_logs` (`db_log_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_news`
--
ALTER TABLE `t_news`
  ADD CONSTRAINT `t_news_ibfk_1` FOREIGN KEY (`category`) REFERENCES `t_category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_news_ibfk_2` FOREIGN KEY (`post_status`) REFERENCES `t_post_status` (`status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_news_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `t_users_comments`
--
ALTER TABLE `t_users_comments`
  ADD CONSTRAINT `t_users_comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_users_comments_ibfk_2` FOREIGN KEY (`comment_id`) REFERENCES `t_comments` (`comment_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
	include_once '../../Configs/global.conf.php';
	include_once '../../Libs/Redirect.php';
	include_once '../../Configs/Database/database.conf.php';
	include_once '../../Libs/User.php';
	
	global $db_host, $db_user, $db_name, $db_pass;
	
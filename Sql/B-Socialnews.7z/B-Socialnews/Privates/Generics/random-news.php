<?php
	include_once 'includes.inc.php'; 	

	global $db_host, $db_user, $db_name, $db_pass;
	
	$query = "SELECT news_id FROM t_news WHERE post_status=(SELECT status_id FROM t_post_status WHERE name='PublIc')";
	
	mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
	
	mysql_select_db($db_name) or die(mysql_error());
	
	$_res = mysql_log_ExeQuery($query) or die(mysql_error());
	
	$_idz=null;
	
	$i=0;
	
	$row = mysql_fetch_array($_res,MYSQL_NUM);
	
	while(isset($row) && $row!=null){
		
		$_idz[$i++]=$row[0];
		
		$row = mysql_fetch_array($_res,MYSQL_NUM);	
	}
	
	$_res=$_idz;
	
	if(count($_res)!=0):
	
		$lst = array();
		
		mt_srand(make_seed());
			
		for($i=0;$i<count($_res) && $i<5;$i++){
			
			$not_rep=true;
			
			$lst[$i]=$i;
			
			if(count($_res)>5){
				
				$lst[$i]=mt_rand(0, count($_res)-1);
				
				foreach ($lst as $key => $value) {
					if($i!=$key && $value==$lst[$i]){
						$not_rep=false;
						break;
					}
				}
			}
			if($not_rep || count($_res)<=5):
				
				$query = "SELECT * FROM t_news WHERE news_id=".$_res[$lst[$i]];
				
				$res=mysql_log_ExeQuery($query);
				
				$row = mysql_fetch_assoc($res);
				
				while(isset($row) && $row!=null){
					?>
						<div id="news-row-<?php echo $row['id']?>" style="margin-top:10px;">
							<div id="pre-body">
<!--								<span id="news-image-<?php echo $row['id']; ?>" style="padding: 15px!important;float:left">-->
<!--									<img id="news-summery-img" id="image-<?php echo $row['id']; ?>" src="<?php echo $row['tnail_address']?>" width="70px" vspace="20px"/>-->
<!--								</span>-->
								<div id="news-header" style="display:inline">
									<p style="display:inline;">
										<a href="<?php echo BASE_URL.'/Publics/Generics/Show-news.php?t='.$row['topic']?>" id='new-link-<?php echo $row['id']?>' target="__blank"><?php echo $row['topic']?></a>
									</p>
									<!--<p>
										<span style="font-size: small;color:gray;margin-left:10px;">
											Posted by <?php echo $row['user']?> <i>at <?php echo $row['post_date'];?></i>
										</span>
									</p>
								--></div>
								
								<p id="main-summery" style="font-size:small!important;width: 400px;"> 
									<i>
										<?php
											$sum = preg_split('/[.!?]/', substr($row['summery'],0,100));
											if(count($sum)==1){
												echo $sum[0].'...';
											}else{
												$count=count($sum);
												for($j=0; $j<$count-1;$j++)
													echo $sum[$j].'. ';
											}
											echo "<br /><a href='".BASE_URL."/Publics/Generics/Show-news.php?t=".$row['topic']."' target='__blank' >[ Read more ]</a>";
										?>
									</i>
								</p>
							</div>
							<div class="clear"></div>
							<hr style="width: 60%;color:gray;" />
						</div>
					<?php 
					
					$row=mysql_fetch_assoc($res);	
				}
			endif;
		}
	endif;
	
	function make_seed()
	{
	  list($usec, $sec) = explode(' ', microtime());
	  return (float) $sec + ((float) $usec * 100000);
	}
	
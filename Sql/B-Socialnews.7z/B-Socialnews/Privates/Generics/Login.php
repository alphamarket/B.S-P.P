<?php
	include 'includes.inc.php';
	
	session_start();
	
	if(isset($_POST)):
	
		global $db_host, $db_user, $db_pass, $db_name;
		
		$sql=mysql_connect($db_host, $db_user, $db_pass);
		
		mysql_select_db($db_name,$sql);
		
		$un=$_POST['user'];
		$up=md5($_POST['pass']);
		$redir=$_POST['redir'];
		unset($_POST);
		
		/**
		 * 
		 * 
		 * TODO: Do Login things here ...
		 * 
		 * 
		 */
		$query = "call IsValidUser('$un','$up',@isvalid,@id,@type);";
		mysql_log_ExeQuery($query,true) or die(mysql_error());
		$res=mysql_query('SELECT @isvalid,@id,@type;');
		$row = mysql_fetch_assoc($res);
		mysql_query('SET @isvalid=null, @id=null, @type=null') or die(mysql_error()); 
		if($row['@isvalid']){
			$_SESSION['LOGGED'] = true;
			$_SESSION['USER'] = new User($row['@id'],$un, $row['@type']);
			if($redir==BASE_URL.'/Publics/Generics/Login.php')
				$redir=BASE_URL;
			$_SESSION['redir'] = $redir;
			$_SESSION['MSG']='You have logged-in successfully ...!';
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Confirmation.php');
		}
		else{
			/*
			 * LOG AS CRACKER;
			 */
			$date=date('M-d-Y H:i:s');
			
			$ip=$_SERVER['REMOTE_ADDR'];
			
			$log_id=mysql_fetch_array(mysql_log_ExeQuery('SELECT COUNT(*) FROM t_logs')) or die(mysql_error()); 
			
			$log_id=$log_id[0];
			
			$query="INSERT INTO t_cracking SET 
						crack_date='$date',
						ip='$ip',
						log_id='$log_id'";
			
			mysql_log_ExeQuery($query);
			
			unset($_SESSION['LOGGED']);
			$_SESSION['LOGINERR']=true;
			$_SESSION['redir'] = $redir;
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Login.php');
		}
	endif;

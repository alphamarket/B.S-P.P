<?php
	include 'includes.inc.php';
	include  'Join.checkuser.php';
	include '../User/Privileges/Add-user.passinfo.inner.php';
	if(isset($_POST)){
		$redir=$_POST['redir'];
		$user=$_POST['user'];
		$pass=md5($_POST['pass']);
		$confPass=md5($_POST['confpass']);
		$type=$_POST['type'];
		if($pass!=$confPass && strlen($_POST['passinfo'])!=15){
			Redirect::Redirect_URL($redir);
		}
		
		if(isset($_POST['cool']) && $_POST['passinfo']!=''){
			if(Check_PassInfo($_POST['passinfo'], $type,true)==0){
				echo '0&'.'The passinfo is not correct ...';
				print_r($_POST);
				die();
			}
		}
		
		if(UserExists($user)){
			if(isset($_POST['ajax'])){
				echo '0&'.$user.'\'s already exists ...';
				unset($_POST);
				die();
			}
			$_SESSION['redir']=$redir;
			$_SESSION['ERROR']="This user &gt; $user &lt; already exists!";
			unset($_POST);
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Error.php');
		}
		
		$db=mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
		
		mysql_select_db($db_name, $db) or die(mysql_error() . ' Line: 28');
	
		/**
		 * NOW WE HAVE OUR USERNAME AND PASSWORD
		 */
		
		$query="INSERT INTO t_users (user, pass, type) VALUES ('$user', '$pass', '$type')";
		
		mysql_log_ExeQuery($query,true) or die(mysql_error());
		
		mysql_close($db);
		
		if(isset($_POST['mailit']) && $_POST['mailit']==true)
			;/**
			  * Mail the inserted username and password to target email.
			  */
		if(isset($_POST['ajax'])){
				echo '1&'.$user.'\'s registeration completed ...';
				unset($_POST);
				die();
		}
		if(!isset($_POST['invite']))
		{
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Login.php');
		}
		else
		{	
			Redirect::Redirect_URL($redir);
		}
	}
	else;
		//Redirect::Redirect_URL(BASE_URL);
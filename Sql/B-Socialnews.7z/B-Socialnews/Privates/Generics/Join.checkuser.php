<?php
	include 'includes.inc.php';
	
	if(isset($_POST['userAjax']) && $_POST['userAjax']=='1'){
		
		if(UserExists($_POST['user']))
			echo 0;
		else 
			echo 1;
				
	}
	function UserExists($username){
		
		global $db_host, $db_user , $db_name, $db_pass;
		
		$db=mysql_connect($db_host,$db_user, $db_pass);
		
		mysql_select_db($db_name, $db) or die(mysql_error());
		
		$query = "SELECT user from t_users where user='$username'";
		
		$res=mysql_log_ExeQuery($query) or die(mysql_error());
		
		mysql_close();
		
		return mysql_num_rows($res)==1;
	}
<?php
	require_once 'includes.inc.php';
	
	session_start();
	
	if(User::IsLoggedIn()){
		$_SESSION['USER']->Logout();
		unset($_SESSION['USER']);
		$_SESSION['MSG'] = 'You have logged-out successfully.';
		$_SESSION['redir'] = BASE_URL;
		if(!(isset($_POST['ajax']) && $_POST['ajax']==1))
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Confirmation.php');
	}else{
		echo 'was not logged!';
		if(!(isset($_POST['ajax']) && $_POST['ajax']==1))
			Redirect::Redirect_URL(BASE_URL);
	}
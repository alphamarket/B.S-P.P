<?php
	require_once 'includes.inc.php';
		
	if(!isset($_POST) || count($_POST)==0 || !isset($_POST['ajax']) || !isset($_POST['function']))
		die();
		
	switch(strtolower($_POST['function']))
	{
		case 'delete-news':
			delete_news($_POST['nid']);
			break;
		case 'edit-news':
			edit_news($_POST['nid']);
			break;
	}
	return;
	
	function delete_news($news_id)
	{
		imysql_connect();
		
		$query = 'DELETE FROM t_news WHERE news_id='.mysql_escape_string($news_id);
		
		mysql_query($query) or die(mysql_error());
		
		echo '1';
	}
<?php
	include_once 'includes.inc.php';
	
	include_once 'Comment-news.functions.php';
	
	if(!isset($_POST) && !isset($_POST['function']))
		Redirect::Redirect_URL(BASE_URL);
		
	switch (strtolower($_POST['function'])) {
		case 'submit-comment':
			submit_Comment($_POST['c'],$_POST['nid'],$_POST['uid']);
			break;
		
		case 'edit-comment':
			edit_Comment($_POST['cid'],$_POST['newc']);	
			break;
		
		case 'like-comment':
			like_Comment($_POST['cid'],$_POST['uid']);
			break;	

		case 'unlike-comment':
			unlike_Comment($_POST['cid'],$_POST['uid']);
			break;
		case 'delete-comment':
			delete_Comment($_POST['cid'],$_POST['uid']);
			break;
		default:
			echo 'invalid function: [ function = '.$_POST['function'].' ]';
			break;
	}
	
	unset($_POST);
	die();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
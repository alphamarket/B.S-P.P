<hr style="width: 60%" />
<div id="Comment-section">
	<fieldset id="Comment-fieldset">
		<legend><a>Comment section</a></legend>
		<form action="Comment-news.inner.php" method="post" name="Comment-submition">
			<p>
				<textarea class='comment-text' name="comment" rows="3">Enter your comment here.</textarea>
			</p>
			<p id='Comment-status' style="float: right;font-variant:small-caps;color:gray;margin: -5px 13px -10px auto;">
				Hit the <a>Ctrl + Enter</a> to submit your comment.
			</p>
			<div class="clear"></div>
		</form>
	</fieldset>
	<div id="comments-presentation">
		<?php include_once 'Comment-news.refresh.php';?>
	</div>
</div>
<script type="text/javascript">
	<?php 
		//include_once 'Scripts/Comment-news.js';
		global $res;
		if(!isset($_SESSION))
			session_start();
		$user=User::RestoreFromSession();
	?>

	
	var news_topic="<?php echo $_GET['t'] ?>";

	var news_id="<?php echo $_GET['id'] ?>";

	var uid=<?php echo $user->Id?>;
	
	$('div#Comment-section form[name="Comment-submition"] textarea[name="comment"]').blur(function(){
		if(($(this).val()).length==0 || $(this).val()=='Enter your comment here.')
			$(this).val('Enter your comment here.').css('color','gray');
	}).keyup(function($e){
		/**
		 * NOT IMPLEMENTED YET ...
		 */
		 var comment=($(this).val()).trim();
		if($e.ctrlKey && $e.keyCode==Enter_keyCode && comment.lenght!=0){
			$('p#Comment-status').html(Create_Ajax_Loader_Img('Submitting your comment!')+'Submitting your database ...');
			$.ajax({
				url:BASE_URL+'/Privates/User/Commenting/Comment-news.inner.php',
				type:'post',
				data:'function=submit-comment&nid=<?php echo $res["news_id"]?>&uid='+uid+'&c='+comment,
				success:function(data){
					data=data.split('&');
					if(data[0]=='1'){
						$('p#Comment-status').html('Hit the <a>Ctrl + Enter</a> to submit your comment.');
						$('div#Comment-section form[name="Comment-submition"] textarea[name="comment"]').val('').css('color','gray').blur();
						updateComments_List(data);
					}else{
						alert(data);
					}
				}			
			});
		}
	}).click(function(){
		if($(this).val()=='Enter your comment here.')
			$(this).val('').css('color','black');
		else
			$(this).css('color','black');
	}).css('color','gray');
	
	function updateComments_List(data){
		
		$.ajax({
			url: BASE_URL+'/Privates/User/Commenting/Comment-news.refresh.php',
			type:'get',
			data: 't='+news_topic+"&ajax=1&id="+news_id,
			success:function(data){
				$('div#comments-presentation').hide().html(data).fadeIn(300);
				window.setTimeout('removeEditLinks()',1000*20);
			}
		});
	}
	function removeEditLinks(){
		$('a.edit').fadeOut(500);
		window.setTimeout("$('a.edit').remove()",1000);
	}
</script>
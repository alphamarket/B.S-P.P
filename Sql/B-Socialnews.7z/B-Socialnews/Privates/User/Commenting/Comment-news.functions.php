<?php
	function delete_Comment($comment_id,$user_id){
		
		global $db_host, $db_user,$db_pass, $db_name;
		
		$query = "call deleteComment($user_id,$comment_id) -- DELETE FROM t_comments WHERE comment_id=$comment_id AND user_id=$user_id";
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		mysql_log_ExeQuery($query) or die(mysql_error());
		
		echo mysql_affected_rows();
		
		mysql_close();
	}
	
	function submit_Comment($comment,$news_id,$user_id){
		
		global $db_host, $db_user,$db_pass, $db_name;
		
		$_comment=mysql_escape_string(nl2br($comment));
		
		$query="call submitComment($news_id,$user_id,'$_comment') -- INSERT INTO t_comments SET news_id='$news_id', user_id='$user_id',comment='$_comment'";
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		mysql_log_ExeQuery($query) or die(mysql_error());
		
		$res=mysql_log_ExeQuery("SELECT comment_id FROM t_comments WHERE comment='$_comment'");
		
		mysql_close();
		
		$res=mysql_fetch_assoc($res);
		
		echo '1&'.$res['comment_id'].'&'.$comment;
	}
	
	function edit_Comment($comment_id, $new_comment){
		
		global $db_host, $db_user,$db_pass, $db_name;
		
		$query="call editComment($comment_id,'$new_comment') -- UPDATE t_comments SET comment='$new_comment' WHERE comment_id='$comment_id'";
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		mysql_log_ExeQuery($query) or die(mysql_error());
		
		echo mysql_affected_rows();
		
		mysql_close();
		
	}
	
	// status_of_success & likes_count & unlikes_count
	function like_Comment($comment_id,$user_id){
		//submit to likers' list
		
		global $db_host, $db_user,$db_pass, $db_name;
		
		$query = "call LikeComment($comment_id,$user_id) -- INSERT INTO t_users_comments VALUES ( $comment_id, $user_id )";
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		mysql_query($query);
		
		echo '1&'.get_like_count($comment_id);
	}
	
	function is_liked_Before($comment_id,$user_id){

		global $db_host, $db_user,$db_pass, $db_name;
		
		$query="call checkforlike($comment_id,$user_id)";
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		$res = mysql_fetch_assoc(mysql_log_ExeQuery($query)) or die(mysql_error());
			
		mysql_close();
	
		return $res['liked'];
	}
	
	
	function unlike_Comment($comment_id, $user_id){
		global $db_host, $db_user,$db_pass, $db_name;
		
		$query="call UnlikeComment($comment_id, $user_id) -- DELETE FROM t_users_comments WHERE comment_id=".mysql_escape_string($comment_id)." and user_id=".mysql_escape_string($user_id);
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
		
		mysql_log_ExeQuery($query) or die(mysql_error());
			
		mysql_close();
		
		echo '1&'.get_like_count($comment_id);
	}
	
	function get_user_like_count($comment_id, $user_id)
	{
		global $db_host, $db_user,$db_pass, $db_name;
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
	
		$query="call checkforlike($comment_id,$user_id) -- SELECT COUNT(*) as count t_users_comments WHERE comment_id=$comment_id and user_id=$user_id";
		
		$res = mysql_fetch_assoc(mysql_log_ExeQuery($query) or die(mysql_error()));
		
		mysql_close();
		
		return $res['count'];
	}
	
	function get_like_count($comment_id)
	{	
		global $db_host, $db_user,$db_pass, $db_name;
		
		mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		
		mysql_select_db($db_name) or die(mysql_error());
	
		$query="call getlikecount($comment_id) -- SELECT COUNT(*) as count FROM `t_users_comments` WHERE `comment_id`=$comment_id";
		
		$res = mysql_log_ExeQuery($query) or die(mysql_error());
		
		mysql_close();
		
		$res = mysql_fetch_assoc($res);
		
		return $res['count'];
	}

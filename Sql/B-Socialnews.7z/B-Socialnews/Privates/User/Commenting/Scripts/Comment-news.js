/**
 * 
 */

$('a.delete-comment').click(function($e){

	$e.preventDefault();
	
	var id=(($(this).attr('id')).split('-'))[1];

	deleteComment(id);
			
});

$('a.like-comment').click(function($e){

	$e.preventDefault();

	var id=(($(this).attr('id')).split('-'))[1];

	likeComment(id);
});

$('a.unlike-comment').click(function($e){

	$e.preventDefault();

	var id=(($(this).attr('id')).split('-'))[1];

	unlikeComment(id);
	
	//submit the unlikes to the database
});
// fagat emkane 1bar edit farahame choon soe estefade mishe!!
$('a.edit').click(function($e){

	$e.preventDefault();
	
	var id=(($(this).attr('id')).split('-'))[1];

	var val=$('div#main-comment-'+id).html();
	
	val=val.trim();

	$('div#main-comment-'+id).css('border','0px').html('<span style="display:none">'+val+'</span><textarea class="comment-text" style="margin-left:-10px;" id="'+id+'" rows="3"></textarea>');
	$('div.main-comment textarea#'+id).val(val);
	$('div.main-comment textarea#'+id).focus().keyup(function($e){
		if(Is_Character($e)){
			/**
			 * what if the user entered valid character.
			 */
		}
		if($e.ctrlKey && $e.keyCode==Enter_keyCode){
			/**
			 * what if user wants to submit the edition.
			 **/
			 var orig_com = $(this).prev().html();
			 var new_com = $(this).val();
			 
			 if(orig_com!=new_com && new_com.length!=0){
				 
				 $(this).attr('disabled','disabled');
				 
				 //$(this).prev().html(Create_Ajax_Loader_Img('submiting the edition!')+"<span style='margin-left:10px;'>Resubmitting the category ...</span>").css("color","gray").show('medium'); 
				 
				 $.ajax({
					 url:  BASE_URL+'/Privates/User/Commenting/Comment-news.inner.php',
					 type: 'post',
					 data: 'ajax=1&function=edit-comment&cid='+id+'&newc='+new_com,
					 success:function(data){
						 if(data=='1'){					
							 $('div.main-comment textarea#'+id).parent().html(new_com).css('border','1px solid black');
						 }else{
							 alert(data);
						 }
						//$('a#edit-'+id).show('medium');
					 }
				 }); 					         
			 }else{
				 $('div#main-comment-'+id).html(orig_com).css('border','1px solid black');
				 //$('a#edit-'+id).show('medium');
			 }
		}
		else if($e.keyCode==Escape_keyCode){
			/**
			 * restore to last name
			 */
			$(this).parent().html($(this).prev().html()).css('border','1px solid black');
			//$('a#edit-'+id).show('medium');
		}
	});
	$(this).hide('medium');
		
});


function deleteComment(id){

	$('div#single-comment-'+id).fadeOut(300);
	
	//delete from database
	$.ajax({
		url:  BASE_URL+'/Privates/User/Commenting/Comment-news.inner.php',
		type: 'post',
		data: 'function=delete-comment&cid='+id+'&uid='+uid,
		success:function(data){
			if(data=='1'){
				window.setTimeout("$('div#single-comment-'"+id+").remove()",1000);
			}else{
				$('div#single-comment-'+id).fadeIn(300);
				window.setTimeout("alert('Something went wrong please try again')",1000);
			}
		},
		error:function(data,data1,data2){
			$('div#single-comment-'+id).fadeIn(300);
			window.setTimeout("alert('Something went wrong please try again : "+data1+" >> "+data2+"')",1000);
		}
	});
}
	

function likeComment(id){
	$.ajax({
		url: BASE_URL+'/Privates/User/Commenting/Comment-news.inner.php',
		type: 'post',
		data: 'function=like-comment&cid='+id+'&uid='+uid,
		success:function(data){
			data=data.split('&');
			if(data[0]=='1'){
				// TODO: make things work
				$('a#like-'+id).hide().next().fadeIn(400);
				$('span#likes-count-'+id).fadeOut(200).html(data[1]).fadeIn(200);
			}else if(data[0]=='-1'){
				$('a#like-'+id).hide().next().fadeIn(400);
			}else{
				alert(data);
			}
		}
	});
}
function unlikeComment(id){
	$.ajax({
		url: BASE_URL+'/Privates/User/Commenting/Comment-news.inner.php',
		type: 'post',
		data: 'function=unlike-comment&cid='+id+'&uid='+uid,
		success:function(data){
			data=data.split('&');
			if(data[0]=='1'){
				// TODO: make things work
				$('a#unlike-'+id).hide().prev().fadeIn(400);
				$('span#likes-count-'+id).fadeOut(200).html(data[1]).fadeIn(200);
			}else if(data[0]=='-1'){
				$('a#unlike-'+id).hide().prev().fadeIn(400);
			}else{
				alert(data);
			}
		}
	});
}
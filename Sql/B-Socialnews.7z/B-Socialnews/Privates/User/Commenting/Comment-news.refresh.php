<div id='total-comments'>
<?php 
	global $user;
	if(isset($_GET['ajax']))
	{
		include_once 'includes.inc.php';
		session_start();
		$user=User::RestoreFromSession();
	}
	global $user;
	global $db_host, $db_user, $db_pass, $db_name;
	
	$t=mysql_escape_string($_GET['t']);
	
	$id=mysql_escape_string($_GET['id']);
	
	$query="SELECT * 
			FROM 
				t_comments c INNER JOIN t_users u ON
					c.user_id = u.user_id
			WHERE 
				news_id=$id
			order by comment_id desc LIMIT 0,30";
	
	mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
	
	mysql_select_db($db_name) or die(mysql_error());

	$query=mysql_log_ExeQuery($query) or die(mysql_error());
	
	$row = mysql_fetch_assoc($query);
	
	while (isset($row) && $row!=null) :
?>	
		<div class='single-comment' id='single-comment-<?php echo $row['comment_id'];?>'>

			<?php 
				if($user->Id==$row['user_id']):
			?>
				<a href="#" class="delete-comment" id="delete-<?php echo $row['comment_id'];?>"><img alt="delete" src="<?php echo BASE_URL.'/Styles/Images/del.png'?>"></a>
			<?php endif;?>
			<a style="font-size:large;"><?php echo $row['user'].' : '?></a>
			<div class='main-comment' id='main-comment-<?php echo $row['comment_id'];?>'>
				<?php echo $row['comment']?>
			</div>
			<div class="comment-likes">
				<?php 
					if($user->Id==$row['user_id'] && isset($_GET['ajax'])):
						unset($_GET['ajax']);
				?>
					<a href="#" class="edit" id="edit-<?php echo $row['comment_id'];?>">Edit</a>
				<?php endif;?>
				<?php 
					include_once 'Comment-news.functions.php';
					$likes_tag='none';
					$unlikes_tag='none';
					if(!is_liked_Before($row['comment_id'], $user->Id))
					{	
						$likes_tag='nomral';
						
					}else{
						$unlikes_tag='normal';
					}
				?>
					<a style="display:<?php echo $likes_tag?>" href="#" class="like-comment" id="like-<?php echo $row['comment_id'];?>">Like </a>
					<a style="display:<?php echo $unlikes_tag?>" href="#" class="unlike-comment" id="unlike-<?php echo $row['comment_id'];?>">Unlike</a>
					[ <span id="likes-count-<?php echo $row['comment_id'];?>" title="Count of users who like this comment.">
					<?php 
						require_once 'Comment-news.functions.php';
						echo get_like_count($row['comment_id']);
					?>
					</span> ]
			</div>
			<div class="clear"></div>
			<hr style="margin-left:-5px;margin-right:-5px;"/>
		</div>
<?php 
	$row = mysql_fetch_assoc($query);
	endwhile;
?>
</div>
<script type="text/javascript">
	<?php 
		global $res;
		$user=User::RestoreFromSession();
	?>

	$('.single-comment:last hr').remove();
	
	var news_topic="<?php echo $_GET['t'] ?>";
	
	var news_id="<?php echo $_GET['id'] ?>";
	
	var uid=<?php echo $user->Id?>;

	<?php include_once 'Scripts/Comment-news.js';?>
</script>
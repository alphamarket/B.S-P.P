		
<?php 
	include 'includes.inc.php';
	
	global $db_host, $db_user, $db_pass,$db_name;
	
	$db=mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
	
	mysql_select_db($db_name, $db) or die(mysql_error());
	
	$count='SELECT COUNT(*) FROM t_users';
	
	$count=mysql_log_ExeQuery($count);
	
	$res = mysql_fetch_array($count);
	
	$count = $res[0];			

	if($count!=0):
?>
		<hr style="width:60%;margin:20px auto 20px auto;" />
		<div style="margin:10px">
			<a id="open-recently" style="cursor: pointer;">Recently joined users</a>
			<script type="text/javascript">
				$('a#open-recently').click(function(){
					$('center#recently-tabel').show('medium');
					$(this).hide('medium');
					$('span#recent-op-label').html('');
				});
			</script>
			<center id="recently-tabel" style="border:1px solid black;display:none">
				<img id="colapse-recently" alt="Close" src="<?php echo BASE_URL.'/Styles/Images/failure-delete.png';?>" width="20px" height="20px" style="float:right;cursor:pointer;margin:5px;" title="Close section" />
				<script type="text/javascript">
					$('center#recently-tabel img#colapse-recently').click(function(){
						$('center#recently-tabel').hide('medium');
						$('a#open-recently').show('medium');
					});
				</script>
				<div id="recentlyJoin" style="margin:10px;min-width: 40px">
					<?php include 'Add-user.recently-refresh.php'?>
				</div>
				<span id='recent-op-label' style="display:none;margin-left:-50px;text-align: left;" ></span>
			</center>
		</div>
<?php endif;?>
/**
 * 
 */
var lastPassInfo=true;
/**
 * Close gPassInfo field click event
 */
$('fieldset#gpassField img#colpaseGpassField').click(function(){
	$('div#PassInfo_div a#openPassInfo').show('medium');
});
/**
 * Genrate a passinfo code .
 */
$('fieldset#gpassField a#GeneratePassInfo').click(function(){
	$('fieldset#gpassField span#gpassPross').html(Create_Ajax_Loader_Img('Genrating PassInfo!'));
	$('fieldset#gpassField span#gpassSubmit').html('');
	$.ajax({
		url: BASE_URL+'/Privates/User/Privileges/Add-user.passinfo.inner.php',
		type: 'post',
		data: 'ajax=1&function=generate',
		success: function(data){
			$('fieldset#gpassField span#gPassInfo').html(data);
			lastPassInfo=true;
			$('fieldset#gpassField span#gPassOptions').show('medium');
			$('fieldset#gpassField span.gpassSubmit-link').show('fast');
			$('fieldset#gpassField span#gpassPross').html(Create_Ajax_Success_Img('PassInfo generated!'));
		}
	});
});
/**
 * Submit the passinfo code here.
 */
$('fieldset#gpassField a#submitGpass').click(function(){
	if($('fieldset#gpassField span#gPassInfo').text()=='Click generate PassInfo')
	{
		$('fieldset#gpassField span#gpassPross').html('');
		$('fieldset#gpassField span#gpassSubmit').html('');
	}
	if(lastPassInfo){
		
		$('fieldset#gpassField span#gpassSubmit').html(Create_Ajax_Loader_Img('Submiting PassInfo!'));
		
		$.ajax({
			url: BASE_URL+'/Privates/User/Privileges/Add-user.passinfo.inner.php',
			type: 'post',
			data: 'ajax=1&function=gs&type='+$('fieldset#gpassField select#gpassType').val(),
			success: function(data){
				data=data.split('&');
				if(data[0]=='1'){
					$('fieldset#gpassField span#gpassSubmit').html(Create_Ajax_Success_Img('PassInfo generated!')).append("<span style='color:green;margin-left:10px;'>"+data[1]+'</span>');
				}else {
					$('fieldset#gpassField span#gpassSubmit').html(Create_Ajax_Failure_Img('Something wents wrong!'));
					alert(data);
				}
			}
		});
	}else{
		$('fieldset#gpassField span#gpassSubmit').html(Create_Ajax_Failure_Img('This pass info has been submited already!'));
	}
});

/**
 * 
 */
// delete event for categories
$('table#catz-table a.delcat').click(function($e){
	$e.preventDefault();
	$('span#cat-op-label').html(Create_Ajax_Loader_Img('Deleting category!')+"<span style='margin-left:10px;'>Deleting category ...</span>").css("color","gray").show('medium');
	$.ajax({
		utl: $('form#cat-form').attr('action'),
		type: 'post',
		data: 'ajax=1&'+$(this).attr('href'),
		success: function(data){
			var i=data.split('&');
			if(i[0]=='1'){
				
				$('span#cat-op-label').html(Create_Ajax_Success_Img('Submitted successfully!')+'<span style="margin-left:10px;">The category has successfully deleted form database.</span>').css('color','green');
				
				$('table#catz-table tr#ci'+i[1]).hide('slow');			
				$('table#catz-table tr#ci'+i[1]).remove();
				$('table#catz-table tr:even').css('background-color','lightgray');
				$('table#catz-table tr:odd').css('background-color','white');
				upDate_Category_Combo();
			}else{
				alert(data);
				$('span#cat-op-label').html('');
			}
		}
	});
});

// quick edit event for categories
$('table#catz-table a.editcat').click(function($e){
	$e.preventDefault();
	var id=$(this).attr('id').replace('e','i');
	var name=$('table#catz-table label#'+id).html();
	$('table#catz-table td.Cat-name label#'+id).html('<input id="'+id+'" maxlength="255"><span id="cat-qe-'+id+'" style="color:gray;margin-left:10px;font-variant:small-caps">Hit enter to submit the edition.</span></input>');
	$('table#catz-table td.Cat-name input#'+id).val(name).attr('name',name);
	$('table#catz-table td.Cat-name input#'+id).focus().keyup(function($e){
		if(Is_Character($e)){
			/**
			 * what if the user entered valid character.
			 */
		}
		if($e.keyCode==Enter_keyCode){
			/**
			 * what if user wants to submit the edition.
			 **/
			 var orig_name=$(this).attr('name');
			 var new_name=$(this).val();
			 
			 if(orig_name!=new_name && ($(this).val()).length!=0){
				 
				 $(this).attr('disabled','disabled');
				 
				 $(this).next().html(Create_Ajax_Loader_Img('submiting the edition!')+"<span style='margin-left:10px;'>Resubmitting the category ...</span>").css("color","gray").show('medium'); 
				 
				 $.ajax({
					 url:  BASE_URL+'/Privates/User/Privileges/Add-news.inner.php',
					 type: 'post',
					 data: 'ajax=1&function=edit_category&c='+orig_name+'&nv='+new_name,
					 success:function(data){
						 if(data=='1'){					
							 $('table#catz-table td.Cat-name input#'+id).parent().html(new_name);
							 $('table#catz-table a#'+id.replace('i','e')).show('medium');
							 upDate_Category_Combo();
						 }else{
							 $('table#catz-table td.Cat-name span#cat-qe-'+id).html('<span style="color:red;margin-left:10px;font-variant:small-caps">Some failure happened, try some later.</span>');
						 }
						 $('table#catz-table a#'+id.replace('i','e')).show('medium');
					 }
				 }); 					         
			 }else{
				$(this).parent().html($(this).attr('name'));
				 $('table#catz-table a#'+id.replace('i','e')).show('medium');
			 }
		}
		else if($e.keyCode==Escape_keyCode){
			/**
			 * restore to last name
			 */
			$(this).parent().html($(this).attr('name'));
			$('table#catz-table a#'+id.replace('i','e')).show('medium');
		}
	});
	$(this).hide('medium');
});	
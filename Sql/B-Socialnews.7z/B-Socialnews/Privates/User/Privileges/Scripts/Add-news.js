/**
 * 
 */

var cool_topic=false,
	cool_cat=false,
	all_cool=false;

function Is_All_Cool(){
	all_cool=
		cool_topic &&
		($('div.container div.form-container form#Add-news select[name="category"]').val()!='-1')&&
		($('div.container div.form-container form#Add-news select[name="status"]').val()!='-1')&&
		($('div.container div.form-container form#Add-news textarea[name="body"]').val()).length!=0 &&
		($('div.container div.form-container form#Add-news textarea[name="summery"]').val()).lenght!=0;
	return all_cool;
}

function Show_Submit($show){
	switch($show){
		case true:
			$('div.container div.form-container form#Add-news input[type="submit"]').slideDown('fast');
			break;
		case false:
			$('div.container div.form-container form#Add-news input[type="submit"]').slideUp('fast');
			break;
	}
}

$(document).ready(function(){
	$('div.container div.form-container form#Add-news').submit(function($e){
		if(!Is_All_Cool())
			$e.preventDefault();
	});
	$('div.container div.form-container form#Add-news *').keyup(function(){
		Show_Submit(Is_All_Cool());
	});
	// checks if this topic does not exists;
	$('div.container div.form-container form#Add-news input[name="topic"]').blur(function(){
		var topic=$(this).val();
		if(topic.length!=0){
			$(this).next().html(Create_Ajax_Loader_Img('Check for topic existion!'));
			$.ajax({
				url: BASE_URL+'/Privates/User/Privileges/Add-news.inner.php',
				type:'post',
				data: 't='+topic+'&ajax=1&function=check_topic', 
				success:function(data){
					cool_topic=(data=='1');
					if(data=='1'){
						$('#check-news-topic').html(Create_Ajax_Success_Img('Valid topic!'));
					}else{
						$('#check-news-topic').html(Create_Ajax_Failure_Img('Invalid topic or this topic already exists!'));

						if(data!='0'){
							alert(data);
						}
					}
					Show_Submit(Is_All_Cool());
				}						
			});
		}else{
			cool_topic=false;
			Show_Submit(false);
			$('#check-news-topic').html('');
		}
	});	
	// watch category selected property's colors
	$('div.container div.form-container form#Add-news select').change(function(){
		switch ($(this).val()!='-1') {
			case false:
				$(this).css("color","gray");
				break;
			case true:
				$(this).css("color",'black');
				break;
		}
		Show_Submit(Is_All_Cool());
	});
	// reseting vars;
	$('div.container div.form-container form#Add-news input[type="reset"]').click(function(){
		$('div.container div.form-container form#Add-news select').css("color","gray");
		$('#check-news-topic').html('');
		all_cool=false;
		cool_topic=false;
		cool_cat=false;
		all_cool=false;
		Show_Submit(false);
	});
	// blur event on news's body texterea 
	$('div.container div.form-container form#Add-news textarea[name="body"]').blur(function(){
		
		Show_Submit(Is_All_Cool());
	});
	// blur event on news's summery texterea 
	$('div.container div.form-container form#Add-news textarea[name="summery"]').blur(function(){
		
		Show_Submit(Is_All_Cool());
	});
});
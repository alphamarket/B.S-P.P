/**
 * used in >> ./Publics/User/Privileges/status-refresh.php << page.
 */

function upDate_Status_Combo(){
	$.ajax({
		utl: $('form#stu-form').attr('action'),
		type: 'post',
		data: 'ajax=1&function=update-status-combo',
		success: function(data){
			$('div.form-container form#Add-news select[name="status"]').html(data);
		}
	});
}

$('div.container a#Orginize-Status').click(function(){
	$('div.container div#Stu-Section').show('medium');
	$(this).hide('medium');
});

$('div.container div#Stu-Section img#colapse-stu-section').click(function(){
	$('div.container div#Stu-Section').hide('medium');
	$('div.container a#Orginize-Status').show('medium');
});

$('div.container form#stu-form').submit(function($e){
	$e.preventDefault();
	var text=$('div.container form#stu-form input[name="stu"]').val();
	if(text.length!=0){
		$('#stu-submit-res').html(Create_Ajax_Loader_Img('Submitting to database!')+"<span style='margin-left:10px;'>submitting to database.</span>").css("color","gray");
		$.ajax({
			url: $('div.container form#cat-form').attr('action'),
			type: 'post',
			data: 'ajax=1&function=submit_status&c='+text,
			success: function(data){
				$('div.container form#cat-form input[name="stu"]').val('');
				$('#check-stu').html('');
				if(data=='1')
				{
					$('#stu-submit-res').html(Create_Ajax_Success_Img('Submitted successfully!')+'<span style="margin-left:10px;">The status submitted into databse successfully.</span>').css('color','green');
					/**
					 *	Enter the >> text << into ajax list!
					 **/	
					 refreshStatus(text);
					 upDate_Status_Combo();
					 $('div.container form#stu-form input[name="stu"]').val('');
				}
				else if(data=='-1'){
					$('#cat-submit-res').html(Create_Ajax_Failure_Img('Invalid status or this status already exists!')+'<span style="margin-left:10px;font-variant:small-caps">This status has been defined already.</span>').css('color','red');
				}
				else
				{
					$('#cat-submit-res').html(Create_Ajax_Failure_Img('Failure in submission!')+'<span style="margin-left:10px;font-variant:small-caps">A failure happened in order to save status into databse.</span>').css('color','red');
					alert(data);
				}
			}
		});
	}
});
function refreshStatus($cat){
	$('span#stu-q-refresh').html(Create_Ajax_Loader_Img('Refreshing status table!')+"<span style='margin-left:10px;'>Laoding from database.</span>").css("color","gray");
	$.ajax({
		url: BASE_URL+'/Privates/User/Privileges/Add-news.status-refresh.php',
		type: 'post',
		data: 'refresh=1',
		success: function(data){
			$('span#stu-q-refresh').hide('fast');
			$('span#stu-q-refresh').html(data).css('color','black');
			$('span#stu-q-refresh').show('fast');
		}
	});
}
/**
 * used in >> ./Publics/User/Privileges/categories-refresh.php << page.
 */



function upDate_Category_Combo(){
	$.ajax({
		utl: $('form#cat-form').attr('action'),
		type: 'post',
		data: 'ajax=1&function=update-category-combo',
		success: function(data){
			$('div.form-container form#Add-news select[name="category"]').html(data);
		}
	});
}

$('div.container a#Orginize-Categories').click(function(){
	$('div.container div#Cat-Section').show('medium');
	$(this).hide('medium');
});

$('div.container div#Cat-Section img#colapse-cat-section').click(function(){
	$('div.container div#Cat-Section').hide('medium');
	$('div.container a#Orginize-Categories').show('medium');
});

$('div.container form#cat-form').submit(function($e){
	$e.preventDefault();
	var text=$('div.container form#cat-form input[name="cat"]').val();
	if(text.length!=0){
		$('#cat-submit-res').html(Create_Ajax_Loader_Img('Submitting to database!')+"<span style='margin-left:10px;'>submitting to database.</span>").css("color","gray");
		$.ajax({
			url: $('div.container form#cat-form').attr('action'),
			type: 'post',
			data: 'ajax=1&function=submit_category&c='+text,
			success: function(data){
				$('div.container form#cat-form input[name="cat"]').val('');
				$('#check-cat').html('');
				if(data=='1')
				{
					$('#cat-submit-res').html(Create_Ajax_Success_Img('Submitted successfully!')+'<span style="margin-left:10px;">The category submitted into databse successfully.</span>').css('color','green');
					/**
					 *	Enter the >> text << into ajax list!
					 **/	
					 refreshCategories(text);
					 upDate_Category_Combo();
					 $('div.container form#cat-form input[name="cat"]').val('');
				}
				else if(data=='-1'){
					$('#cat-submit-res').html(Create_Ajax_Failure_Img('Invalid category or this category already exists!')+'<span style="margin-left:10px;font-variant:small-caps">This category has been defined already.</span>').css('color','red');
				}
				else
				{
					$('#cat-submit-res').html(Create_Ajax_Failure_Img('Failure in submission!')+'<span style="margin-left:10px;font-variant:small-caps">A failure happened in order to save category into databse.</span>').css('color','red');
					alert(data);
				}
			}
		});
	}
});

function refreshCategories($cat){
	$('span#cat-q-refresh').html(Create_Ajax_Loader_Img('Refreshing categories table!')+"<span style='margin-left:10px;'>Laoding from database.</span>").css("color","gray");
	$.ajax({
		url: BASE_URL+'/Privates/User/Privileges/Add-news.categories-refresh.php',
		type: 'post',
		data: 'refresh=1',
		success: function(data){
			$('span#cat-q-refresh').hide('fast');
			$('span#cat-q-refresh').html(data).css('color','black');
			$('span#cat-q-refresh').show('fast');
		}
	});
}
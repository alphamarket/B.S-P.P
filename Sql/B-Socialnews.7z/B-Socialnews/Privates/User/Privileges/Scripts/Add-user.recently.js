/**
 * 
 */
$('table#recent-users a.deluser').click(function($e){
	$e.preventDefault();
	
	$('span#recent-op-label').html(Create_Ajax_Loader_Img('Deleting user')+"<span style='margin-left:10px;'>Deleting user ...</span>").css("color","gray").show('medium');
	
	$.ajax({
		url: BASE_URL+'/Privates/User/Privileges/Deleted-user.php',
		type: 'post',
		data: 'ajax=1&'+$(this).attr('href'),
		success: function(data){
			var i=data.split('&');
			if(i[0]=='1'){
				$('span#recent-op-label').html(Create_Ajax_Success_Img('The user deleted successfully.')+'<span style="margin-left:10px;">The user has successfully deleted form database.</span>').css('color','green');
				
				$('table#recent-users tr#ui'+i[1]).hide('medium').remove();
				$('table#recent-users tr:odd:not(#t-head)').css('background-color','white');
				$('table#recent-users tr:even').css('background-color','lightgray');
			}else {
				alert('something wents wrong!'+data);
				$('span#recent-op-label').html('');
			}
		}
	});
});

$('table#recent-users a.edituser').click(function($e){
	//$e.preventDefault();
	//alert("Does not implemented yet ...");
	return;

	
	
	$.ajax({
		url: BASE_URL+'/Privates/del-user.php',
		type: 'post',
		data: 'ajax=1&'+$(this).attr('href'),
		success: function(data){
			var i=data.split('&');
			if(i[0]=='1'){
				$('table#recent-users tr#'+i[1]).hide();
			}else {
				alert('something wents wrong!');
				alert(data);
			}
		}
	});
});
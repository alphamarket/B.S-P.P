<?php
	require_once 'includes.inc.php';
	session_start();
	if(isset($_POST) && isset($_POST['ajax']) && isset($_POST['function']))
	{
		switch(strtolower($_POST['function'])){
			case 'generate':
				if(!User::IsLoggedIn() && isset($_SESSION['USER']) && $_SESSION['USER']->Type!='SuperAdmin')
					Redirect::Redirect_URL(BASE_URL);
				unset($_POST);
				echo Generate_PassInfo();
				return;
			case 'check':
				$res = Check_PassInfo($_POST['passinfo'],$_POST['type'],(isset($_POST['del']) && $_POST['del']=='1'));
				unset($_POST);
				echo $res;
				return ;
			case 'submit':
				$res = Submit_PassInfo($_POST['passinfo'],$_POST['type']);
				unset($_POST);
				echo $res;
				return;
			case 'gs':
				$res = GenerateAndSubmitPI($_POST['type']);
				unset($_POST);
				echo $res;
				return;
			default:
				die('<strong style="color:red;margin:300px auto;">WRONG FUNCTION NAMED : '.$_POST['function'].'</strong>');
		}
		return;
	}
	
	/**
	 * Generate unique Add-user.passinfo.inner
	 */
	function Generate_PassInfo(){
		/**
		 * FIXME: code some algorithm to generate automatic PassInfo code here.
		 */
		$gen=1;
		$gpass='';
		while($gen){
			$gpass=substr(md5(rand(-10000000, +10000000)),0,15);
			//Comment last sql query string for prevent to check the type requirment.
			$gen=Check_PassInfo($gpass.'-- ', 'non-req');
		}
		//die('NOT IMPLEMENTED FUNCTION : Generate_PassInfo()');
		return $gpass;
	}
	
	function Submit_PassInfo($passinfo, $type){
		
		global $db_host, $db_user, $db_pass, $db_name;
		
		$user=User::Serialize($_SESSION['USER']);
		$date=date('Y-m-d');
		$db=mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
		
		mysql_select_db($db_name,$db);
		
		$query="INSERT INTO t_admin_users_p VALUES ( $passinfo , $type, $user->Id, $date , null )";//Call generatePassinfo('$user->Id', '$type', 'null')";
		
		mysql_log_ExeQuery($query) or die(mysql_error());
		
		return 1;
	}
	
	function GenerateAndSubmitPI($type)
	{
		global $db_host, $db_user, $db_pass, $db_name;
		
		$user=User::Serialize($_SESSION['USER']);
		$db = mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
		mysql_select_db($db_name,$db) or die(mysql_error());
		$query = "call generatePassinfo($user->Id,'admin',null )";
		$res = mysql_query($query) or die(mysql_error());
		$res=mysql_fetch_array($res,MYSQL_NUM) or die('error');
		mysql_close();
		return '1&'.$res[0];
	}

	/**
	 * 
	 * Checks if passed $Add-user.passinfo.inner is already exists in database or not
	 * @param String $Add-user.passinfo.inner target $Add-user.passinfo.inner
	 * @param String $delete_on_exists_from_db Delete the passed $Add-user.passinfo.inner from database
     * @return true if exists; otherwise false
	 */
	function Check_PassInfo($passinfo, $type, $delete_on_exists_from_db=FALSE){
		global $db_host, $db_user, $db_pass, $db_name;
		
		$db=mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
		
		mysql_select_db($db_name,$db);
		
		$query="SELECT * FROM t_admin_users_p WHERE pass='$passinfo' and type='$type'";
		
		$res=mysql_log_ExeQuery($query) or die(mysql_error());
		
		if(mysql_num_rows($res)==0)
			return 0;
		
		if(mysql_num_rows($res)==1){
				/**
			 	 *	DELETE IF DEMANDED FROM DATABASE  HERE
			 	 */
				if($delete_on_exists_from_db){
					$query = "DELETE FROM t_admin_users_p WHERE pass='".$_POST['Add-user.passinfo.inner']."' and type='".$_POST['type']."'";
					$res=mysql_log_ExeQuery($query) or die(mysql_error());
				}
				return 1;
		}
		else 
			return 0;
	}
	

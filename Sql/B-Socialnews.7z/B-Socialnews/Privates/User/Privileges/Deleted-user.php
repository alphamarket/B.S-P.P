<?php
	include 'includes.inc.php';
	if(isset($_POST)){
		
		global $db_host, $db_user, $db_pass, $db_name;
		
		$db=mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
		
		mysql_select_db($db_name, $db) or die(mysql_error());
		
		$query="delete from t_users where user_id='".$_POST['id']."' AND type='".$_POST['type']."'";
		
		mysql_log_ExeQuery($query) or die(mysql_error());
		
		echo '1&'.$_POST['id'];
		
		unset($_POST);
	}else{
		Redirect::Redirect_URL(BASE_URL);
	}
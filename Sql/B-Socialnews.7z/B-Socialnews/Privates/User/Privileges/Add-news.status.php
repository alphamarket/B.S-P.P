	<hr style="width: 60%;color:gray;" />
	<a id="Orginize-Status" style="margin:10px;cursor: pointer;">Orginize statuses</a>
	
	<div class="form-container" style="display:none;" id="Stu-Section">
		<img id="colapse-stu-section" alt="Close" src="<?php echo BASE_URL.'/Styles/Images/failure-delete.png';?>" width="20px" height="20px" style="float:right;cursor:pointer;margin:0px;" title="Close section" />
		<span id='stu-q-refresh'>
			<?php include '../../../Privates/User/Privileges/Add-news.status-refresh.php'; ?>
		</span>
		
		<form id="stu-form" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
			<p>
				<label>Enter new status : </label>
				<input type="text" name="stu" maxlength="50" />
				<span id="check-stu" style="float:right;margin:3px 5px -5px 5px;"><!-- Ajax check if this topic exist in database or not --></span>
			</p>
			<p>
				<span id="stu-submit-res" style="float:right!important;color:gray;font-variant:small-caps;">Hit enter to submit to database.</span>
				<input type="submit" name="submit-stu" value="Submit" style="visibility: collapse;">
			</p>
			<div class="clear"></div>
		</form>
		<div class="clear"></div>
	</div>
	<div class="clear" style="margin:10px;"></div>
	
	<script type="text/javascript">
		<?php include_once '../../../Privates/User/Privileges/Scripts/Add-news.status.js'?>
	</script>
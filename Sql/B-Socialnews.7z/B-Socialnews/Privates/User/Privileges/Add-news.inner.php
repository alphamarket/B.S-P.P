<?php
	require_once 'includes.inc.php';	
	session_start();
	$user=User::RestoreFromSession();
	if(!User::IsLoggedIn() || $_SESSION['USER']->User_Type=='Standard' || $_SESSION['USER']->User_Type=='Visitor')
		Redirect::Redirect_URL(BASE_URL);
	function Exit_Post(){
		unset($_POST);
		die();
	}
	if(isset($_POST))
	{

		if(isset($_POST['submit']))
		{
			include_once 'Add-news.submit-news.php';
			
			Exit_Post();
		}
		else if(isset($_POST['ajax']))
		{
			if(isset($_POST['function'])){
				
				switch (strtolower($_POST['function']))
				{
				 	case 'check_topic':
				 		Ajax_Check_Topic();
				 		break;
				 		
					case 'check_category':
						Ajax_Check_Category('t_category');
						break;
					case 'submit_category':
						Ajax_Submit_Category('t_category');
						break;
					case 'delete_category':
						Ajax_Delete_Category('t_category');
						break;
					case 'edit_category':
						Ajax_Edit_Category('t_category');
						break;
					case 'update-category-combo':
						Ajax_Update_Category_Combo('t_category');
						break;
						
					case 'check_status':
						Ajax_Check_Category('t_post_status');
						break;
					case 'submit_status':
						Ajax_Submit_Category('t_post_status');
						break;
					case 'delete_status':
						Ajax_Delete_Category('t_post_status');
						break;
					case 'edit_status':
						Ajax_Edit_Category('t_post_status');
						break;
					case 'update-status-combo':
						Ajax_Update_Category_Combo('t_post_status');
						break;
						
					default:
						echo 'function does not set properly!';
				}
				Exit_Post();
			}else{
				echo 'function does not setted!';
				Exit_Post();
			}
		}
	}
	
	function Ajax_Update_Category_Combo($table){
	
		global $db_host, $db_user,$db_pass, $db_name;
		
		$table_id = str_replace(array('t_post_','t_'), array(''), $table)."_id";
		
		mysql_connect($db_host, $db_user,$db_pass) or die(mysql_error());

		mysql_select_db($db_name) or die('28 '.mysql_error());
	
		$query="SELECT * FROM $table order by $table_id desc";
		
		$query=mysql_log_ExeQuery($query) or die(Create_Error_String('Unable to load categories', mysql_error()));

		$odd=false;
		
		$row = mysql_fetch_assoc($query, MYSQL_ASSOC);
		
		echo "<option value='-1'>Select an option</option>";
		
		while (isset($row) && $row!=null){
			
			echo "<option value='".$row["$table_id"]."'>".$row['name']."</option>";
			
			$row = mysql_fetch_assoc($query, MYSQL_ASSOC);
		}
	}
	
	function Ajax_Edit_Category($table){
		global $db_host, $db_name, $db_user, $db_pass;
		
		$c=Entery_Security::Security_Push($_POST['c']);
		
		$nv=Entery_Security::Security_Push($_POST['nv']);
		
		mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String(mysql_error()));
		
		mysql_select_db($db_name) or die(Create_Error_String(mysql_error()));
		
		mysql_log_ExeQuery("UPDATE $table SET name='$nv' WHERE name='$c'") or die(mysql_error());
		
		echo '1';
	}
	
	function Ajax_Delete_Category($table){
		global $db_host, $db_name, $db_user, $db_pass;
		
		$id=mysql_escape_string($_POST['id']);
		
		$table_id = str_replace(array('t_post_','t_'), array(''), $table)."_id";
		
		mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String(mysql_error()));
		
		mysql_select_db($db_name) or die(Create_Error_String(mysql_error()));
		
		mysql_log_ExeQuery("DELETE FROM $table WHERE $table_id='$id'") or die(mysql_error());
		
		echo '1&'.$id;
	}
	
	function Ajax_Submit_Category($table){
		if(Ajax_Check_Category($table)){
			
			global $db_host, $db_name, $db_user, $db_pass;
			
			$c=Entery_Security::Security_Push($_POST['c']);
			
			mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String(mysql_error()));
			
			mysql_select_db($db_name) or die(Create_Error_String(mysql_error()));
			
			$query="INSERT INTO $table SET name='$c'";
			
			mysql_log_ExeQuery($query) or die(Create_Error_String('Query error : ', mysql_error()));
			
			echo '1';
		}else{
			echo '-1';
		}
	}
	
	function Ajax_Check_Category($table){
		
		global $db_host, $db_name, $db_user, $db_pass;
		
		$c=Entery_Security::Security_Push($_POST['c']);
		
		mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String(mysql_error()));
		
		mysql_select_db($db_name) or die(Create_Error_String(mysql_error()));
		
		$query="SELECT COUNT(*) FROM $table WHERE name='$c.'";
		
		$res=mysql_log_ExeQuery($query) or die(Create_Error_String("Fail ajax checker : ",mysql_error()));
		
		$res=mysql_fetch_array($res,MYSQL_NUM);
		
		if($res[0]==0)
			return 1;
		else 
			return 0;
	}
	
	function Ajax_Check_Topic(){
		global $db_host, $db_name, $db_user, $db_pass;
		
		$t=Entery_Security::Security_Push($_POST['t']);
		
		mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String(mysql_error()));
		
		mysql_select_db($db_name) or die(Create_Error_String(mysql_error()));
		
		$query='SELECT COUNT(topic) FROM t_news WHERE topic="'.$t.'"';
		
		$res=mysql_log_ExeQuery($query) or die(Create_Error_String("Fail ajax checker : ",mysql_error()));
	
		$res=mysql_fetch_array($res,MYSQL_NUM);
		
		if($res[0]!=0){
			echo 0;
			
			Exit_Post();
		}
goto RET;
		// check if topic contains a filtered keyword!?
		foreach (explode(' ', $t) as $value){
			if(strlen($value)!=0){
				$query="SELECT COUNT(filter_id) FROM t_news_filtering WHERE key_word='$value'";
				
				$res = mysql_log_ExeQuery($query)or die(Create_Error_String("Fail ajax checker : ",mysql_error()));
				
				$res = mysql_fetch_array($res,MYSQL_NUM);
				
				if($res[0]!=0){
					echo 0;
					
					Exit_Post();
				}
			}
		}
RET:
		// return 1 if there is no this topic
		echo 1;
	}
	

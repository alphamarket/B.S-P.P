
	<hr style="width: 60%;color:gray;" />
	<a id="Orginize-Categories" style="margin:10px;cursor: pointer;">Orginize categories</a>
	
	<div class="form-container" style="display:none;" id="Cat-Section">
		<img id="colapse-cat-section" alt="Close" src="<?php echo BASE_URL.'/Styles/Images/failure-delete.png';?>" width="20px" height="20px" style="float:right;cursor:pointer;margin:0px;" title="Close section" />
		<span id='cat-q-refresh'>
			<?php include '../../../Privates/User/Privileges/Add-news.categories-refresh.php'; ?>
		</span>
		
		<form id="cat-form" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
			<p>
				<label>Enter new category : </label>
				<input type="text" name="cat" maxlength="50" />
				<span id="check-cat" style="float:right;margin:3px 5px -5px 5px;"><!-- Ajax check if this topic exist in database or not --></span>
			</p>
			<p>
				<span id="cat-submit-res" style="float:right!important;color:gray;font-variant:small-caps;">Hit enter to submit to database.</span>
				<input type="submit" name="submit-cat" value="Submit" style="visibility: collapse;">
			</p>
			<div class="clear"></div>
		</form>
		<div class="clear"></div>
	</div>
	<div class="clear" style="margin:10px;"></div>
	
	<script type="text/javascript">
		<?php include_once '../../../Privates/User/Privileges/Scripts/Add-news.category.js';?>
	</script>
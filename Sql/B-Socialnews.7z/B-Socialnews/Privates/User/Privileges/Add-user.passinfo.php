			<div id="PassInfo_div" style="margin-top:10px;margin-left: 10px;">
				<a id="openPassInfo" style="cursor:pointer">Generate Pass Info</a>
				<script type="text/javascript">
					$('div#PassInfo_div a#openPassInfo').click(function(){
						$('fieldset#gpassField').show('medium');
						$(this).hide('medium');
					});
				</script>			
				<fieldset id='gpassField' style="border:1px solid black;">	
					<span id='_gPassOptions' >
						<span class='float-left'>
							<label>Generate PassInfo for</label>
							<select name='type' id='gpassType' style="width: 150px;margin-left:0px;">
								<option value="SuperAdmin">SuperAdmin</option>
								<option value="Admin" selected="selected">Admin</option>
								<option value="Developer">Developer</option>
							</select>
							<label> and </label>
							<span class='action-link gpassSubmit-link' style="margin-left:0px;">
								<a id="submitGpass"style="cursor:pointer;">Submit</a>
								<span id="gpassSubmit" style="margin:10px;"></span>
							</span>
						</span>
						<!-- FIXME: Create a code here to pickup expire date here! -->	
						<p>	
					</span>
					<br />
				</fieldset>
			</div>
			<script type="text/javascript">
				<?php include_once 'Scripts/Add-user.passinfo.js';?>
			</script>

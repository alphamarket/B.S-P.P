<?php		
			require_once 'includes.inc.php';
			
			global $user;
			
			if(isset($_POST) && isset($_POST['refresh'])){
				session_start();
				$user=User::RestoreFromSession();
			}
			
			mysql_connect($db_host, $db_user,$db_pass) or die(mysql_error());
	
			mysql_select_db($db_name) or die(mysql_error());
			
			$query='SELECT COUNT(*) FROM t_post_status';
			
			$query=mysql_log_ExeQuery($query);
			
			$query=mysql_fetch_array($query,MYSQL_NUM);
			
			if($query[0]!=0):
		?>
		<table border="0px" cellspacing="0px" id="stuz-table" width="700px" style="margin:10px;border:1px solid black;background-color:lightgray">
			<thead>
				<tr>
					<th>Category</th>
					<th style="text-align:center;">Operation</th>
				</tr>
			</thead>
			<tbody>
			<?php 
				
			
				mysql_connect($db_host, $db_user,$db_pass) or die(mysql_error());
		
				mysql_select_db($db_name) or die('28 '.mysql_error());
			
				$query='SELECT * FROM t_post_status order by status_id desc';
				
				$query=mysql_log_ExeQuery($query) or die(Create_Error_String('Unable to load status', mysql_error()));

				$odd=false;
				
				$row = mysql_fetch_assoc($query, MYSQL_ASSOC);
				
				while (isset($row) && $row!=null){
					?>
						<tr style="background-color: <?php if(!$odd) echo 'white';else echo 'lightgray';?>" id="si<?php echo $row['status_id'] ?>">
							<td class='Stu-name'>
								<label id='si<?php echo $row['status_id']?>'><?php echo Entery_Security::Security_Pop($row['name']);?></label>
							</td>
							<?php
								$modiratable= ($user->User_Type!="Standard" && $user->User_Type!="Visitor" && $user->User_Type!='Admin');
								if($modiratable):
							?>
								<td style="text-align: center;">
									[ <a class="delstu" id="sd<?php echo $row['status_id'] ?>" href="<?php echo "id=".$row['status_id']."&function=delete_status"; ?>">Delete</a> ]
									&nbsp;
									[ <a class="editstu" id="se<?php echo $row['status_id'] ?>"  href="<?php echo "id=".$row['status_id']."&function=edit_status"; ?>">Edit</a> ]
								</td>
							<?php endif;?>
							
						</tr>
					<?php 
					$odd=!$odd;
					
					$row = mysql_fetch_assoc($query, MYSQL_ASSOC);
				}
			?>
			</tbody>
		</table>
		<script type="text/javascript">
			<?php include 'Scripts/Add-news.status-refresh.js'?>
		</script>
		<span id='stu-op-label' style="display:none;margin:10px;" ></span>
		<hr style="margin:10px auto 10px auto;width:60%" />
		<?php endif;?>
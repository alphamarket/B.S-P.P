<?php
if(isset($_POST) && isset($_FILES)):
				unset($_POST['submit']);
		
			// create a thumbnail and retrun the created thumbnail address.
			function createThumbNail($original){

				list($width,$height,$type) = getimagesize($original);
		
				$limit=100;
		
				if($width<$limit && $height<$limit) 
					$ratio = 1;
				elseif($width>$height) 
					$ratio = $limit/$width;
				else 
					$ratio = $limit/$height;
		
				$imagetypes = array('/\.gif$/','/\.jpg$/','/\.jpeg$/','/\.png$/');
		
				$name = preg_replace($imagetypes,'',basename($original));
		
				switch($type){
				    case 1:
					$source = @imagecreatefromgif($original);
					break;
				    case 2:
					$source = @imagecreatefromjpeg($original);
					break;
				    case 3:
					$source = @imagecreatefrompng($original);
					break;
				    default:
					$source = null;
				}
		
				$thumb_width = round($width*$ratio);
		
				$thumb_height = round($height*$ratio);
		
				$thumb = imagecreatetruecolor($thumb_width,$thumb_height);
		
				imagecopyresampled($thumb,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
		
				switch($type){
				    case 1:
					if(function_exists('imagegif')){
					    $thumb_name = '../../../Styles/Images/Uploaded/ThumbNail/'.md5($name).time();
					    $success = imagegif($thumb,$thumb_name);
					}
					else{
					    $thumb_name = '../../../Styles/Images/Uploaded/ThumbNail/'.md5($name).time();
					    $success = imagejpeg($thumb,$thumb_name,50);
					}
					break;
				    case 2:
					$thumb_name = '../../../Styles/Images/Uploaded/ThumbNail/'.md5($name).time();
					$success = imagejpeg($thumb,$thumb_name,100);
					break;
				    case 3:
					$thumb_name = '../../../Styles/Images/Uploaded/ThumbNail/'.md5($name).time();
					$success = imagepng($thumb,$thumb_name);
				}
		
				imagedestroy($source);
		
				imagedestroy($thumb);
		
				return BASE_URL.'/Styles/Images/Uploaded/ThumbNail/'.md5($name).time();
			    }
//die(print_r($_POST));
			$uploaded_image = $_FILES['tnail']['tmp_name'];
		
			$parted=explode('.',$_FILES['tnail']['name']);
		
			$type=$parted[count($parted)-1];
		
			$file_name=md5($_FILES['tnail']['name'])."$type";
		
			$orig_address = BASE_URL.'/Styles/Images/Uploaded/Original/'.$file_name.time();  
		
			// create a ThumbNail of picture here and put that in this directory >> '../../../Styles/Images/Uploaded/ThumbNail/'.$file_name <<
			$tnail=createThumbNail($uploaded_image);
		
			move_uploaded_file($uploaded_image, '../../../Styles/Images/Uploaded/Original/'.$file_name.time());    
		
			$topic=mysql_escape_string($_POST['topic']);
		
			$cat=mysql_escape_string($_POST['category']);
		
			$body=mysql_escape_string(nl2br($_POST['body']));
		
			$summery=mysql_escape_string(nl2br($_POST['summery']));
			
			$status=$_POST['status'];
		
			$query="call addnews('$topic',$user->Id,$cat,'$summery','$body','".date('m/d/Y')."','$status','$orig_address','$tnail')";
		
			global $db_host, $db_user,$db_pass, $db_name;
		
			mysql_connect($db_host, $db_user,$db_pass) or die(Create_Error_String('', mysql_error()));
		
			mysql_select_db($db_name);
		
			mysql_log_ExeQuery($query) or die(Create_Error_String('', mysql_error()));
		
			$res=mysql_log_ExeQuery("SELECT news_id FROM t_news WHERE topic='$topic'");
		
			$res=mysql_fetch_assoc($res);
		
			unset($_FILES);
		
			unset($_POST);
		
			session_start();
		
			$_SESSION['MSG'] = 'Your post successfully submitted ...';
		
			$_SESSION['redir'] = BASE_URL.'/Publics/Generics/Show-news.php?t='.urlencode($topic).'&id='.$res['news_id'];
		
			Redirect::Redirect_URL(BASE_URL.'/Publics/Generics/Confirmation.php');
		
			return;
		
			endif;

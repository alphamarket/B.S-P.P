<table border="0px" cellspacing="0px" id="recent-users">
	<thead style="border-bottom:1px solid black;">
		<tr style="background-color:lightgray">
			<th>User Name</th>
			<th>User Type</th>
			<th>Operations</th>
		</tr>
	</thead>
	<tbody>
	<?php 
				
				global $count,$user;
				
				if(isset($_POST) && isset($_POST['ajax']))
				{
					include 'includes.inc.php';
					
					include_once '../../../Libs/User.php';
					
					session_start();
					
					$user=User::RestoreFromSession();
					
					unset($_POST);
					
					global $db_host, $db_user, $db_pass,$db_name;
	
					mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
					
					mysql_select_db($db_name) or die(mysql_error());
					
					$count='SELECT COUNT(*) FROM t_users';
					
					$count=mysql_log_ExeQuery($count);
					
					$res = mysql_fetch_array($count);
					
					$count = $res[0];
				}
				
				$query="SELECT * FROM t_users order by user_id desc LIMIT ";
				
				if($count<30)
					$query=$query."0 , $count";
				else
					$query=$query.($count-30)." , $count";
				
				$query=mysql_log_ExeQuery($query) or die(mysql_error());
				
				$odd=false;

				$row = mysql_fetch_assoc($query, MYSQL_ASSOC);
				
				while (isset($row) && $row!=null){
					?>
						<tr style="background-color: <?php if(!$odd) echo 'white';else echo 'lightgray';?>" id="ui<?php echo $row['user_id'] ?>">
							<td>
								<?php echo $row['user'];?>
							</td>
							<td>
								<?php echo $row['type'];?>
							</td>
							<?php $modiratable= ($user->User_Type=="SuperAdmin");?>
							<td style="text-align: center;">
								<?php if($modiratable || $user->Id==$row['user_id']):?>
									[ <a class="deluser" href="<?php echo "id=".$row['user_id']."&type=".$row['type']; ?>">Delete</a> ]&nbsp;
								<?php endif;if($row['user']==$user->Name):?>
									[ <a class="edituser" href="<?php echo "../Generics/Edit-user.php?id=".$row['user_id']."&type=".$row['type'];?>">Edit</a> ]
								<?php endif;?>
							</td>
							
						</tr>
					<?php 
					
					$odd=!$odd;
					
					$row=mysql_fetch_assoc($query,MYSQL_ASSOC);
				}
		?>
	</tbody>
</table>
<script type="text/javascript">
	<?php include 'Scripts/Add-user.recently.js'?>
</script>
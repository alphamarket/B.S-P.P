/*
 * File:   main.cpp
 * Author: dariush
 *
 * Created on March 27, 2014, 8:11 PM
 */
#if defined(__DEBUG__) || defined(__RELEASE__)
    #undef __TESTING__
#endif
#ifndef __TESTING__
/**
 * iLib's includes
 */
#include "hpp/Argument_Processor.hpp"
#include "parse/hpp/semAnalyzer.hpp"
UN BC;
/**
 * Validate required arguments which client MUST provide<br />
 * If the input variables map were invalid a `std::invalid_argument` will be thrown.
 * @param vm the input arguments' variables map
 */
void validate_required_args(const boost::program_options::variables_map vm);
/**
 * The main entery point of program
 * @param argc The input arguments' count
 * @param argv The input arguments' container array
 * @return The termination state of program
 */
int main(int argc, char** argv) {
    try
    {
        std::cout<<"\033[mChecking \033[m";
        /* process and validate input argument */
       boost::program_options::variables_map vm = BC::Argument_Processor(argc, argv, &validate_required_args);
        /* now we are sure that we atleast we have `file` in our processed variables' map */
        source* __source = source::Create(vm["file"].as<string>().c_str());
        /* state the status */
        std::cout<<"\033[m`"<<__source->getSourceFile()<<"`\033[m";
        /* initialize the source */
        __source->process();
        lexSet* pls = NULL;
        BC::Lexer::lexParser* lp = NULL;
        BC::Sem::semAnalyzer* sa = NULL;
        try {
            lp = new lexParser(__source);
            pls = lp->parse();
            sa = new BC::Sem::semAnalyzer(pls);
            sa->analyze();
        }catch(LexParserException& e) {
            std::cerr<<std::endl<<"\x1b[A"<<"\033[41m\033[67G"<<"[ FAILED ]"<<"\033[m"<<std::endl;
            if(e.EndOfErrors())
                throw std::invalid_argument("Caught `LexParser` exception, but its error collection was empty!");
            while(!e.EndOfErrors())
            {
                pair<string, const BC::Lexer::lexNode*> __e = e.getNextError();
                std::cerr<<"\033[33m"<<__e.first<<"\033[m"<<std::endl;
            }
            TERMINATE_FAILURE;
        }
        delete sa;
        delete lp;
        delete pls;
        delete __source;
        /* termination disp. state */
        disp("\033[42m\033[71G[ OK ]\033[m");
        /* exit from program */
        TERMINATE_SUCCESS;
    }
    catch(std::exception &e)
    {
        std::cerr<<std::endl<<"\x1b[A"<<"\033[41m\033[67G"<<"[ FAILED ]"<<"\033[m"<<std::endl;
        std::cerr<<"\033[31m"<<"Error:    `"<<e.what()<<"`\033[m"<<std::endl;
        TERMINATE_FAILURE;
    }
}
/**
 * Validate required arguments which client MUST provide<br />
 * If the input variables map were invalid a `std::invalid_argument` will be thrown.
 * @param vm the input arguments' variables map
 * */
void validate_required_args(const boost::program_options::variables_map vm) {
    if(!vm.count("file"))
        throw std::invalid_argument("Target file not supplied!");
}
#endif
/*
 * File:   utils.hpp
 * Author: dariush
 *
 * Created on March 29, 2014, 1:06 AM
 */
#ifndef UTILS_HPP
#define	UTILS_HPP
#include "bootstrap.hpp"
#include <stdio.h>
#include <stdarg.h>
#include <cstdio>
#include <boost/program_options.hpp>
NS BC{
    class utils {
    public:
        /**
         * Format strings and returns formatted string
         * @see std::vsprintf()
         */
        static std::string fstr(const char* __format, ...);
        /**
         * Get OS dependant new line char
         */
        inline static std::string getNewLine() { return string("\n"); }
        /**
         * Generate standard error string
         * @param msg the error message
         * @param file the file which error has been raised
         * @param lineno the line number of error
         * @return the error string
         */
        static std::string genErrorStr(std::string msg, std::string file, size_t lineno) {
            char* ln = new char();
            sprintf(ln, "%d", (int)lineno);
            return file+": error "+msg+" at line `"+string(ln)+"`";
        }
    private:
    };
}
#endif	/* UTILS_HPP */
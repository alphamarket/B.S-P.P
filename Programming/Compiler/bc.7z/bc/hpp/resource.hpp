/*
 * File:   resource.hpp
 * Author: dariush
 *
 * Created on April 2, 2014, 5:52 PM
 */
#ifndef RESOURCE_HPP
#define	RESOURCE_HPP
#include "bootstrap.hpp"
NS BC {
    class resource {
    protected:
        /**
         * The related source which `this` resource has fetched from
         */
        const resource* related_source;
    };
}
#endif	/* RESOURCE_HPP */
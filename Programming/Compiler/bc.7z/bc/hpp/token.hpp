/*
 * File:   token.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 4:21 PM
 */
#ifndef TOKEN_HPP
#define	TOKEN_HPP
#include "../parse/hpp/lexerstrap.hpp"
#include "line.hpp"
NS BC {
/**
 * Create a token
 */
#define CREATE_TOKEN(_txt, _type, _line) new BC::Lexer::token(_txt, _type, _line);
    /**
     * Token container for lexer
     */
    class token : public resource{
    protected:
        /**
         * Initialize this instance with its arguments
         * @param _text The token's text.
         * @param _type The token's type.
         * @param _related_line The line which token has fetched from.
         * @return `this` instance
         */
        token* __init(std::string _text, BC::Lexer::LexTypeEnum _type, const BC::line* _related_line);
    public:
        /**
         * Construct a token.
         * @param _text The token's text.
         * @param _type The token's type.
         * @param _related_line The line which token has fetched from.
         */
        token(std::string _text, BC::Lexer::LexTypeEnum _type, const BC::line* _related_line) { this->__init(_text, _type, _related_line); }
        /**
         * Construct a token.
         * @param _text The token's text.
         * @param _type The token's type.
         */
        token(std::string _text, BC::Lexer::LexTypeEnum _type) { this->__init(_text, _type, NULL); }
        /**
         * Construct a token from an other's token.
         * @param orig The origin token
         */
        inline token(const token& orig) { this->__init(orig.text, orig.type, orig.related_line);}
        /**
         * Get token's text
         */
        inline std::string getText() const { return this->text; }
        /**
         * Get token's type
         */
        inline BC::Lexer::LexTypeEnum getType() const { return this->type; }
        /**
         * Get token's related line
         */
        inline const BC::line* getRelatedLine() const { return this->related_line; }
        /**
         * ToString() function of token class
         */
        friend std::ostream & operator<<(std::ostream & _stream, token const * _token) {
            /* output the line's content only */
            _stream << _token->getText();
            /* return the streaming instance */
            return _stream;
        }
    private:
        /**
         * The token's text.
         */
        std::string text;
        /**
         * The token's type.
         */
        BC::Lexer::LexTypeEnum type;
        /**
         * The related line which token has fetched from.
         */
        const BC::line* related_line;
    };
}
#endif	/* TOKEN_HPP */
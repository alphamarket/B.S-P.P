/*
 * File:   Argument_Processor.hpp
 * Author: dariush
 *
 * Created on March 28, 2014, 7:55 PM
 */
#ifndef ARGUMENT_PROCESSOR_HPP
#define	ARGUMENT_PROCESSOR_HPP
/**
 * BOOST lib's includes
 */
#include <boost/program_options.hpp>
namespace po = boost::program_options;
/**
 * iLibs' includes
 */
#include "bootstrap.hpp"
NS BC {
    /**
     * A varibale map validator delegate
     */
    typedef void (*variables_map_validator) (const po::variables_map);
    /**
     * Process and validate arguments.
     * @param argc The input arguments' count
     * @param argv The input arguments' container array
     * @return boost::program_options::variables_map The arguments' variable map
     */
    boost::program_options::variables_map Argument_Processor(int argc, char** argv, variables_map_validator vmv = NULL)
    {
        /* Declare the supported options. */
        po::options_description desc("Allowed options");
        desc.add_options()
            ("help", "Print this help messages.")
            ("file",  po::value<string>() ,"Target entry point file for compilation.")
        ;
        /* initiate a variable map */
        po::variables_map vm;
        try
        {
            /* store the currently passed arguments with declaration and variable map */
            po::store(po::parse_command_line(argc, argv, desc), vm);
            /* notifiy if any error happened */
            po::notify(vm);
        } catch(po::error& e) {
            /* catch and plot error using stderror stream line */
            std::cerr << "ERROR: " << e.what() << std::endl << std::endl;
            std::cerr << desc << std::endl;
            TERMINATE_FAILURE;
        }
        /* IF ANY `variables_map` VALIDATOR PROVIDED */
        if(vmv)
            /* VALIDATE THE GENERATED `variables_map` */
            vmv(vm);
        return vm;
    }
}
#endif	/* ARGUMENT_PROCESSOR_HPP */
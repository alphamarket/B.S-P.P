/*
 * File:   source.hpp
 * Author: dariush
 *
 * Created on March 29, 2014, 1:04 AM
 */
#ifndef SOURCE_HPP
#define	SOURCE_HPP
#include "bootstrap.hpp"
#include <vector>
#include "line.hpp"
NS BC{
    /**
     * The source container.
     */
    class source : public resource{
    private:
        /**
         * flag to indicate if the source has been initialized or not?
         */
        bool __hasInitialized;
        /**
         * file content container
         */
        std::string fBuffer;
    public:
        typedef pair<line, std::string> Error;
        /**
         * Get source file's address.
         */
        inline const char* getSourceFile() const { return this->source_file; }
        /**
         * Get current line#
         * @return The current line#
         */
        inline long getCurrentLineNo() const { return this->current_line;}
        /**
         * Get total line# of source
         */
        inline size_t getLineCount() const { return this->source_codes.size();}
        /**
         * Get source's content
         * @return the file's content
         */
        inline std::string getSourceContent() const { return this->fBuffer; }
        /**
         * Return next line from source code based on current line#
         * @return line instance, or NULL if reaching end of file
         */
        inline line* const readNext(){ line* _line = this->readLineAt(this->current_line); if(_line != NULL) this->current_line++; return _line;}
        /**
         * Return the line which is seek pointer is pointing now, and it will NOT change the seek pointer's position.
         * @return line instance, or NULL if reaching end of file
         */
        inline line* const readCurrent() const { return this->readLineAt(this->current_line); }
        /**
         * Check if seek pointer has reached the EndOfSource?
         * @return returns TRUE if the seek pointer has reach the EndOfSource; otherwise FALSE;
         */
        inline bool isEOS() { return this->current_line + 1 > this->getLineCount(); }
        /**
         * Get error container related to current source
         * @return The error vector
         * @Remark The first <u>pair&lt;size_t, string&gt;</u> of each item is the line's detail of the
         * &nbsp;&nbsp;linked error and the second <u>string</u> is the error message.
         */
        inline vector< Error > getErrors() const { return this->errors; }
        /**
         * Clears out the errors
         */
        inline void clearErrors() { this->errors.clear(); }
        /**
         * Check if the source has been processed or not
         */
        inline bool hasProcessed() const { return this->__hasInitialized; }
        /**
         * Construct a source.
         */
        inline static source* Create() { return new source("INLINE-CODE"); }
        /**
         * Construct a source.
         * @param source_file_path the source file path.
         */
        inline static source* Create(const char* source_file_path) { return new source(source_file_path); }
        /**
         * Process the source's instance.
         * @param context If any inline context passed, it will only process the passed context and ignore any
         * previously file initialization.
         */
        void process(std::string context = "");
        /**
         * Changes the seek pointer of current line#
         * @param lineNo the target line #
         * @return the target line's value or NULL if line# overflow
         */
        line* const gotoLine(size_t lineNo);
        /**
         * Read given string line by #
         * @param lineNo The desired line #
         * @return line instance, or NULL if reaching end of file
         */
         line* const readLineAt(size_t lineNo) const;
        /**
         * Link an error to a line
         * @param line The line instance to link the error
         * @param error_str The error string
         * @return true if the passed `_line` is valid(i.e its line detail fits with `this` source)
         */
        bool linkError(line* _line, string error_str);
        /**
         * Releases resources used by `this` class
         */
        ~source();
    protected:
        /**
         * The source file's path containers.
         */
        const char* source_file;
        /**
         * The source code from source file in lines vector format.
         */
         vector<line*> source_codes;
        /**
         * The current line while processing source code.
         */
        size_t current_line;
        /**
         * Errors' container handler.<br />
         * @Remark The first <u>pair&lt;size_t, string&gt;</u> of each item is the line's detail of the
         * &nbsp;&nbsp;linked error and the second <u>string</u> is the error message.
         */
        vector< Error > errors;
    private:
        /**
         * Construct a source.
         * @param source_file_path the source file path.
         */
        source(const char* source_file_path);
        /**
         * Processes passed puffer
         * @param buffer The buffer string
         */
        void process_buffer(std::string buffer);
    };
}
#endif	/* SOURCE_HPP */
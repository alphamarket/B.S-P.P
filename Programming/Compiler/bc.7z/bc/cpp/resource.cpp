/*
 * File:   resource.cpp
 * Author: dariush
 *
 * Created on April 2, 2014, 5:52 PM
 */
#include "../hpp/resource.hpp"
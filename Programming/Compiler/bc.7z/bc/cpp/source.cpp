/*
 * File:   source.cpp
 * Author: dariush
 *
 * Created on March 28, 2014, 10:31 PM
 */
#include "../hpp/source.hpp"
#include <boost/filesystem.hpp>
#include <boost/tokenizer.hpp>
#include <boost/format.hpp>
#include <boost/array.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
#include <fstream>
NS BC {
    source::source(const char* source_file_path) {
        /* grab the source file */
        this->source_file = source_file_path;
        /* initially nothing has been processed */
        this->__hasInitialized = false;
    }
    source::~source() {
        if(this->getLineCount() == 0) return;
        line* __line = NULL;
        this->current_line = 0;
        while((__line = this->readNext()))
            delete __line;
    }
    void source::process(std::string context) {
        /* if any context passed */
        if(context.length()) {
            /* update the file buffer */
            this->fBuffer = context;
            /* ignore the file add process the passed context */
            this->process_buffer(context);
            return;
        }
        /* validate the source code file address */
        /* `string(this->getSourceFile())` is essential seems boost changes the pointer of its arg */
        if(!boost::filesystem::exists(string(this->getSourceFile()).c_str()))
            throw std::invalid_argument("File `"+string(this->getSourceFile())+"` not found!!");
        /* Try to open the file for reading */
        FILE* file = fopen(this->source_file, "rb");
        /* Indicate failure */
        if (!file)
            throw ifstream::failure(utils::fstr("Couldn't open `%s`!", this->source_file));
        /* close the file handler */
        fclose(file);
        /* init ifstream for source file */
        std::ifstream fs(this->source_file);
        /* invoke a ss */
        std::stringstream __buffer;
        /* read file */
        __buffer << fs.rdbuf();
        /* Indicate if empty */
        if(!__buffer.str().length())
            throw ifstream::failure(utils::fstr("`%s` is empty!", this->source_file));
        /* update the file buffer */
        this->fBuffer = __buffer.str();
        /* fetch and normalize the buffer */
        this->process_buffer(__buffer.str());
    }
    void source::process_buffer(std::string buffer) {
        /* initially trim the buffer */
        boost::algorithm::trim_if(buffer, boost::is_any_of("\n"));
        /* our bellow spliter needs it */
        buffer +=  "\n";
        /* since basic if not case-sensitive we map buffer to its upper cased version */
        boost::algorithm::to_upper(buffer);
        /* currently no file has been processed yet */
        this->current_line = 0;
        /* init the source code container */
        this->source_codes.clear();
        /* lines' tokens container */
        std::string token;
        /* Tokenize the file's content into seperate lines */
        /* fetch and tokenizing line version of readed data  and maintain it into the container vector*/
        for(int top = 0, lineCounter = 0, bottom = 0; top < buffer.length() ; top++)
        {
            /* inline tokenizing with line breakings */
            if(buffer[top] != '\n')
            { /* collect current line's tokens */ token += char(buffer[top]); /* continue seeking */continue; }
            /* if we reach here we have collected the current line's tokens */
            /* normalize current tokens */
            boost::algorithm::trim(token);
            /* no token collected, it means an empty line */
            if(!token.length()) { /* to be sync with file's line# increase the line# counter by one */ lineCounter++; /* do not proceed */ continue; }
            /* concurrent statements check point */
            if(token.find(':') != std::string::npos)
            {
                /* a quotation mark encounter flag */
                bool quotation_meet = false;
                /* process entire line from beginning */
                for(int index = 0; true ; index++)
                {
                    /* loop's exit cond. */
                    if(!(index < token.length())) { break; }
                    /* fetch currently processing char */
                    char _char = token[index];
                    /* if encountered  a quotation mark */
                    /* we are moving into a string */
                    /* note that in basic for printing quotation mark, should use `CHR$(34)`
                     * so there is no `\"` to worry about! :) */
                    if(_char == '"')
                    {
                        /* change quotation meeting flag */
                        quotation_meet = !quotation_meet;
                        /* proceed with other chars. */
                        continue;
                    }
                    /* general regex pattern for matching floating points number */
                    const string pattern = "^(\\d+|:)?\\s*REM(.*)$";
                    boost::regex exp(pattern);
                    boost::cmatch m;
                    if(boost::regex_match(token.c_str(), m, exp)) goto __ADD_TOKEN;
                    /* make a quick search and return the result */
                    /* if we have meet the `:` char and also we are not in a pair quotation*/
                    if(_char == ':' && !quotation_meet)
                    {
                        /* if index is greater than zero? */
                        if(index) {
                            /* this is the first sub-token of current token */
                            std::string subtoken(token.substr(0, index));
                            /* normalize the sub-token */
                            boost::algorithm::trim(subtoken);
                            /* add sub-token as new line */
                            source_codes.push_back(line::Create(lineCounter, subtoken, this));
                        }
                        /* replace the rest of sub-token as new token */
                        /**
                         * Note: We keep the `:` mark intentionally, since every code line in BASIC
                         * should start with a number; by keeping `:` while processing lines starting with `:` means
                         * they are meant to execute semi-concurrent with previous numbered statement.
                         * So we use following `substr` pattern instead of `token.substr(index + 1, token.length() - 1);`
                         */
                        /* if we don't do this normalization this `:END` will flaged as invalid in `lexParser` */
                        token = ": "+token.substr(index + 1, token.length());
                        /* normalize the sub-token */
                        boost::algorithm::trim(token);
                        /* reset the index for new token */
                        index = 0;
                        /* continue with other chars */
                        continue;
                    }
                }
                /* if we have any remained token and not empty one? */
                if(token.length())
                    /* a the tokens into collection */
                    goto __ADD_TOKEN;
            }
__ADD_TOKEN:
            /* if the token is not empty? */
            if(token.length())
                /* add fetched of token to our source code */
                source_codes.push_back(line::Create(lineCounter++, token, this));
__NEXT_TOKEN:
            /* move pointer to next tokens' position */
            bottom = top + 1;
            /* clear the token buffer */
            token.clear();
            /* a fail safe for loop */
            continue;
        }
        /* We NOW have our source code departed into lines and saved in a vector */
        this->__hasInitialized = true;
    }
    line* const source::readLineAt(size_t lineNo) const
    {
        /* check line# overflow */
        if(lineNo >= this->getLineCount())
            return NULL;
        /* create a line instance with content from source code and from `this` source */
        return this->source_codes.at(lineNo);
    }
    line* const source::gotoLine(size_t lineNo)
    {
        /* check line# overflow */
        if (lineNo >= this->getLineCount())
            return NULL;
        /* update the current line# */
        this->current_line = lineNo;
        /* read current line && move the pointer forward by one */
        return this->readNext();
    }
    bool source::linkError(line* _line, string error_str) {
        /* check line# overflow */
        if(_line->getLineNumber() >= this->getLineCount())
            return false;
        /* the same line's content in `this` source */
        /* should match exactly with passed argument */
        if(*_line != *this->readLineAt(_line->getLineNumber()))
            return false;
        /* push into errors collection */
        this->errors.push_back(Error(*_line, error_str));
        /* return the succession */
        return true;
    }
}
/*
 * File:   line.cpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#include "../hpp/line.hpp"
#include "boost/algorithm/string.hpp"
NS BC {
    std::ostream & operator<<(std::ostream & _stream, line const & _line) {
        /* output the line's content only */
        _stream << _line.getContent();
        /* return the streaming instance */
        return _stream;
    }
    bool operator==(const line& lhs, const line& rhs) {
        /* everything should match */
        return lhs.getLineNumber() == rhs.getLineNumber() &&
                lhs.getContent() == rhs.getContent() &&
                lhs.getSource() == rhs.getSource();
    }
    line* line::__init(size_t lineNo, string content, const resource* _source) {
        /* init the line's no */
        this->lineNo = lineNo;
        /* init the line's content */
        this->content = content;
        /* init the related source */
        this->related_source = _source;
        /* return `this` instance */
        return this;
    }
    std::vector<string> line::Tokenize() const {
        std::vector<string> t;
        /* fetch current line's content */
        std::string buffer = this->getContent();
        /* lines' tokens container */
        std::string token;
        /* a quotation mark encounter flag */
        bool quotation_meet = false;
        /* Tokenize the file's content into seperate lines */
        /* fetch and tokenizing line version of readed data  and maintain it into the container vector*/
        for(int top = 0; top < buffer.length() ; top++)
        {
__RELOOP:
            char __PC = '\0';
            if(!quotation_meet && top + 1 < buffer.length() && (buffer[top] == '>' || buffer[top] == '<'))
                if(
                    (buffer[top] == '>' && buffer[top+1] == '<') ||
                    (buffer[top] == '<' && buffer[top+1] == '>') ||
                    (buffer[top] == '>' && buffer[top+1] == '=') ||
                    (buffer[top] == '<' && buffer[top+1] == '=')
                 ) { token += string({buffer[top], buffer[++top]}); goto __LOOP; }
                else{__PC = buffer[top]; goto __LOOP; }
            switch(buffer[top]) {
                case '"':
                    /* change quotation meeting flag */
                    quotation_meet = !quotation_meet;
                    if(token.length())
                        if(quotation_meet && top--)
                        /* since we go back -1 char. this quotation will be meet on next loop */
                        { quotation_meet = false; goto __LOOP; }
                    goto __DEFAULT;
                case '+':
                case '-':
                    if(!quotation_meet &&  top > 0 && token.length())
                        if((token[token.length() -1] < '0' || token[token.length() -1] > '9') || (token[token.length() -1] >= '0' && token[token.length() -1] <= '9'))  {
                            __PC = buffer[top];
                            goto __LOOP;
                        }
                    if(!quotation_meet && top + 1 < buffer.length())
                        if(buffer[top+1] >= '0' && buffer[top+1] <= '9')
                            goto __DEFAULT;
                case ';':
                case '#':
                case '*':
                case '/':
                case '^':
                case '(':
                case ')':
                case '=':
                case ',':
                case ' ':
                    if(quotation_meet)
                        goto __DEFAULT;
                    else if(buffer[top] != ' ')
                        __PC = buffer[top];
                    goto __LOOP;
                default:
__DEFAULT:
                    /* collect current line's tokens */
                    token += char(buffer[top]);
                    /* continue seeking */
                    goto __CONTINUE;
            }
__CONTINUE:
            continue;
__LOOP:
            /* if we reach here we have collected the current line's tokens */
            /* normalize current tokens */
            boost::algorithm::trim(token);
            if(token.length())
                t.push_back(token);
            if(__PC != '\0')
                t.push_back(string({__PC}));
            token.clear();
        }
        if(token.length()) {
            boost::algorithm::trim(token);
            if(token.length())
                t.push_back(token);
        }
        return t;
    }
}
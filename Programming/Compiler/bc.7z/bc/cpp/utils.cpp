/*
 * File:   utils.cpp
 * Author: dariush
 *
 * Created on March 29, 2014, 1:06 AM
 */
#include "../hpp/utils.hpp"
#include <sstream>
NS BC {
    /**
     * Format strings and returns formatted string
     * @see std::vsprintf()
     */
    std::string utils::fstr(const char* __format, ...) {
        char* buffer = new char();
        va_list arg_ptr;
        va_start(arg_ptr, __format);
        vsprintf(buffer, __format, arg_ptr);
        va_end(arg_ptr);
        return string(buffer);
    }
}
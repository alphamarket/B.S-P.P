/*
 * File:   token.cpp
 * Author: dariush
 *
 * Created on March 30, 2014, 4:21 PM
 */
#include "../hpp/token.hpp"
NS BC {
    token* token::__init(std::string _text, BC::Lexer::LexTypeEnum _type, const BC::line* _related_line) {
        this->text = _text;
        this->type = _type;
        this->related_line = _related_line;
        return this;
    }
}
/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/hpp/source.hpp
 *
 * File:   sourceTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __SOURCE_TEST__
#ifdef __SOURCE_TEST__
 #include "../../hpp/testCase.hpp"
#include "../../../hpp/line.hpp"
#include "../../../hpp/source.hpp"
#include <fstream>
UN BC;
NS BC_TESTER { NS TESTS {
    class sourceTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
        static const char* create_test_source() {
            std::string file_name = "/tmp/testSource.b";
            ofstream file(file_name);
            file<<"10 PRINT \"HELLO WORLD\"\n20 END";
            file.close();
            return file_name.c_str();
        }
    private:
        bool heap_check() {
            const char* source_file = create_test_source();
            source* __source = source::Create(source_file);
            __source->process();
           SHOULD_BE( __source->getSourceFile(), source_file);
           PSAME_POINT(__source->getSourceFile(), source_file);
           SHOULD_BE(__source->getLineCount(), 2);
           IS_ZERO(__source->getCurrentLineNo());
           IS_ZERO(__source->getErrors().size());
           IS_FALSE(__source->isEOS());
           SHOULD_BE(__source->readCurrent()->getContent(), "10 PRINT \"HELLO WORLD\"");
           SHOULD_BE(__source->readLineAt(0)->getContent(), "10 PRINT \"HELLO WORLD\"");
           SHOULD_BE(__source->readNext()->getContent(), "10 PRINT \"HELLO WORLD\"");
           SHOULD_BE(__source->readLineAt(1)->getContent(), "20 END");
           SHOULD_BE(__source->readNext()->getContent(), "20 END");
           IS_TRUE(__source->isEOS());
           SHOULD_BE(__source->getCurrentLineNo(), 2);
           SHOULD_BE(__source->getCurrentLineNo(), __source->getLineCount());
           IS_NULL(__source->readNext());
           SHOULD_BE(__source->getCurrentLineNo(), 2);
           SHOULD_BE(__source->getCurrentLineNo(), __source->getLineCount());
           IS_NULL(__source->gotoLine(123));
           SHOULD_BE(__source->gotoLine(0)->getContent(), "10 PRINT \"HELLO WORLD\"");
           SHOULD_BE(__source->readNext()->getContent(), "20 END");
           SHOULD_BE(__source->gotoLine(1)->getContent(), "20 END");
           SHOULD_BE(__source->readNext(), NULL);
           IS_TRUE(__source->isEOS());
           IS_FALSE(__source->linkError(line::Create(0, "FAKE"), "FAKE-ERROR"));
           IS_TRUE(__source->linkError(__source->readLineAt(0), "LINE#0-ERROR"));
           IS_TRUE(__source->linkError(__source->readLineAt(1), "LINE#1-ERROR"));
           vector<source::Error> e = __source->getErrors();
           SHOULD_BE(e.size(), 2);
           SHOULD_BE(e[0].first, *__source->readLineAt(0));
           NNOT_SAME_POINT(e[0].first, *__source->readLineAt(0));
           SHOULD_BE(e[0].second, "LINE#0-ERROR");
           SHOULD_BE(e[1].first, *__source->readLineAt(1));
           NNOT_SAME_POINT(e[1].first, *__source->readLineAt(1));
           SHOULD_BE(e[1].second, "LINE#1-ERROR");
           SHOULD_NOT_BE(*__source->readLineAt(0), *__source->readLineAt(1));
           PSAME_POINT(__source->readLineAt(0)->getSource(), __source);
           PSAME_POINT(__source->readLineAt(1)->getSource(), __source);
           delete(__source);
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
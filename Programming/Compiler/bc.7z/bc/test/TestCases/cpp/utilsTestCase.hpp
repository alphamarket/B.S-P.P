/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/hpp/utils.hpp
 *
 * File:   utilsTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __UTILS_TEST__
#ifdef __UTILS_TEST__
 #include "../../hpp/testCase.hpp"
#include "../../../hpp/utils.hpp"
UN BC;
NS BC_TESTER { NS TESTS {
    class utilsTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->static_check());
        }
    private:
        bool static_check() {
            SHOULD_BE(utils::getNewLine(), string("\n"));
            SHOULD_BE(utils::fstr("{%d}", 23), string("{23}").c_str());
            SHOULD_BE(utils::fstr("{%i}", 23), string("{23}").c_str());
            SHOULD_BE(utils::fstr("{%u}", 23), string("{23}").c_str());
            SHOULD_BE(utils::fstr("{%o}", 23), string("{27}").c_str());
            SHOULD_BE(utils::fstr("{%x}", 0x2f3), string("{2f3}").c_str());
            SHOULD_BE(utils::fstr("{%X}", 0x2f3), string("{2F3}").c_str());
            SHOULD_BE(utils::fstr("{%.3f}", 2.3456), string("{2.346}").c_str());
            SHOULD_BE(utils::fstr("{%.3g}", 2.3456), string("{2.35}").c_str());
            SHOULD_BE(utils::fstr("{%.3G}", 2.3456), string("{2.35}").c_str());
            SHOULD_BE(utils::fstr("{%.1F}", 2.3456), string("{2.3}").c_str());
            SHOULD_BE(utils::fstr("{%e}", 2000.3456), string("{2.000346e+03}").c_str());
            SHOULD_BE(utils::fstr("{%E}", 2000.3456), string("{2.000346E+03}").c_str());
            SHOULD_BE(utils::fstr("{%g}", 2000.3456), string("{2000.35}").c_str());
            SHOULD_BE(utils::fstr("{%G}", 2000.3456), string("{2000.35}").c_str());
            SHOULD_BE(utils::fstr("{%a}", 2.3456), string("{0x1.2c3c9eecbfb16p+1}").c_str());
            SHOULD_BE(utils::fstr("{%A}", 2.3456), string("{0X1.2C3C9EECBFB16P+1}").c_str());
            SHOULD_BE(utils::fstr("{%c}", 'a'), string("{a}").c_str());
            SHOULD_BE(utils::fstr("{%s}", "TEST"), string("{TEST}").c_str());
            SHOULD_BE(utils::fstr("{%s}", "TEST"), string("{TEST}").c_str());
            SHOULD_BE(utils::fstr("{%%}"), string("{%}").c_str());
            SHOULD_BE(utils::fstr("{TEST}"), string("{TEST}").c_str());
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
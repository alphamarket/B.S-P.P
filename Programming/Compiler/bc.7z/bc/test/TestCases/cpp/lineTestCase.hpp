/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/hpp/line.hpp
 *
 * File:   lineTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __LINE_TEST__
#ifdef __LINE_TEST__
#include "../../hpp/testCase.hpp"
#include "../../../hpp/line.hpp"
#include "../../../hpp/source.hpp"
#include <algorithm>
UN BC;
NS BC_TESTER { NS TESTS {
    class lineTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
            BESURE(this->tokenizing());
        }
    private:
        bool heap_check() {
            line* __line = line::Create(0, "TEST_LINE");
            IS_ZERO(__line->getLineNumber());
            IS_EQUAL(__line->getContent(), "TEST_LINE");
            IS_NULL(__line->getSource());
            line* __inv_line = line::Create(-1, "INVALID_TEST_LINE");
            NOT_EQUAL(__inv_line->getLineNumber(), (unsigned)-1);
            IS_EQUAL(__inv_line->getContent(), "INVALID_TEST_LINE");
            IS_NULL(__inv_line->getSource());
            BC::source* __source = source::Create(__FILE__);
            IS_POINTER(__source);
            NOT_EQUAL(*__line, *__inv_line);
            delete(__line);
            delete(__inv_line);
            __line = line::Create(1, "SOURCED_LINE", __source);
            IS_EQUAL(__line->getLineNumber(), 1);
            IS_EQUAL(__line->getContent(), "SOURCED_LINE");
            NOT_NULL(__line->getSource());
            PSAME_POINT(__source, __line->getSource());
            delete(__source);
            /* deleting __source will automatically dispose the __line */
            /* the following line is a segment fault! */
            /* delete(__line); */
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
        bool tokenizing() {
            echo("Tokenizing Tests....");
#define print_v(v) echo("Array\n(");for(int i=0;i<v.size();i++) echo("    "<<v[i]); echo(")");
            vector<string> testLine = {
                "()","<",">","=","\"","'","=","<=",">=","<>","a,s","d;k","\0",
                "+827",
                "-827",
                "-9\"23'",
                "-9\"23'\"",
                "-'9\"23'\"",
                "1+3*4 = -192",
                "1+>3",
                "1+<3",
                "1+=3",
                "1+>=3",
                "1+<=3",
                "1+1 <> -23",
                "1+1 >< -23",
                "PRINT (\"HELLO WORLD\")",
                "10 PRINT (-12/3+2)*(1-9/02)",
                "ak#666",
                "10 PRINT \"(-12/3+2)*(1-9/02)\"",
                "10 PRINT \"(-12/3+2)*(1-9/02)",
                "+8^27",
            };
            vector<vector<string> > expectaion = {
                {"(",")"},{"<"},{">"},{"="},{"\""},{"'"},{"="},{"<="},{">="},{"<>"},{"a",",","s"},{"d",";","k"},{},
                {"+827"},{"-827"},{"-9","\"23'"},{"-9","\"23'\""},{ "-", "'9", "\"23'\"" },{"1","+","3","*","4","=","-192"},
                {"1","+",">","3"},{"1","+","<","3"},{"1","+","=","3"},{"1","+",">=","3"},{"1","+","<=","3"},
                {"1","+","1","<>","-23"},{"1","+","1","><","-23"},{"PRINT", "(", "\"HELLO WORLD\"",")"},
                {"10","PRINT","(","-12","/","3","+","2",")","*","(","1","-","9","/","02",")"},{"ak", "#", "666"},
                {"10","PRINT","\"(-12/3+2)*(1-9/02)\""},{"10","PRINT","\"(-12/3+2)*(1-9/02)"},{"+8", "^", "27"}
            };
            IS_EQUAL(testLine.size(), expectaion.size());
            vector<string> diff;
            while(testLine.size())
            {
                line* __line = line::Create(0, testLine[0]);
                echo("    [T] `"<<__line->getContent()<<"`");
                vector<string> exp = expectaion[0];
                testLine.erase(testLine.begin());
                expectaion.erase(expectaion.begin());
                vector<string> tk = __line->Tokenize();
                if(tk.size() != exp.size()) { print_v(tk); }
                SHOULD_BE(tk.size(), exp.size());
                std::set_difference (tk.begin(), tk.end(), exp.begin(), exp.end(), std::back_inserter(diff));
                SHOULD_BE(diff.size(), 0);
                delete(__line);
            }
            SHOULD_BE(diff.size(), 0);
            echo("Tokenizing Tested....");
#undef print_v
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
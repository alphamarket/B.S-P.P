/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/lexParser.hpp
 *
 * File:   lexParserTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __PARSER_TEST__
#ifdef __PARSER_TEST__
#include "../../../hpp/testCase.hpp"
#include "../../../../parse/hpp/lexParser.hpp"
#include "../../../../hpp/source.hpp"
#include <vector>
#define L LEXTE
UN BC;
UN BC::Lexer;
NS BC_TESTER { NS TESTS {
    class lexParserTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
    private:
        bool heap_check() {
            this->initTestCase("@ID", 1);
            this->initTestCase("!ID", 1);
            this->initTestCase("$ID", 1);
            this->initTestCase("#ID", {{L::MRK_SHARP, L::GEN_ID}});
            this->initTestCase("$ID", 1);
            this->initTestCase("%ID", 1);
            this->initTestCase("^ID", {{L::OPR_EXP, L::GEN_ID}});
            this->initTestCase("&ID", 1);
            this->initTestCase("*ID", {{L::OPR_MUL, L::GEN_ID}});
            this->initTestCase("(ID", {{L::MRK_BRACK_OP, L::GEN_ID}});
            this->initTestCase(")ID", {{L::MRK_BRACK_CL, L::GEN_ID}});
            this->initTestCase("_ID", 1);
            this->initTestCase("-ID", {{L::OPR_SUB, L::GEN_ID}});
            this->initTestCase("+ID", {{L::OPR_ADD, L::GEN_ID}});
            this->initTestCase("/ID", {{L::OPR_DIV, L::GEN_ID}});
            this->initTestCase("\\ID", 1);
            this->initTestCase("~ID", 1);
            this->initTestCase("`ID", 1);
            this->initTestCase("ID@", {{L::GEN_ID}});
            this->initTestCase("ID!", {{L::GEN_ID}});
            this->initTestCase("ID$", {{L::GEN_ID}});
            this->initTestCase("ID#", {{L::GEN_ID, L::MRK_SHARP}});
            this->initTestCase("ID$", {{L::GEN_ID}});
            this->initTestCase("ID%", {{L::GEN_ID}});
            this->initTestCase("ID^", {{L::GEN_ID, L::OPR_EXP}});
            this->initTestCase("ID&", {{L::GEN_ID}});
            this->initTestCase("ID*", {{L::GEN_ID, L::OPR_MUL}});
            this->initTestCase("ID(", {{L::GEN_ID, L::MRK_BRACK_OP}});
            this->initTestCase("ID)", {{L::GEN_ID, L::MRK_BRACK_CL}});
            this->initTestCase("ID_", {{L::GEN_ID}});
            this->initTestCase("ID-", {{L::GEN_ID, L::OPR_SUB}});
            this->initTestCase("ID+", {{L::GEN_ID, L::OPR_ADD}});
            this->initTestCase("ID/", {{L::GEN_ID, L::OPR_DIV}});
            this->initTestCase("ID\\", {{L::GEN_ID}});
            this->initTestCase("ID~", {{L::GEN_ID}});
            this->initTestCase("ID`", {{L::GEN_ID}});
            this->initTestCase("ID", {{L::GEN_ID}});
            this->initTestCase("\"STRING\"", {{L::GEN_STRING}});
            this->initTestCase("-\"STRING\"", {{L::OPR_SUB, L::GEN_STRING}});
            this->initTestCase("+\"STRING\"", {{L::OPR_ADD, L::GEN_STRING}});
            this->initTestCase("CLOSE#12", {{L::KWD_CLOSE, L::MRK_SHARP, L::GEN_NUM}});
            this->initTestCase(":CLOSE#12", {{L::GEN_SEPARATOR, L::KWD_CLOSE, L::MRK_SHARP, L::GEN_NUM}});
            this->initTestCase("2CLOSE#12",  1);
            this->initTestCase("2CLOSE#\\12", 2);
            this->initTestCase("DATA 12, \"STRING TEXT\", 12.3", {{L::KWD_DATA,  L::GEN_NUM, L::MRK_COMMA,L::GEN_STRING, L::MRK_COMMA,L::GEN_NUM}});
            this->initTestCase("DIM ID2 (1, 2, 3)", {{ L::KWD_DIM, L::GEN_ID, L::MRK_BRACK_OP, L::GEN_NUM, L::MRK_COMMA, L::GEN_NUM, L::MRK_COMMA, L::GEN_NUM, L::MRK_BRACK_CL }});
            this->initTestCase("END\n\n", {{L::KWD_END}});
            this->initTestCase("FOR ID1 = (31+3) TO 42", {{L::KWD_FOR, L::GEN_ID, L::OPR_EQ, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_ADD, L::GEN_NUM, L::MRK_BRACK_CL, L::KWD_TO, L::GEN_NUM}});
            this->initTestCase("FOR ID1 = (31+3) TO 42 STEP N", {{L::KWD_FOR, L::GEN_ID, L::OPR_EQ, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_ADD, L::GEN_NUM, L::MRK_BRACK_CL, L::KWD_TO, L::GEN_NUM, L::KWD_STEP, L::GEN_ID}});
            this->initTestCase("GOTO 213-2", {{L::KWD_GOTO, L::GEN_NUM, L::OPR_SUB, L::GEN_NUM}});
            this->initTestCase("GOSUB 213-2", {{L::KWD_GOSUB, L::GEN_NUM, L::OPR_SUB, L::GEN_NUM}});
            this->initTestCase("IF 32 = 2 THEN GOTO \"INVALID\"", {{ L::KWD_IF,  L::GEN_NUM, L::OPR_EQ, L::GEN_NUM, L::KWD_THEN, L::KWD_GOTO, L::GEN_STRING}});
            this->initTestCase("INPUT ID1, ID2", {{L::KWD_INPUT, L::GEN_ID, L::MRK_COMMA, L::GEN_ID}});
            this->initTestCase("INPUT # 3, ID1, ID2", {{L::KWD_INPUT, L::MRK_SHARP, L::GEN_NUM, L::MRK_COMMA, L::GEN_ID, L::MRK_COMMA, L::GEN_ID}});
            this->initTestCase("LET ID = (23 + invalidSTT", {{ L::KWD_LET, L::GEN_ID, L::OPR_EQ, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_ADD, L::GEN_ID}});
            this->initTestCase("LET ID = (23 + validSTT)", {{ L::KWD_LET, L::GEN_ID, L::OPR_EQ, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_ADD, L::GEN_ID, L::MRK_BRACK_CL}});
            this->initTestCase("NEXT ID!, ID$", {{L::KWD_NEXT, L::GEN_ID, L::MRK_COMMA, L::GEN_ID}});
            this->initTestCase("OPEN FU FOR OUTPUT AS 14", {{L::KWD_OPEN, L::GEN_ID, L::KWD_FOR, L::KWD_OUTPUT, L::KWD_AS, L::GEN_NUM}});
            this->initTestCase("OPEN UR_MOUTH FOR MY_DICK AS A_BITCH", {{L::KWD_OPEN, L::GEN_ID, L::KWD_FOR, L::GEN_ID, L::KWD_AS, L::GEN_ID}});
            this->initTestCase("POKE (12/34 OR FU)", {{L::KWD_POKE, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_DIV, L::GEN_NUM, L::OPR_OR, L::GEN_ID, L::MRK_BRACK_CL}});
            this->initTestCase("PRINT \"TXT\"; 12; ID", {{L::KWD_PRINT, L::GEN_STRING, L::MRK_SEMICLN, L::GEN_NUM, L::MRK_SEMICLN, L::GEN_ID}}); 
            this->initTestCase("PRINT # 3, \"TXT\"; 12; ID", {{L::KWD_PRINT, L::MRK_SHARP, L::GEN_NUM, L::MRK_COMMA, L::GEN_STRING, L::MRK_SEMICLN, L::GEN_NUM, L::MRK_SEMICLN, L::GEN_ID}}); 
            this->initTestCase("READ ID1, ID2", {{L::KWD_READ, L::GEN_ID, L::MRK_COMMA, L::GEN_ID}});
            this->initTestCase("RETURN", {{L::KWD_RETURN}});
            this->initTestCase("RESTORE", {{L::KWD_RESTORE}});
            this->initTestCase("RUN", {{L::KWD_RUN}});
            this->initTestCase("STOP", {{L::KWD_STOP}});
            this->initTestCase("SYS (12 OR OK)", {{L::KWD_SYS, L::MRK_BRACK_OP, L::GEN_NUM, L::OPR_OR, L::GEN_ID, L::MRK_BRACK_CL}});
            this->initTestCase("WAIT ID1, ID2", {{L::KWD_WAIT, L::GEN_ID, L::MRK_COMMA, L::GEN_ID}});
            this->initTestCase("REM TEST FU", {{L::KWD_REM}});
            return true;
        }
        void initTestCase(std::string code, size_t expections_counts = 0) { this->initTestCase(code, {}, expections_counts); }
        void initTestCase(std::string code, vector<vector<L> > results, size_t expections_counts = 0) {
            echo("    [T] `"<<boost::algorithm::replace_all_copy(code, "\n", "\\n")<<"`");
            source* s = NULL;
            lexSet* pls = NULL;
            lexParser* p = NULL;
            SHOULD_NOT_THROW(s = source::Create());
            SHOULD_NOT_THROW(s->process(code));
            SHOULD_NOT_THROW(p = new lexParser(s));
            try {
                 pls = p->parse();
                 // if any excetion expected, make a `THROW` assertion which will fail again
                 if(expections_counts) { die("!Expecting to catch something, but didn't!"); }
            }catch(LexParserException& e) {
                IS_FALSE(e.EndOfErrors());
                // exception count should match
                if(e.getErrorsCount() != expections_counts) {
                    e.InitIterator();
                    while(!e.EndOfErrors())
                    {
                        pair<string, const BC::Lexer::lexNode*> __e = e.getNextError();
                        echo("        [E] "<<__e.first);
                    }
                    die("    [Errors# didn't match: expecting `"<<expections_counts<<"`, but got `"<<e.getErrorsCount()<<"`]");
                }
            }
            if(results.size()) {
                SHOULD_BE(results.size(), pls->getSetCount());
                lexNode* node = NULL;
                size_t index = 0;
                while((node = pls->getNextSet())) {
                    vector<LEXTE> expected = results[index++];
                    if(expected.size() != node->getChildrenCount()) {
                        die("Failed asserting { expecting lexNode# : `"<<expected.size()<<"`, but got `"<<node->getChildrenCount()<<"`}");
                    }
                    for(size_t index = 0; index < node->getChildrenCount(); index++) {
                        if(expected[index] != node->getChild(index)->getValue()->getType()) {
                            die("Failed asserting { expecting: `"+LEXTE2String(expected[index])+"`, but got `"+LEXTE2String(node->getChild(index)->getValue()->getType())+"`}");
                        }
                    }
                }
            }
            delete s;
            delete p;
            delete pls;
        }
    };
} }
#undef L
#endif
/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/lexNode.hpp
 *
 * File:   lexNodeTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __LEXNODE_TEST__
#ifdef __LEXNODE_TEST__
 #include "../../../hpp/testCase.hpp"
#include "../../../../parse/hpp/lexNode.hpp"
UN BC;
using namespace BC::Lexer;
NS BC_TESTER { NS TESTS {
    class lexNodeTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
    private:
        bool heap_check() {
            lexNode* __ln = new lexNode();
            lexNode* __lnc1 = new lexNode();
            lexNode* __lnc2 = new lexNode();
            lexNode* __lnc3 = new lexNode();
            token* __lnv = new token("TOKEN", LexTypeEnum::GEN_ID);
            IS_ZERO(__ln->getChildrenCount());
            IS_NULL(__ln->getValue());
            IS_NULL(__ln->getParent());
            IS_NULL(__ln->getNextSibling());
            IS_NULL(__ln->getPrevSibling());
            IS_FALSE(__ln->hasNextSibling());
            IS_FALSE(__ln->hasPrevSibling());
            IS_NULL(__ln->unlinkNextSibling());
            IS_NULL(__ln->unlinkPrevSibling());
            IS(__ln->unlinkFromParent(), __ln);
            NOT_NULL(__ln->getChildren());
            IS_TRUE(__ln->isRoot());
            IS_TRUE(__ln->isLeaf());
            SHOULD_NOT_THROW(__ln->clearChildren());
            SHOULD_THROW(__ln->getChild(0));
            SHOULD_THROW(__ln->unLinkChild(size_t(0)));
            SHOULD_THROW(__ln->deleteChild(size_t(0)));
            SHOULD_NOT_THROW(__ln->setValue(__lnv));
            PSAME_POINT(__ln->getValue(), __lnv);
            IS_ZERO(__ln->getChildrenCount());
            for(int i = 0; i < 2; i++) {
                IS_NULL(__ln->addChild((lexNode*)NULL));
                PSAME_POINT(__ln->addChild(__lnc1), __lnc1);
                SHOULD_BE(__ln->getChildrenCount(), 1);
                PSAME_POINT(__ln->addChild(__lnc2), __lnc2);
                SHOULD_BE(__ln->getChildrenCount(), 2);
                PSAME_POINT(__ln->addChild(__lnc3), __lnc3);
                SHOULD_BE(__ln->getChildrenCount(), 3);
                PSAME_POINT(__lnc1->getParent(), __ln);
                PSAME_POINT(__lnc2->getParent(), __ln);
                PSAME_POINT(__lnc3->getParent(), __ln);
                if(!i) {
                    SHOULD_NOT_THROW(__ln->clearChildren());
                    SHOULD_BE(__ln->getChildrenCount(), 0);
                }
            }
            SHOULD_BE(__ln->getChildrenCount(), 3);
            PSAME_POINT(__ln->getChild(0), __lnc1);
            PSAME_POINT(__ln->getChild(1), __lnc2);
            PSAME_POINT(__ln->getChild(2), __lnc3);
            PSAME_POINT(__ln->unLinkChild(2), __lnc3);
            NOT_NULL(__lnc3);
            SHOULD_BE(__ln->getChildrenCount(), 2);
            PSAME_POINT(__ln->addChild(__lnc3), __lnc3);
            SHOULD_BE(__ln->getChildrenCount(), 3);
            PSAME_POINT(__ln->getChild(1), __lnc2);
            PSAME_POINT(__ln->unLinkChild(1), __lnc2);
            SHOULD_THROW(__ln->getChild(2));
            PSAME_POINT(__ln->getChild(0), __lnc1);
            PSAME_POINT(__ln->getChild(1), __lnc3);
            IS_FALSE(__ln->hasNextSibling());
            IS_FALSE(__ln->hasPrevSibling());
            __lnc3->setNextSibling(__lnc1);
            PSAME_POINT(__lnc1->getPrevSibling() , __lnc3);
            PSAME_POINT(__lnc3->getNextSibling() , __lnc1);
            PSAME_POINT(__ln->addChild(__lnc2) , __lnc2);
            SHOULD_BE(__ln->getChildrenCount(), 3);
            PSAME_POINT(__ln->getChild(2), __lnc2);
            __lnc2->setNextSibling(__lnc1);
            IS_TRUE(__ln->deleteChild(__lnc2));
            IS_NULL(__lnc2);
            SHOULD_BE(__ln->getChildrenCount(), 2);
            SHOULD_THROW(__ln->getChild(2));
            token* t = new token("FOO", LexTypeEnum::GEN_ID);
            /* This delete will there __ln and all its children */
            /* Put `echo(this)` in lexNode construcor to monitor the event */
            __lnc1->addChild(t);
            delete(__lnc1);
            delete(__ln);
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/lexSet.hpp
 *
 * File:   lexSetTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __LEXSET_TEST__
#ifdef __LEXSET_TEST__
  #include "../../../hpp/testCase.hpp"
#include "../../../../parse/hpp/lexSet.hpp"
#include "../../../../parse/hpp/lexNode.hpp"
UN BC::Lexer;
NS BC_TESTER { NS TESTS {
    class lexSetTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
    private:
        bool heap_check() {
            lexSet* __ls = new lexSet("LEXSET_NAME");
            SHOULD_BE(__ls->getName(), "LEXSET_NAME");
            IS_ZERO(__ls->getSetCount());
            IS_NULL(__ls->getNextSet());
            SHOULD_NOT_THROW(__ls->clearSets());
            vector<lexNode*> __lna = {
                new lexNode(),
                new lexNode(),
                new lexNode(),
                new lexNode(),
                new lexNode()
            };
            for(int i=0;i<__lna.size();i++)
            {
                PSAME_POINT(__ls->addSubSet(__lna.at(i)), __lna.at(i));
            }
            SHOULD_BE(__lna.size(), __ls->getSetCount());
            for(int i=1;i<__lna.size();i++)
            {
                PSAME_POINT(__lna[i]->getPrevSibling(), __lna[i-1]);
                PSAME_POINT(__lna[i-1]->getNextSibling(), __lna[i]);
            }
            IS_NULL(__lna.front()->getPrevSibling());
            IS_NULL(__lna.back()->getNextSibling());
            int __iter = 0;
            for(; __iter < 2; __iter++) {
                int index = 0;
                lexNode* next = NULL;
                while((next = __ls->getNextSet()))
                    PSAME_POINT(__lna[index++], next);
                SHOULD_BE(index, __ls->getSetCount());
                IS_NULL(__ls->getNextSet());
                __ls->initIterator();
            }
            SHOULD_BE(__iter, 2);
            __iter = 0;
            while(__ls->getSetCount() && ++__iter)
            {
                lexNode* __unlinked = __ls->unlinkSubSet(0);
                NOT_NULL(__unlinked);
                PSAME_POINT(__unlinked, __lna[0]);
                __lna.erase(__lna.begin());
                delete __unlinked;
            }
            SHOULD_BE(__iter, 5);
            SHOULD_BE(__ls->getName(), "LEXSET_NAME");
            IS_ZERO(__ls->getSetCount());
            IS_NULL(__ls->getNextSet());
            SHOULD_NOT_THROW(__ls->clearSets());
            delete(__ls);
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
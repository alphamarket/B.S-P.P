/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/semAnalyzer.hpp
 *
 * File:   semAnalyzerTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __TOKEN_TEST__
#ifdef __TOKEN_TEST__
#include "../../../hpp/testCase.hpp"
#include "../../../../parse/hpp/lexParser.hpp"
#include "../../../../parse/hpp/semAnalyzer.hpp"
#include <vector>
UN BC;
UN BC::Lexer;
NS BC_TESTER {NS TESTS {
    class semAnalyzerTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() {}
        bool __dispose() {}
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
    private:
        bool heap_check() {
            /**
             * Test Unit Pairs
             */
            typedef std::pair<std::string, std::size_t> tu;
#define z(o) tu(string("0 ")+string(o), 0)
#define o(z) tu(string("0 ")+string(z), 1)
            vector<tu> validations = {
                z("CLOSE#12"),
                o("CLOSE 12"),
                o("CLOSE#"),
                z("CLOSE#-12"),
                z("CLOSE#+12"),
                o("CLOSE#12.2"),
                o("CLOSE#-12.2"),
                o("CLOSE#+12.2"),
                z("REM { 'CLOSE' DONE }"),
                o("DATA"),
                z("DATA 12"),
                z("DATA +12"),
                z("DATA -12"),
                z("DATA 12.12"),
                z("DATA +12.12"),
                z("DATA -12.12"),
                z("DATA \"string\""),
                o("DATA -\"string\""),
                o("DATA +\"string\""),
                z("DATA 12, \"string\", 21.21"),
                o("DATA 12; \"string\"; 21.21"),
                o("DATA 12; < \"string\"; 21.21"),
                o("DATA 12, >, \"string\", 21.21"),
                o("DATA 12, \"string\" 21.21"),
                o("DATA 12 \"string\", 21.21"),
                o("DATA 12 \"string\" 21.21"),
                z("REM { 'DATA' DONE }"),
                o("DIM"),
                o("DIM ID"),
                o("DIM ID ("),
                o("DIM ID ( )"),
                o("DIM ID ( 12.12 )"),
                o("DIM ID ( \"string\" )"),
                z("DIM ID ( +1 )"),
                o("DIM ID ( 1, )"),
                z("DIM ID ( +1,-2 )"),
                z("REM { 'DIM' DONE }"),
                z("END"),
                o("END 12"),
                o("END ID"),
                o("END REM COMMENT"),
                z("REM { 'END' DONE }"),
                o("FOR"),
                o("FOR ID"),
                o("FOR ID = "),
                o("FOR ID = ("),
                o("FOR ID = (12)"),
                o("FOR ID = (12) TO "),
                z("FOR ID = (12) TO 24.23"),
                o("FOR ID = (12) 24"),
                o("FOR ID (12) TO 24"),
                o("FOR = (12) TO -24.23"),
                z("FOR ID = (12) TO -24.23 STEP 12"),
                o("FOR ID = (12) TO -24.23 STEP 12.21"),
                o("FOR ID = (12) TO -24.23 STEP ID"),
                o("FOR ID = (12) TO -24.23 STEP 12 12 ID"),
                z("REM { 'FOR' DONE }"),
                o("GOTO"),
                z("GOTO 12"),
                z("GOTO -12"),
                z("GOTO +12"),
                z("GOTO 12.12"),
                z("GOTO +12.12"),
                z("GOTO -12.12"),
                z("GOTO (-12.12 OR 76)"),
                z("REM { 'GOTO' DONE }"),
                o("GOSUB"),
                z("GOSUB 12"),
                z("GOSUB -12"),
                z("GOSUB +12"),
                z("GOSUB 12.12"),
                z("GOSUB +12.12"),
                z("GOSUB -12.12"),
                z("GOSUB (-12.12 OR 76)"),
                z("REM { 'GOSUB' DONE }"),
                o("LET"),
                o("LET 12"),
                o("LET 12 = 12"),
                z("LET ID = 12"),
                o("LET ID 12"),
                o("LET ID = (12"),
                z("LET ID = (12+13/42)"),
                z("REM { 'LET' DONE }"),
                o("IF"),
                o("IF ("),
                o("IF (12) THEN"),
                o("IF (12) THEN 12"),
                z("LET ID1 = 12 : LET ID2 = 13 : IF (ID1 = 12) THEN IF (ID2 = 12) THEN GOTO 10"),
                o("IF (ID1 = 12) THEN IF (ID2 = 12) THEN GOTO 10"),
                o("IF (12 THEN 12"),
                o("LET ID1 = 12 : LET ID2 = 13 : IF (ID1 = 12) THEN IF (ID2 = 12)) THEN GOTO 10"),
                z("REM { 'IF' DONE }"),
                o("INPUT"),
                o("INPUT 12"),
                o("INPUT 12.2"),
                z("INPUT ID"),
                z("INPUT ID1, ID2"),
                o("INPUT ID1, ID2,"),
                o("INPUT ID1, ID2,12"),
                o("INPUT #"),
                o("INPUT # ID"),
                o("INPUT # 2"),
                o("INPUT # 2, "),
                z("INPUT # 2, ID1, ID2"),
                o("INPUT # ID, ID1, ID2"),
                z("REM { 'INPUT' DONE }"),
                o("NEXT"),
                o("NEXT 12"),
                o("NEXT 12.2"),
                o("NEXT ID"), /* undefined ID */
                z("LET ID = 0:NEXT ID"),
                z("LET ID1=1:LET ID2=2:NEXT ID1, ID2"),
                o("LET ID1=1:LET ID2=2:NEXT ID1, ID2,"),
                o("LET ID1=1:LET ID2=2:NEXT ID1, ID2,12"),
                z("REM { 'NEXT' DONE }"),
                o("OPEN"),
                o("OPEN ("),
                o("OPEN (12)"),
                o("OPEN \"STRING\""),
                o("OPEN ID"),
                o("OPEN ID FOR "),
                o("OPEN ID FOR INPUT"),
                o("OPEN ID FOR INPUT AS "),
                o("OPEN ID FOR INPUT AS #"),
                z("LET ID=0:OPEN ID FOR INPUT AS # 12"),
                z("LET ID=0:OPEN ID FOR INPUT AS # +12"),
                z("LET ID=0:OPEN ID FOR INPUT AS # -12"),
                o("LET ID=0:OPEN ID FOR INPUT AS # 12.3"),
                o("LET ID=0:OPEN ID FOR INPUT AS # +12.3"),
                o("LET ID=0:OPEN ID FOR INPUT AS # -12.3"),
                z("LET ID=0:OPEN ID FOR OUTPUT AS # 12"),
                z("LET ID=0:OPEN ID FOR OUTPUT AS # +12"),
                z("LET ID=0:OPEN ID FOR OUTPUT AS # -12"),
                o("LET ID=0:OPEN ID FOR OUTPUT AS # 12.3"),
                o("LET ID=0:OPEN ID FOR OUTPUT AS # +12.3"),
                o("LET ID=0:OPEN ID FOR OUTPUT AS # -12.3"),
                o("LET ID=0:OPEN ID FOR ID1 AS # 12.3"),
                o("LET ID=0:OPEN ID FOR ID1 AS # 12"),
                z("OPEN \"STRING\" FOR INPUT AS # 12"),
                z("OPEN (12*23/24) FOR INPUT AS # 12"),
                z("REM { 'OPEN' DONE }"),
                o("POKE"),
                o("POKE ,"),
                z("POKE 12"),
                o("POKE 12,"),
                o("POKE 12,ID"), /* undefined ID */
                z("LET ID=-1:POKE 12,ID"),
                o("LET ID=-1:POKE 12,ID)"),
                z("REM { 'POKE' DONE }"),
                o("PRINT"),
                o("PRINT ;"),
                o("PRINT ,"),
                z("PRINT (12)"),
                o("PRINT #(12)"),
                o("PRINT #;(12)"),
                z("PRINT \"STRING\""),
                o("PRINT \"STRING\", 12"),
                z("PRINT \"STRING\"; 12"),
                o("PRINT \"STRING\"; 12;"),
                z("PRINT \"STRING\"; 12;(12 OR (123*-23))"),
                o("PRINT \"STRING\"; 12;(12 OR 123*-23))"),
                o("PRINT #"),
                o("PRINT # 12"),
                o("PRINT # 12, "),
                o("PRINT # 12; 13"),
                z("PRINT # 12, 13"),
                z("PRINT # 12, \"STRING\"; 12;(12 OR (123*-23))"),
                o("PRINT # 12; \"STRING\"; 12;(12 OR (123*-23))"),
                o("PRINT # 12; ID, \"STRING\"; 12;(12 OR (123*-23))"),
                o("PRINT # 12; ID; \"STRING\"; 12;(12 OR (123*-23))"),
                o("LET ID=0048:PRINT # 12; ID; \"STRING\"; 12;(12 OR (123*-23))"),
                z("LET ID=0048:PRINT # 12, ID; \"STRING\"; 12;(12 OR (123*-23))"),
                z("REM { 'PRINT' DONE }"),
                o("READ"),
                o("READ 12"),
                o("READ 12.2"),
                z("READ ID"),
                z("READ ID1, ID2"),
                o("READ ID1, ID2,"),
                o("READ ID1, ID2,12"),
                o("READ #"),
                o("READ # ID"),
                o("READ # 2"),
                o("READ # 2, "),
                o("READ # 2, ID1, ID2"),
                o("READ # ID, ID1, ID2"),
                z("REM { 'READ' DONE }"),
                z("RETURN"),
                o("RETURN ANYTHING"),
                z("REM { 'RETURN' DONE }"),
                z("RESTORE"),
                o("RESTORE ANYTHING"),
                z("REM { 'RESTORE' DONE }"),
                z("RUN"),
                o("RUN ANYTHING"),
                z("REM { 'RUN' DONE }"),
                z("STOP"),
                o("STOP ANYTHING"),
                z("REM { 'STOP' DONE }"),
                o("SYS"),
                z("LET ANYTHING=0:SYS ANYTHING"),
                z("SYS 12"),
                z("SYS \"STRING\""),
                o("SYS \"STRING\" ANYTHING"),
                o("SYS \"STRING\","),
                o("SYS \"STRING\";"),
                o("SYS \"STRING\";"),
                o("SYS \"STRING\",12"),
                o("SYS \"STRING\";12"),
                z("REM { 'SYS' DONE }"),
                o("WAIT"),
                o("WAIT ,"),
                z("WAIT 12"),
                o("WAIT 12,"),
                o("WAIT 12,ID"), /* undefined ID */
                z("LET ID=-1:WAIT 12,ID"),
                o("LET ID=-1:WAIT 12,ID)"),
                z("REM { 'WAIT' DONE }"),
                z("REM"),
                z("REM TEST 4 COMMENT"),
                z("REM { 'REM' DONE }"),
                tu("REM", 1), /* every line should start with an integer */
                tu("1.2 REM", 1),
                tu("1 REM", 0),
                tu("+1 REM", 1),
                tu("-1 REM", 1),                
                o("ID"), /* every command should start with a keyword */
                o("12"), /* every command should start with a keyword */
                o("12.3"), /* every command should start with a keyword */
                z("PRINT \"LINE#0\"\n1 PRINT \"LINE#1\""),
                o("PRINT \"LINE#0\"\n0 PRINT \"ALSO LINE#0\""),
                tu("0 PRINT \"LINE#0\"\n0 PRINT \"ALSO LINE#0\"\n0 PRINT \"ALSO LINE#0\"", 2),
                z("LET ID=1"),
                o("LET ID=1\n0 LET ID=2"),
                z("LET ID=1\n1 LET ID=2"),
                tu("0 LET ID0=1\n0 LET ID=2\n0 LET ID=3", 2), /* `LET` is a both definition and assignment statement, SO only 2 error line duplication */
                o("LET ID0=1\n0 LET ID=2\n2 LET ID=3"), /* `LET` is a both definition and assignment statement, SO only 1 error line duplication */
                z("LET ID=1\n1 LET ID=2\n2 LET ID=3"),
                z("DIM ID(1)"),
                o("DIM ID(1)\n0 DIM ID(2)"),
                o("DIM ID(1)\n1 DIM ID(2)"), /* ID duplication */
                tu("0 DIM ID0(1)\n0 DIM ID(2)\n0 DIM ID(3)", 2), /* the validator won't reach to check ID duplications because of line# duplications, SO there are 2 errors for line# duplication */
                o("DIM ID0(1)\n0 DIM ID(2)\n2 DIM ID(3)"), /* the validator won't reach to check ID duplications because of line# duplications, SO there is 1 error for line# duplication */
                tu("0 DIM ID(1)\n1 DIM ID(2)\n2 DIM ID(3)", 2), /* 2 errors for ID duplications */
                tu("0 DIM ID1(1)\n1 DIM ID2(2)\n2 DIM ID3(3)", 0), /* no error for ID duplications */
                z("REM { 'GENERAL RULES' DONE }"),
            };
#undef o
#undef z
            size_t index;
            for(index = 0; index < validations.size(); index++) {
                this->initTestCase(validations[index].first, validations[index].second);
            }
            echo(std::endl<<"    [OK] Total# `"<<index<<"` case tested!");
            return true;
        }
        void initTestCase(std::string code, size_t expections_counts = 0) {
            echo("    [T] e{"<<expections_counts<<"}: `"<<boost::algorithm::replace_all_copy(code, "\n", "\\n")<<"`");
            lexSet* pls = NULL;
            source* __source = NULL;
            BC::Lexer::lexParser* lp = NULL;
            BC::Sem::semAnalyzer* sa = NULL;
            SHOULD_NOT_THROW(__source = source::Create());
            SHOULD_NOT_THROW(__source->process(code));
            SHOULD_NOT_THROW(lp = new lexParser(__source));
            SHOULD_NOT_THROW(pls = lp->parse());
            SHOULD_NOT_THROW(sa = new BC::Sem::semAnalyzer(pls));
            try {
                sa->analyze();
                 // if any excetion expected, make a `THROW` assertion which will fail again
                 if(expections_counts) {die("        !Expecting to catch something, but didn't!"); }
            }catch(LexParserException& e) {
                IS_FALSE(e.EndOfErrors());
                // exception count should match
                if(e.getErrorsCount() != expections_counts) {
                    e.InitIterator();
                    while(!e.EndOfErrors())
                    {
                        pair<string, const BC::Lexer::lexNode*> __e = e.getNextError();
                        echo("        [E] "<<__e.first);
                    }
                    die("    [Errors# didn't match: expecting `"<<expections_counts<<"`, but got `"<<e.getErrorsCount()<<"`]");
                }
            }
            delete sa;
            delete lp;
            delete pls;
            delete __source;
        }
    };
} }
#endif
#undef EXPRESSION_TESTING
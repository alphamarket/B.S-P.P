/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/token.hpp
 *
 * File:   tokenTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __TOKEN_TEST__
#ifdef __TOKEN_TEST__
  #include "../../../hpp/testCase.hpp"
#include "../../../../hpp/token.hpp"
UN BC;
UN BC::Lexer;
NS BC_TESTER { NS TESTS {
    class tokenTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            BESURE(this->heap_check());
        }
    private:
        bool heap_check() {
            token* __tok = new token("TOKEN", LexTypeEnum::GEN_STATMNT);
            SHOULD_BE(__tok->getText(), "TOKEN");
            SHOULD_BE(__tok->getType(), LexTypeEnum::GEN_STATMNT);
            IS_NULL(__tok->getRelatedLine());
            delete(__tok);
            line* __line = line::Create(0, "");
            __tok = new token("TOKEN", LexTypeEnum::GEN_STATMNT, __line);
            SHOULD_BE(__tok->getText(), "TOKEN");
            SHOULD_BE(__tok->getType(), LexTypeEnum::GEN_STATMNT);
            NOT_NULL(__tok->getRelatedLine());
            PSAME_POINT(__tok->getRelatedLine(), __line);
            delete(__line);
            delete(__tok);
__ASSERT_SUCCESS:
            return true;
__ASSERT_FAILURE:
            return false;
        }
    };
} }
#endif
/*
 * This file construct test units for testing
 * TargetFile: https://github.com/dariushha/basic-compiler/blob/master/parse/hpp/token.hpp
 *
 * File:   tokenTestCase.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 12:37 AM
 */
#define __TOKEN_TEST__
#ifdef __TOKEN_TEST__
  #include "../../../hpp/testCase.hpp"
#include "../../../../parse/hpp/lexValidator.hpp"
UN BC;
UN BC::Lexer;
NS BC_TESTER { NS TESTS {
    class lexValidatorTestCase : public CPP_TESTER::testCase {
    public:
        bool __init() { }
        bool __dispose() { }
        bool __run(int argc = 0, void** argv = NULL) {
            /*
             * POV Validations
             */
            IS_TRUE(lexValidator::IS_GEN_EMPTY(""));
            IS_TRUE(lexValidator::IS_GEN_ID("DAR2IUSH"));
            IS_FALSE(lexValidator::IS_GEN_ID("DAR<AND"));
            IS_FALSE(lexValidator::IS_GEN_ID("2DARIUSH"));
            IS_FALSE(lexValidator::IS_GEN_ID(""));
            IS_FALSE(lexValidator::IS_GEN_ID("RUN"));
            IS_FALSE(lexValidator::IS_GEN_ID(">"));
            IS_FALSE(lexValidator::IS_GEN_ID("A#AD"));
            IS_FALSE(lexValidator::IS_GEN_ID("AND"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("CLOSE"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("DATA"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("DIM"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("END"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("FOR"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("TO"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("STEP"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("GOTO"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("GOSUB"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("IF"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("THEN"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("INPUT"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("OUTPUT"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("LET"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("NEXT"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("OPEN"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("AS"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("POKE"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("PRINT"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("READ"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("RETURN"));
            IS_FALSE(lexValidator::IS_GEN_KYWD("RETRUN"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("RESTORE"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("RUN"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("STOP"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("SYS"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("WAIT"));
            IS_TRUE(lexValidator::IS_GEN_KYWD("REM"));
            IS_FALSE(lexValidator::IS_GEN_KYWD("AREM"));
            IS_TRUE(lexValidator::IS_GEN_LINE_NUM("12"));
            IS_FALSE(lexValidator::IS_GEN_LINE_NUM("+12"));
            IS_TRUE(lexValidator::IS_GEN_MARK("("));
            IS_TRUE(lexValidator::IS_GEN_MARK(")"));
            IS_TRUE(lexValidator::IS_GEN_MARK(","));
            IS_TRUE(lexValidator::IS_GEN_MARK(";"));
            IS_TRUE(lexValidator::IS_GEN_MARK("\""));
            IS_TRUE(lexValidator::IS_GEN_MARK("#"));
            IS_TRUE(lexValidator::IS_GEN_NUM("123"));
            IS_TRUE(lexValidator::IS_INTEGER_NUM("123"));
            IS_TRUE(lexValidator::IS_GEN_NUM("-123"));
            IS_TRUE(lexValidator::IS_INTEGER_NUM("-123"));
            IS_TRUE(lexValidator::IS_GEN_NUM("+123"));
            IS_TRUE(lexValidator::IS_INTEGER_NUM("+123"));
            IS_TRUE(lexValidator::IS_GEN_NUM("+0.123"));
            IS_TRUE(lexValidator::IS_REAL_NUM("+0.123"));
            IS_FALSE(lexValidator::IS_INTEGER_NUM("+0.123"));
            IS_FALSE(lexValidator::IS_GEN_NUM("+0123."));
            IS_FALSE(lexValidator::IS_REAL_NUM("+0123."));
            IS_FALSE(lexValidator::IS_INTEGER_NUM("+0123."));
            IS_FALSE(lexValidator::IS_GEN_NUM("+01.23."));
            IS_FALSE(lexValidator::IS_REAL_NUM("+01.23."));
            IS_FALSE(lexValidator::IS_GEN_NUM("+01.a23"));
            IS_FALSE(lexValidator::IS_REAL_NUM("+01.a23"));
            IS_FALSE(lexValidator::IS_INTEGER_NUM("+01.a23"));
            IS_FALSE(lexValidator::IS_GEN_NUM("+01.A23"));
            IS_FALSE(lexValidator::IS_GEN_NUM("+01.z23"));
            IS_FALSE(lexValidator::IS_GEN_NUM("+01.Z23"));
            IS_TRUE(lexValidator::IS_GEN_OPR("^"));
            IS_TRUE(lexValidator::IS_GEN_OPR("+"));
            IS_TRUE(lexValidator::IS_GEN_OPR("<"));
            IS_TRUE(lexValidator::IS_GEN_OPR(">"));
            IS_TRUE(lexValidator::IS_GEN_OPR("<>"));
            IS_TRUE(lexValidator::IS_GEN_OPR("><"));
            IS_TRUE(lexValidator::IS_GEN_OPR("<="));
            IS_TRUE(lexValidator::IS_GEN_OPR("=>"));
            IS_TRUE(lexValidator::IS_GEN_OPR(">="));
            IS_TRUE(lexValidator::IS_GEN_OPR("=<"));
            IS_TRUE(lexValidator::IS_GEN_OPR("AND"));
            IS_TRUE(lexValidator::IS_GEN_OPR("OR"));
            IS_TRUE(lexValidator::IS_GEN_OPR("NOT"));
            IS_FALSE(lexValidator::IS_GEN_PRG(""));
            IS_TRUE(lexValidator::IS_GEN_PRG("@"));
            IS_TRUE(lexValidator::IS_GEN_STATMNT("NIL"));
            IS_TRUE(lexValidator::IS_GEN_STRING("\"HI\""));
            IS_FALSE(lexValidator::IS_GEN_STRING("HI"));
            IS_FALSE(lexValidator::IS_GEN_STRING("\"HI"));
            IS_FALSE(lexValidator::IS_GEN_STRING("HI\""));
            IS_TRUE(lexValidator::IS_KWD_CLOSE("CLOSE"));
            IS_TRUE(lexValidator::IS_KWD_DATA("DATA"));
            IS_TRUE(lexValidator::IS_KWD_DIM("DIM"));
            IS_TRUE(lexValidator::IS_KWD_END("END"));
            IS_TRUE(lexValidator::IS_KWD_FOR("FOR"));
            IS_TRUE(lexValidator::IS_KWD_TO("TO"));
            IS_TRUE(lexValidator::IS_KWD_STEP("STEP"));
            IS_TRUE(lexValidator::IS_KWD_GOSUB("GOSUB"));
            IS_TRUE(lexValidator::IS_KWD_GOTO("GOTO"));
            IS_TRUE(lexValidator::IS_KWD_IF("IF"));
            IS_TRUE(lexValidator::IS_KWD_THEN("THEN"));
            IS_TRUE(lexValidator::IS_KWD_INPUT("INPUT"));
            IS_TRUE(lexValidator::IS_KWD_LET("LET"));
            IS_TRUE(lexValidator::IS_KWD_NEXT("NEXT"));
            IS_TRUE(lexValidator::IS_KWD_OPEN("OPEN"));
            IS_TRUE(lexValidator::IS_KWD_AS("AS"));
            IS_TRUE(lexValidator::IS_KWD_POKE("POKE"));
            IS_TRUE(lexValidator::IS_KWD_PRINT("PRINT"));
            IS_TRUE(lexValidator::IS_KWD_READ("READ"));
            IS_TRUE(lexValidator::IS_KWD_REM("REM"));
            IS_TRUE(lexValidator::IS_KWD_RESTORE("RESTORE"));
            IS_TRUE(lexValidator::IS_KWD_RETURN("RETURN"));
            IS_TRUE(lexValidator::IS_KWD_RUN("RUN"));
            IS_TRUE(lexValidator::IS_KWD_STOP("STOP"));
            IS_TRUE(lexValidator::IS_KWD_SYS("SYS"));
            IS_TRUE(lexValidator::IS_KWD_WAIT("WAIT"));
            IS_TRUE(lexValidator::IS_MRK_BRACK_CL(")"));
            IS_TRUE(lexValidator::IS_MRK_BRACK_OP("("));
            IS_TRUE(lexValidator::IS_MRK_COMMA(","));
            IS_TRUE(lexValidator::IS_MRK_QUOTE("\""));
            IS_TRUE(lexValidator::IS_MRK_SEMICLN(";"));
            IS_TRUE(lexValidator::IS_MRK_SHARP("#"));
            /*
             * General Validations
             */
            typedef LexTypeEnum LTE;
            SHOULD_BE(lexValidator::GeneralValidate(""), LTE::GEN_EMPTY);
            SHOULD_BE(lexValidator::GeneralValidate("DAR2IUSH"), LTE::GEN_ID);
            SHOULD_BE(lexValidator::GeneralValidate("DAR<AND"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("2DARIUSH"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("RUN"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate(">"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("A#AD"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("AND"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("CLOSE"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("DATA"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("DIM"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("END"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("FOR"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("TO"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("STEP"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("GOTO"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("GOSUB"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("IF"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("THEN"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("INPUT"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("OUTPUT"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("LET"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("NEXT"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("OPEN"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("AS"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("POKE"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("PRINT"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("READ"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("RETURN"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("RETRUN"), LTE::GEN_ID);
            SHOULD_BE(lexValidator::GeneralValidate("RESTORE"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("RUN"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("STOP"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("SYS"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("WAIT"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("REM"), LTE::GEN_KYWD);
            SHOULD_BE(lexValidator::GeneralValidate("AREM"), LTE::GEN_ID);
            SHOULD_BE(lexValidator::GeneralValidate("12"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("+12"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("("), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate(")"), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate(","), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate(";"), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate("\""), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate("#"), LTE::GEN_MARK);
            SHOULD_BE(lexValidator::GeneralValidate("123"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("-123"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("+123"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("+0.123"), LTE::GEN_NUM);
            SHOULD_BE(lexValidator::GeneralValidate("+0123."), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("+01.23."), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("+01.a23"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("+01.A23"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("+01.z23"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("+01.Z23"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("^"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("+"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("<"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate(">"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("<>"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("><"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("<="), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("=>"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate(">="), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("=<"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("AND"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("OR"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("NOT"), LTE::GEN_OPR);
            SHOULD_BE(lexValidator::GeneralValidate("@"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("NIL"), LTE::GEN_ID);
            SHOULD_BE(lexValidator::GeneralValidate("\"HI\""), LTE::GEN_STRING);
            SHOULD_BE(lexValidator::GeneralValidate("HI"), LTE::GEN_ID);
            SHOULD_BE(lexValidator::GeneralValidate("\"HI"), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::GeneralValidate("HI\""), LTE::GEN_UNKNOWN);
            SHOULD_BE(lexValidator::KeywordValidate("CLOSE"), LTE::KWD_CLOSE);
            SHOULD_BE(lexValidator::KeywordValidate("DATA"), LTE::KWD_DATA);
            SHOULD_BE(lexValidator::KeywordValidate("DIM"), LTE::KWD_DIM);
            SHOULD_BE(lexValidator::KeywordValidate("END"), LTE::KWD_END);
            SHOULD_BE(lexValidator::KeywordValidate("FOR"), LTE::KWD_FOR);
            SHOULD_BE(lexValidator::KeywordValidate("TO"), LTE::KWD_TO);
            SHOULD_BE(lexValidator::KeywordValidate("STEP"), LTE::KWD_STEP);
            SHOULD_BE(lexValidator::KeywordValidate("GOSUB"), LTE::KWD_GOSUB);
            SHOULD_BE(lexValidator::KeywordValidate("GOTO"), LTE::KWD_GOTO);
            SHOULD_BE(lexValidator::KeywordValidate("IF"), LTE::KWD_IF);
            SHOULD_BE(lexValidator::KeywordValidate("THEN"), LTE::KWD_THEN);
            SHOULD_BE(lexValidator::KeywordValidate("INPUT"), LTE::KWD_INPUT);
            SHOULD_BE(lexValidator::KeywordValidate("OUTPUT"), LTE::KWD_OUTPUT);
            SHOULD_BE(lexValidator::KeywordValidate("LET"), LTE::KWD_LET);
            SHOULD_BE(lexValidator::KeywordValidate("NEXT"), LTE::KWD_NEXT);
            SHOULD_BE(lexValidator::KeywordValidate("OPEN"), LTE::KWD_OPEN);
            SHOULD_BE(lexValidator::KeywordValidate("AS"), LTE::KWD_AS);
            SHOULD_BE(lexValidator::KeywordValidate("POKE"), LTE::KWD_POKE);
            SHOULD_BE(lexValidator::KeywordValidate("PRINT"), LTE::KWD_PRINT);
            SHOULD_BE(lexValidator::KeywordValidate("READ"), LTE::KWD_READ);
            SHOULD_BE(lexValidator::KeywordValidate("REM"), LTE::KWD_REM);
            SHOULD_BE(lexValidator::KeywordValidate("RESTORE"), LTE::KWD_RESTORE);
            SHOULD_BE(lexValidator::KeywordValidate("RETURN"), LTE::KWD_RETURN);
            SHOULD_BE(lexValidator::KeywordValidate("RUN"), LTE::KWD_RUN);
            SHOULD_BE(lexValidator::KeywordValidate("STOP"), LTE::KWD_STOP);
            SHOULD_BE(lexValidator::KeywordValidate("SYS"), LTE::KWD_SYS);
            SHOULD_BE(lexValidator::KeywordValidate("WAIT"), LTE::KWD_WAIT);
            SHOULD_BE(lexValidator::MarkValidate(")"), LTE::MRK_BRACK_CL);
            SHOULD_BE(lexValidator::MarkValidate("("), LTE::MRK_BRACK_OP);
            SHOULD_BE(lexValidator::MarkValidate(","), LTE::MRK_COMMA);
            SHOULD_BE(lexValidator::MarkValidate("\""), LTE::MRK_QUOTE);
            SHOULD_BE(lexValidator::MarkValidate(";"), LTE::MRK_SEMICLN);
            SHOULD_BE(lexValidator::MarkValidate("#"), LTE::MRK_SHARP);
        }
    };
} }
#endif
/*
 * File:   tester.cpp
 * Author: dariush
 *
 * Created on March 31, 2014, 10:51 PM
 */

#include "../hpp/testCase.hpp"
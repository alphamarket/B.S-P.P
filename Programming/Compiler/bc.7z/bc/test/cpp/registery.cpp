/*
 * File:   registery.cpp
 * Author: dariush
 *
 * Created on April 3, 2014, 1:22 AM
 */
#include "../hpp/registery.hpp"

NS CPP_TESTER {
#if defined(__TESTING__) && !defined(__DEMO__)
    test_suite registery::__suite;
#endif
}
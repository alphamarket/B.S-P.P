/*
 * File:   manifest.hpp
 * Author: dariush
 *
 * Created on April 1, 2014, 2:13 AM
 */
#ifndef MANIFEST_HPP
#define	MANIFEST_HPP
#include "hpp/registery.hpp"
#include "TestCases/cpp/lineTestCase.hpp"
#include "TestCases/cpp/sourceTestCase.hpp"
#include "TestCases/parse/cpp/tokenTestCase.hpp"
#include "TestCases/cpp/utilsTestCase.hpp"
#include "TestCases/parse/cpp/lexNodeTestCase.hpp"
#include "TestCases/parse/cpp/lexSetTestCase.hpp"
#include "TestCases/parse/cpp/lexParserTestCase.hpp"
#include "TestCases/parse/cpp/lexValidatorTestCase.hpp"
#include "TestCases/parse/cpp/semAnalyzerTestCase.hpp"
/*
 * Include test case files
 */
namespace CPP_TESTER {
    UN BC_TESTER::TESTS;
    /**
     * bootstrap the test suite for testing
     */
    void __bootstrap() {
        /* example */
        registery::__register("Line Tester", new lineTestCase());
        registery::__register("Source Tester", new sourceTestCase());
        registery::__register("Utils Tester", new utilsTestCase());
        registery::__register("LexNode Tester", new lexNodeTestCase());
        registery::__register("LexSet Tester", new lexSetTestCase());
        registery::__register("Token Tester", new tokenTestCase());
        registery::__register("LexValidator Tester", new lexValidatorTestCase());
        registery::__register("Parser Tester", new lexParserTestCase());
        registery::__register("Semantic Analyzer Tester", new semAnalyzerTestCase());
    }
}
#endif	/* MANIFEST_HPP */

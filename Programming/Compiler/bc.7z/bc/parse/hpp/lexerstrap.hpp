/*
 * File:   lexerstrap.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 2:39 PM
 */
#ifndef LEXERSTARP_HPP
#define	LEXERSTARP_HPP
#include "../../hpp/bootstrap.hpp"
#include <boost/array.hpp>
#include <boost/algorithm/string.hpp>
NS BC { NS Lexer {
    /**
     * Lexer Type Enum
     */
    typedef enum  LEXTE {
        /** Operators  **/
            /** Comparison Operators **/
                 /** `=` Equal Operator */
                OPR_EQ,
                /** `&lt;` Less than Operator */
                OPR_LT,
                /** `&gt;` Greater than Operator */
                OPR_GT,
                 /** `&lt;=` | `=&lt;` Less than or equal Operator */
                OPR_LE,
                 /** `&gt;=` | `=&gt;` Greater than or equal Operator */
                OPR_GE,
                 /** `&lt;&gt;` | `&gt;&lt;` Not equal Operator */
                OPR_NE,
            /** Boolean Operators **/
                 /** `AND` Operator */
                OPR_AND,
                 /** `OR` Operator */
                OPR_OR,
                 /** `NOT` Operator */
                OPR_NOT,
            /** Arithmetic Operators **/
                 /** `^` Exponentiation Operator */
                OPR_EXP,
                 /** `*` Multiplication Operator */
                OPR_MUL,
                 /** `/` Division Operator */
                OPR_DIV,
                 /** `+` Addition Operator */
                OPR_ADD,
                 /** `-` Subtraction Operator */
                OPR_SUB,
            /** String Operators **/
                 /** `+` String Concatenation Operator */
                OPR_CONCAT,
        /** End Of Operators **/
        /** Keywords **/
             /** Keyword `CLOSE` */
            KWD_CLOSE,
             /** Keyword `DATA` */
            KWD_DATA,
             /** Keyword `DIM` */
            KWD_DIM,
             /** Keyword `END` */
            KWD_END,
             /** Keyword `FOR` */
            KWD_FOR,
             /** Keyword `TO` */
            KWD_TO,
             /** Keyword `STEP` */
            KWD_STEP,
            /** Keyword `GOTO` */
            KWD_GOTO,
            /** Keyword `GOSUB` */
            KWD_GOSUB,
             /** Keyword `IF` */
            KWD_IF,
             /** Keyword `THEN` */
            KWD_THEN,
             /** Keyword `INPUT` */
            KWD_INPUT,
             /** Keyword `OUTPUT` */
            KWD_OUTPUT,
             /** Keyword `LET` */
            KWD_LET,
             /** Keyword `NEXT` */
            KWD_NEXT,
             /** Keyword `OPEN` */
            KWD_OPEN,
             /** Keyword `AS` */
            KWD_AS,
             /** Keyword `POKE` */
            KWD_POKE,
             /** Keyword `PRINT` */
            KWD_PRINT,
             /** Keyword `READ` */
            KWD_READ,
             /** Keyword `RETURN` */
            KWD_RETURN,
             /** Keyword `RESTORE` */
            KWD_RESTORE,
             /** Keyword `RUN` */
            KWD_RUN,
             /** Keyword `STOP` */
            KWD_STOP,
             /** Keyword `SYS` */
            KWD_SYS,
             /** Keyword `WAIT` */
            KWD_WAIT,
             /** Keyword `REM` */
            KWD_REM,
        /** End of Keywords **/
        /** Generals **/
            /** General Program */
            GEN_PRG,
             /** Genral Identifier */
            GEN_ID,
             /** General Number */
            GEN_NUM,
             /** General Keyword */
            GEN_KYWD,
             /** General String */
            GEN_STRING,
            /** General Statement */
            GEN_STATMNT,
            /** General Line Number */
            GEN_LINE_NUM,
            /** General Operator */
            GEN_OPR,
            /** General Mark */
            GEN_MARK,
            /** General Empty Phrase */
            GEN_EMPTY,
            /** General Unknown*/
            GEN_UNKNOWN,
            /** General Command Seperator */
            GEN_SEPARATOR,
        /** End Of Generals **/
        /** Marks **/
             /** `(` Bracket OPen mark */
            MRK_BRACK_OP,
             /** `)` Bracket CLose mark */
            MRK_BRACK_CL,
             /** `,` Comma mark */
            MRK_COMMA,
             /** `;` Semicolon mark */
            MRK_SEMICLN,
             /** `"` Quotation mark */
            MRK_QUOTE,
             /** `#` Sharp | Hash | Number Sign mark */
            MRK_SHARP,
        /** End Of Marks **/
    } LexTypeEnum;
    const boost::array<string, 27>  __KEYWORDS = {
        "CLOSE",
        "DATA",
        "DIM",
        "END",
        "FOR",
        "TO",
        "STEP",
        "GOTO",
        "GOSUB",
        "IF",
        "THEN",
        "INPUT",
        "OUTPUT",
        "LET",
        "NEXT",
        "OPEN",
        "AS",
        "POKE",
        "PRINT",
        "READ",
        "RETURN",
        "RESTORE",
        "RUN",
        "STOP",
        "SYS",
        "WAIT",
        "REM"
    };
    const boost::array<string, 17> __OPERATORS = {
        "=",
        "<",
        ">",
        "<=",
        "=<",
        ">=",
        "=>",
        "<>",
        "><",
        "AND",
        "OR",
        "NOT",
        "^",
        "*",
        "/",
        "+",
        "-"
    };
    const boost::array<string, 6> __MARKS = {
        "(",
        ")",
        ",",
        ";",
        "\"",
        "#",
    };
/**
 * Checks if the passed txt is a keyword or not.
 */
inline bool IS_KEYWORD(std::string txt) { for(int i=0;i<BC::Lexer::__KEYWORDS.size();i++) if(boost::algorithm::to_upper_copy<string>(txt) == BC::Lexer::__KEYWORDS[i]) return true; return false; }
} }
/**
 * Checks if the passed txt is an operator or not.
 */
inline bool IS_OPERATOR(std::string txt) {  for(int i=0;i<BC::Lexer::__OPERATORS.size();i++) if(boost::algorithm::to_upper_copy<string>(txt) == BC::Lexer::__OPERATORS[i]) return true; return false;  }
/**
 * Checks if the passed txt is a mark or not.
 */
inline bool IS_MARK(std::string txt) {   for(int i=0;i<BC::Lexer::__MARKS.size();i++) if(boost::algorithm::to_upper_copy<string>(txt) == BC::Lexer::__MARKS[i]) return true; return false; }
inline std::string LEXTE2String(BC::Lexer::LEXTE lexte) {
    switch(lexte) {
        case BC::Lexer::LEXTE::OPR_EQ: return "=";
        case BC::Lexer::LEXTE::OPR_LT: return "<";
        case BC::Lexer::LEXTE::OPR_GT: return ">";
        case BC::Lexer::LEXTE::OPR_LE: return "(<=|=<)";
        case BC::Lexer::LEXTE::OPR_GE: return "(>=|=>)";
        case BC::Lexer::LEXTE::OPR_NE: return "(<>|><)";
        case BC::Lexer::LEXTE::OPR_AND: return "AND";
        case BC::Lexer::LEXTE::OPR_OR: return "OR";
        case BC::Lexer::LEXTE::OPR_NOT: return "NOT";
        case BC::Lexer::LEXTE::OPR_EXP: return "^";
        case BC::Lexer::LEXTE::OPR_MUL: return "*";
        case BC::Lexer::LEXTE::OPR_DIV: return "/";
        case BC::Lexer::LEXTE::OPR_CONCAT:
        case BC::Lexer::LEXTE::OPR_ADD: return "+";
        case BC::Lexer::LEXTE::OPR_SUB: return "-";
        case BC::Lexer::LEXTE::KWD_CLOSE: return "CLOSE";
        case BC::Lexer::LEXTE::KWD_DATA: return "DATA";
        case BC::Lexer::LEXTE::KWD_DIM: return "DIM";
        case BC::Lexer::LEXTE::KWD_END: return "END";
        case BC::Lexer::LEXTE::KWD_FOR: return "FOR";
        case BC::Lexer::LEXTE::KWD_TO: return "TO";
        case BC::Lexer::LEXTE::KWD_STEP: return "STEP";
        case BC::Lexer::LEXTE::KWD_GOTO: return "GOTO";
        case BC::Lexer::LEXTE::KWD_GOSUB: return "GOSUB";
        case BC::Lexer::LEXTE::KWD_IF: return "IF";
        case BC::Lexer::LEXTE::KWD_THEN: return "THEN";
        case BC::Lexer::LEXTE::KWD_INPUT: return "INPUT";
        case BC::Lexer::LEXTE::KWD_OUTPUT: return "OUTPUT";
        case BC::Lexer::LEXTE::KWD_LET: return "LET";
        case BC::Lexer::LEXTE::KWD_NEXT: return "NEXT";
        case BC::Lexer::LEXTE::KWD_OPEN: return "OPEN";
        case BC::Lexer::LEXTE::KWD_AS: return "AS";
        case BC::Lexer::LEXTE::KWD_POKE: return "POKE";
        case BC::Lexer::LEXTE::KWD_PRINT: return "PRINT";
        case BC::Lexer::LEXTE::KWD_READ: return "READ";
        case BC::Lexer::LEXTE::KWD_RETURN: return "RETURN";
        case BC::Lexer::LEXTE::KWD_RESTORE: return "RESTORE";
        case BC::Lexer::LEXTE::KWD_RUN: return "RUN";
        case BC::Lexer::LEXTE::KWD_STOP: return "STOP";
        case BC::Lexer::LEXTE::KWD_SYS: return "SYS";
        case BC::Lexer::LEXTE::KWD_WAIT: return "WAIT";
        case BC::Lexer::LEXTE::KWD_REM: return "REM";
        case BC::Lexer::LEXTE::GEN_PRG: return "Program";
        case BC::Lexer::LEXTE::GEN_ID: return "Identifier";
        case BC::Lexer::LEXTE::GEN_NUM: return "Number";
        case BC::Lexer::LEXTE::GEN_KYWD: return "Keyword";
        case BC::Lexer::LEXTE::GEN_STRING: return "String";
        case BC::Lexer::LEXTE::GEN_STATMNT: return "Statement";
        case BC::Lexer::LEXTE::GEN_LINE_NUM: return "Line Number";
        case BC::Lexer::LEXTE::GEN_OPR: return "Operator";
        case BC::Lexer::LEXTE::GEN_MARK: return "Mark";
        case BC::Lexer::LEXTE::GEN_EMPTY: return "Empty";
        case BC::Lexer::LEXTE::GEN_UNKNOWN: return "Unknown";
        case BC::Lexer::LEXTE::GEN_SEPARATOR: return "Seperator";
        case BC::Lexer::LEXTE::MRK_BRACK_OP: return "(";
        case BC::Lexer::LEXTE::MRK_BRACK_CL: return ")";
        case BC::Lexer::LEXTE::MRK_COMMA: return ",";
        case BC::Lexer::LEXTE::MRK_SEMICLN: return ";";
        case BC::Lexer::LEXTE::MRK_QUOTE: return "\"";
        case BC::Lexer::LEXTE::MRK_SHARP: return "#";
        default:
            throw std::invalid_argument("Undefined `LEXTE` enum!");
    }
}
#endif	/* LEXERSTARP_HPP */
/*
 * File:   errorCollector.hpp
 * Author: dariush
 *
 * Created on April 4, 2014, 2:31 PM
 */
#ifndef ERRORCOLLECTOR_HPP
#define	ERRORCOLLECTOR_HPP
#include "lexerstrap.hpp"
#include <vector>
#include "../../hpp/token.hpp"
#include "lexNode.hpp"
NS BC { NS Lexer {
    class lexErrorCollector : public exception {
    protected:
        /**
         * Currently Iterator Position
         */
        mutable size_t CIP;
        /**
         * The error collection
         */
        vector<pair<std::string, const BC::Lexer::lexNode*> > errors;
    public:
        /**
         * Initiate the error collector
         */
        inline lexErrorCollector() { this->InitIterator(); }
        /**
         * Destruct the error collector
         */
        inline virtual ~lexErrorCollector() throw() { }
        /**
         * Initializes the position of iterator to begin
         */
        inline void InitIterator() const throw() { this->CIP = 0; }
        /**
         * Checks if any error exists in error container, if so throws `this`
         */
        inline void throwIfAny() const { if(this->IsContainError()) { this->InitIterator(); throw this; } }
        /**
         * Checks if any error exists in error container
         */
        inline bool IsContainError() const throw() { return this->errors.size(); }
        /**
         * Checks if the error iteration position has reached the end
         * @return true if so; otherwise false
         */
        inline bool EndOfErrors() const throw() { return this->CIP >= this->errors.size(); }
        /**
         * Get errors' count which `this` container contains
         * @return The # of errors `this` contains
         */
        inline size_t getErrorsCount() const throw() { return this->errors.size(); }
        /**
         * Fetches the next error when iterator pointer points at and incearses the iterator pointer by one
         * @return The lexError
         */
        inline pair<std::string, const BC::Lexer::lexNode*> getNextError() const throw() { return this->errors.at(this->CIP++); }
        /**
         * Adds a new error to error container
         * @param msg The error message
         * @param node The lexNode that error belongs to
         */
        void AddError(std::string msg, const BC::Lexer::lexNode* const node) throw() { this->errors.push_back(pair<std::string, const BC::Lexer::lexNode*>(msg, node)); }
    };
} }
#endif	/* ERRORCOLLECTOR_HPP */
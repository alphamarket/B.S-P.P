/*
 * File:   lexValidator.hpp
 * Author: dariush
 *
 * Created on April 3, 2014, 8:35 PM
 */
#ifndef LEXVALIDATOR_HPP
#define	LEXVALIDATOR_HPP
#include "lexerstrap.hpp"
NS BC { NS Lexer {
    class lexValidator {
    public:
        static LexTypeEnum GeneralValidate(std::string tokenString);
        static LexTypeEnum OperatorValidate(std::string tokenString);
        static LexTypeEnum MarkValidate(std::string tokenString);
        static LexTypeEnum KeywordValidate(std::string tokenString);
        static inline bool IS_GEN_SEPARATOR(std::string tokenString) { return tokenString == ":";}
        static inline bool IS_OP_EQ(std::string tokenString) { return tokenString == "=";}
        static inline bool IS_OP_LT(std::string tokenString) { return tokenString == "<";}
        static inline bool IS_OP_GT(std::string tokenString) { return tokenString == ">"; }
        static inline bool IS_OP_LE(std::string tokenString) { return tokenString == "<=" || tokenString == "=<"; }
        static inline bool IS_OP_GE(std::string tokenString) { return tokenString == ">=" || tokenString == "=>"; }
        static inline bool IS_OP_NE(std::string tokenString) { return tokenString == "<>" || tokenString == "><"; }
        static inline bool IS_OP_AND(std::string tokenString) { return tokenString == "AND"; }
        static inline bool IS_OP_OR(std::string tokenString) { return tokenString == "OR"; }
        static inline bool IS_OP_NOT(std::string tokenString) { return tokenString == "NOT"; }
        static inline bool IS_OP_EXP(std::string tokenString) { return tokenString == "^"; }
        static inline bool IS_OP_MUL(std::string tokenString) { return tokenString == "*"; }
        static inline bool IS_OP_DIV(std::string tokenString) { return tokenString == "/"; }
        static inline bool IS_OP_ADD(std::string tokenString) { return tokenString == "+"; }
        static inline bool IS_OP_SUB(std::string tokenString) { return tokenString == "-"; }
        static inline bool IS_OP_CONCAT(std::string tokenString) { return IS_OP_ADD(tokenString); }
        static inline bool IS_KWD_CLOSE(std::string tokenString) { return tokenString == "CLOSE"; }
        static inline bool IS_KWD_DATA(std::string tokenString) { return tokenString == "DATA"; }
        static inline bool IS_KWD_DIM(std::string tokenString) { return tokenString == "DIM"; }
        static inline bool IS_KWD_END(std::string tokenString) { return tokenString == "END"; }
        static inline bool IS_KWD_FOR(std::string tokenString) { return tokenString == "FOR"; }
        static inline bool IS_KWD_TO(std::string tokenString) { return tokenString == "TO"; }
        static inline bool IS_KWD_STEP(std::string tokenString) { return tokenString == "STEP"; }
        static inline bool IS_KWD_GOTO(std::string tokenString) { return tokenString == "GOTO"; }
        static inline bool IS_KWD_GOSUB(std::string tokenString) { return tokenString == "GOSUB"; }
        static inline bool IS_KWD_IF(std::string tokenString) { return tokenString == "IF"; }
        static inline bool IS_KWD_THEN(std::string tokenString) { return tokenString == "THEN"; }
        static inline bool IS_KWD_INPUT(std::string tokenString) { return tokenString == "INPUT"; }
        static inline bool IS_KWD_OUTPUT(std::string tokenString) { return tokenString == "OUTPUT"; }
        static inline bool IS_KWD_LET(std::string tokenString) { return tokenString == "LET"; }
        static inline bool IS_KWD_NEXT(std::string tokenString) { return tokenString == "NEXT"; }
        static inline bool IS_KWD_OPEN(std::string tokenString) { return tokenString == "OPEN"; }
        static inline bool IS_KWD_AS(std::string tokenString) { return tokenString == "AS"; }
        static inline bool IS_KWD_POKE(std::string tokenString) { return tokenString == "POKE"; }
        static inline bool IS_KWD_PRINT(std::string tokenString) { return tokenString == "PRINT"; }
        static inline bool IS_KWD_READ(std::string tokenString) { return tokenString == "READ"; }
        static inline bool IS_KWD_RETURN(std::string tokenString) { return tokenString == "RETURN"; }
        static inline bool IS_KWD_RESTORE(std::string tokenString) { return tokenString == "RESTORE"; }
        static inline bool IS_KWD_RUN(std::string tokenString) { return tokenString == "RUN"; }
        static inline bool IS_KWD_STOP(std::string tokenString) { return tokenString == "STOP"; }
        static inline bool IS_KWD_SYS(std::string tokenString) { return tokenString == "SYS"; }
        static inline bool IS_KWD_WAIT(std::string tokenString) { return tokenString == "WAIT"; }
        static inline bool IS_KWD_REM(std::string tokenString) { return tokenString == "REM"; }
        static inline bool IS_GEN_EMPTY(std::string tokenString) { return !tokenString.length(); }
        static inline bool IS_MRK_BRACK_OP(std::string tokenString) { return tokenString == "("; }
        static inline bool IS_MRK_BRACK_CL(std::string tokenString) { return tokenString == ")"; }
        static inline bool IS_MRK_COMMA(std::string tokenString) { return tokenString == ","; }
        static inline bool IS_MRK_SEMICLN(std::string tokenString) { return tokenString == ";"; }
        static inline bool IS_MRK_QUOTE(std::string tokenString) { return tokenString == "\""; }
        static inline bool IS_MRK_SHARP(std::string tokenString) { return tokenString == "#"; }
        static inline bool IS_GEN_PRG(std::string tokenString) { return !IS_GEN_EMPTY(tokenString); }
        static inline bool IS_GEN_OPR(std::string tokenString) { return IS_OPERATOR(tokenString); }
        static inline bool IS_GEN_KYWD(std::string tokenString) { return IS_KEYWORD(tokenString); }
        static inline bool IS_GEN_MARK(std::string tokenString) { return IS_MARK(tokenString); }
        static inline bool IS_GEN_STRING(std::string tokenString) { return tokenString.length() > 1 && tokenString[0] == '"' && tokenString[tokenString.length() - 1] == '"'; }
        static inline bool IS_GEN_LINE_NUM(std::string tokenString) { return !IS_GEN_EMPTY(tokenString) && !(tokenString[0] == '+' || tokenString[0] == '-') && IS_INTEGER_NUM(tokenString); }
        static inline bool IS_GEN_STATMNT(std::string tokenString) { return !IS_GEN_EMPTY(tokenString); }
        static bool IS_GEN_ID(std::string tokenString);
        static bool IS_GEN_NUM(std::string tokenString);
        static bool IS_REAL_NUM(std::string tokenString);
        static bool IS_INTEGER_NUM(std::string tokenString);
    };
} }
#endif	/* LEXVALIDATOR_HPP */
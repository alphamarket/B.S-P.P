/*
 * File:   lexNode.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 10:33 PM
 */
#ifndef LEXNODE_HPP
#define	LEXNODE_HPP
#include "lexerstrap.hpp"
#include <vector>
#include "../../hpp/token.hpp"
NS BC { NS Lexer {
    /**
     * A lexer node structor suited for lexering purposes
     */
    class lexNode {
    protected:
        /**
         * The next and previous siblings pointer
         */
        lexNode* nextSibling, *prevSibling;
        /**
         * The children collection of node
         */
        vector<lexNode*>* Children;
        /**
         * The parent of node
         */
        lexNode* Parent;
        /**
         * The value of node
         */
        token* Value;
        /**
         * The index of current child in it parrent
         * @note <b>muted</b> Can change in constent flagged operations
         */
        mutable size_t parentIndex;
    public:
        /**
         * Construct an empty lexNode
         */
        inline lexNode() { this->__init(NULL, NULL); }
        /**
         * Construct a parent-less lexNode
         * @param _value The value of the node.
         */
        inline lexNode(token* const _value) { this->__init(_value, NULL); }
        /**
         * Construct a lexNode with a value and a parent
         * @param _value The node's value
         * @param parent The node's parent
         */
        inline lexNode(token* const _value, lexNode* const _parent) { this->__init(_value, _parent); }
        /**
         * Add a child to children's list's end
         * @param _child The child token
         * @return The lexNode pointer of added child
         */
        inline lexNode* addChild(token* const _child) { return this->addChild(new lexNode(_child)); }
        /**
         * Get count of children
         */
        inline size_t getChildrenCount() const { return this->Children->size(); }
        /**
         * Check if current node has any child
         */
        inline bool hasChildren() const { return this->getChildrenCount() > 0; }
        /**
         * Get a readonly vector of children list, But the children themselves can be manipulated
         */
        inline const vector<lexNode*>* getChildren() const { return this->Children; }
        /**
         * Check if current node is a root(i.e has no parrent)
         */
        inline bool isRoot() const { return this->Parent == NULL; }
        /**
         * Check if current node is a leaf(i.e has no child)
         */
        inline bool isLeaf() const { return !this->hasChildren(); }
        /**
         * Get current node's value
         * @return The token of current node
         */
        inline token* getValue() const { return this->Value; }
        /**
         * Set current's node's value
         * @param _value The token of curent node
         */
        inline void setValue(token* const _value) { this->Value = _value; }
        /**
         * Get current node's parent
         */
        inline lexNode* getParent() const {return this->Parent; }
        /**
         * Set current node's parent
         * @param _parent The parent of current node
         */
        inline void setParent(lexNode* const _parent) { this->Parent = _parent; if(_parent != NULL && _parent->__getChildIndex(this) == -1) _parent->addChild(this); }
        /**
         * unlink a child, but the child still exists in memroy(i.e NOT deleted).
         * @param index The child's index
         * @return The unlinked child if unlinking was successful; otherwise NULL.
         */
        inline lexNode* unLinkChild(size_t index) { return this->unLinkChild(this->getChild(index));}
        /**
         * deletes a child from memory, the child children will not accessible after this.
         * @param index The child's index
         * @return true if deletion was successful; otherwise false.
         */
        inline bool deleteChild(size_t index) { lexNode* __ln = this->getChild(index); return this->deleteChild(__ln);}
        /**
         * Clears all children which `this` node contains
         */
        inline void clearChildren() { this->Children->clear(); }
        /**
         * Add next sibling to current node
         * @param next The sibling
         */
        inline void setNextSibling(lexNode* const next) { this->nextSibling = next; if(next != NULL) next->prevSibling = this;}
        /**
         * Add previous sibling to current node
         * @param previous The sibling
         */
        inline void setPrevSibling(lexNode* const prev) { this->prevSibling = prev; if(prev != NULL) prev->nextSibling = this;}
        /**
         * Get next sibling to current node
         * @return The next sibling
         */
        inline lexNode* getNextSibling() const { return this->nextSibling; }
        /**
         * Get previous sibling to current node
         * @return The previous sibling
         */
        inline lexNode* getPrevSibling() const { return this->prevSibling; }
        /**
         * Check wheter is there any next siblings or not
         */
        inline bool hasNextSibling() const { return this->nextSibling != NULL; }
        /**
         * Check wheter is there any prev siblings or not
         */
        inline bool hasPrevSibling() const { return this->prevSibling != NULL; }
        /**
         * Unlinks the next siblings
         * @return The unlinked siblings
         */
        inline lexNode* unlinkNextSibling() { lexNode* ns = this->nextSibling; this->nextSibling = NULL; return ns; }
        /**
         * Unlinks the previous siblings
         * @return The unlinked siblings
         */
        inline lexNode* unlinkPrevSibling() { lexNode* ns = this->nextSibling; this->nextSibling = NULL; return ns; }
        /**
         * replace a child in a index which already exists
         * @param index The target child
         * @param node The target node
         */
        inline void setChild(size_t index, lexNode* node) { this->Children->at(index) = (node); }
        /**
         * Construct a lexNode from an other one
         * @param orig The origin lexNode
         */
        lexNode(const lexNode& orig);
        /**
         * Get child at passed index
         * @param index The child's index
         * @return The children
         */
        lexNode* getChild(size_t index) const;
        /**
         * Add a child to children's list's end
         * @param _child The child node
         * @return The child node(Input) for convention
         */
        lexNode* addChild(lexNode* const _child);
        /**
         * unlink a child, but the child still exists in memroy(i.e NOT deleted).
         * @param _lexNode The target child.
         * @return true if unlinking was successful; otherwise false.
         */
        virtual lexNode* unLinkChild(lexNode* const _lexNode);
        /**
         * deletes a child from memory, the child children will not accessible after this.
         * @param _lexNode The target child.
         * @return true if deletion was successful; otherwise false.
         */
        virtual bool deleteChild(lexNode*& _lexNode);
        /**
         * Unlink current node from its parent, if you delete `this` node after this, it is like that you
         * `deleteChild(this)` in parrent node.
         * @return return `this` node.
         */
        virtual lexNode* unlinkFromParent();
        /**
         * Deletes all resources contained by `this` node and its children and also from its parent
         */
        virtual ~lexNode() throw() ;
    protected:
        /**
         * Initialize this instance with its arguments
         * @param _value The node's value
         * @param parent The node's parent
         * @return `this` instance
         */
        lexNode* __init(token* const _value, lexNode* const _parent);
        /**
         * Get child index among the children
         * @param _lexNode The child pointer to check
         * @note It will automatically update the passed node's parrentIndex value
         * @return if child exists among children returns greater than 0; otherwise if
         * &nbsp;&nbsp;the child does NOT exits returns -1.
         */
        int __getChildIndex(const lexNode* const _lexNode) const;
    };
} }
#endif	/* LEXNODE_HPP */
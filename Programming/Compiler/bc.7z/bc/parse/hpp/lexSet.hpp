/*
 * File:   lexSet.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 10:28 PM
 */
#ifndef lexSet_HPP
#define	lexSet_HPP
#include "lexerstrap.hpp"
#include "lexNode.hpp"
#include <vector>
NS BC { NS Lexer {
    class lexSet {
    private:
        /**
         * The Current Iteration Position of sets
         * @Note <b>muted</b> so constant operations allowed to modify it.
         */
        mutable size_t CIP;
        /**
         * The sets collection
         */
        vector<lexNode*>* sets;
        /**
         * The set's name
         */
        std::string name;
    public:
        /**
         * Construct a lexSet with `default`name.
         */
        inline lexSet() { this->__init("default"); }
        /**
         * Construct a lexSet
         * @param name The name of set
         */
        inline lexSet(std::string name) { this->__init(name); }
        /**
         * Get a readonly vector of sets, but the subset can be manipulated.
         * @return the sets vector
         */
        inline const vector<lexNode*>* getSets() const { return  this->sets; }
        /**
         * Initialize the iterator for iterations used by `lexSet::getNextSet()`
         */
        inline void initIterator() { this->CIP = 0; }
        /**
         * Get subsets' count
         */
        inline size_t getSetCount() const { return this->sets->size(); }
        /**
         * Clear the subsets
         * @Note It does NOT delete sets to free occupied memory.<br />
         * &nbsp;&nbsp;delete() current instace of `lexSet` and create new set for
         * &nbsp;&nbsp;releasing memory.
         */
        inline void clearSets() { this->sets->clear(); }
        /**
         * Get current set's name
         */
        inline std::string getName() { return this->name; }
        /**
         * Frees all resources used by current instance
         */
        virtual ~lexSet();
        /**
         * Builds a set from an other set
         */
        lexSet(const lexSet& orig);
        /**
         * Get next set(For iteration)
         * @return Next set or NULL if there is no next set.
         */
        lexNode* getNextSet();
        /**
         * Adds subset to sets
         * @param subset The subset
         * @return The added subset
         */
        lexNode* addSubSet(lexNode* const subset);
        /**
         * Unlinks a subset from sets
         * @param index The subset's index
         * @return The unlined subset's pointer, or NULL if index is out of range
         */
        lexNode* unlinkSubSet(size_t index);
    protected:
        /**
         * Initialize an instance of `lexSet`
         * @param name The name of set
         * @return
         */
        lexSet* __init(std::string name);
    };
} }
#endif	/* lexSet_HPP */
/*
 * File:   lexParser.hpp
 * Author: dariush
 *
 * Created on March 30, 2014, 2:34 PM
 */
#ifndef PARSER_HPP
#define	PARSER_HPP
#include "../../hpp/source.hpp"
#include "lexerstrap.hpp"
#include "lexSet.hpp"
#include "lexErrorCollector.hpp"
NS BC { NS Lexer {
    typedef  lexErrorCollector LexParserException;
    class lexParser {
    protected:
        source* s;
    public:
        /**
         * Construct a lexParse
         * @param __source The source to bind
         */
        lexParser(source* const __source);
        /**
         * Get bounded source code
         */
        inline const source* getSource() const { return this->s; }
        /**
         * Initiate the parse of source
         * @return The lexSet from parsing the source
         */
        lexSet* parse() const;
    protected:
        /**
         * Construct an empty node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* EmptyConstructor(std::string token, const line* const __line) const;
        /**
         * Construct an ID node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* IDConstructor(std::string token, const line* const __line) const;
        /**
         * Construct a keyword node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* KeywordConstructor(std::string token, const line* const __line) const;
        /**
         * Construct a mark node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* MarkConstructor(std::string token, const line* const __line) const;
        /**
         * Construct a number node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* NumberConstructor(std::string token, const line* const __line) const;
        /**
         * Construct an operator node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* OperatorConstructor(std::string token, const line* const __line) const;
        /**
         * Construct a command separator(AKA `:`) node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* CommandSepConstructor(std::string token, const line* const __line) const;
        /**
         * Construct a literal string node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* StringConstructor(std::string token, const line* const __line) const;
        /**
         * Construct an unknown node
         * @param token The token string to construct from
         * @param __line The related line to construct from
         * @return The lexNode
         */
        lexNode* UnknownConstructor(std::string token, const line* const __line) const;
    };
} }
#endif	/* PARSER_HPP */
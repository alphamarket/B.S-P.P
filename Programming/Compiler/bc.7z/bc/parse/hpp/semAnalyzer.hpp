/*
 * File:   semAnalyzer.hpp
 * Author: dariush
 *
 * Created on April 4, 2014, 7:25 PM
 */
#ifndef SEMANALYZER_HPP
#define	SEMANALYZER_HPP
#include "lexerstrap.hpp"
#include "lexSet.hpp"
#include "lexParser.hpp"
#include "../../hpp/utils.hpp"
#include <stack>
#include <unordered_map>
UN BC::Lexer;
NS BC { NS Sem {
    class semAnalyzer {
        /**
         * The lexSet from contructor
         */
        lexSet* __lexSet;
        /**
         * The lexErrorCollector
         */
        LexParserException errors;
        /**
         * The map collection for lines
         */
        std::unordered_map<std::string, const line*> lineMaps;
        /**
         * The map collection for IDs
         */
        std::unordered_map<std::string, const line*> IDMaps;
    public:
        /**
         * Construct a semantic analyzer
         * @param _lexSet the The processed lexSet from `lexParser`
         */
        semAnalyzer(lexSet* _lexSet);
        /**
         * Destruct the semantic analyzer
         */
        virtual ~semAnalyzer();
        /**
         * Apply the analysis on provided lexSet fom constructor
         */
        void analyze();
        /**
         * If any error generated during the analyzing; throw it.
         */
        void throwOnError() const { if(this->errors.IsContainError()) throw this->errors; }
    private:
        /**
         * Add new error with a message for a node
         */
        void addError(std::string msg, const lexNode* const node) { errors.AddError(utils::genErrorStr(msg, this->__lexSet->getName(), node->getValue()->getRelatedLine()->getLineNumber() + 1), node); }
    protected:
        /**
         * validate the first node of a parent node
         * @param node the first child of a parent node
         * @param __stack the stack of parent nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateFirstToken(lexNode* node, stack<lexNode*> __stack);
        /**
         * validate the empty node of a parent node
         * @param node the first child of a parent node
         * @param __stack the stack of parent nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateEmptyLine(lexNode* node, stack<lexNode*> __stack);
        /**
         * check general rules
         * @param node the node to validate
         * @param __stack the previous nodes
         * @return true if general validator can accept any other node of passed node's siblings; otherwise false.
         */
        bool validateGeneralToken(const lexNode* node, stack<lexNode*>* __stack);
        /**
         * registers an ID in ID's map
         * @param id The ID token
         * @param __line The related line
         */
        inline void registerID(std::string id, const line* __line) { this->IDMaps.insert(pair<std::string, const line*>(id, __line)); }
        /**
         * registers a line# in line's map
         * @param lineNo The line#
         * @param __line The related line
         */
        inline void registerLine(std::string lineNo, const line* __line) { this->lineMaps.insert(pair<std::string, const line*>(lineNo, __line)); }
        /**
         * checks if an ID has already been registered
         * @param id The ID token
         * @return true if ID has already been registered; otherwise false
         */
        inline const line* HasIDRegistered(std::string id) const { return this->IDMaps.count(id) ? this->IDMaps.at(id) : NULL; }
        /**
         * checks if a line# has already been registered
         * @param lineNo The line#
         * @return true if line# has already been registered; otherwise false
         */
        inline const line* HasLineRegistered(std::string lineNo) const { return this->lineMaps.count(lineNo) ? this->lineMaps.at(lineNo) : NULL; }
        /**
         * validate if the node matches as a `general` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateExpression(lexNode*& node, stack<lexNode*>* __stack, bool valueCheck = false, bool forceBracketCheck = false);
        /**
         * validate if the node matches as a `add` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateAndExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `not` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateNotExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `compare` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateCompareExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `add` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateAddExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `multiply` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateMultExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `negative` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateNegExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `power` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validatePowerExpression(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node matches as a `value` expression
         * @param node the node to validate
         * @param __stack the stack of previously processed nodes
         * @return true if the validation succeed; otherwise false
         */
        bool validateValue(lexNode*& node, stack<lexNode*>* __stack);
        /**
         * validate if the node's brackets are aligned correctly
         * @param node the node to validate
         * @return true if the validation succeed; otherwise false
         */
        bool validateBracket(lexNode* node);
    protected:
        /**
         * Get type of a node
         * @param node The target node
         * @return The `LEXTE` type of the node
         */
        inline LEXTE getType(const lexNode* const node) const { return node->getValue()->getType(); }
        /**
         * Get context of a ndoe
         * @param node The target node
         * @return The context of the node
         */
        inline std::string getText(const lexNode* const node) const { return node->getValue()->getText(); }
        /**
         * Gives the node's next sibling
         * @param node The target node
         * @return The next sibling if any exists; otherwise returns NULL
         */
        inline lexNode* moveToNextSibling(const lexNode* const node) const { return node?node->getNextSibling():NULL; }
        /**
         * Gives the node's previous sibling
         * @param node The target node
         * @return The previous sibling if any exists; otherwise returns NULL
         */
        inline lexNode* moveToPrevSibling(const lexNode* const node) const { return node?node->getPrevSibling():NULL; }
        /**
         * Counts the next siblings' #
         * @param node The target node
         * @return The next siblings' #
         */
        inline size_t getNextSiblingsCount(const lexNode* const node) const { size_t count = 0; const  lexNode* tmp = node; while((tmp = this->moveToNextSibling(tmp))) count++; return count; }
        /**
         * Counts the previous siblings' #
         * @param node The target node
         * @return The previous siblings' #
         */
        inline size_t getPrevSiblingsCount(const lexNode* const node) const { size_t count = 0; const lexNode* tmp = node; while((tmp = this->moveToPrevSibling(tmp))) count++; return count; }
    };
} }
#endif	/* SEMANALYZER_HPP */
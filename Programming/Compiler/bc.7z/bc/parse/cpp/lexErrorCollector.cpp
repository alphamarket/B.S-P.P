/*
 * File:   errorCollector.cpp
 * Author: dariush
 *
 * Created on April 4, 2014, 2:31 PM
 */
#include "../hpp/lexErrorCollector.hpp"
/*
 * File:   lexParser.cpp
 * Author: dariush
 *
 * Created on March 30, 2014, 2:34 PM
 */
#include "../hpp/lexParser.hpp"
#include "../hpp/lexValidator.hpp"
#include "../../hpp/token.hpp"
#include "../hpp/lexErrorCollector.hpp"
UN BC;
NS BC { NS Lexer {
    lexParser::lexParser(source* const __source) {
        /* the source cannot be NULL */
        if(__source == NULL)
            throw std::invalid_argument("The source cannot be NULL!");
        /* if the source has not been processed */
        if(!__source->hasProcessed())
            /* process it */
            __source->process();
        /* register the source */
        this->s = __source;
    }
    lexSet* lexParser::parse() const {
        /* if no line count exists */
        if(!this->s->getLineCount())
            /* flag it */
            throw std::invalid_argument("Nothing exists to parse!");
        /* create a lexer set */
        lexSet* __lexSet = new lexSet(this->s->getSourceFile());
        /* initially no line exists for processing */
        line* __line = NULL;
        /* invoke a lexer error collector */
        lexErrorCollector lec;
        /* while there is a line? read it */
        while((__line = this->s->readNext())) {
            /* tokenize the line */
            vector<string> __tokens = __line->Tokenize();
            /* create a parent lexNode */
            lexNode* __ln =  new lexNode();
            /* if no token exists */
            if(!__tokens.size()) {
                /* flag current line as an empty line */
                __ln->setValue(new token(__line->getContent(), LEXTE::GEN_EMPTY, __line));
                /* proceed with other lines */
                continue;
            }
            /* foreach token in current line */
            for(int Tindex = 0; Tindex < __tokens.size(); Tindex++)
            {
                /* determine general token type of current token */
                LEXTE lte = lexValidator::GeneralValidate(__tokens[Tindex]);
                /* create a child lexNode */
                lexNode* __lnc =NULL;
                /* foreach specified general type of current token */
                /* create a proper formatted child node */
                switch(lte) {
                    case LEXTE::GEN_EMPTY:
                        __lnc = this->EmptyConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_ID:
                        __lnc = this->IDConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_KYWD:
                        __lnc = this->KeywordConstructor(__tokens[Tindex], __line);
                        /* if this is a `REM` keyword? */
                        if(lexValidator::KeywordValidate(__tokens[Tindex]) == LEXTE::KWD_REM) { /* don't process other tokens */Tindex = __tokens.size(); }
                        break;
                    case LEXTE::GEN_MARK:
                        __lnc = this->MarkConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_NUM:
                        __lnc = this->NumberConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_OPR:
                        __lnc = this->OperatorConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_SEPARATOR:
                        __lnc = this->CommandSepConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_STRING:
                        __lnc = this->StringConstructor(__tokens[Tindex], __line);
                        break;
                    case LEXTE::GEN_UNKNOWN:
                        /* UNKNOWN tokens are error in lex-parsing phase */
                        lec.AddError(utils::genErrorStr("unknown token `"+__tokens[Tindex]+"`", this->s->getSourceFile(), __line->getLineNumber() + 1),  this->UnknownConstructor(__tokens[Tindex], __line));
                        break;
                    default:
                        /* notify the unmatching general type */
                        delete(__ln);
                        delete(__lexSet);
                        throw std::invalid_argument("Undefined type lexType!");
                }
                if(__lnc)
                    /* add child node to parent */
                    __ln->addChild(__lnc);
            }
            if(__ln->getChildrenCount())
                /* add parent node to lex-set */
                __lexSet->addSubSet(__ln);
        }
        /* if any error collected? */
        if(lec.IsContainError())
            /* throw it */
            throw lec;
        /* return constructed lex-set */
        return __lexSet;
    }
    lexNode* lexParser::EmptyConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_EMPTY(token))
            throw std::invalid_argument("The passed token is not Empty!");
        /* create an empty node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_EMPTY, __line));
    }
    lexNode* lexParser::IDConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_ID(token))
            throw std::invalid_argument("The passed token is not in a ID format!");
        /* create an ID node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_ID, __line));
    }
    lexNode* lexParser::KeywordConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_KYWD(token))
            throw std::invalid_argument("The passed token is not in Keywords' list!");
        /* create a keyword node */
        return new BC::Lexer::lexNode(new BC::token(token, lexValidator::KeywordValidate(token), __line));
    }
    lexNode* lexParser::MarkConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_MARK(token))
            throw std::invalid_argument("The passed token is not in Marks' list!");
        /* create a mark node */
        return new BC::Lexer::lexNode(new BC::token(token, lexValidator::MarkValidate(token), __line));
    }
    lexNode* lexParser::NumberConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_NUM(token))
            throw std::invalid_argument("The passed token is not a Number!");
        /* create a number node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_NUM, __line));
    }
    lexNode* lexParser::OperatorConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_OPR(token))
            throw std::invalid_argument("The passed token is not in Operators' list!");
        return new BC::Lexer::lexNode(new BC::token(token, lexValidator::OperatorValidate(token), __line));
    }
    lexNode* lexParser::CommandSepConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_SEPARATOR(token))
            throw std::invalid_argument("The passed token is not in Operators' list!");
        /* create a separator node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_SEPARATOR, __line));
    }
    lexNode* lexParser::StringConstructor(std::string token, const line* const __line) const {
        /* confirm type */
        if(!lexValidator::IS_GEN_STRING(token))
            throw std::invalid_argument("The passed token is not in a String format!");
        /* create a literal string node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_STRING, __line));
    }
    lexNode* lexParser::UnknownConstructor(std::string token, const line* const __line) const {
        /* create an unknown node */
        return new BC::Lexer::lexNode(new BC::token(token, LEXTE::GEN_UNKNOWN, __line));
    }
} }
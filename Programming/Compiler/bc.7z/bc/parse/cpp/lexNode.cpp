/*
 * File:   lexNode.cpp
 * Author: dariush
 *
 * Created on March 30, 2014, 10:33 PM
 */
#include "../hpp/lexNode.hpp"
NS BC { NS Lexer {
    lexNode* lexNode::__init(token* const _value, lexNode* const _parent) {
        /* set value */
        this->setValue(_value);
        /* set parent */
        this->setParent(_parent);
        /* init children vector */
        this->Children = new vector<lexNode*>();
        /* by default this is the first children of its parrent */
        /* it will update when adding `this` node as child to a node */
        this->parentIndex = 0;
        /* initialy there is no sibling*/
        this->setNextSibling(NULL);
        this->setPrevSibling(NULL);
        /* return `this` node */
        return this;
    }
    lexNode::lexNode(const lexNode& orig) {
        /* construct the value and parent */
        this->__init(orig.Value, orig.Parent);
        /* foreach child in orig's children */
        for(int child = 0; child < orig.Children->size(); child++)
            this->addChild(orig.Children->at(child));
    }
    lexNode::~lexNode() throw() {
        /* first safely unlink it from its parent */
        this->unlinkFromParent();
        /* delete its value */
        delete(this->Value);
        /* initially we hav this count of children */
        const size_t initChildrenCount = this->getChildrenCount();
        /* initially no child as been deleted yet */
        register size_t childDeleted = 0;
        /* foreach child in children */
        while(this->hasChildren())
        {
            /* delete the ground child */
            this->deleteChild(size_t(0));
            /* a fail safe for limited delete child */
            if(++childDeleted >= initChildrenCount) break;
        }
        /* delete children container */
        delete(this->Children);
        /* unlink from siblings */
        if(this->nextSibling != NULL && this->prevSibling != NULL)
            this->nextSibling->setPrevSibling(this->prevSibling);
        /* unlink from next sibling */
        else if(this->nextSibling != NULL)
            this->nextSibling->setPrevSibling(NULL);
        /* unlink from prev sibling */
        else if(this->prevSibling != NULL)
            this->prevSibling->setNextSibling(NULL);
        /* nil siblings */
        this->prevSibling = this->nextSibling = NULL;
    }
    lexNode* lexNode::addChild(lexNode* const _child) {
        /* if child is NULL don't add it */
        if(_child == NULL) return NULL;
        /* update the parent of child */
        if(_child->Parent != this)
            _child->Parent = this;
        /* update the child's parent index */
        _child->parentIndex = this->Children->size();
        /* next sibling of latest child so far */
        if(this->Children->size())
            this->Children->back()->setNextSibling(_child);
        /* add the child into children collection */
        this->Children->push_back(_child);
        /* return the child */
        return _child;
    }
    int lexNode::__getChildIndex(const lexNode* const _lexNode) const {
        /* if is NULL, so ... FUCK NO */
        if(_lexNode == NULL) return -1;
        /* test the primary index of node */
        if(_lexNode->parentIndex < this->Children->size()
           &&
           this->Children->at(_lexNode->parentIndex) == _lexNode)
            /* no need for further check */
            return _lexNode->parentIndex;
        /* search among children */
        for(int index = 0; index < this->Children->size(); index++)
            if(this->Children->at(index) == _lexNode)
                return (_lexNode->parentIndex = index);
        return -1;
    }
    lexNode* lexNode::unLinkChild(lexNode* const _lexNode) {
        /* if `this` is not the parent of passed child */
        if (_lexNode->Parent != this) return NULL;
        /* disconnect parent from child */
        _lexNode->Parent = NULL;
        if(
                /* try to update the child's index in `this` children collection */
                (_lexNode->parentIndex >= this->Children->size()  && (this->__getChildIndex(_lexNode)) == -1)
                &&
                /* if child does not exist among `this` children collection */
                (this->getChild(_lexNode->parentIndex) != _lexNode && (this->__getChildIndex(_lexNode)) == -1)
            )
            /* if child does not exist among `this` children collection */
            return NULL;
        /* unlink from children collection */
        this->Children->erase(this->Children->begin() + _lexNode->parentIndex);
        /* update the rest of children's parentIndex by descending by one */
        for(
                std::vector<lexNode*>::iterator child = this->Children->begin() + _lexNode->parentIndex;
                child != this->Children->end();
                (*child)->parentIndex--, child++
           ) /* No internal process for loop */ ;
        /* indicate the successful unliking */
        return _lexNode;
    }
    bool lexNode::deleteChild(lexNode*& _lexNode) {
        /* if node is null */
        if(_lexNode == NULL) return false;
        /* unlink/delete the node */
        delete(this->unLinkChild(_lexNode));
        /* nil the pointer */
        _lexNode = NULL;
        /* flag the succession */
        return true;
    }
    lexNode* lexNode::unlinkFromParent() {
        /* if no parrent exists */
        if(this->Parent == NULL) return this;
        /* unlink from parent `this` child */
        this->Parent->unLinkChild(this);
        /* return `this` node */
        return this;
    }
    lexNode* lexNode::getChild(size_t index) const {
        /* check for overflowness */
        if(index >= this->getChildrenCount())
            throw std::overflow_error("Index overflow!");
        /* return the child at the index */
        return this->Children->at(index);
    }
} }
/*
 * File:   semAnalyzer.cpp
 * Author: dariush
 * Used Grammar: http://rosettacode.org/wiki/BNF_Grammar#BASIC
 * Created on April 4, 2014, 7:25 PM
 */
#include "../hpp/semAnalyzer.hpp"
#include "../hpp/lexValidator.hpp"
NS BC { NS Sem {
    semAnalyzer::semAnalyzer(lexSet* _lexset) {
        /* the lex-set cannot be empty or NULL */
        if(!_lexset || !_lexset->getSetCount())
            throw std::invalid_argument("Lexset cannot be NULL or Empty");
        /* register the lex-set */
        this->__lexSet = _lexset;
    }
    semAnalyzer::~semAnalyzer() {
    }
    void semAnalyzer::analyze() {
        /* create an alias for LEXTE */
        typedef LEXTE L;
        /* re-init the registered lex-set */
        this->__lexSet->initIterator();
        /* initially no parent node is processing */
        lexNode* pnode = NULL;
        /* create a head-set stack for collecting headlines */
        stack<lexNode*> headsets;
        /* while there is a set to read? read it */
        while((pnode = this->__lexSet->getNextSet())) {
            /* create a miniature-set for internal processing purposes */
            stack<lexNode*> miniatureSet;
            /* if the parent node has value and is in empty mode */
            if(pnode->getValue() && pnode->getValue()->getType() == L::GEN_EMPTY) {
                /* validate current parent node */
                this->validateEmptyLine(pnode, headsets);
                /* stack current parent node as processed */
                headsets.push(pnode);
                /* continue with other sets */
                continue;
            }
            /* if parent node does not have value then should have some child */
            /* if parent ndoe does not have any children? */
            if(!pnode->getChildrenCount()) {
                /* with is my program's fault and this should no happent */
                stringstream ss;
                /* build a proper formatted expcetion detail */
                ss<<"genaral invalid statement `"<<__FILE__<<"` at "<<__LINE__;
                /* throw a logical error */
                throw std::logic_error(ss.str());
            }
            /* since the first child of every parent node is a special child! */
            /* we process it exclusively */
            if(!this->validateFirstToken(pnode->getChild(size_t(0)), headsets)) continue;
            /* push first processed pnode into miniature */
            miniatureSet.push(pnode->getChild(size_t(0)));
            /* general validation */
            this->validateGeneralToken(pnode, &miniatureSet);
            /* ultimately */
            headsets.push(pnode);
        }
        /* if any error collected? */
        if(this->errors.IsContainError())
            /* throw the errors */
            throw this->errors;
    }
    bool semAnalyzer::validateFirstToken(lexNode* node, stack<lexNode*> __stack) {
        /* create an alias for LEXTE */
        typedef LEXTE L;
        /* if the first node is a command separator? */
        if(this->getType(node) == L::GEN_SEPARATOR) {
            /* fail-safe checkpoint for very-first command line */
            /* there SHOULD BE at least one line before */
            if(!__stack.size()) {
                this->addError("expected line `number`", node);
                return false;
            }
            return true;
        }
        /* else if the first node is a number, this SHOULD BE an integer */
        if (!(this->getType(node) == L::GEN_NUM && lexValidator::IS_GEN_LINE_NUM(node->getValue()->getText()))) {
            this->addError("lines should always start with `unsigned digits`", node);
            return false;
        }
__RETURN_TRUE:
        /* if previously no line# like current line# defined? */
        if(this->HasLineRegistered(this->getText(node))) {
            /* no  tolerated for line# duplication */
            std::stringstream ss;
            /* build a proper error text */
            ss<<"The line# `"<<this->getText(node)<<"` has already been declared";
            /* add to error collection */
            this->addError(ss.str(), node);
            return false;
        }
        /* register the line# */
        this->registerLine(this->getText(node), node->getValue()->getRelatedLine());
        return true;
    }
    bool semAnalyzer::validateEmptyLine(lexNode* pnode, stack<lexNode*> __stack) {
        /* all empty line accepted */
        return true;
    }
/** Add Error */
#define AE(m) this->addError(m, node)
/** Add `invalid/expecting` Error */
#define IE2(m, n) AE("invalid `"+m+"` expecting `"+n+"`")
/** Add `invalid` Error */
#define IE1(m) AE("invalid `"+m+"`")
/** Shortcut for Add `invalid/expecting` Error, based on `node`'s text */
#define IE0(n) IE2(this->getText(node), n)
/** Checks to make sure no further sibling exists */
#define DEADEND if(this->moveToNextSibling(node)) { this->addError("invalid `"+this->getText(this->moveToNextSibling(node))+"`", node); }
/** Makes sure that `node` has already been registered */
#define CHECK_ID_EXISTS if(!this->HasIDRegistered(this->getText(node))) { AE("undefined `"+this->getText(node)+"` variable"); return false; }
    bool semAnalyzer::validateGeneralToken(const lexNode* pnode, stack<lexNode*>* miniatureSet) {
/** Move Forward : stacks the `node` and move the `node` to its next sibling */
#define MF miniatureSet->push(node); node = this->moveToNextSibling(node)
        /* create an alias for LEXTE */
        typedef LEXTE L;
        /* parent node cannot be NULL */
        if(!pnode)
            throw std::invalid_argument("The `pnode` cannot be NULL!");
        /* start general processing from the next child{child# 1} */
        for(size_t index = 1; index < pnode->getChildrenCount(); index++) {
            /* fetch a child */
            lexNode* node = pnode->getChild(index);
            /* if no value exists it means the child node is also a root of a subtree by itself */
            if(!node->getValue()) {
                /* recursive validation for the child node */
                this->validateGeneralToken(node, miniatureSet);
                /* after child node validated proceed with other children */
                continue;
            }
            /* for each head-keywords */
            switch(this->getType(node)) {
                /* KYWD{CLOSE} */
                case L::KWD_CLOSE:
                    if(this->getNextSiblingsCount(node) != 2) {
                        AE("invalid `CLOSE` statement");
                        return false;
                    }
                    MF;
                    if(this->getType(node)  != L::MRK_SHARP) {
                        IE0("#");
                        return false;
                    }
                    MF;
                    if(this->getType(node) != L::GEN_NUM || !lexValidator::IS_INTEGER_NUM(this->getText(node))) {
                        IE0("integer");
                        return false;
                    }
                    miniatureSet->push(node);
                    DEADEND;
                    return true;
                /* KYWD{DATA} */
                case L::KWD_DATA: {
                        if(this->getNextSiblingsCount(node) < 1) {
                            AE("invalid `DATA` statement");
                            return false;
                        }
                        miniatureSet->push(node);
                        unsigned int flip = 1;
                        while((node = this->moveToNextSibling(node))) {
                            if(!node->getValue()) {
                                AE("invalid `DATA` statement");
                                return false;
                            }
                            if(flip == 1) {
                                if( this->getType(node) != L::GEN_NUM && this->getType(node) != L::GEN_STRING) {
                                    IE0("constant");
                                    return false;
                                }
                                flip = 2;
                            } else if(flip == 2) {
                                if(this->getType(node) != L::MRK_COMMA) {
                                    IE0("`,`");
                                    return false;
                                }
                                flip = 1;
                            } else {
                                throw std::invalid_argument("invalid `flip` value");
                            }
                            miniatureSet->push(node);
                        }
                        if(miniatureSet->top()->getValue()->getType() == L::MRK_COMMA) {
                            this->addError("invalid `,` at the end of line", miniatureSet->top());
                            return false;
                        }
                        DEADEND;
                    }
                    return true;
                /* KYWD{DIM} */
                case L::KWD_DIM: {
                        if(this->getNextSiblingsCount(node) < 4) {
                            AE("invalid `DIM` statement");
                            return false;
                        }
                        MF;
                        if(!node->getValue()) {
                            AE("invalid `DIM` statement");
                            return false;
                        }
                        if(node->getValue()->getType() != L::GEN_ID) {
                            AE("expecting `identifer` after `DIM`");
                            return false;
                        }
                        if(this->HasIDRegistered(this->getText(node))) { AE("variable `"+this->getText(node)+"` has already been defined!"); return false; }
                        this->registerID(this->getText(node), node->getValue()->getRelatedLine());
                        MF;
                        if(!node->getValue()) {
                            AE("invalid `DIM` statement");
                            return false;
                        }
                        if(node->getValue()->getType() != L::MRK_BRACK_OP) {
                            IE0("(");
                            return false;
                        }
                        miniatureSet->push(node);
                        unsigned int flip = 1;
                        while((node = this->moveToNextSibling(node))) {
                            if(this->getType(node) != L::GEN_NUM && this->getType(node) != L::MRK_COMMA) break;
                            if(flip == 1) {
                                if(!lexValidator::IS_INTEGER_NUM(this->getText(node))) {
                                    this->addError("invalid `"+this->getText(node)+"` expecting `integer`", node);
                                    return false;
                                }
                                flip = 2;
                            } else if(flip == 2) {
                                if(this->getType(node) != L::MRK_COMMA) {
                                    this->addError("invalid `"+this->getText(node)+"` expecting `,`", node);
                                    return false;
                                }
                                flip = 1;
                            }
                            miniatureSet->push(node);
                        }
                        if(this->getType(miniatureSet->top()) != L::GEN_NUM) {
                            IE2(this->getText(miniatureSet->top()), "integer");
                            return false;
                        }
                        if(this->getType(node) != L::MRK_BRACK_CL) {
                            IE0(")");
                            return false;
                        }
                        DEADEND;
                    }
                    return true;
                /* KYWD{FOR} */
                case L::KWD_FOR:
                        if(this->getNextSiblingsCount(node) < 4) {
                            AE("invalid `FOR` statement");
                            return false;
                        }
                        MF;
                        if(!node->getValue()) {
                            AE("invalid `FOR` statement");
                            return false;
                        }
                        if(node->getValue()->getType() != L::GEN_ID) {
                            AE("expecting `identifer` after `FOR`");
                            return false;
                        }
                        /* WE DON'T CHECK IF ID EXISTS IN FOR BECAUSE EITHER ID ALREADY EXISTS OR ID
                            GETS GENERATED DURING ASSEMBLY CODE GENERATION */
                        /* CHECK_ID_EXISTS; */
                        if(!this->HasIDRegistered(this->getText(node))) { this->registerID(this->getText(node), node->getValue()->getRelatedLine()); }
                        MF;
                        if(!node->getValue()) {
                            AE("invalid `FOR` statement");
                            return false;
                        }
                        if(this->getType(node) != L::OPR_EQ) {
                            IE0("=");
                            return false;
                        }
                        MF;
                        if(!this->validateExpression(node, miniatureSet, true, true)) { return false; }
                        if(lexValidator::KeywordValidate(this->getText(node)) != L::KWD_TO) { IE0("TO"); return false; }
                        MF;
                        if(!this->validateExpression(node, miniatureSet, true, true)) { return false; }
                        if(lexValidator::KeywordValidate(this->getText(node)) == L::KWD_STEP) { MF; }
                        else { DEADEND; return false; }
                        if(!lexValidator::IS_INTEGER_NUM(this->getText(node))) { IE0("integer"); return false; }
                        DEADEND;
                    return true;
                /* KYWD{GOTO} */
                case L::KWD_GOTO:
                /* KYWD{GOSUB} */
                case L::KWD_GOSUB:
                        if(this->getNextSiblingsCount(node) < 1) {
                            AE("invalid `"+this->getText(node)+"` statement");
                            return false;
                        }
                        MF;
                        if(!this->validateExpression(node, miniatureSet)) { return false; }
                        DEADEND;
                    return true;
                /* KYWD{IF} */
                case L::KWD_IF: {
                            if(this->getNextSiblingsCount(node) < 3 || lexValidator::KeywordValidate(this->getText(node)) != L::KWD_IF) {
                                AE("invalid `IF` statement");
                                return false;
                            }
                            MF;
                            if(!this->validateExpression(node, miniatureSet, true, true)) { return false; }
                            if(lexValidator::KeywordValidate(this->getText(node)) != L::KWD_THEN) { IE0("THEN"); return false; }
                            /* create a fake parent node */
                            lexNode* pp = new lexNode();
                            /* make it like a new command line */
                            pp->addChild(new token(":", L::GEN_SEPARATOR, node->getValue()->getRelatedLine()));
                            /* add any other siblings to out fake parent */
                            while(this->getNextSiblingsCount(node)) {
                                node = this->moveToNextSibling(node);
                                pp->addChild(node);
                            }
                            /* there should be at least a sibling after `THEN` statement */
                            if(pp->getChildrenCount() == 1) {
                                this->addError("expecting statement after `THEN`", miniatureSet->top());
                                return false;
                            }
                            /* recursive validate the statement */
                            return this->validateGeneralToken(pp, miniatureSet);
                        }
                        return true;
                /* KYWD{INPUT} */
                case L::KWD_INPUT:
                        if(!this->getNextSiblingsCount(node) || lexValidator::KeywordValidate(this->getText(node)) != L::KWD_INPUT) {
                            AE("invalid `INPUT` statement");
                            return false;
                        }
                        MF;
                        if(this->getType(node) == L::GEN_ID) {
                            unsigned int flip = 1;
                            do{
                                if(flip == 1) {
                                    if(this->getType(node) != L::GEN_ID) { IE0("identifier"); return false; }
                                    /* WE MAY ALSO CREATE NEW ID IF NOT EXISTS IN INPUT*/
                                    /* CHECK_ID_EXISTS; */
                                    if(!this->HasIDRegistered(this->getText(node))) { this->registerID(this->getText(node), node->getValue()->getRelatedLine()); }
                                    flip = 2;
                                }else if(flip == 2) {
                                    if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                                    flip = 1;
                                }
                                miniatureSet->push(node);
                            }while((node = this->moveToNextSibling(node)));
                            if(this->getType(miniatureSet->top()) != L::GEN_ID) { node = miniatureSet->top(); IE0("identifier"); return false; }
                        } else if(lexValidator::MarkValidate(this->getText(node)) == L::MRK_SHARP) {
                            if(this->getNextSiblingsCount(node) < 3) { AE("invalid `INPUT`statement"); return false; }
                            MF;
                            if(!lexValidator::IS_INTEGER_NUM(this->getText(node))) { IE0("integer"); return false; }
                            MF;
                            if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                            MF;
                            unsigned int flip = 1;
                            do{
                                if(flip == 1) {
                                    if(this->getType(node) != L::GEN_ID) { IE0("identifier"); return false; }
                                    flip = 2;
                                }else if(flip == 2) {
                                    if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                                    flip = 1;
                                }
                                miniatureSet->push(node);
                            }while((node = this->moveToNextSibling(node)));
                            if(this->getType(miniatureSet->top()) != L::GEN_ID) { node = miniatureSet->top(); IE0("identifier"); return false; }
                        } else { IE0("#|identifier"); return false; }
                    return true;
                /* KYWD{LET} */
                case L::KWD_LET:
                        if(this->getNextSiblingsCount(node) < 3 || lexValidator::KeywordValidate(this->getText(node)) != L::KWD_LET) {
                            AE("invalid `LET` statement");
                            return false;
                        }
                        MF;
                        if(this->getType(node) != L::GEN_ID) { IE0("identifier"); return false; }
                        /* don't go for below check for fuck sake! */
                        /* `LET` also is varibale definition and assignment */
                        /* CHECK_ID_EXISTS; */
                        if(!this->HasIDRegistered(this->getText(node))) { this->registerID(this->getText(node), node->getValue()->getRelatedLine()); }
                        MF;
                        if(this->getType(node) != L::OPR_EQ) { IE0("="); return false; }
                        MF;
                        if(!this->validateExpression(node, miniatureSet/*NOT NEED FOR {, true, true} WE WANT TO PROCESS ALL REMAINING ITEMS*/)) { return false ; }
                        DEADEND;
                    return true;
                /* KYWD{READ} */
                case L::KWD_READ:
                /* KYWD{NEXT} */
                case L::KWD_NEXT: {
                        L type = this->getType(node);
                        if(!this->getNextSiblingsCount(node)) {
                            AE("invalid `"+this->getText(node)+"` statement");
                            return false;
                        }
                        MF;
                        unsigned int flip = 1;
                        do{
                            if(flip == 1) {
                                if(this->getType(node) != L::GEN_ID) { IE0("identifier"); return false; }
                                switch(type) {
                                    case L::KWD_READ:
                                        /* WE MAY ALSO CREATE NEW ID IF NOT EXISTS IN READ*/
                                        /* CHECK_ID_EXISTS; */
                                        if(!this->HasIDRegistered(this->getText(node))) { this->registerID(this->getText(node), node->getValue()->getRelatedLine()); }
                                        break;
                                    case L::KWD_NEXT:
                                        CHECK_ID_EXISTS;
                                        break;
                                    default:
                                        throw std::invalid_argument("Undefined case for `"+LEXTE2String(type)+"`");
                                }
                                flip = 2;
                            }else if(flip == 2) {
                                if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                                flip = 1;
                            }
                            miniatureSet->push(node);
                        }while((node = this->moveToNextSibling(node)));
                        if(this->getType(miniatureSet->top()) != L::GEN_ID) { node = miniatureSet->top(); IE0("identifier"); return false; }
                        DEADEND;
                    }
                    return true;
                /* KYWD{OPEN} */
                case L::KWD_OPEN:
                        if(this->getNextSiblingsCount(node)  < 6 || lexValidator::KeywordValidate(this->getText(node)) != L::KWD_OPEN) {
                            AE("invalid `OPEN` statement");
                            return false;
                        }
                        MF;
                        if(!this->validateValue(node, miniatureSet)) { return false; }
                        MF;
                        if(lexValidator::KeywordValidate(this->getText(node)) != L::KWD_FOR) { IE0("FOR"); return false; }
                        MF;
                        if(lexValidator::KeywordValidate(this->getText(node)) != L::KWD_INPUT && lexValidator::KeywordValidate(this->getText(node)) != L::KWD_OUTPUT) { IE0("INPUT|OUTPUT"); return false; }
                        MF;
                        if(lexValidator::KeywordValidate(this->getText(node)) != L::KWD_AS) { IE0("AS"); return false; }
                        MF;
                        if(lexValidator::MarkValidate(this->getText(node)) != L::MRK_SHARP) { IE0("#"); return false; }
                        MF;
                        if(!lexValidator::IS_INTEGER_NUM(this->getText(node))) { IE0("integer"); return false; }
                        DEADEND;
                    /* since `OPEN` has `FOR` keyword we will process all siblings of `node` and no need the `above for loop` to continue, so we retrun */
                    return true;
                /* KYWD{WAIT} */
                case L::KWD_WAIT:
                /* KYWD{POKE} */
                case L::KWD_POKE:{
                        if(!this->getNextSiblingsCount(node)) {
                            AE("invalid `"+this->getText(node)+"` statement");
                            return false;
                        }
                        MF;
                        unsigned int flip = 1;
                        do{
                            if(flip == 1) {
                                if(!this->validateValue(node, miniatureSet)) { return false; }
                                flip = 2;
                            }else if(flip == 2) {
                                if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                                flip = 1;
                            }
                            miniatureSet->push(node);
                        }while((node = this->moveToNextSibling(node)));
                        if(this->getType(miniatureSet->top()) == L::MRK_COMMA) { node = miniatureSet->top(); IE0("value"); return false; }
                        DEADEND;
                    }
                    return true;
                /* KYWD{PRINT} */
                case L::KWD_PRINT: {
                        if(!this->getNextSiblingsCount(node)) { AE("invalid `PRINT`statement"); return false; }
                        MF;
                        if(lexValidator::MarkValidate(this->getText(node)) != L::MRK_SHARP) { goto __PRINT_LIST; }
                        /* in this case the next siblings# should be at least 3 */
                        if(this->getNextSiblingsCount(node) < 3) { AE("invalid `PRINT`statement"); return false; }
                        MF;
                        if(!lexValidator::IS_INTEGER_NUM(this->getText(node))) { IE0("integer"); return false; }
                        MF;
                        if(this->getType(node) != L::MRK_COMMA) { IE0(","); return false; }
                        MF;
__PRINT_LIST:
                        do{
                            if(!this->validateExpression(node, miniatureSet, true, true)) { return false; }
                            if(node && this->moveToNextSibling(node) && this->getType(node) != L::MRK_SEMICLN) { IE0(";"); return false; }
                            miniatureSet->push(node);
                        }while((node = this->moveToNextSibling(node)));
                        DEADEND;
                        if(this->getType(miniatureSet->top()) == L::MRK_SEMICLN) { node = miniatureSet->top(); IE0("expression"); return false; }
                    }
                    return true;
                /* KYWD{SYS} */
                case L::KWD_SYS:
                        if(!this->getNextSiblingsCount(node)) {
                            AE("invalid `"+this->getText(node)+"` statement");
                            return false;
                        }
                        MF;
                        if(!this->validateValue(node, miniatureSet)) { return false; }
                        DEADEND;
                    return true;
                /* KYWD{END} */
                case L::KWD_END:
                /* KYWD{RESTORE} */
                case L::KWD_RESTORE:
                /* KYWD{RETURN} */
                case L::KWD_RETURN:
                /* KYWD{RUN} */
                case L::KWD_RUN:
                /* KYWD{STOP} */
                case L::KWD_STOP:
                    DEADEND;
                    return true;
                /* KYWD{REM} */
                case L::KWD_REM:
                    /* don't register in miniature stack-set like it doesn't  exist */
                    while((node = this->moveToNextSibling(node))) ;
                    /* ignore every thing after */
                    return true;
                default:
                    /* if none of above cases where match, so it is unexpected */
                    this->addError("unexpected `"+this->getText(node)+"`", node);
                    return false;
            }
            /* add the child to miniature set for further processes */
            miniatureSet->push(pnode->getChild(index));
        }
#undef MF
    }
/* LEXTE's aliases */
#define L LEXTE
    bool semAnalyzer::validateExpression(lexNode*& node, stack<lexNode*>* __stack, bool valueCheck, bool forceBracketCheck) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        if(!valueCheck || forceBracketCheck) {
            if(!this->validateBracket(node)) {
                AE("unbalanced `(|)`");
                return false;
            }
        }
        bool deepRes = this->validateAndExpression(node, __stack);
        if(node && this->getNextSiblingsCount(node)) {
            node = this->moveToNextSibling(node);
            if(this->getType(node) != L::OPR_OR) {
                if(valueCheck)
                    return deepRes;
                IE1(this->getText(node));
                return false;
            }
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validateExpression(node, __stack, valueCheck) && deepRes;
        }
        return deepRes;
    }
    bool semAnalyzer::validateAndExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        bool deepRes = this->validateNotExpression(node, __stack);
        if(node && this->getNextSiblingsCount(node)) {
            if(this->getType(this->moveToNextSibling(node)) != L::OPR_AND) {
                /* give others a chance */
                return deepRes;
            }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validateAndExpression(node, __stack) && deepRes;
        }
        return deepRes;
    }
    bool semAnalyzer::validateNotExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        if(this->getType(node) == L::OPR_NOT) {
            __stack->push(node);
            node = this->moveToNextSibling(node);
        }
        return this->validateCompareExpression(node, __stack);
    }
    bool semAnalyzer::validateCompareExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        bool deepRes = this->validateAddExpression(node, __stack);
        if(node && this->getNextSiblingsCount(node)) {
            switch(this->getType(this->moveToNextSibling(node))) {
                case L::OPR_EQ:
                case L::OPR_NE:
                case L::OPR_LT:
                case L::OPR_LE:
                case L::OPR_GT:
                case L::OPR_GE:
                    break;
                default:
                    /* give others a chance */
                    return deepRes;
            }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validateCompareExpression(node, __stack) && deepRes;
        }
        return deepRes;
    }
    bool semAnalyzer::validateAddExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        bool deepRes = this->validateMultExpression(node, __stack);
        if(node && this->getNextSiblingsCount(node)) {
            switch(this->getType(this->moveToNextSibling(node))) {
                case L::OPR_ADD:
                case L::OPR_SUB:
                    break;
                default:
                    /* give others a chance */
                    return deepRes;
            }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validateAddExpression(node, __stack) && deepRes;
        }
        return deepRes;
    }
    bool semAnalyzer::validateMultExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        bool deepRes = this->validateNegExpression(node, __stack);
        if(node && this->getNextSiblingsCount(node)) {
            switch(this->getType(this->moveToNextSibling(node))) {
                case L::OPR_MUL:
                case L::OPR_DIV:
                    break;
                default:
                    /* give others a chance */
                    return deepRes;
            }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validateMultExpression(node, __stack) && deepRes;
        }
        return deepRes;
    }
    bool semAnalyzer::validateNegExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        if(this->getType(node) == L::OPR_SUB) {
            __stack->push(node);
            node = this->moveToNextSibling(node);
        }
        return this->validatePowerExpression(node, __stack);
    }
    bool semAnalyzer::validatePowerExpression(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        if(node && this->getNextSiblingsCount(node)) {
            switch(this->getType(this->moveToNextSibling(node))) {
                case L::OPR_EXP:
                    break;
                default:
                    /* give others a chance */
                    return this->validateValue(node, __stack);;
            }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            node = this->moveToNextSibling(node);
            return this->validatePowerExpression(node, __stack);
        }
        return this->validateValue(node, __stack);
    }
    bool semAnalyzer::validateValue(lexNode*& node, stack<lexNode*>* __stack) {
        if(!node) {
            this->addError("expecting an expression", __stack->top());
            return false;
        }
        static bool valueCheck = false;
        if( this->getType(node) == LEXTE::MRK_BRACK_OP) {
            __stack->push(node);
            node = this->moveToNextSibling(node);
            valueCheck = true;
            if(this->validateExpression(node, __stack, true, false)) {
                if(!node) {
                    this->addError("expecting `)`", __stack->top());
                    valueCheck = false;
                    return false;
                }else if(this->getType(node) != LEXTE::MRK_BRACK_CL) {
                    this->addError("expecting `)`", this->moveToNextSibling(node));
                    valueCheck = false;
                    return false;
                }
                __stack->push(node);
                valueCheck = false;
                return true;
            } else { valueCheck = false; return false; }
        } else if(this->getType(node) == LEXTE::GEN_ID) {
            CHECK_ID_EXISTS;
            __stack->push(node);
            if(this->getNextSiblingsCount(node) == 0) return true;
            if(this->getType(this->moveToNextSibling(node)) != LEXTE::MRK_BRACK_OP) { return  true; }
            node = this->moveToNextSibling(node);
            __stack->push(node);
            unsigned int flip = 1;
            while((node = this->moveToNextSibling(node))) {
                if(this->getType(node) == LEXTE::MRK_BRACK_CL) break;
                valueCheck = true;
                if(!this->validateExpression(node, __stack, true, false)) {
                    valueCheck = false;
                    return false;
                }
                if(this->getType(node) == LEXTE::MRK_BRACK_CL) break;
                valueCheck = false;
                if(this->getType(node) != LEXTE::MRK_COMMA) {
                    this->addError("invalid `"+this->getText(node)+"` expecting `,`", node);
                    return false;
                }
                __stack->push(node);
            }
            if(!node || this->getType(node) != LEXTE::MRK_BRACK_CL) {
                this->addError("expecting `)`", node?node:__stack->top());
                return false;
            }
            __stack->push(node);
            return true;
        } else if(
                lexValidator::IS_GEN_STRING(this->getText(node)) ||
                lexValidator::IS_GEN_NUM(this->getText(node))
                ) {
            __stack->push(node);
            return true;
        } else {
            this->addError("invalid `"+this->getText(node)+"`", node);
            return false;
        }
        throw std::logic_error("The `PC` should not ever reach here!");
    }
    bool semAnalyzer::validateBracket(lexNode* node) {
        int brackCount = 0;
        while(node) {
            if(this->getType(node) == L::MRK_BRACK_CL) brackCount++;
            if(this->getType(node) == L::MRK_BRACK_OP) brackCount--;
            node = this->moveToNextSibling(node);
        }
        return brackCount == 0;
    }
#undef L
#undef CHECK_ID_EXISTS
#undef DEADEND
#undef IE0
#undef IE1
#undef IE2
#undef AE
} }
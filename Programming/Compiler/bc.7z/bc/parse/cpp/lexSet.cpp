/*
 * File:   lexSet.cpp
 * Author: dariush
 *
 * Created on March 30, 2014, 10:28 PM
 */
#include "../hpp/lexSet.hpp"
NS BC { NS Lexer {
    lexSet* lexSet::__init(std::string name) {
        /* set current set's name */
        this->name = name;
        /* the initial point of iterator is zero */
        this->CIP = 0;
        /* init sets' vector */
        this->sets = new vector<lexNode*>();
        /* return `this` */
        return this;
    }
    lexSet::lexSet(const lexSet& orig) {
        /* init current instance with the origin's name */
        this->__init(orig.name);
        /* if there is no subsets in origin */
        if(orig.sets->size() == 0) return;
        /* re-init the `this` CIP */
        this->initIterator();
        /* while there is a node in origin that is not added to `this` */
        while(this->CIP < orig.sets->size())
            /* add the subset from origin into `this` set */
            this->addSubSet(orig.sets->at(this->CIP++));
        /* re-init the `this` CIP */
        this->initIterator();
    }
    lexSet::~lexSet() {
        /* init `this` CIP for iteration */
        this->initIterator();
        /* make a container for iterator */
        lexNode* node = NULL;
        /* while there is a  */
        while((node = this->getNextSet()))
            /* delete the note */
            delete(node);
    }
    lexNode* lexSet::getNextSet() {
        /* if the set collection is empty */
        if(!this->sets->size()) return NULL;
        /* if the CIP has overflow from sets' size */
        if(this->CIP >= this->sets->size()) return NULL;
        /* return the node at CIP and increase the CIP as well */
        return this->sets->at(this->CIP++);
    }
    lexNode* lexSet::addSubSet(lexNode* const subset) {
        /* since we added every subset in sets' back */
        /* no next siblings for subset */
        subset->unlinkNextSibling();
        /* if there is no subset in sets */
        if(this->sets->size() == 0)
            /* no prev siblings for subset */
            subset->unlinkPrevSibling();
        /* if there are subsets in sets */
        if(this->sets->size() > 0)
            /* set previous node's next sibling to incoming subset */
            this->sets->back()->setNextSibling(subset);
        /* push the subset into sets' back */
        this->sets->push_back(subset);
        /* return the subset */
        return subset;
    }
    lexNode* lexSet::unlinkSubSet(size_t index) {
        /* if the index has overflow-ness of sets size */
        if(index >= this->sets->size()) return NULL;
        /* fetch the taget subset to unlink */
        lexNode* unlinked  = this->sets->at(index);
        /* if there is a next sibling in fetched subset */
        if(unlinked->getNextSibling())
            /* set the next sibling's previous sibling to fetch subset's previous */
            unlinked->getNextSibling()->setPrevSibling(unlinked->getPrevSibling());
        /* if there is a previous sibling in fetched subset */
        if(unlinked->getPrevSibling())
            /* set the previous sibling's next sibling to fetch subset's next */
            unlinked->getPrevSibling()->setNextSibling(unlinked->getNextSibling());
        /* unlink the previous sibling of fetched subset */
        unlinked->unlinkPrevSibling();
        /* unlink the next sibling of fetched subset */
        unlinked->unlinkNextSibling();
        /* unlink the fetched subset sets collection */
        this->sets->erase(this->sets->begin() + index);
        /* return the fetched unlinked subset */
        return unlinked;
    }
} }
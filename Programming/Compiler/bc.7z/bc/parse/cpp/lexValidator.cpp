/*
 * File:   lexValidator.cpp
 * Author: dariush
 *
 * Created on April 3, 2014, 8:35 PM
 */
#include "../hpp/lexValidator.hpp"
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
NS BC { NS Lexer {
    LexTypeEnum lexValidator::OperatorValidate(std::string tokenString) {
        typedef LexTypeEnum LTE;
        boost::algorithm::trim(tokenString);
        boost::algorithm::to_upper<string>(tokenString);
        /*
         *
         * OPERATORS
         *
         */
        if(IS_OP_ADD(tokenString)) return LTE::OPR_ADD;
        if(IS_OP_AND(tokenString)) return LTE::OPR_AND;
        if(IS_OP_DIV(tokenString)) return LTE::OPR_DIV;
        if(IS_OP_EQ(tokenString)) return LTE::OPR_EQ;
        if(IS_OP_EXP(tokenString)) return LTE::OPR_EXP;
        if(IS_OP_GE(tokenString)) return LTE::OPR_GE;
        if(IS_OP_GT(tokenString)) return LTE::OPR_GT;
        if(IS_OP_LE(tokenString)) return LTE::OPR_LE;
        if(IS_OP_LT(tokenString)) return LTE::OPR_LT;
        if(IS_OP_MUL(tokenString)) return LTE::OPR_MUL;
        if(IS_OP_NE(tokenString)) return LTE::OPR_NE;
        if(IS_OP_NOT(tokenString)) return LTE::OPR_NOT;
        if(IS_OP_OR(tokenString)) return LTE::OPR_OR;
        if(IS_OP_SUB(tokenString)) return LTE::OPR_SUB;
    }
    LexTypeEnum lexValidator::MarkValidate(std::string tokenString) {
        typedef LexTypeEnum LTE;
        boost::algorithm::trim(tokenString);
        boost::algorithm::to_upper<string>(tokenString);
        /*
         *
         * MARKS
         *
         */
        if(IS_MRK_BRACK_CL(tokenString)) return LTE::MRK_BRACK_CL;
        if(IS_MRK_BRACK_OP(tokenString)) return LTE::MRK_BRACK_OP;
        if(IS_MRK_COMMA(tokenString)) return LTE::MRK_COMMA;
        if(IS_MRK_QUOTE(tokenString)) return LTE::MRK_QUOTE;
        if(IS_MRK_SEMICLN(tokenString)) return LTE::MRK_SEMICLN;
        if(IS_MRK_SHARP(tokenString)) return LTE::MRK_SHARP;
        return LTE::GEN_UNKNOWN;
    }
    LexTypeEnum lexValidator::KeywordValidate(std::string tokenString) {
        typedef LexTypeEnum LTE;
        boost::algorithm::trim(tokenString);
        boost::algorithm::to_upper<string>(tokenString);
        /*
         *
         * KEYWORDS
         *
         */
        if(IS_KWD_CLOSE(tokenString)) return LTE::KWD_CLOSE;
        if(IS_KWD_DATA(tokenString)) return LTE::KWD_DATA;
        if(IS_KWD_DIM(tokenString)) return LTE::KWD_DIM;
        if(IS_KWD_END(tokenString)) return LTE::KWD_END;
        if(IS_KWD_FOR(tokenString)) return LTE::KWD_FOR;
        if(IS_KWD_TO(tokenString)) return LTE::KWD_TO;
        if(IS_KWD_STEP(tokenString)) return LTE::KWD_STEP;
        if(IS_KWD_GOSUB(tokenString)) return LTE::KWD_GOSUB;
        if(IS_KWD_GOTO(tokenString)) return LTE::KWD_GOTO;
        if(IS_KWD_IF(tokenString)) return LTE::KWD_IF;
        if(IS_KWD_THEN(tokenString)) return LTE::KWD_THEN;
        if(IS_KWD_INPUT(tokenString)) return LTE::KWD_INPUT;
        if(IS_KWD_OUTPUT(tokenString)) return LTE::KWD_OUTPUT;
        if(IS_KWD_LET(tokenString)) return LTE::KWD_LET;
        if(IS_KWD_NEXT(tokenString)) return LTE::KWD_NEXT;
        if(IS_KWD_OPEN(tokenString)) return LTE::KWD_OPEN;
        if(IS_KWD_AS(tokenString)) return LTE::KWD_AS;
        if(IS_KWD_POKE(tokenString)) return LTE::KWD_POKE;
        if(IS_KWD_PRINT(tokenString)) return LTE::KWD_PRINT;
        if(IS_KWD_READ(tokenString)) return LTE::KWD_READ;
        if(IS_KWD_REM(tokenString)) return LTE::KWD_REM;
        if(IS_KWD_RESTORE(tokenString)) return LTE::KWD_RESTORE;
        if(IS_KWD_RETURN(tokenString)) return LTE::KWD_RETURN;
        if(IS_KWD_RUN(tokenString)) return LTE::KWD_RUN;
        if(IS_KWD_STOP(tokenString)) return LTE::KWD_STOP;
        if(IS_KWD_SYS(tokenString)) return LTE::KWD_SYS;
        if(IS_KWD_WAIT(tokenString)) return LTE::KWD_WAIT;
        return LTE::GEN_UNKNOWN;
    }
    LexTypeEnum lexValidator::GeneralValidate(std::string tokenString) {
        typedef LexTypeEnum LTE;
        boost::algorithm::trim(tokenString);
        boost::algorithm::to_upper<string>(tokenString);
        /*
         *
         * GENERALS
         *
         */
        if(IS_GEN_EMPTY(tokenString)) return LTE::GEN_EMPTY;
        if(IS_GEN_ID(tokenString)) return LTE::GEN_ID;
        if(IS_GEN_KYWD(tokenString)) return LTE::GEN_KYWD;
        if(IS_GEN_NUM(tokenString)) return LTE::GEN_NUM;
        if(IS_GEN_MARK(tokenString)) return LTE::GEN_MARK;
        if(IS_GEN_OPR(tokenString)) return LTE::GEN_OPR;
        if(IS_GEN_STRING(tokenString)) return LTE::GEN_STRING;
        if(IS_GEN_SEPARATOR(tokenString)) return LTE::GEN_SEPARATOR;
        return LTE::GEN_UNKNOWN;
    }
    bool lexValidator::IS_GEN_ID(std::string tokenString){
        /* keyword/opr/marks/strings/numbers cannot be ID */
        if(IS_GEN_KYWD(tokenString) || IS_GEN_OPR(tokenString) || IS_GEN_MARK(tokenString) || IS_GEN_STRING(tokenString) || IS_GEN_EMPTY(tokenString))
            return false;
        /* ID starts with a letter*/
        if(tokenString[0] < 'A' || tokenString[0] > 'Z')
            return false;
        using namespace boost;
        /* the pattern for invalid chars in ID */
        const string pattern = "(^\\d+)|[<|>|=|+|-|^|(|)|,|;|.|\"|#]";
        regex exp(pattern);
        std::string::const_iterator start, end;
        start = tokenString.begin();
        end = tokenString.end();
        boost::match_results<std::string::const_iterator> what;
        boost::match_flag_type flags = boost::match_default;
        while(regex_search(start, end, what, exp, flags))
            /* if anything matched the tokenString is an invalid ID */
            return false;
        /* otherwise the tokenString is ID */
        return true;
    }
    bool lexValidator::IS_GEN_NUM(std::string tokenString) {
        /* keyword/opr/marks/strings cannot be ID */
        if(IS_GEN_KYWD(tokenString) || IS_GEN_OPR(tokenString) || IS_GEN_MARK(tokenString) || IS_GEN_STRING(tokenString) || IS_GEN_ID(tokenString) || IS_GEN_EMPTY(tokenString))
            return false;
        using namespace boost;
        /* general regex pattern for matching both floating point and integer numbers */
        const string pattern = "^[-+]?([0-9]+\\.[0-9]+|[0-9]+)$";
        regex exp(pattern);
        boost::cmatch m;
        /* make a quick search and return the result */
        return regex_match(tokenString.c_str(), m, exp);
    }
    bool lexValidator::IS_REAL_NUM(std::string tokenString) {
        /* firstly it should match with general number format */
        if(!IS_GEN_NUM(tokenString))
            return false;
        using namespace boost;
        /* general regex pattern for matching floating points number */
        const string pattern = "^[-+]?([0-9]+\\.[0-9]+)$";
        regex exp(pattern);
        boost::cmatch m;
        /* make a quick search and return the result */
        return regex_match(tokenString.c_str(), m, exp);
    }
    bool lexValidator::IS_INTEGER_NUM(std::string tokenString) {
        /* firstly it should match with general number format */
        if(!IS_GEN_NUM(tokenString))
            return false;
        using namespace boost;
        /* general regex pattern for matching integer  number */
        const string pattern = "^[-+]?([0-9]+)$";
        regex exp(pattern);
        boost::cmatch m;
        /* make a quick search and return the result */
        return regex_match(tokenString.c_str(), m, exp);
    }
} }
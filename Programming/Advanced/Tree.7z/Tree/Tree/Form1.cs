﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Tree
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            toolStripProgressBar1.Visible = false;
            toolStripStatusLabel1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] driver = Environment.GetLogicalDrives();
            treeView1.BeginUpdate();
            foreach (string str in driver)
            {
                TreeNode node = new TreeNode(str.Remove(2, 1));
                switch (str)
                {
                    case "A:\\":
                        node.SelectedImageIndex = 1;
                        node.ImageIndex = 1;
                        break;
                    case "C:\\":
                        treeView1.SelectedNode = node;
                        node.SelectedImageIndex = 1;
                        node.ImageIndex = 1;
                        break;
                    case "D:\\":
                        node.SelectedImageIndex = 1;
                        node.ImageIndex = 1;
                        break;
                    default:
                        node.SelectedImageIndex = 1;
                        node.ImageIndex = 1;
                        break;
                }
                treeView1.Nodes.Add(node);
            }
            treeView1.EndUpdate();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            Add_Directories add = new Add_Directories();
            add.addnewdirector(e.Node, treeView1);
            treeView1.SelectedNode.Expand();
            showFileinListView Show = new showFileinListView();
            Show.AddFile(e.Node.FullPath.ToString(), listView1);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            toolStripProgressBar1.Value = 0;
            Search S = new Search();
            S.newSearch(textBox1.Text, listView1);
        }



        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                timer1.Enabled = true;
                Search S = new Search();
                S.newSearch(textBox1.Text, listView1);
                toolStripProgressBar1.Value = 0;
            }
        }

        private void setvalue()
        {
            toolStripProgressBar1.Value += 10;
            toolStripStatusLabel1.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            toolStripProgressBar1.Visible = true;
            toolStripProgressBar1.Value += 10;
            toolStripStatusLabel1.Visible = true;
            if (toolStripProgressBar1.Value == 100)
            {
                timer1.Enabled = false;
                toolStripProgressBar1.Visible = false;
                toolStripStatusLabel1.Visible = false;
            }
        }

        private void aboutToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("in barname be onvane tamrin kar ba file(IO) dar c#  Baraye \ndarse barname nevisiye pishrafte dar 89/10/18 tavsote A-M \n neveshte shode ast!!!!!!!!");
        }
    }
}

﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
namespace Tree
{
    class Search
    {
        public void newSearch(string spath, ListView lview)
        {
            int count = 0;
            lview.Items.Clear();
            try
            {
                DirectoryInfo Dinfo = new DirectoryInfo(spath);
      
                DirectoryInfo[] dirs = Dinfo.GetDirectories();
                foreach (DirectoryInfo dir in dirs)
                {
                    
                    ListViewItem lvItem = new ListViewItem(dir.Name,11);
                    lvItem.SubItems.Add("");
                    lvItem.SubItems.Add(dir.LastWriteTime.ToShortDateString());
                    lvItem.SubItems.Add(dir.LastWriteTime.ToShortTimeString());
                    lvItem.SubItems.Add(dir.FullName);

                    lview.Items.Add(lvItem);
                }
            }
            catch
            {
                try
                {
                    DirectoryInfo di = new DirectoryInfo(spath);
                    FileInfo[] theFiles = di.GetFiles();

                    foreach (FileInfo theFile in theFiles)
                    {
                        setImageinListview image = new setImageinListview();
                        ListViewItem lvItem = new ListViewItem(theFile.Name, image.setValue(theFile));
                        lvItem.SubItems.Add(theFile.Length.ToString());
                        lvItem.SubItems.Add(theFile.LastWriteTime.ToShortDateString());
                        lvItem.SubItems.Add(theFile.LastWriteTime.ToShortTimeString());
                        lvItem.SubItems.Add(theFile.FullName);

                        lview.Items.Add(lvItem);
                    }
                    count = 1;
                }
                catch { }
    
            }
            if (count == 0)
            {
                try
                {
                    DirectoryInfo di = new DirectoryInfo(spath);
                    FileInfo[] theFiles = di.GetFiles();

                    foreach (FileInfo theFile in theFiles)
                    {
                        setImageinListview image = new setImageinListview();
                        ListViewItem lvItem = new ListViewItem(theFile.Name, image.setValue(theFile));
                        lvItem.SubItems.Add(theFile.Length.ToString());
                        lvItem.SubItems.Add(theFile.LastWriteTime.ToShortDateString());
                        lvItem.SubItems.Add(theFile.LastWriteTime.ToShortTimeString());
                        lvItem.SubItems.Add(theFile.FullName);

                        lview.Items.Add(lvItem);
                    }
                }
                catch { }
            }
        }
    }
}

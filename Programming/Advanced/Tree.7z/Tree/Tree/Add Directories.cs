﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.IO;

namespace Tree
{
    class Add_Directories
    {
        public void addnewdirector(TreeNode newnode,TreeView treeView1)
        {
           // treeView1.BeginUpdate();
            try
            {
                DirectoryInfo Dinfo;
                if (newnode.SelectedImageIndex < 11)
                {
                    Dinfo = new DirectoryInfo(newnode.FullPath + "\\");
                }
                else
                {
                    Dinfo = new DirectoryInfo(newnode.FullPath);
                }
                DirectoryInfo[] dirs = Dinfo.GetDirectories();
                newnode.Nodes.Clear();
                foreach (DirectoryInfo dir in dirs)
                {
                    TreeNode Newnodes = new TreeNode(dir.Name);
                    Newnodes.ImageIndex = 2;
                    Newnodes.SelectedImageIndex = 12;
                    newnode.Nodes.Add(Newnodes);
                }
            }
            catch
            {
            }
           // treeView1.EndUpdate();
        }
    }
}

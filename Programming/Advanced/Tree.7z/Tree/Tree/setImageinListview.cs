﻿using System.IO;
namespace Tree
{
    class setImageinListview
    {
        public int  setValue(FileInfo item)
        {
          
            switch (item.Extension)
           { 
               case ".sys":
                   return 1;
               case ".pdf":
                   return 2;
               case".doc":
                   return 3;
               case ".avi":
               case ".mp4":
               case "..wmv":
               case".DAT":
               case".3gp":
               case ".psp":
                   return 4;
               case".jpg":
               case ".ico":
               case".png":
               case".bmp":
               case".jif":
                   return 5;
               case ".mp3":
               case ".wav":
               case ".wma":
               case ".ogg":
               case ".mpc":
                   return 6;
               case ".exe":
                   return 7;
               case ".chm":
               case ".txt":
               case ".xml":
                   return 8;
                case ".mht":
                   return 9;
                case".zip":
                case ".rar":
                   return 10;
              
           }
           return 0;
        }
    }
}

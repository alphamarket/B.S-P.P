﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Tree
{
    class showFileinListView
    {
        public void AddFile(string spath,ListView lview)
        {

           // lview.BeginUpdate();

            lview.Items.Clear();
            try
            {
                DirectoryInfo di = new DirectoryInfo(spath + "\\");
                FileInfo[] theFiles = di.GetFiles();
                foreach (FileInfo theFile in theFiles)
                {
                    setImageinListview image = new setImageinListview();
                    ListViewItem lvItem = new ListViewItem(theFile.Name,image.setValue(theFile));
                    lvItem.SubItems.Add(theFile.Length.ToString());
                    lvItem.SubItems.Add(theFile.LastWriteTime.ToShortDateString());
                    lvItem.SubItems.Add(theFile.LastWriteTime.ToShortTimeString());
                    lview.Items.Add(lvItem);
                }
            }
            catch  {  }

          //  lview.EndUpdate();		
        }
        //private string path;
        //public string getpath()
        //{
        //    return path;
        //}
    }
}

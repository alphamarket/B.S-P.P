﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private enum shape {Circle,Rectangle}
        private shape choosen;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    label3.Enabled = false;
                    textBox2.Enabled = false;
                    label4.Enabled = false;
                    textBox4.Enabled = false;
                    label3.Visible = false;
                    label4.Visible = false;
                    textBox3.Enabled = false;
                    label2.Visible = true;
                    label5.Visible = true;
                    textBox1.Enabled = true;
                    textBox4.Enabled = true;
                    choosen = shape.Circle;
                    label2.Text = "شعاع دایره اول را وارد کنید";
                    label5.Text = "شعاع دایره دوم را ورد کنید";
                    break;
                case 1:
                    label3.Enabled = true; ;
                    textBox2.Enabled = true;
                    label5.Enabled = true;
                    textBox4.Enabled = true;
                    label4.Visible = true;
                    label5.Visible = true;
                    label2.Visible = true;
                    label3.Visible = true;
                    label4.Enabled = true;
                    textBox1.Enabled = true;
                    textBox3.Enabled = true;
                    choosen = shape.Rectangle;
                    label2.Text = "طول مستطیل اول را وارد کنید";
                    label3.Text = "عرض مستطیل اول را وارد کنید";
                    label4.Text = "عرض مستطیل دوم را وارد کنید";
                    label5.Text = "طول مستطیل دوم را ورد کنید";
                    break;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                switch (choosen)
                {
                    case shape.Circle:
                        Circle[] cr = new Circle[3];
                        cr[0] = new Circle(double.Parse(textBox1.Text));
                        cr[1] = new Circle(double.Parse(textBox4.Text));
                        cr[2] = cr[0] * cr[1];
                        MessageBox.Show("The new " + cr[2].ToString() + " radius will be : " + cr[2].radius);
                        break;
                    case shape.Rectangle:
                        Rectangle[] rec = new Rectangle[3];
                        rec[0] = new Rectangle(double.Parse(textBox1.Text), double.Parse(textBox2.Text));
                        rec[1] = new Rectangle(double.Parse(textBox4.Text), double.Parse(textBox3.Text));
                        rec[2] = rec[0] * rec[1];
                        MessageBox.Show("The New Rectangle will be X = " + rec[2].X + " And Y = " + rec[2].Y);
                        break;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                switch (choosen)
                {
                    case shape.Circle:
                        Circle[] cr = new Circle[3];
                        cr[0] = new Circle(double.Parse(textBox1.Text));
                        cr[1] = new Circle(double.Parse(textBox4.Text));
                        cr[2] = cr[0] - cr[1];
                        MessageBox.Show("The new " + cr[2].ToString() + " radius will be : " + cr[2].radius);
                        break;
                    case shape.Rectangle:
                        Rectangle[] rec = new Rectangle[3];
                        rec[0] = new Rectangle(double.Parse(textBox1.Text), double.Parse(textBox2.Text));
                        rec[1] = new Rectangle(double.Parse(textBox4.Text), double.Parse(textBox3.Text));
                        rec[2] = rec[0] - rec[1];
                        MessageBox.Show("The New Rectangle will be X = " + rec[2].X + " And Y = " + rec[2].Y);
                        break;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                switch (choosen)
                {
                    case shape.Circle:
                        Circle[] cr = new Circle[3];
                        cr[0] = new Circle(double.Parse(textBox1.Text));
                        cr[1] = new Circle(double.Parse(textBox4.Text));
                        cr[2] = cr[0] + cr[1];
                        MessageBox.Show("The new " + cr[2].ToString() + " radius will be : " + cr[2].radius);
                        break;
                    case shape.Rectangle:
                        Rectangle[] rec = new Rectangle[3];
                        rec[0] = new Rectangle(double.Parse(textBox1.Text), double.Parse(textBox2.Text));
                        rec[1] = new Rectangle(double.Parse(textBox4.Text), double.Parse(textBox3.Text));
                        rec[2] = rec[0] + rec[1];
                        MessageBox.Show("The New Rectangle will be X = " + rec[2].X + " And Y = " + rec[2].Y);
                        break;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                switch (choosen)
                {
                    case shape.Circle:
                        Circle[] cr = new Circle[3];
                        cr[0] = new Circle(double.Parse(textBox1.Text));
                        cr[1] = new Circle(double.Parse(textBox4.Text));
                        cr[2] = cr[0] / cr[1];
                        MessageBox.Show("The new " + cr[2].ToString() + " radius will be : " + cr[2].radius);
                        break;
                    case shape.Rectangle:
                        Rectangle[] rec = new Rectangle[3];
                        rec[0] = new Rectangle(double.Parse(textBox1.Text), double.Parse(textBox2.Text));
                        rec[1] = new Rectangle(double.Parse(textBox4.Text), double.Parse(textBox3.Text));
                        rec[2] = rec[0] / rec[1];
                        MessageBox.Show("The New Rectangle will be X = " + rec[2].X + " And Y = " + rec[2].Y);
                        break;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }
    }
}

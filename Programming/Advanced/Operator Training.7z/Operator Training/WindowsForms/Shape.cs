﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsForms
{
    abstract class Shape
    {
        public abstract string Name
        {
            get;
        }
        public virtual double Area()
        {
            return 0;
        }
        public virtual double Volume()
        {
            return 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsForms
{
    class Rectangle:Shape
    {
        public override string Name
        {
            get { return "Rectangle"; }
        }
        public override double Area()
        {
            return X * Y;
        }
        public double X, Y;
        public Rectangle(double x, double y)
        {
            if (x <= 0 || y <= 0)
                throw new Exception("Invalid input");
            X = x;
            Y = y;
        }
        public static Rectangle operator +(Rectangle r1, Rectangle r2)
        {
            return new Rectangle(r1.X + r2.X, r1.Y + r2.Y);
        }
        public static Rectangle operator -(Rectangle r1, Rectangle r2)
        {
            return new Rectangle(r1.X - r2.X, r1.Y - r2.Y);
        }
        public static Rectangle operator *(Rectangle r1, Rectangle r2)
        {
            return new Rectangle(r1.X * r2.X, r1.Y * r2.Y);
        }
        public static Rectangle operator /(Rectangle r1, Rectangle r2)
        {
            return new Rectangle(r1.X / r2.X, r1.Y / r2.Y);
        }
    }
}

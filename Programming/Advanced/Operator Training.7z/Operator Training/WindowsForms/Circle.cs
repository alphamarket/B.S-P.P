﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsForms
{
    class Circle : Shape
    {

        public int Xcenter;
        public int Ycenter;
        public double radius;
        public Circle(int x, int y, double Radius)
        {
            if (Radius < 0)
                throw new Exception("Radius cannot be less than or equal to zero!!");
            Xcenter = x;
            Ycenter = y;
            radius = Radius;
        }
        public Circle() { }
        public Circle(double Radius)
        {
            if(Radius<0)
                throw new Exception("Radius cannot be less than or equal to zero!!");
            this.radius = Radius;
        }
        public static Circle operator +(Circle c1, Circle c2)
        {
            return new Circle(c1.Xcenter, c1.Ycenter, c1.radius + c2.radius);
        }
        public static Circle operator -(Circle c1, Circle c2)
        {
            return new Circle(c1.Xcenter, c1.Ycenter, Math.Abs(c1.radius - c2.radius));
        }
        public static Circle operator /(Circle c1, Circle c2)
        {
            return new Circle(c1.Xcenter, c1.Ycenter, c1.radius / c2.radius);
        }
        public static Circle operator *(Circle c1, Circle c2)
        {
            return new Circle(c1.Xcenter, c1.Ycenter, c1.radius * c2.radius);
        }
        public override double Area()
        {
            return Math.PI * 2 * radius;
        }
        public override string Name
        {
            get
            {
                return "Circle";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class _Default : System.Web.UI.Page
    {
        public int NumberOfRow, tmpID;
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            string limitStatement;
            if (Request.QueryString["id"] == null)
                limitStatement = "  0 and 10 ";
            else
                limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            try
            {
                SqlCommand crt = new SqlCommand("WITH news(_id, _poster, _topic, _smry, _body, _date, RowNumber, count)AS(SELECT _news.id, _news.poster, _news.news_topic, _news.news_smry, _news.news_body,"+
                    "_news.news_create_date ,ROW_NUMBER() OVER (order by news_create_date) AS 'RowNumber', (SELECT COUNT(*) FROM comment where _news.id=comment.newsid ) as 'count' FROM _news)"+
                    "SELECT * FROM news decs WHERE RowNumber between " + limitStatement + " order by _date desc", con);
                con.Open();
                SqlDataReader _reader = crt.ExecuteReader();
                myRepeater.DataSource = _reader;
                myRepeater.DataBind();
                _reader.Close();
                SqlCommand count = new SqlCommand("select COUNT(*) as count from _news", con);
                _reader = count.ExecuteReader();
                if (_reader.Read())
                    NumberOfRow = Convert.ToInt32(_reader["count"]);

                _reader.Close();
            }
            catch (Exception err)
            {
                Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
            }
            finally
            {
                con.Close();
            }
        }
        void Page_PreInit(Object s, EventArgs e)
        {
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
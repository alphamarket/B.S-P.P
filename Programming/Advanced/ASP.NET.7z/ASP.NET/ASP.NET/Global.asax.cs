﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Data.SqlClient;
namespace erae
{
    public class Global : System.Web.HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            // Code that runs on application startup
            try
            {
                if (Application["emotions"] == null)
                {
                    lock (this)
                    {
                        SqlCommand com = new SqlCommand("SELECT * FROM emotions order by id asc", con);
                        con.Open();
                        SqlDataReader reader = com.ExecuteReader();
                        while (reader.Read())
                        {
                            string[] tmp = reader["shortcut"].ToString().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                            emotions em = new emotions();
                            em.shortcut = tmp.ToList<string>();
                            em.address = reader["address"].ToString();
                            em.title = reader["title"].ToString();
                            GlobalInfo.Emotions.Add(em);
                        }
                        reader.Close();
                        Application.Add("emotions", GlobalInfo.Emotions);
                    }
                }
            }
            catch { }
            finally { con.Close(); }
            Application.Add("VISITORS",0);
            Application.Add("TOTALVISITS", 0);
            Application.Add("MEMBERSNO", 0);
        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown
            Application.RemoveAll();
        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_Start(object sender, EventArgs e)
        {
            // Code that runs when a new session is started
            Application["VISITORS"] = Convert.ToInt64(Application["VISITORS"]) + 1;
            Application["TOTALVISITS"] = Convert.ToInt64(Application["TOTALVISITS"]) + 1;
        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.
            Application["VISITORS"] = Convert.ToInt64(Application["VISITORS"]) - 1;
            LoggedInUserInfo.ResetInfo();
            Session.RemoveAll();
        }

    }
}

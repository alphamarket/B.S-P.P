﻿using System;
using System.Data.SqlClient;
namespace erae
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("SELECT * FROM about_us order by id desc", con);
            try
            {
                con.Open();
                SqlDataReader reader = com.ExecuteReader();
                if (reader.Read())
                {
                    about.Text = reader["about"].ToString().Replace("\r\n", "<br />");
                    reader.Close();
                }
                else
                    about.Text = "THERE IS NOT ANY THING ABOUT THIS SITE!";
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
        void Page_PreInit(Object s, EventArgs e)
        {
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace erae.Account
{
    public partial class Register : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            if (LoggedInUserInfo._UserType == UserType.Normal)
            {
                status.Visible = true;
                reg.Visible = rg.Visible = false;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }
        }
    }
}
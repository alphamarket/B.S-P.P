﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace erae
{
    public enum UserType { Normal, Admin, Supper, NONE }
    public class LoggedInUserInfo
    {
        private static string text;
        private static string user_name, email, name;
        private static DateTime dt;
        private static UserType ut;
        public static string TempText
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
            }
        }
        public static UserType _UserType
        {
            get
            {
                return ut;
            }
            set
            {
                ut = value;
            }
        }
        public static DateTime LastLogIn
        {
            get
            {
                return dt;
            }
            set
            {
                dt = value;
            }
        }
        public static string UserName
        {
            get
            {
                return user_name;
            }
            set
            {
                user_name = value;
            }
        }
        public static string Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }
        public static string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public static void ResetInfo()
        {
            text = user_name = email = name = null;
            ut = UserType.NONE;
    }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.Account
{
    public partial class Register1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            if (USER_PASS.Text != USER_PASS_CONF.Text)
            {
                match.Visible = true;
                return;
            }

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand check_user = new SqlCommand("SELECT * FROM users SELECT * FROM users WHERE user_name=\'" + USER_ID.Text + "\'", con);
            SqlCommand set = new SqlCommand("INSERT INTO users (user_name, password, email, name, last_login_date, type) VALUES (@userid, @userpass, @usermail, @username, @date, @type)", con);
            try
            {
                con.Open();
                SqlDataReader reader = check_user.ExecuteReader();
                while (reader.Read())
                {
                    if (reader["user_name"].ToString() == USER_ID.Text)
                    {
                        reader.Close();
                        con.Close();
                        JoinStatus.Text = "A user with this user id has been defined or send request already ...!";
                        return;
                    }
                }
                reader.Close();
                set.Parameters.Add("@userid", System.Data.SqlDbType.NVarChar, 30);
                set.Parameters.Add("@userpass", System.Data.SqlDbType.NVarChar, 30);
                set.Parameters.Add("@usermail", System.Data.SqlDbType.NVarChar, 30);
                set.Parameters.Add("@username", System.Data.SqlDbType.NVarChar, 15);
                set.Parameters.Add("@date", System.Data.SqlDbType.DateTime);
                set.Parameters.Add("@type", System.Data.SqlDbType.Int);
                set.Parameters["@userid"].Value = USER_ID.Text;
                set.Parameters["@userpass"].Value = USER_PASS_CONF.Text.GetHashCode();
                set.Parameters["@usermail"].Value = USER_EMAIL.Text;
                set.Parameters["@username"].Value = User_Name.Text;
                set.Parameters["@date"].Value = DateTime.Now;
                set.Parameters["@type"].Value = DropDownList1.SelectedIndex;
                set.ExecuteNonQuery();
                con.Close();
                Session["Join"] = "Join";
                Response.Redirect("Admin/Writters/WrittersManager.aspx");
            }
            catch
            {
                con.Close();
            }
        }
    }
}
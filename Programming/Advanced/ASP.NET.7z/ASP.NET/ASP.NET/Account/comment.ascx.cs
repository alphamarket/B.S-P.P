﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class comment : System.Web.UI.UserControl
    {
        public bool NameReadOnly
        {
            get
            {
                return name.ReadOnly;
            }
            set
            {
                name.ReadOnly = value;
            }
        }
        public bool MailReadOnly
        {
            get
            {
                return mail.ReadOnly;
            }
            set
            {
                mail.ReadOnly = value;
            }
        }
        public string NameTxt
        {
            get
            {
                return name.Text;
            }
            set
            {
                name.Text = value;
            }
        }
        public string MailTxt
        {
            get
            {
                return mail.Text;
            }
            set
            {
                mail.Text = value;
            }
        }
        public string CommentText
        {
            set
            {
                _comment.Text = value;
            }
            get
            {
                return _comment.Text;
            }
        }
        public TextBox CommentTextBox
        {
            get
            {
                return _comment;
            }
        }
        public Button Submit
        {
            get
            {
                return ok;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ok_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com;
            try
            {
                con.Open();
                com = new SqlCommand("select top 1 * from CommentsFilter order by id desc", con);
                SqlDataReader reader = com.ExecuteReader();
                if (reader.Read())
                {
                    string[] filters = reader["Filter"].ToString().Split(new string[] { ", ", ",", " ," }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string i in filters)
                        if (_comment.Text.ToLower().Contains(i.ToLower()))
                        {
                            WebMessage.WebMessageBox.Show("Your Message Has Inappropriated Word(s)!                                           Your Comments Did NOT Saved in Database ...");
                            return;
                        }
                    reader.Close();
                }
                string SQLQUERY = "INSERT INTO comment (name, email, _comment, newsid, date)VALUES( @nam, @mail, @com, @newid, @dt)";
                com = new SqlCommand(SQLQUERY, con);
                com.Parameters.Add("@nam", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters.Add("@mail", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters.Add("@com", System.Data.SqlDbType.Text);
                com.Parameters.Add("@newid", System.Data.SqlDbType.Int);
                com.Parameters.Add("@dt", System.Data.SqlDbType.DateTime);
                com.Parameters["@nam"].Value = name.Text;
                com.Parameters["@mail"].Value = mail.Text;
                com.Parameters["@com"].Value = GlobalInfo.SetEmotions(_comment.Text);
                com.Parameters["@newid"].Value = Request.QueryString["newsid"];
                com.Parameters["@dt"].Value = DateTime.Now;
                com.ExecuteNonQuery();
                Response.Redirect(Request.Url.ToString().Replace("&comid=" + Request.QueryString["comid"], "").Replace("#com_ment", ""));
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }

        protected void _comment_TextChanged(object sender, EventArgs e)
        {
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Collections;

class DataBase
{
    public static string ConnectionString = "Data Source=DARIUSH-PC;Initial Catalog=news_portal;Integrated Security=True";
}
    public struct emotions
    {
        public List<string> shortcut;
        public string address, title;
    }
    public struct GlobalInfo
    {
        enum SetConvert{ToEmotion, ToHTMLCode}
        static public List<emotions> Emotions = new List<emotions>();
        public static string SetEmotions(string query)
        {
            SetConvert sc=SetConvert.ToHTMLCode;
            foreach(emotions i in Emotions)
                if (query.Contains("<img src=\"" + i.address + "\" style alt=\"" + i.title.Replace(" ", "") + "\" border=\"0\"  title=\"" + i.title.Replace(" ", "") + "\"/>"))
                {
                    sc = SetConvert.ToEmotion;
                    break;
                }
            switch (sc)
            {
                case SetConvert.ToHTMLCode:
                    foreach (emotions i in GlobalInfo.Emotions)
                    {
                        if (AdvancedContain(i.shortcut, query))
                        {
                            AdvancedReplace(i, ref query);
                        }
                    }
                    return query;
                case SetConvert.ToEmotion:
                    string finalize = "";
                    foreach (emotions i in Emotions)
                    {
                        finalize = "<img src=\"" + i.address + "\" style alt=\"" + i.title.Replace(" ", "") + "\" border=\"0\"  title=\"" + i.title.Replace(" ", "") + "\"/>";
                        if (query.ToLower().Contains(finalize.ToLower()))
                            query = query.Replace(finalize, i.shortcut[0]);
                    }
                    return query;
            }
            return query;
        }
        public static bool AdvancedContain(List<string> str, string target)
        {
            foreach (string i in str)
            {
                string t = target.ToLower(),
                    im = i.ToLower();
                if (t.Contains(im))
                    return true;
            }
            return false;
        }
        public static void AdvancedReplace(emotions em, ref string target)
        {
            foreach (string i in em.shortcut)
                if (target.ToLower().Contains(i.ToLower()))
                {
                    target = target.Replace(target.Contains(i.ToLower()) ? i.ToLower() : i.ToUpper(), "<img src=\"" + em.address + "\" style alt=\"" + em.title.Replace(" ", "") + "\" border=\"0\"  title=\"" + em.title.Replace(" ", "") + "\"/>");
                    return;
                }
        }
        public static void AdvancedReplace(emotions em, ref string target, string replace)
        {
            foreach (string i in em.shortcut)
                if (target.ToLower().Contains(i.ToLower()))
                {
                    target = target.ToLower().Replace(i.ToLower(), replace);
                    return;
                }
        }
        public static string RemoveEmotions(string query){
            foreach (emotions i in Emotions)
            {
                string finalize = "<img src=\"" + i.address + "\" style alt=\"" + i.title.Replace(" ", "") + "\" border=\"0\"  title=\"" + i.title.Replace(" ", "") + "\"/>";
                if (query.ToLower().Contains(finalize.ToLower()))
                    query = query.Replace(finalize, "");
            }
           return query;
        }
    }
 
namespace WebMessage
{
      public class WebMessageBox
      {
            protected static Hashtable handlerPages = new Hashtable();            
            private WebMessageBox()
            {
            }
 
            public static void Show(string Message)
            {
                  if (!(handlerPages.Contains(HttpContext.Current.Handler)))
                  {
                        Page currentPage = (Page)HttpContext.Current.Handler;
                        if (!((currentPage == null)))
                        {
                              Queue messageQueue = new Queue();
                              messageQueue.Enqueue(Message);
                              handlerPages.Add(HttpContext.Current.Handler, messageQueue);
                              currentPage.Unload += new EventHandler(CurrentPageUnload);
                        }
                  }
                  else
                  {
                        Queue queue = ((Queue)(handlerPages[HttpContext.Current.Handler]));
                        queue.Enqueue(Message);
                  }
            }
 
            private static void CurrentPageUnload(object sender, EventArgs e)
            {
                  Queue queue = ((Queue)(handlerPages[HttpContext.Current.Handler]));
                  if (queue != null)
                  {
                        StringBuilder builder = new StringBuilder();
                        int iMsgCount = queue.Count;
                        builder.Append("<script language='javascript'>");
                        string sMsg;
                        while ((iMsgCount > 0))
                        {
                              iMsgCount = iMsgCount - 1;
                              sMsg = System.Convert.ToString(queue.Dequeue());
                              sMsg = sMsg.Replace("\"", "'");
                              builder.Append("alert( \"" + sMsg + "\" );");
                        }
                        builder.Append("</script>");
                        handlerPages.Remove(HttpContext.Current.Handler);
                        HttpContext.Current.Response.Write(builder.ToString());
                  }
            }
      }
 
}
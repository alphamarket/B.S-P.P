﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.AdminPrivacy.Comments
{
    public partial class FilterComments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
            {
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            }
            Filters.Focus();
            if (!this.IsPostBack)
            {
                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand com = new SqlCommand("select top 1 * from CommentsFilter order by id desc", con);
                try
                {
                    con.Open();
                    SqlDataReader reader = com.ExecuteReader();
                    if(reader.Read())
                        Filters.Text = reader["Filter"].ToString();
                    reader.Close();
                }
                catch (Exception er)
                {
                    WebMessage.WebMessageBox.Show(er.Message);
                }
                finally { con.Close(); }
            }
        }
        protected void svFltrs_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("DELETE CommentsFilter insert into CommentsFilter (Filter) values (@fil)", con);
            try
            {
                con.Open();
                com.Parameters.Add("@fil", System.Data.SqlDbType.Text);
                com.Parameters["@fil"].Value = Filters.Text;
                com.ExecuteNonQuery();
                WebMessage.WebMessageBox.Show("Filters Word(s) Have Been Saved Successfully ....");
            }
            catch (Exception er) { WebMessage.WebMessageBox.Show(er.Message); }
            finally { con.Close(); }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.AdminPrivacy.Comments
{
    public partial class DeleteComments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]) || LoggedInUserInfo._UserType == UserType.Normal || Request.QueryString["comid"]==null)
                Response.Redirect("../../../Default.aspx");
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("DELETE FROM comment where id=" + Request.QueryString["comid"], con);
            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch { }
            finally { 
                con.Close();
                if (Request.QueryString["redir"] != null)
                    Response.Redirect(Request.QueryString["redir"] + "&id=" + Request.QueryString["p"]);
                else
                    Response.Redirect("../../../Comment.aspx?newsid=" + Request.QueryString["newsid"] + "&id=" + Request.QueryString["p"]);
            
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class EditAbout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir="+Request.RawUrl);
            if (LoggedInUserInfo._UserType == UserType.Normal)
            {
                status.Visible = true;
                div.Visible = false;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }
            this.Title = "Edit About ...";
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("SELECT * FROM about_us order by id desc", con);
            try
            {
                con.Open();
                com.Parameters.Add("@abt", System.Data.SqlDbType.Text);
                com.Parameters["@abt"].Value = NewAboutText.Text;
                SqlDataReader reader = com.ExecuteReader();
                if (reader.Read())
                    current.Text = reader["about"].ToString().Replace("\r\n", "<br />");
                else
                    current.Text = "There is nothing saved in database!";
                reader.Close();
            }
            catch
            {
            }
            finally
            {
                con.Close();
                NewAboutText.Focus();
            }
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            bool i = true;
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("INSERT INTO about_us (about, date) VALUES(@abt, @date)", con);
            try
            {
                if (NewAboutText.Text.Replace("\r\n", "<br />").ToLower() == current.Text.ToLower())
                {
                    WebMessage.WebMessageBox.Show("You cannot set this passage to about us.Becuase of this is the current passge of About Us!!");
                    i = false;
                    return;
                }
                con.Open();
                com.Parameters.Add("@abt", System.Data.SqlDbType.Text);
                com.Parameters.Add("@date", System.Data.SqlDbType.Date);
                com.Parameters["@abt"].Value = NewAboutText.Text;
                com.Parameters["@date"].Value = DateTime.Now;
                com.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                WebMessage.WebMessageBox.Show(err.Message);
                return;
            }
            finally
            {
                con.Close();
                if(i)
                    Response.Redirect("~/Admin/AdminPrivacy/Admin.aspx");
            }
        }

        protected void Discard_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/AdminPrivacy/Admin.aspx");
        }
    }
}
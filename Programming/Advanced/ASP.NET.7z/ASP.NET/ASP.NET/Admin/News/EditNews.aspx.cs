﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class EditNews : System.Web.UI.Page
    {
        public int NumberOfRow;
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            this.Title = "Edit News...";
            if (LoggedInUserInfo._UserType == UserType.Normal && Request.QueryString["auther"] == null)
            {
                status.Visible = true;
                field.Visible = false;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }
            if (!IsPostBack)
            {
                string limitStatement;
                if (Request.QueryString["id"] == null)
                    limitStatement = "  0 and 10 ";
                else
                    limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand crt;
                if (Request.QueryString["edit"] == null)
                {
                    field.Visible = false;
                    crt = new SqlCommand("WITH news(_id, _poster, _topic, _smry, _body, _date, RowNumber, count)AS(SELECT _news.id, _news.poster, _news.news_topic, _news.news_smry, _news.news_body," +
                    "_news.news_create_date ,ROW_NUMBER() OVER (order by news_create_date) AS 'RowNumber', (SELECT COUNT(*) FROM comment where _news.id=comment.newsid ) as 'count' FROM _news)" +
                    "SELECT * FROM news decs WHERE RowNumber between " + limitStatement + " order by _date desc", con);
                    try
                    {
                        con.Open();
                        SqlDataReader reader = crt.ExecuteReader();
                        myRepeater.DataSource = reader;
                        myRepeater.DataBind();
                        reader.Close();
                        SqlCommand count = new SqlCommand("select COUNT(*) as count from _news", con);
                        reader = count.ExecuteReader();
                        if (reader.Read())
                            NumberOfRow = Convert.ToInt32(reader["count"]);
                        reader.Close();
                    }
                    catch (Exception err)
                    {
                        Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                else
                {
                    crt = new SqlCommand("Select * from _news where id=" + Convert.ToInt32(Request.QueryString["newsid"]), con);
                    myRepeater.Visible = false;
                    try
                    {
                        con.Open();
                        SqlDataReader reader = crt.ExecuteReader();
                        while (reader.Read())
                        {
                            topic.Text = GlobalInfo.SetEmotions(reader["news_topic"].ToString());
                            newssmry.Text = GlobalInfo.SetEmotions(reader["news_smry"].ToString());
                            newsBody.Text = GlobalInfo.SetEmotions(reader["news_body"].ToString());
                        }
                        field.Visible = true;
                    }
                    catch
                    {
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }
        protected void AddNews_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("UPDATE _news SET poster=@poster, news_topic=@topic, news_smry=@smry, news_body=@body, news_modified_date=@date" +
                " where id=" + Request.QueryString["newsid"], con);
            try
            {
                com.Parameters.Add("@poster", System.Data.SqlDbType.NVarChar, 20);
                com.Parameters.Add("@topic", System.Data.SqlDbType.Text);
                com.Parameters.Add("@smry", System.Data.SqlDbType.Text);
                com.Parameters.Add("@body", System.Data.SqlDbType.Text);
                com.Parameters.Add("@date", System.Data.SqlDbType.DateTime);
                com.Parameters["@poster"].Value = erae.LoggedInUserInfo.Name;
                com.Parameters["@topic"].Value = GlobalInfo.SetEmotions(topic.Text);
                com.Parameters["@smry"].Value = GlobalInfo.SetEmotions(newssmry.Text);
                com.Parameters["@body"].Value = GlobalInfo.SetEmotions(newsBody.Text);
                com.Parameters["@date"].Value = DateTime.Now;
                con.Open();
                com.ExecuteNonQuery();
                con.Close();
                if(LoggedInUserInfo._UserType==UserType.Normal)
                    Response.Redirect("~/Admin/News/ManageNews.aspx");
                else
                    Response.Redirect("~/Admin/News/EditNews.aspx");
            }
            catch
            {
                con.Close();
                saveError.Text = "Something went wrong while trying to save news !";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class ManageNews : System.Web.UI.Page
    {
        public int NumberOfRow;
        public static string status(string id, string poster, MyNewsStatus ns, string no)
        {
            string str = "<a style=\"text-decoration:none;\" target=\"_blank\" href=\"../../ShowNews.aspx?newsid=" + id + "\"> Continue . . . </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
                "<a style=\"text-decoration:none;\" target=\"_blank\" href=\"../../Comment.aspx?newsid=" + id + "&id=1\"> Comments ( "+no+" ) </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            if (erae.LoggedInUserInfo._UserType != erae.UserType.Normal || poster == erae.LoggedInUserInfo.Name)
            {

                str+= "<a style=\"text-decoration:none;\" href=\"../News/EditNews.aspx?newsid=" + id + "&edit=1&auther=1\"> Edit . . . </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+
                        "<a style=\"text-decoration:none;margin-left:29%;color:#D41F55;\" href=\"../News/DeleteNews.aspx?newsid=" + id + "&delete=1&auther=1\"> Delete . . . </a>";
            }
            if(ns==MyNewsStatus.True)
                return str.Replace("auther=1","auther=2");
            return str;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir="+Request.RawUrl);
            Title = "News Management ...";
            string limitStatement;
            if (Request.QueryString["id"] == null)
                limitStatement = "  0 and 10 ";
            else
                limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand crt = new SqlCommand("WITH news(_id, _poster, _topic, _smry, _body, _date, _email, RowNumber, count)AS(SELECT _news.id, _news.poster, _news.news_topic, _news.news_smry, _news.news_body,"+
                    "_news.news_create_date, _news.email ,ROW_NUMBER() OVER (order by news_create_date) AS 'RowNumber', (SELECT COUNT(*) FROM comment where _news.id=comment.newsid ) as 'count' FROM _news)"+
                    "SELECT * FROM news decs WHERE RowNumber between " + limitStatement + " order by _date desc", con);
            try
            {
                con.Open();
                SqlDataReader reader = crt.ExecuteReader();
                myRepeater.DataSource = reader;
                myRepeater.DataBind();
                reader.Close();
                SqlCommand count = new SqlCommand("select COUNT(*) as count from _news", con);
                reader = count.ExecuteReader();
                if (reader.Read())
                    NumberOfRow = Convert.ToInt32(reader["count"]);
                reader.Close();
            }
            catch (Exception err)
            {
                Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
            }
            finally
            {
                con.Close();
            }
        }
    }
}
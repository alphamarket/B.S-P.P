﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public enum MyNewsStatus { False, True }
namespace erae.News
{
    public partial class MyNews : System.Web.UI.Page
    {
        public int NumberOfRow;
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            Title = "News Management ...";
            string limitStatement;
            if (Request.QueryString["id"] == null)
                limitStatement = "  0 and 10 ";
            else
                limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand crt = new SqlCommand("WITH news(_id, _poster, _topic, _smry, _body, _date, _email, RowNumber, count)AS " +
                "(SELECT _news.id, _news.poster, _news.news_topic, _news.news_smry, _news.news_body, _news.news_create_date, _news.email, ROW_NUMBER() OVER (order by news_create_date) AS 'RowNumber', (SELECT COUNT(*) FROM comment where"+" comment.newsid=_news.id) as 'count' FROM _news WHERE poster=\'"+LoggedInUserInfo.Name+"\')" +
                "SELECT * FROM news decs WHERE RowNumber between " + limitStatement + " order by _date desc", con);
            try
            {
                con.Open();
                SqlDataReader reader = crt.ExecuteReader();
                myRepeater.DataSource = reader;
                myRepeater.DataBind();
                reader.Close();
                SqlCommand count = new SqlCommand("select COUNT(*) as count from _news WHERE poster=\'"+LoggedInUserInfo.Name+"\'", con);
                reader = count.ExecuteReader();
                if (reader.Read())
                    NumberOfRow = Convert.ToInt32(reader["count"]);
                reader.Close();
            }
            catch (Exception err)
            {
                Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
            }
            finally
            {
                con.Close();
            }
        }
    }
}
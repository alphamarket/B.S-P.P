﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.News
{
    public partial class AddNews : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir="+Request.RawUrl);
            this.Title = "Adding News ...";
            topic.Focus();
        }

        protected void AddNews_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("INSERT INTO _news (poster, news_topic, news_smry, news_body, news_create_date, news_modified_date, email)" +
                " VALUES (@poster, @topic, @smry, @body, @date, @_date, @mail)", con);
            try
            {
                com.Parameters.Add("@poster", System.Data.SqlDbType.NVarChar, 20);
                com.Parameters.Add("@mail", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters.Add("@topic", System.Data.SqlDbType.Text);
                com.Parameters.Add("@smry", System.Data.SqlDbType.Text);
                com.Parameters.Add("@body", System.Data.SqlDbType.Text);
                com.Parameters.Add("@date", System.Data.SqlDbType.DateTime);
                com.Parameters.Add("@_date", System.Data.SqlDbType.DateTime);
                com.Parameters["@poster"].Value=erae.LoggedInUserInfo.Name;
                com.Parameters["@topic"].Value = GlobalInfo.SetEmotions(topic.Text);
                com.Parameters["@smry"].Value = GlobalInfo.SetEmotions(newssmry.Text);
                com.Parameters["@body"].Value = GlobalInfo.SetEmotions(newsBody.Text);
                com.Parameters["@date"].Value = DateTime.Now;
                com.Parameters["@_date"].Value = DateTime.Now;
                com.Parameters["@mail"].Value = LoggedInUserInfo.Email;
                con.Open();
                com.ExecuteNonQuery();
                con.Close();
                Response.Redirect("~/Admin/News/ManageNews.aspx");
            }
            catch
            {
                con.Close();
                saveError.Text = "Something went wrong while trying to save news !";
            }
        }
    }
}
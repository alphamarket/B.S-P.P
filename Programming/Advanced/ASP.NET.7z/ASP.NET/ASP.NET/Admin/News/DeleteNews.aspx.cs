﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class DeleteNews : System.Web.UI.Page
    {
        public int NumberOfRow;
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            this.Title = "Delete News ...";
            if (Request.QueryString["auther"] != null && LoggedInUserInfo._UserType==UserType.Normal || Request.QueryString["auther"]=="2")
                deleteNormalPoster(new SqlConnection(DataBase.ConnectionString));
            if (LoggedInUserInfo._UserType == UserType.Normal)
            {
                status.Visible = true;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }
            if (!IsPostBack)
            {
                this.Title = "Delete News...";
                string limitStatement;
                if (Request.QueryString["id"] == null)
                    limitStatement = "  0 and 10 ";
                else
                    limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand crt;
                if (Request.QueryString["delete"] == null)
                {
                    crt = new SqlCommand("WITH news(_id, _poster, _topic, _smry, _body, _date, RowNumber, count)AS(SELECT _news.id, _news.poster, _news.news_topic, _news.news_smry, _news.news_body," +
                    "_news.news_create_date ,ROW_NUMBER() OVER (order by news_create_date) AS 'RowNumber', (SELECT COUNT(*) FROM comment where _news.id=comment.newsid ) as 'count' FROM _news)" +
                    "SELECT * FROM news decs WHERE RowNumber between " + limitStatement + " order by _date desc", con);
                    try
                    {
                        con.Open();
                        SqlDataReader reader = crt.ExecuteReader();
                        myRepeater.DataSource = reader;
                        myRepeater.DataBind();
                        reader.Close();
                        SqlCommand count = new SqlCommand("select COUNT(*) as count from _news", con);
                        reader = count.ExecuteReader();
                        if (reader.Read())
                            NumberOfRow = Convert.ToInt32(reader["count"]);
                        reader.Close();
                    }
                    catch (Exception err)
                    {
                        Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                else
                {
                    crt = new SqlCommand("DELETE FROM _news where id=" + Request.QueryString["newsid"]+" DELETE FROM comment WHERE newsid="+Request.QueryString["newsid"], con);
                    try
                    {
                        con.Open();
                        crt.ExecuteNonQuery();
                        Response.Redirect("DeleteNews.aspx");
                    }
                    catch (Exception err)
                    {
                        Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }
        void deleteNormalPoster(SqlConnection con)
        {

            SqlCommand crt = new SqlCommand("DELETE FROM _news where id=" + Request.QueryString["newsid"], con);
            try
            {
                con.Open();
                crt.ExecuteNonQuery();
                if (Request.QueryString["auther"] == "1")
                    Response.Redirect("ManageNews.aspx");
                else
                    Response.Redirect("MyNews.aspx");
            }
            catch (Exception err)
            {
                Response.Write("<p style=\"color:Red\">" + err.Message + "</p>");
            }
            finally
            {
                con.Close();
            }
        }
    }
}
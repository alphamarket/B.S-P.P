﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.Writters
{
    public partial class SearchWritter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("../../LogIn.aspx?redir=" + Request.RawUrl);
            user_name.Focus();
            this.Title = "Users Search ...";
        }
        protected void search_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("select * from users where name like @nam and user_name like @userName and email like @mail order by last_login_date desc", con);
            try
            {
                com.Parameters.Add("@nam", System.Data.SqlDbType.NVarChar, 15);
                com.Parameters.Add("@userName", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters.Add("@mail", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters["@nam"].Value = "%"+user_name.Text+"%";
                com.Parameters["@userName"].Value = "%"+user_id.Text + "%";
                com.Parameters["@mail"].Value = "%"+user_mail.Text + "%";
                con.Open();
                SqlDataReader reader = com.ExecuteReader();
                myRepeater.DataSource = reader;
                myRepeater.DataBind();
                reader.Close();
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }
    }
}
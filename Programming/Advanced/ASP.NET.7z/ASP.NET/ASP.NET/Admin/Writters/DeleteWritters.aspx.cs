﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.Writters
{
    public partial class DeleteWritters : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = "Delete Writters ...";
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            if (LoggedInUserInfo._UserType == UserType.Normal)
            {
                status.Visible = true;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }

            if (Request.QueryString["id"] == null)
            {
                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand com = new SqlCommand("select * from users order by id desc",con);// where users.type!=1 order by last_login_date", con);
                try
                {
                    con.Open();
                    SqlDataReader reader = com.ExecuteReader();
                    if (!reader.Read())
                    {
                        status.Visible = true;
                        status.Text = "There is not any normal user to show!";
                        return;
                    }
                    myRepeater.DataSource = reader;
                    myRepeater.DataBind();
                    reader.Close();
                }
                catch (Exception Error)
                {
                    WebMessage.WebMessageBox.Show(Error.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand com = new SqlCommand("DELETE FROM users WHERE id=@id", con);
                com.Parameters.Add("@id", System.Data.SqlDbType.Int);
                com.Parameters["@id"].Value = Request.QueryString["id"];
                try
                {
                    con.Open();
                    com.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    WebMessage.WebMessageBox.Show(err.Message);
                }
                finally
                {
                    con.Close();
                    Response.Redirect("DeleteWritters.aspx");
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.Writters
{
    public partial class WrittersManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = "Writters Managers ...";
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx?redir=" + Request.RawUrl);
            if (LoggedInUserInfo._UserType == UserType.Normal)
            {
                status.Visible = true;
                status.Text = "You Have Not That Authorization To Access This Part Of Site!";
                return;
            }
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("SELECT * FROM users order by id desc", con);// where type!=1 order by last_login_date desc", con);
            try
            {
                con.Open();
                SqlDataReader reader = com.ExecuteReader();
                if (!reader.Read())
                {
                    status.Visible = true;
                    status.Text = "There is not any normal user to show!";
                    return;
                }
                myRepeater.DataSource = reader;                    
                myRepeater.DataBind();
                reader.Close();
            }
            catch (Exception Error)
            {
                WebMessage.WebMessageBox.Show(Error.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
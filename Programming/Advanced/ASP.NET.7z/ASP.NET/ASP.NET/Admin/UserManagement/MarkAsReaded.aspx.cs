﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace erae.UserManagement
{
    public partial class MarkAsReaded : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]))
                Response.Redirect("~/Login.aspx");
            //TODO: PUT IN READED TABLE IN DB
            Response.Redirect("~/Admin/UserManagement/UsersMessages.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae.News
{
    public partial class ShowNews : System.Web.UI.Page
    {
        public int NumberOfRow;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            try
            {
                if (Request.QueryString["newsid"] == null)
                    Response.Redirect(Request.ServerVariables.Get("HTTP_REFERER"));
                string i = Request.QueryString["newsid"];
                SqlCommand _com = new SqlCommand("SELECT * FROM _news WHERE id=" + i, con);
                try
                {
                    con.Open();
                    SqlDataReader reader = _com.ExecuteReader();
                    myRepeater.DataSource = reader;
                    myRepeater.DataBind();
                    reader.Close();
                }
                catch
                {
                    con.Close();
                }
            }
            catch (ArgumentNullException)
            {
                Response.Redirect("Default.aspx");
            }
            try
            {
                string limitStatement;
                if (Request.QueryString["id"] == null)
                    limitStatement = "  0 and 10 ";
                else
                    limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10+1).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();

                SqlCommand com = new SqlCommand("WITH com(_id, _name, _email, _comment, _date, RowNumber)AS " +
                    "(SELECT id, name, email, _comment, date, ROW_NUMBER() OVER (order by id desc) AS 'RowNumber' FROM comment WHERE newsid=" + Request.QueryString["newsid"] + ")" +
                    "SELECT * FROM com WHERE RowNumber between " + limitStatement + " order by _id desc", con);
                SqlDataReader reader = com.ExecuteReader();
                Repeater1.DataSource = reader;
                Repeater1.DataBind();
                reader.Close();
                com = new SqlCommand("select COUNT(*) as count from comment where newsid=" + Request.QueryString["newsid"], con);
                reader = com.ExecuteReader();
                if (reader.Read())
                    NumberOfRow = Convert.ToInt32(reader["count"]);
                reader.Close();
                com_ment.Visible = true;
                if (Convert.ToBoolean(Session["LOGIN"]))
                {
                    com_ment.NameTxt = LoggedInUserInfo.Name;
                    com_ment.NameReadOnly = true;
                    com_ment.MailReadOnly = true;
                    com_ment.MailTxt = LoggedInUserInfo.Email;
                }
            }
            catch
            {
            }
            finally
            {
                con.Close();
            }
        }

        void Page_PreInit(Object s, EventArgs e)
        {
            if(Request.QueryString["logged"]!=null)
                MasterPageFile="\\Admin\\News\\ManageNews.Master";
        }
        protected void btn_Click(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(Session["LOGIN"]) || LoggedInUserInfo._UserType == UserType.Normal)
                Response.Redirect("../../../Default.aspx");

            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("UPDATE comment SET _comment=@com WHERE id=" + Request.QueryString["comid"], con);
            try
            {
                com.Parameters.Add("@com", System.Data.SqlDbType.Text);
                com.Parameters["@com"].Value = LoggedInUserInfo.TempText;
                LoggedInUserInfo.TempText = "";
                con.Open();
                com.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                con.Close();
                Response.Redirect("ShowNews.aspx?newsid=" + Request.QueryString["newsid"] + "&id=" + Request.QueryString["p"]);
            }
        }

        protected void btn_cncl_Click(object sender, EventArgs e)
        {
            Response.Redirect("ShowNews.aspx?newid=" + Request.QueryString["newid"] + "&id=" + Request.QueryString["id="]);
        }
    }
}
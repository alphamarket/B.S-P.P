﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace erae.Account
{
    public partial class Contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = "Contact us ...";
            if (Convert.ToBoolean(Session["LOGIN"]))
            {
                TextBox1.Text = LoggedInUserInfo.Name;
                TextBox2.Text = LoggedInUserInfo.Email;
            }
        }
        void Page_PreInit(Object s, EventArgs e)
        {
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBase.ConnectionString);
            SqlCommand com = new SqlCommand("INSERT INTO contact (name, phone, text, email)" +
                " VALUES (@nam, @phon, @txt, @mail)", con);
            try
            {
                com.Parameters.Add("@nam", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters.Add("@phon", System.Data.SqlDbType.NChar, 20);
                com.Parameters.Add("@txt", System.Data.SqlDbType.Text);
                com.Parameters.Add("@mail", System.Data.SqlDbType.NVarChar, 30);
                com.Parameters["@nam"].Value = TextBox1.Text;
                com.Parameters["@phon"].Value = phoneTxt.Text;
                com.Parameters["@txt"].Value = messageTxt.Text;
                com.Parameters["@mail"].Value = TextBox2.Text;
                con.Open();
                com.ExecuteNonQuery();
            }
            catch
            {
                status.Visible = true;
                status.Text = "Sorry, Unable to send your message, try later!";
            }
            finally
            {
                con.Close();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace erae
{
    public partial class LogOut : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Remove("LOGIN");
            if (Convert.ToInt64(Application["MEMBERSNO"]) > 1)
                Application["MEMBERSNO"] = Convert.ToInt64(Application["MEMBERSNO"]) + 1;
            else
                Application["MEMBERSNO"] = 0;
            this.Response.Redirect("~/Default.aspx");
        }
    }
}
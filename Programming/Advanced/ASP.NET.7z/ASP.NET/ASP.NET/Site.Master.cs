﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        public enum Span { Start, End }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["LOGIN"]))
            {
                Qlogin.Visible = false;
            }
            else
                Qlogin.Visible = true;
        }
        protected void QloginBtn_Click(object sender, EventArgs e)
        {
            if (Qpass.Text != "" && QuserName.Text != "")
            {
                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand com = new SqlCommand("SELECT * FROM users WHERE user_name=\'" + QuserName.Text + "\'", con);
                try
                {
                    con.Open();
                    SqlDataReader reader = com.ExecuteReader();
                    if (reader.Read())
                    {
                        if (int.Parse(reader["password"].ToString()) == Qpass.Text.GetHashCode())
                        {
                            LoggedInUserInfo.Name = reader["name"].ToString();
                            LoggedInUserInfo.UserName = QuserName.Text;
                            LoggedInUserInfo.Email = reader["email"].ToString();
                            LoggedInUserInfo.LastLogIn = (DateTime)reader["last_login_date"];
                            if (reader["type"].ToString() == "")
                                LoggedInUserInfo._UserType = UserType.Admin;
                            else if (Convert.ToInt16(reader["type"]) == 1)
                                LoggedInUserInfo._UserType = UserType.Admin;
                            else if (Convert.ToInt16(reader["type"]) == 2)
                                LoggedInUserInfo._UserType = UserType.Supper;
                            else
                                LoggedInUserInfo._UserType = UserType.Normal;
                            com = new SqlCommand("UPDATE users SET last_login_date=@date WHERE id=" + reader["id"].ToString(), con);
                            reader.Close();
                            com.Parameters.Add("@date", System.Data.SqlDbType.DateTime);
                            com.Parameters["@date"].Value = DateTime.Now;
                            com.ExecuteNonQuery();
                            con.Close();
                            Session["LOGIN"] = true;
                            Application["MEMBERSNO"] = Convert.ToInt64(Application["MEMBERSNO"]) + 1;
                            Response.Redirect(Request.QueryString["redir"] == null ? "~\\Admin\\AdminPrivacy\\Admin.aspx" : "~" + Request.QueryString["redir"]);
                        }
                        else
                            throw new Exception("Wrong Username Or Passwsord!");
                    }
                    else
                    {
                        throw new Exception("This User Is Not Registered Yet ....");
                    }
                }
                catch (Exception err)
                {
                    WebMessage.WebMessageBox.Show(err.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}

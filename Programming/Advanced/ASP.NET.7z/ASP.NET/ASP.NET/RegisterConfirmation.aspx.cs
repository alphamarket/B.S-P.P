﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace erae.Account
{
    public partial class RegisterConfirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Join"] == null)
                Response.Redirect("~/Default.aspx");
            if (Session["Join"].ToString() == "Remove")
            {
                Label1.Text = "Your account has been removed successfully.";
                Session.Remove("Join");
            }
            else if (Session["Join"].ToString() == "Join")
            {
                Label1.Text = "The users has been joined successfully.";
                Session.Remove("Join");
            }
        }
    }
}
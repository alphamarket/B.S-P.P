﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace erae
{
    
    public partial class Comment : System.Web.UI.Page
    {
        public int NumberOfRow;
        public static string mailStatus(string email, string name)
        {
            if (!string.IsNullOrEmpty(email))
            {
                if (email.ToString().Contains("@yahoo.com"))
                    return "<a style=\"color:Red;text-decoration:none\" title=\"Send E-mail To : " + email + "\" href=\"mailto:" + email + "\">" + (string.IsNullOrEmpty(name) ? "Anonymous" : name) + "</a><span style=\"margin-left:7px;\"><a href=\"ymsgr:sendim?" + email.Replace("@yahoo.com", "") + "\">"+
                        "<img src=\"..\\..\\images\\yahoo-messenger - white.jpg\" style alt=\"+Yahoo!\" border=\"0\"  title=\"Send Your Message With Yahoo!\" /></a></span>";
                return "<a style=\"color:Red;text-decoration:none\" title=\"Send E-mail To : " + email + "\" href=\"mailto:" + email + "\">" + (string.IsNullOrEmpty(name) ? "Anonymous" : name) + "</a>";
            }
            else
                return "Anonymous";
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            NumberOfRow = 0;
            this.Title = "Commentting ...";
            if (Request.QueryString["newsid"] != null)
            {
                SqlConnection con = new SqlConnection(DataBase.ConnectionString);
                SqlCommand com = new SqlCommand("SELECT news_topic, news_smry FROM _news where id=" + Request.QueryString["newsid"], con);
                try
                {
                    con.Open();
                    SqlDataReader reader = com.ExecuteReader();
                    if (reader.Read())
                    {
                        name.Text = reader["news_topic"].ToString();
                        smry.Text = reader["news_smry"].ToString().Replace("\r\n", "<br />");
                    }
                    else
                    {
                        name.ForeColor = System.Drawing.Color.Red;
                        name.Text = "This new does not exists in database any more!";
                        smry.Visible = false;
                        return;
                    }
                    reader.Close();

                    string limitStatement;
                    if (Request.QueryString["id"] == null)
                        limitStatement = "  0 and 10 ";
                    else
                        limitStatement = ((int.Parse(Request.QueryString["id"]) - 1) * 10).ToString() + " and " + (int.Parse(Request.QueryString["id"]) * 10).ToString();
                    
 
                    com = new SqlCommand("WITH com(_id, _name, _email, _comment, _date, RowNumber)AS " +
                        "(SELECT id, name, email, _comment, date, ROW_NUMBER() OVER (order by id desc) AS 'RowNumber' FROM comment WHERE newsid=" + Request.QueryString["newsid"] + ")" +
                        "SELECT * FROM com WHERE RowNumber between " + limitStatement + " order by _id desc", con);
                    reader = com.ExecuteReader();
                    myRepeater.DataSource = reader;
                    myRepeater.DataBind();
                    reader.Close();
                    com = new SqlCommand("select COUNT(*) as count from comment where newsid=" + Request.QueryString["newsid"], con);
                    reader = com.ExecuteReader();
                    if (reader.Read())
                        NumberOfRow = Convert.ToInt32(reader["count"]);
                    reader.Close();
                    com_ment.Visible = true;
                    if (Convert.ToBoolean(Session["LOGIN"]))
                    {
                        com_ment.NameTxt = LoggedInUserInfo.Name;
                        com_ment.NameReadOnly = true;
                        com_ment.MailReadOnly = true;
                        com_ment.MailTxt = LoggedInUserInfo.Email;
                    }
                }
                catch
                {
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }

    }
}
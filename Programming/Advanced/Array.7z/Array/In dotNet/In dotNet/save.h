#pragma once
using namespace System;
ref class save
{
	static String^userName="",^LastLogIn="";
	static bool shouldStartTheGame=false,keeping=true,signing=false,createOne=false,_exit=false;
public:
	save();
	static bool keepGoing(){return keeping;}
	static bool shouldSigningOut(){return signing;}
	static bool canProceed(){return shouldStartTheGame;}
	static bool isCreatingOne(){return createOne;}
	static String^getUserID(){return userName;}
	static String^lastLogIn(){return LastLogIn;}
	static void setUserID(String^);
	static void isValidUserID(String^);
	static void setProceed(){shouldStartTheGame=true;}
	static void ShouldExit(){keeping=false;shouldStartTheGame=false;_exit=true;}
	static bool exit(){return _exit;}
	static void resetEth();
	static void signOut(){signing=true;}
	static void create_One(bool what){createOne=what;}
	static void lastLogIn(String^what){LastLogIn=what;}
};

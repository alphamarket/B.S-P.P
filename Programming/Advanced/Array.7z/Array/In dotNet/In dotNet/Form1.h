#pragma once
#include "UserID.h"
#include "save.h"
namespace IndotNet {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  statusLabel;
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::TabPage^  tabPage2;
	private: System::Windows::Forms::Label^  lectureLabel;
	private: System::Windows::Forms::Label^  termLabel;
	private: System::Windows::Forms::Label^  yearLabel;





	private: System::Windows::Forms::TextBox^  newTxtBx3;
	private: System::Windows::Forms::TextBox^  newTxtBx2;
	private: System::Windows::Forms::TextBox^  newTxtBx1;
	private: System::Windows::Forms::ComboBox^  lectureCombo;
	private: System::Windows::Forms::ComboBox^  termCombo;
	private: System::Windows::Forms::ComboBox^  yearCombo;

	private: System::Windows::Forms::Button^  clearFieldsBtn;
	private: System::Windows::Forms::Button^  saveGradesBrn;
	private: System::Windows::Forms::RichTextBox^  richInfoFeed;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  newCnclBtn3;
	private: System::Windows::Forms::Button^  newOkBtn3;


	private: System::Windows::Forms::Button^  lectureDelCourseBtn;
	private: System::Windows::Forms::Button^  termDelCourseBtn;
	private: System::Windows::Forms::Button^  yeardelCourseBtn;
	private: System::Windows::Forms::Button^  exitBtn;


	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::RadioButton^  radioButton4;

	private: System::Windows::Forms::RadioButton^  radioButton3;


	private: System::Windows::Forms::RichTextBox^  richTextBox2;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::RadioButton^  radioButton2;
	private: System::Windows::Forms::RadioButton^  radioButton1;
	private: System::Windows::Forms::Button^  resShoBtn;

	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Button^  newCnclBtn2;
	private: System::Windows::Forms::Button^  newOkBtn2;
	private: System::Windows::Forms::Button^  newCnclBtn1;
	private: System::Windows::Forms::Button^  newOkBtn1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::BindingSource^  bindingSource1;























































	private: System::ComponentModel::IContainer^  components;

	protected: 
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->statusLabel = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->exitBtn = (gcnew System::Windows::Forms::Button());
			this->lectureDelCourseBtn = (gcnew System::Windows::Forms::Button());
			this->termDelCourseBtn = (gcnew System::Windows::Forms::Button());
			this->yeardelCourseBtn = (gcnew System::Windows::Forms::Button());
			this->clearFieldsBtn = (gcnew System::Windows::Forms::Button());
			this->saveGradesBrn = (gcnew System::Windows::Forms::Button());
			this->richInfoFeed = (gcnew System::Windows::Forms::RichTextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->newCnclBtn3 = (gcnew System::Windows::Forms::Button());
			this->newOkBtn3 = (gcnew System::Windows::Forms::Button());
			this->newCnclBtn2 = (gcnew System::Windows::Forms::Button());
			this->newOkBtn2 = (gcnew System::Windows::Forms::Button());
			this->newCnclBtn1 = (gcnew System::Windows::Forms::Button());
			this->newOkBtn1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->newTxtBx3 = (gcnew System::Windows::Forms::TextBox());
			this->newTxtBx2 = (gcnew System::Windows::Forms::TextBox());
			this->newTxtBx1 = (gcnew System::Windows::Forms::TextBox());
			this->lectureCombo = (gcnew System::Windows::Forms::ComboBox());
			this->termCombo = (gcnew System::Windows::Forms::ComboBox());
			this->yearCombo = (gcnew System::Windows::Forms::ComboBox());
			this->lectureLabel = (gcnew System::Windows::Forms::Label());
			this->termLabel = (gcnew System::Windows::Forms::Label());
			this->yearLabel = (gcnew System::Windows::Forms::Label());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton3 = (gcnew System::Windows::Forms::RadioButton());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
			this->resShoBtn = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->bindingSource1 = (gcnew System::Windows::Forms::BindingSource(this->components));
			this->statusStrip1->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->bindingSource1))->BeginInit();
			this->SuspendLayout();
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->statusLabel});
			this->statusStrip1->Location = System::Drawing::Point(0, 336);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(857, 22);
			this->statusStrip1->SizingGrip = false;
			this->statusStrip1->TabIndex = 6;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// statusLabel
			// 
			this->statusLabel->Name = L"statusLabel";
			this->statusLabel->Size = System::Drawing::Size(0, 17);
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Location = System::Drawing::Point(0, 0);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(859, 333);
			this->tabControl1->TabIndex = 7;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->exitBtn);
			this->tabPage1->Controls->Add(this->lectureDelCourseBtn);
			this->tabPage1->Controls->Add(this->termDelCourseBtn);
			this->tabPage1->Controls->Add(this->yeardelCourseBtn);
			this->tabPage1->Controls->Add(this->clearFieldsBtn);
			this->tabPage1->Controls->Add(this->saveGradesBrn);
			this->tabPage1->Controls->Add(this->richInfoFeed);
			this->tabPage1->Controls->Add(this->label7);
			this->tabPage1->Controls->Add(this->newCnclBtn3);
			this->tabPage1->Controls->Add(this->newOkBtn3);
			this->tabPage1->Controls->Add(this->newCnclBtn2);
			this->tabPage1->Controls->Add(this->newOkBtn2);
			this->tabPage1->Controls->Add(this->newCnclBtn1);
			this->tabPage1->Controls->Add(this->newOkBtn1);
			this->tabPage1->Controls->Add(this->label3);
			this->tabPage1->Controls->Add(this->label2);
			this->tabPage1->Controls->Add(this->label1);
			this->tabPage1->Controls->Add(this->newTxtBx3);
			this->tabPage1->Controls->Add(this->newTxtBx2);
			this->tabPage1->Controls->Add(this->newTxtBx1);
			this->tabPage1->Controls->Add(this->lectureCombo);
			this->tabPage1->Controls->Add(this->termCombo);
			this->tabPage1->Controls->Add(this->yearCombo);
			this->tabPage1->Controls->Add(this->lectureLabel);
			this->tabPage1->Controls->Add(this->termLabel);
			this->tabPage1->Controls->Add(this->yearLabel);
			this->tabPage1->Location = System::Drawing::Point(4, 25);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(851, 304);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"Workpage";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// exitBtn
			// 
			this->exitBtn->Location = System::Drawing::Point(698, 259);
			this->exitBtn->Name = L"exitBtn";
			this->exitBtn->Size = System::Drawing::Size(139, 39);
			this->exitBtn->TabIndex = 26;
			this->exitBtn->Text = L"Exit";
			this->exitBtn->UseVisualStyleBackColor = true;
			this->exitBtn->Click += gcnew System::EventHandler(this, &Form1::exitBtn_Click);
			// 
			// lectureDelCourseBtn
			// 
			this->lectureDelCourseBtn->Location = System::Drawing::Point(394, 80);
			this->lectureDelCourseBtn->Name = L"lectureDelCourseBtn";
			this->lectureDelCourseBtn->Size = System::Drawing::Size(198, 23);
			this->lectureDelCourseBtn->TabIndex = 27;
			this->lectureDelCourseBtn->Text = L"Delete this course items";
			this->lectureDelCourseBtn->UseVisualStyleBackColor = true;
			// 
			// termDelCourseBtn
			// 
			this->termDelCourseBtn->Location = System::Drawing::Point(394, 50);
			this->termDelCourseBtn->Name = L"termDelCourseBtn";
			this->termDelCourseBtn->Size = System::Drawing::Size(198, 23);
			this->termDelCourseBtn->TabIndex = 28;
			this->termDelCourseBtn->Text = L"Delete this course items";
			this->termDelCourseBtn->UseVisualStyleBackColor = true;
			// 
			// yeardelCourseBtn
			// 
			this->yeardelCourseBtn->Location = System::Drawing::Point(394, 20);
			this->yeardelCourseBtn->Name = L"yeardelCourseBtn";
			this->yeardelCourseBtn->Size = System::Drawing::Size(198, 23);
			this->yeardelCourseBtn->TabIndex = 29;
			this->yeardelCourseBtn->Text = L"Delete this course items";
			this->yeardelCourseBtn->UseVisualStyleBackColor = true;
			// 
			// clearFieldsBtn
			// 
			this->clearFieldsBtn->Location = System::Drawing::Point(266, 259);
			this->clearFieldsBtn->Name = L"clearFieldsBtn";
			this->clearFieldsBtn->Size = System::Drawing::Size(326, 39);
			this->clearFieldsBtn->TabIndex = 21;
			this->clearFieldsBtn->Text = L"Clear Fields";
			this->clearFieldsBtn->UseVisualStyleBackColor = true;
			this->clearFieldsBtn->Click += gcnew System::EventHandler(this, &Form1::clearFieldsBtn_Click);
			// 
			// saveGradesBrn
			// 
			this->saveGradesBrn->Location = System::Drawing::Point(23, 259);
			this->saveGradesBrn->Name = L"saveGradesBrn";
			this->saveGradesBrn->Size = System::Drawing::Size(139, 39);
			this->saveGradesBrn->TabIndex = 20;
			this->saveGradesBrn->Text = L"Save Grades";
			this->saveGradesBrn->UseVisualStyleBackColor = true;
			this->saveGradesBrn->Click += gcnew System::EventHandler(this, &Form1::saveGradesBrn_Click);
			// 
			// richInfoFeed
			// 
			this->richInfoFeed->Location = System::Drawing::Point(23, 138);
			this->richInfoFeed->Name = L"richInfoFeed";
			this->richInfoFeed->Size = System::Drawing::Size(814, 115);
			this->richInfoFeed->TabIndex = 30;
			this->richInfoFeed->Text = L"";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(20, 118);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(311, 17);
			this->label7->TabIndex = 31;
			this->label7->Text = L"Enter Garde : ( seperate gardes with comma \',\' )";
			// 
			// newCnclBtn3
			// 
			this->newCnclBtn3->Location = System::Drawing::Point(762, 83);
			this->newCnclBtn3->Name = L"newCnclBtn3";
			this->newCnclBtn3->Size = System::Drawing::Size(75, 23);
			this->newCnclBtn3->TabIndex = 11;
			this->newCnclBtn3->Text = L"Cancel";
			this->newCnclBtn3->UseVisualStyleBackColor = true;
			this->newCnclBtn3->Click += gcnew System::EventHandler(this, &Form1::newCnclBtn3_Click);
			// 
			// newOkBtn3
			// 
			this->newOkBtn3->Location = System::Drawing::Point(664, 83);
			this->newOkBtn3->Name = L"newOkBtn3";
			this->newOkBtn3->Size = System::Drawing::Size(75, 23);
			this->newOkBtn3->TabIndex = 10;
			this->newOkBtn3->Text = L"OK";
			this->newOkBtn3->UseVisualStyleBackColor = true;
			this->newOkBtn3->Click += gcnew System::EventHandler(this, &Form1::newOkBtn3_Click);
			// 
			// newCnclBtn2
			// 
			this->newCnclBtn2->Location = System::Drawing::Point(762, 51);
			this->newCnclBtn2->Name = L"newCnclBtn2";
			this->newCnclBtn2->Size = System::Drawing::Size(75, 23);
			this->newCnclBtn2->TabIndex = 7;
			this->newCnclBtn2->Text = L"Cancel";
			this->newCnclBtn2->UseVisualStyleBackColor = true;
			this->newCnclBtn2->Click += gcnew System::EventHandler(this, &Form1::newCnclBtn2_Click);
			// 
			// newOkBtn2
			// 
			this->newOkBtn2->Location = System::Drawing::Point(664, 51);
			this->newOkBtn2->Name = L"newOkBtn2";
			this->newOkBtn2->Size = System::Drawing::Size(75, 23);
			this->newOkBtn2->TabIndex = 6;
			this->newOkBtn2->Text = L"OK";
			this->newOkBtn2->UseVisualStyleBackColor = true;
			this->newOkBtn2->Click += gcnew System::EventHandler(this, &Form1::newOkBtn2_Click);
			// 
			// newCnclBtn1
			// 
			this->newCnclBtn1->Location = System::Drawing::Point(762, 20);
			this->newCnclBtn1->Name = L"newCnclBtn1";
			this->newCnclBtn1->Size = System::Drawing::Size(75, 23);
			this->newCnclBtn1->TabIndex = 3;
			this->newCnclBtn1->Text = L"Cancel";
			this->newCnclBtn1->UseVisualStyleBackColor = true;
			this->newCnclBtn1->Click += gcnew System::EventHandler(this, &Form1::newCnclBtn1_Click);
			// 
			// newOkBtn1
			// 
			this->newOkBtn1->Location = System::Drawing::Point(664, 20);
			this->newOkBtn1->Name = L"newOkBtn1";
			this->newOkBtn1->Size = System::Drawing::Size(75, 23);
			this->newOkBtn1->TabIndex = 2;
			this->newOkBtn1->Text = L"OK";
			this->newOkBtn1->UseVisualStyleBackColor = true;
			this->newOkBtn1->Click += gcnew System::EventHandler(this, &Form1::newOkBtn1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(391, 86);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 17);
			this->label3->TabIndex = 32;
			this->label3->Text = L"New one :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(391, 54);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 17);
			this->label2->TabIndex = 33;
			this->label2->Text = L"New one :";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(391, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(71, 17);
			this->label1->TabIndex = 34;
			this->label1->Text = L"New one :";
			// 
			// newTxtBx3
			// 
			this->newTxtBx3->Location = System::Drawing::Point(492, 83);
			this->newTxtBx3->Name = L"newTxtBx3";
			this->newTxtBx3->Size = System::Drawing::Size(100, 22);
			this->newTxtBx3->TabIndex = 9;
			// 
			// newTxtBx2
			// 
			this->newTxtBx2->Location = System::Drawing::Point(492, 51);
			this->newTxtBx2->Name = L"newTxtBx2";
			this->newTxtBx2->Size = System::Drawing::Size(100, 22);
			this->newTxtBx2->TabIndex = 5;
			// 
			// newTxtBx1
			// 
			this->newTxtBx1->Location = System::Drawing::Point(492, 23);
			this->newTxtBx1->Name = L"newTxtBx1";
			this->newTxtBx1->Size = System::Drawing::Size(100, 22);
			this->newTxtBx1->TabIndex = 1;
			// 
			// lectureCombo
			// 
			this->lectureCombo->FormattingEnabled = true;
			this->lectureCombo->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"Create new . . ."});
			this->lectureCombo->Location = System::Drawing::Point(243, 83);
			this->lectureCombo->Name = L"lectureCombo";
			this->lectureCombo->Size = System::Drawing::Size(121, 24);
			this->lectureCombo->TabIndex = 8;
			this->lectureCombo->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::lectureCombo_SelectedIndexChanged);
			// 
			// termCombo
			// 
			this->termCombo->FormattingEnabled = true;
			this->termCombo->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"Create new . . ."});
			this->termCombo->Location = System::Drawing::Point(243, 53);
			this->termCombo->Name = L"termCombo";
			this->termCombo->Size = System::Drawing::Size(121, 24);
			this->termCombo->TabIndex = 4;
			this->termCombo->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::termCombo_SelectedIndexChanged);
			// 
			// yearCombo
			// 
			this->yearCombo->FormattingEnabled = true;
			this->yearCombo->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"Create new . . ."});
			this->yearCombo->Location = System::Drawing::Point(243, 23);
			this->yearCombo->Name = L"yearCombo";
			this->yearCombo->Size = System::Drawing::Size(121, 24);
			this->yearCombo->TabIndex = 0;
			this->yearCombo->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::yearCombo_SelectedIndexChanged);
			// 
			// lectureLabel
			// 
			this->lectureLabel->AutoSize = true;
			this->lectureLabel->Location = System::Drawing::Point(20, 86);
			this->lectureLabel->Name = L"lectureLabel";
			this->lectureLabel->Size = System::Drawing::Size(182, 17);
			this->lectureLabel->TabIndex = 35;
			this->lectureLabel->Text = L"Select Lecture : ( reguired )";
			// 
			// termLabel
			// 
			this->termLabel->AutoSize = true;
			this->termLabel->Location = System::Drawing::Point(22, 54);
			this->termLabel->Name = L"termLabel";
			this->termLabel->Size = System::Drawing::Size(162, 17);
			this->termLabel->TabIndex = 36;
			this->termLabel->Text = L"Select term : ( required )";
			// 
			// yearLabel
			// 
			this->yearLabel->AutoSize = true;
			this->yearLabel->Location = System::Drawing::Point(20, 26);
			this->yearLabel->Name = L"yearLabel";
			this->yearLabel->Size = System::Drawing::Size(164, 17);
			this->yearLabel->TabIndex = 37;
			this->yearLabel->Text = L"Select Year : ( required )";
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->label9);
			this->tabPage2->Controls->Add(this->label8);
			this->tabPage2->Controls->Add(this->comboBox3);
			this->tabPage2->Controls->Add(this->groupBox2);
			this->tabPage2->Controls->Add(this->richTextBox2);
			this->tabPage2->Controls->Add(this->richTextBox1);
			this->tabPage2->Controls->Add(this->groupBox1);
			this->tabPage2->Controls->Add(this->resShoBtn);
			this->tabPage2->Controls->Add(this->comboBox1);
			this->tabPage2->Controls->Add(this->comboBox2);
			this->tabPage2->Controls->Add(this->label4);
			this->tabPage2->Controls->Add(this->label5);
			this->tabPage2->Controls->Add(this->label6);
			this->tabPage2->Location = System::Drawing::Point(4, 25);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(851, 304);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"Result Page";
			this->tabPage2->UseVisualStyleBackColor = true;
			this->tabPage2->Enter += gcnew System::EventHandler(this, &Form1::tabPage2_Enter);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(487, 141);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(56, 17);
			this->label9->TabIndex = 52;
			this->label9->Text = L"Result :";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(20, 141);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(123, 17);
			this->label8->TabIndex = 51;
			this->label8->Text = L"Students Grades :";
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Location = System::Drawing::Point(243, 48);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(121, 24);
			this->comboBox3->TabIndex = 38;
			this->comboBox3->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox3_SelectedIndexChanged);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->radioButton4);
			this->groupBox2->Controls->Add(this->radioButton3);
			this->groupBox2->Location = System::Drawing::Point(391, 81);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(450, 59);
			this->groupBox2->TabIndex = 50;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Show Style";
			// 
			// radioButton4
			// 
			this->radioButton4->AutoSize = true;
			this->radioButton4->Location = System::Drawing::Point(255, 21);
			this->radioButton4->Name = L"radioButton4";
			this->radioButton4->Size = System::Drawing::Size(198, 21);
			this->radioButton4->TabIndex = 49;
			this->radioButton4->Text = L"Greatest And Worst Garde";
			this->radioButton4->UseVisualStyleBackColor = true;
			// 
			// radioButton3
			// 
			this->radioButton3->AutoSize = true;
			this->radioButton3->Checked = true;
			this->radioButton3->Location = System::Drawing::Point(6, 21);
			this->radioButton3->Name = L"radioButton3";
			this->radioButton3->Size = System::Drawing::Size(225, 21);
			this->radioButton3->TabIndex = 48;
			this->radioButton3->TabStop = true;
			this->radioButton3->Text = L"Average Garde Of This Course";
			this->radioButton3->UseVisualStyleBackColor = true;
			// 
			// richTextBox2
			// 
			this->richTextBox2->Location = System::Drawing::Point(490, 161);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->Size = System::Drawing::Size(341, 137);
			this->richTextBox2->TabIndex = 49;
			this->richTextBox2->Text = L"";
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(23, 161);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(341, 137);
			this->richTextBox1->TabIndex = 48;
			this->richTextBox1->Text = L"";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->radioButton2);
			this->groupBox1->Controls->Add(this->radioButton1);
			this->groupBox1->Location = System::Drawing::Point(23, 78);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(352, 62);
			this->groupBox1->TabIndex = 47;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Show Style";
			// 
			// radioButton2
			// 
			this->radioButton2->AutoSize = true;
			this->radioButton2->Location = System::Drawing::Point(157, 21);
			this->radioButton2->Name = L"radioButton2";
			this->radioButton2->Size = System::Drawing::Size(189, 21);
			this->radioButton2->TabIndex = 49;
			this->radioButton2->Text = L"Just Show Me The Result";
			this->radioButton2->UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this->radioButton1->AutoSize = true;
			this->radioButton1->Checked = true;
			this->radioButton1->Location = System::Drawing::Point(6, 21);
			this->radioButton1->Name = L"radioButton1";
			this->radioButton1->Size = System::Drawing::Size(143, 21);
			this->radioButton1->TabIndex = 48;
			this->radioButton1->TabStop = true;
			this->radioButton1->Text = L"Show The Grades";
			this->radioButton1->UseVisualStyleBackColor = true;
			// 
			// resShoBtn
			// 
			this->resShoBtn->Location = System::Drawing::Point(387, 176);
			this->resShoBtn->Name = L"resShoBtn";
			this->resShoBtn->Size = System::Drawing::Size(74, 122);
			this->resShoBtn->TabIndex = 46;
			this->resShoBtn->Text = L"show The Result";
			this->resShoBtn->UseVisualStyleBackColor = true;
			this->resShoBtn->Click += gcnew System::EventHandler(this, &Form1::resShoBtn_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(243, 16);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 24);
			this->comboBox1->TabIndex = 40;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Location = System::Drawing::Point(710, 16);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(121, 24);
			this->comboBox2->TabIndex = 39;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox2_SelectedIndexChanged);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(20, 51);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(182, 17);
			this->label4->TabIndex = 41;
			this->label4->Text = L"Select Lecture : ( reguired )";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(471, 19);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(162, 17);
			this->label5->TabIndex = 42;
			this->label5->Text = L"Select term : ( required )";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(20, 19);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(164, 17);
			this->label6->TabIndex = 43;
			this->label6->Text = L"Select Year : ( required )";
			// 
			// bindingSource1
			// 
			this->bindingSource1->CurrentChanged += gcnew System::EventHandler(this, &Form1::bindingSource1_CurrentChanged);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(857, 358);
			this->ControlBox = false;
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->statusStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->tabControl1->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->bindingSource1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		static String^ listPath = "..\\Files\\list\\registry.xrec"
			, ^singlesPath = "..\\Files\\universities\\"
            , ^directory = "";
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {				 
				 newedCourseVisible(false,4);
				 comboAdd_tab_1();
				 label7->Enabled=false;
				 richInfoFeed->Enabled=false;
				 if(save::shouldSigningOut()){
					 save::resetEth();
					 this->Close();
				 }else if(save::keepGoing()){
					 this->Visible::set(true);
					 statusLabel->Text::set("Welcome "+save::getUserID()+", "+save::lastLogIn());
					 this->Text = L"Welcome to "+save::getUserID()+" Workspace.";
				 }
			 }
	private: System::Void comboAdd_tab_1(){
				 StreamReader^ read_1=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\yearList.cmlt");
				 while(String^tmp=read_1->ReadLine())
					 yearCombo->Items->Add(tmp);
				 read_1->Close();
				 StreamReader^ read_2=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\termList.cmlt");
				 while(String^tmp=read_2->ReadLine())
					 termCombo->Items->Add(tmp);
				 read_2->Close();
				 StreamReader^ read_3=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\lectureList.cmlt");
				 while(String^tmp=read_3->ReadLine())
					 lectureCombo->Items->Add(tmp);
				 read_3->Close();
			 }
	private: System::Void signOutBtn_Click(System::Object^  sender, System::EventArgs^  e) {
				 save::resetEth();
				 Form1_Load(sender,e);
			 }
	private: System::Void newedCourseVisible(bool what,int which){
				 switch(which){
					 case 1:
						 label1->Visible=what;
						 newTxtBx1->Visible=what;
						 newCnclBtn1->Visible=what;
						 newOkBtn1->Visible=what;
						 yearCombo->Enabled=!what;
						 yeardelCourseBtn->Visible=!what;
						 lectureDelCourseBtn->Visible=what;
						 termDelCourseBtn->Visible=what;
						 //
						 yeardelCourseBtn->Visible=false;
						 label7->Enabled=false;
						 richInfoFeed->Enabled=false;
						 saveGradesBrn->Enabled=false;
						 break;
					 case 2:
						 label2->Visible=what;
						 newTxtBx2->Visible=what;
						 newCnclBtn2->Visible=what;
						 newOkBtn2->Visible=what;
						 termCombo->Enabled=!what;
						 yeardelCourseBtn->Visible=what;
						 lectureDelCourseBtn->Visible=what;
						 termDelCourseBtn->Visible=!what;
						 //
						 termDelCourseBtn->Visible=false;
						 label7->Enabled=false;
						 richInfoFeed->Enabled=false;
						 saveGradesBrn->Enabled=false;
						 break;
					 case 3:
						 label3->Visible=what;
						 newTxtBx3->Visible=what;
						 newCnclBtn3->Visible=what;
						 newOkBtn3->Visible=what;
						 lectureCombo->Enabled=!what;
						 yeardelCourseBtn->Visible=what;
						 lectureDelCourseBtn->Visible=!what;
						 termDelCourseBtn->Visible=what;
						 //
						 lectureDelCourseBtn->Visible=false;
						 label7->Enabled=false;
						 richInfoFeed->Enabled=false;
						 saveGradesBrn->Enabled=false;
						 break;
					 case 4:
						 label3->Visible=what;
						 newTxtBx3->Visible=what;
						 newCnclBtn3->Visible=what;
						 newOkBtn3->Visible=what;
						 label1->Visible=what;
						 newCnclBtn1->Visible=what;
						 newCnclBtn1->Visible=what;
						 yearCombo->Enabled=what;
						 yeardelCourseBtn->Visible=what;
						 label2->Visible=what;
						 newTxtBx1->Visible=what;
						 newOkBtn1->Visible=what;
						 newTxtBx2->Visible=what;
						 newCnclBtn2->Visible=what;
						 newOkBtn2->Visible=what;
						 newOkBtn2->Visible=what;
						 yearCombo->Enabled=!what;
						 termCombo->Enabled=!what;
						 termLabel->Enabled=!what;
						 yearLabel->Enabled=!what;
						 lectureCombo->Enabled=!what;
						 lectureLabel->Enabled=!what;
						 termDelCourseBtn->Visible=false;
						 lectureDelCourseBtn->Visible=false;
						 label7->Enabled=false;
						 richInfoFeed->Enabled=false;
						 saveGradesBrn->Enabled=false;
				 }
			 }
private: System::Void yearCombo_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(yearCombo->SelectedItem::get()!="Create new . . ."){
				 yeardelCourseBtn->Visible=true;
				 if(lectureCombo->Text!="Create new . . ."&&String::IsNullOrEmpty(termCombo->Text)&&String::IsNullOrEmpty(lectureCombo->Text)&&termCombo->Text!="Create new . . ."){
					 label7->Enabled=true;
					 richInfoFeed->Enabled=true;
					 saveGradesBrn->Enabled=true;
				 }else{
					 label7->Enabled=false;
					 richInfoFeed->Enabled=false;
					 saveGradesBrn->Enabled=false;
				 }
			 }
			 else
				 newedCourseVisible(true,1);
		 }
private: System::Void termCombo_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(termCombo->SelectedItem::get()!="Create new . . ."){
				 termDelCourseBtn->Visible=true;
				 if(yearCombo->Text!="Create new . . ."&&String::IsNullOrEmpty(yearCombo->Text)&&String::IsNullOrEmpty(lectureCombo->Text)&&lectureCombo->Text!="Create new . . ."){
					 label7->Enabled=true;
					 richInfoFeed->Enabled=true;
					 saveGradesBrn->Enabled=true;
				 }else{
					 label7->Enabled=false;
					 richInfoFeed->Enabled=false;
					 saveGradesBrn->Enabled=false;
				 }
			 }
			 else
				 newedCourseVisible(true,2);
		 }
private: System::Void lectureCombo_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(lectureCombo->SelectedItem::get()!="Create new . . ."){
				 label1->Enabled=true;
				 if(yearCombo->Text!="Create new . . ."&&String::IsNullOrEmpty(yearCombo->Text)&&String::IsNullOrEmpty(termCombo->Text)&&termCombo->Text!="Create new . . ."){
					 label7->Enabled=true;
					 richInfoFeed->Enabled=true;
					 saveGradesBrn->Enabled=true;
				 }else{
					 label7->Enabled=false;
					 richInfoFeed->Enabled=false;
					 saveGradesBrn->Enabled=false;
				 }
			 }else
				 newedCourseVisible(true,3);
		 }
private: System::Void newOkBtn1_Click(System::Object^  sender, System::EventArgs^  e) {
			 yearCombo->Items->Add(newTxtBx1->Text);
			 if(!File::Exists("..\\Files\\universities\\"+save::getUserID()+"\\yearList.cmlt")){
				 StreamWriter^ write_1=File::CreateText("..\\Files\\universities\\"+save::getUserID()+"\\yearList.cmlt");
				 write_1->WriteLine(newTxtBx1->Text);
				 write_1->Close();
			 }else{
				 StreamWriter^ write_1=File::AppendText("..\\Files\\universities\\"+save::getUserID()+"\\yearList.cmlt");
				 write_1->WriteLine(newTxtBx1->Text);
				 write_1->Close();
			 }
			 MessageBox::Show("You creat new course!","done!",MessageBoxButtons::OK,MessageBoxIcon::Information);
			 yearCombo->Text=newTxtBx1->Text;
			 newTxtBx3->Clear();
			 comboBox1_SelectedIndexChanged(sender,e);
		 }
private: System::Void newOkBtn2_Click(System::Object^  sender, System::EventArgs^  e) {
			 termCombo->Items->Add(newTxtBx2->Text);
			 if(!File::Exists("..\\Files\\universities\\"+save::getUserID()+"\\termList.cmlt")){
				 StreamWriter^ write_1=File::CreateText("..\\Files\\universities\\"+save::getUserID()+"\\termList.cmlt");
				 write_1->WriteLine(newTxtBx2->Text);
				 write_1->Close();
			 }else{
				 StreamWriter^ write_1=File::AppendText("..\\Files\\universities\\"+save::getUserID()+"\\termList.cmlt");
				 write_1->WriteLine(newTxtBx2->Text);
				 write_1->Close();
			 }
			 MessageBox::Show("You creat new course!","done!",MessageBoxButtons::OK,MessageBoxIcon::Information);
			 newedCourseVisible(false,2);
			 termCombo->Text=newTxtBx2->Text;
			 newTxtBx2->Clear();
			 comboBox2_SelectedIndexChanged(sender,e);
		 }
private: System::Void newOkBtn3_Click(System::Object^  sender, System::EventArgs^  e) {
			 lectureCombo->Items->Add(newTxtBx3->Text);
			 if(!File::Exists("..\\Files\\universities\\"+save::getUserID()+"\\lectureList.cmlt")){
				 StreamWriter^ write_1=File::CreateText("..\\Files\\universities\\"+save::getUserID()+"\\lectureList.cmlt");
				 write_1->WriteLine(newTxtBx3->Text);
				 write_1->Close();
			 }else{
				 StreamWriter^ write_1=File::AppendText("..\\Files\\universities\\"+save::getUserID()+"\\lectureList.cmlt");
				 write_1->WriteLine(newTxtBx3->Text);
				 write_1->Close();
			 }
			 MessageBox::Show("You creat new course!","done!",MessageBoxButtons::OK,MessageBoxIcon::Information);
			 lectureCombo->Text=newTxtBx3->Text;
			 newedCourseVisible(false,3);
			 newTxtBx3->Clear();
			 comboBox1_SelectedIndexChanged(sender,e);
		 }
private: System::Void newCnclBtn1_Click(System::Object^  sender, System::EventArgs^  e) {
			 newTxtBx1->Text=String::Empty;
			 yearCombo->Text=String::Empty;
			 label1->Visible=false;
			 newTxtBx1->Visible=false;
			 newOkBtn1->Visible=false;
			 newCnclBtn1->Visible=false;
			 yearCombo->Enabled=true;
		 }
private: System::Void newCnclBtn2_Click(System::Object^  sender, System::EventArgs^  e) {
			 newTxtBx2->Text=String::Empty;
			 termCombo->Text=String::Empty;
			 label2->Visible=false;
			 newTxtBx2->Visible=false;
			 newOkBtn2->Visible=false;
			 newCnclBtn2->Visible=false;
			 termCombo->Enabled=true;
		 }
private: System::Void newCnclBtn3_Click(System::Object^  sender, System::EventArgs^  e) {
			 newTxtBx3->Text=String::Empty;
			 lectureCombo->Text=String::Empty;
			 label3->Visible=false;
			 newTxtBx3->Visible=false;
			 newOkBtn3->Visible=false;
			 newCnclBtn3->Visible=false;
			 lectureCombo->Enabled=true;
		 }
private: System::Void exitBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 Application::Exit();
		 }
private: System::Void clearFieldsBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 newedCourseVisible(false,4);
			 yearCombo->Text=String::Empty;
			 termCombo->Text=String::Empty;
			 lectureCombo->Text=String::Empty;
			 newTxtBx1->Text=String::Empty;
			 newTxtBx2->Text=String::Empty;
			 newTxtBx3->Text=String::Empty;
			 richInfoFeed->Text=String::Empty;
		 }
private: System::Void folderInitializer(String^dir){
			if (!Directory::Exists(dir))
				Directory::CreateDirectory(dir);
        }
private: System::Void saveGradesBrn_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (File::Exists(listPath)){
				 try{
					 directory = singlesPath + save::getUserID() + "\\" +yearCombo->SelectedItem::get()+ "\\" +termCombo->SelectedItem::get()+"\\"+lectureCombo->SelectedItem::get();
                        folderInitializer(directory);
						array<String^> ^tmp=(richInfoFeed->Text)->Split(',');
						StreamWriter^write=File::CreateText( directory+"\\grades.txt" );
						for(int i=0;i<tmp->Length;i++)
							if (Convert::ToDouble(tmp[i]) >= 0 && Convert::ToDouble(tmp[i]) <= 20){
								write->WriteLine(tmp[i]);
							}else
								throw gcnew Exception("Some of the grade(s) are not acceptable!Please correct them and try agian!");
							write->Close();
							MessageBox::Show("The grades have been saved successfully.", "Data saved successfully!", MessageBoxButtons::OK, MessageBoxIcon::Information);
				 }catch (Exception^exp){
					MessageBox::Show(exp->Message, "Oops!", MessageBoxButtons::OK, MessageBoxIcon::Error);
                }
			 }else{
				 MessageBox::Show("There is fatal error has been encountered!!\nAll saved data will be deleted!and application will be restarted!", "Oops!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				 Directory::Delete("..\\File", true);
			 }
			 yearCombo->Text=String::Empty;
			 termCombo->Text=String::Empty;
			 lectureCombo->Text=String::Empty;
			 richInfoFeed->Text=String::Empty;
			 clearFieldsBtn_Click(sender,e);
		}
private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(!String::IsNullOrEmpty(comboBox2->Text)&&!String::IsNullOrEmpty(comboBox3->Text))
				 resShoBtn->Enabled=true;
			 else
				 resShoBtn->Enabled=false;
		 }
private: System::Void comboBox2_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(!String::IsNullOrEmpty(comboBox1->Text)&&!String::IsNullOrEmpty(comboBox3->Text))
				 resShoBtn->Enabled=true;
			 else
				 resShoBtn->Enabled=false;
		 }
private: System::Void comboBox3_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(!String::IsNullOrEmpty(comboBox1->Text)&&!String::IsNullOrEmpty(comboBox2->Text))
				 resShoBtn->Enabled=true;
			 else
				 resShoBtn->Enabled=false;
		 }
private: System::Void resShoBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 directory = singlesPath + save::getUserID() + "\\" +comboBox1->SelectedItem::get()+ "\\" +comboBox2->SelectedItem::get()+"\\"+comboBox3->SelectedItem::get();
			 StreamReader^read=File::OpenText(directory+"\\grade.txt");
			 int line=0;
			 while(String^tmp=read->ReadLine())
				 line++;
			 array<Double>^grd=gcnew array<Double>(line);
			 int i=0;
			 while(String^tmp=read->ReadLine())
				  grd[i++]=Convert::ToDouble(tmp);				
			 if(radioButton1->Checked){
				 for(int i=0;i<grd->Length;i++)
					 richTextBox1->Text+="Student #"+i+"::> grd";
			 }else{
				 label8->Enabled=false;
				 richTextBox1->Enabled=false;
			 }
			 if(radioButton3->Checked){
				 Double tot=0;
				 for(int i=0;i<grd->Length;i++)
					 tot+=grd[i];
				 richTextBox2->Text="The average of tooken grade in course :\n"
					 +"Year :: "+comboBox1->SelectedItem::get()+ " , " +"Term :: "+comboBox2->SelectedItem::get()+" , "
					 +"Lecture :: "+comboBox3->SelectedItem::get()+"\nAt "+save::getUserID()+"university is :"
					 +tot/grd->Length;
			 }else if(radioButton4->Checked){
				 Double max=0.0,min=20.0;
				 for(int i=0;i<grd->Length;i++)
					 if(grd[i]>max)
						 max=grd[i];
				 for(int i=0;i<grd->Length;i++)
					 if(grd[i]<min)
						 min=grd[i];
				 richTextBox2->Text="The minimum and maximum of tooken grade in course :\n"
					 +"Year :: "+comboBox1->SelectedItem::get()+ " , " +"Term :: "+comboBox2->SelectedItem::get()+" , "
					 +"Lecture :: "+comboBox3->SelectedItem::get()+"\nAt "+save::getUserID()+"university is :"
					 +"Maximum :: "+max+"\nMinimum :: "+min;
			 }
		 }
		 static bool just1=true;
private: System::Void tabPage2_Enter(System::Object^  sender, System::EventArgs^  e) {
			 resShoBtn->Enabled=false;
			 if(just1)
				 comboAdd_tab_2();
			 comboBox1->Text=String::Empty;
			 comboBox2->Text=String::Empty;
			 comboBox3->Text=String::Empty;
			 radioButton1->Checked=true;
			 radioButton3->Checked=true;
		 }
private: System::Void comboAdd_tab_2(){
			 StreamReader^ read_1=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\yearList.cmlt");
			 while(String^tmp=read_1->ReadLine())
				 comboBox1->Items->Add(tmp);
			 read_1->Close();
			 StreamReader^ read_2=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\termList.cmlt");
			 while(String^tmp=read_2->ReadLine())
				 comboBox2->Items->Add(tmp);
			 read_2->Close();
			 StreamReader^ read_3=File::OpenText("..\\Files\\universities\\"+save::getUserID()+"\\lectureList.cmlt");
			 while(String^tmp=read_3->ReadLine())
				 comboBox3->Items->Add(tmp);
			 read_3->Close();
			 just1=false;
		 }
private: System::Void bindingSource1_CurrentChanged(System::Object^  sender, System::EventArgs^  e) {
			 BindingSource
		 }
};
}


#pragma once
#include "save.h"
using namespace System;
using System::Exception;
using namespace System::IO;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

namespace IndotNet {

	/// <summary>
	/// Summary for UserID
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class UserID : public System::Windows::Forms::Form
	{
	public:
		UserID(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~UserID()
		{
			if (components)
			{
				delete components;
			}
		}
	protected: 
	private: System::Windows::Forms::Panel^  panel3;
	private: System::Windows::Forms::Panel^  panel2;
	private: System::Windows::Forms::Button^  CancelBtn;
	private: System::Windows::Forms::Button^  OKBtn;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Button^  CreateBtn;
	private: System::Windows::Forms::Label^  newUser;
	private: System::Windows::Forms::Label^  selectID;
	private: System::Windows::Forms::Button^  ExitBtn;
	private: System::Windows::Forms::Button^  p1_ExitBTn;
	private: System::Windows::Forms::Button^  ClearTotBtn;

	private: System::Windows::Forms::ComboBox^  comboBox1;
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->ClearTotBtn = (gcnew System::Windows::Forms::Button());
			this->p1_ExitBTn = (gcnew System::Windows::Forms::Button());
			this->CreateBtn = (gcnew System::Windows::Forms::Button());
			this->newUser = (gcnew System::Windows::Forms::Label());
			this->selectID = (gcnew System::Windows::Forms::Label());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->ExitBtn = (gcnew System::Windows::Forms::Button());
			this->CancelBtn = (gcnew System::Windows::Forms::Button());
			this->OKBtn = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel3->SuspendLayout();
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel3
			// 
			this->panel3->Controls->Add(this->panel1);
			this->panel3->Controls->Add(this->panel2);
			this->panel3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel3->Location = System::Drawing::Point(0, 0);
			this->panel3->Margin = System::Windows::Forms::Padding(4);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(407, 274);
			this->panel3->TabIndex = 5;
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->comboBox1);
			this->panel1->Controls->Add(this->ClearTotBtn);
			this->panel1->Controls->Add(this->p1_ExitBTn);
			this->panel1->Controls->Add(this->CreateBtn);
			this->panel1->Controls->Add(this->newUser);
			this->panel1->Controls->Add(this->selectID);
			this->panel1->Location = System::Drawing::Point(3, 123);
			this->panel1->Margin = System::Windows::Forms::Padding(4);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(404, 151);
			this->panel1->TabIndex = 5;
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(208, 17);
			this->comboBox1->Margin = System::Windows::Forms::Padding(4);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(167, 24);
			this->comboBox1->TabIndex = 11;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &UserID::comboBox1_SelectedIndexChanged);
			// 
			// ClearTotBtn
			// 
			this->ClearTotBtn->Location = System::Drawing::Point(36, 59);
			this->ClearTotBtn->Margin = System::Windows::Forms::Padding(4);
			this->ClearTotBtn->Name = L"ClearTotBtn";
			this->ClearTotBtn->Size = System::Drawing::Size(340, 28);
			this->ClearTotBtn->TabIndex = 10;
			this->ClearTotBtn->Text = L"Clear List";
			this->ClearTotBtn->UseVisualStyleBackColor = true;
			this->ClearTotBtn->Click += gcnew System::EventHandler(this, &UserID::ClearTotBtn_Click);
			// 
			// p1_ExitBTn
			// 
			this->p1_ExitBTn->Location = System::Drawing::Point(276, 105);
			this->p1_ExitBTn->Margin = System::Windows::Forms::Padding(4);
			this->p1_ExitBTn->Name = L"p1_ExitBTn";
			this->p1_ExitBTn->Size = System::Drawing::Size(100, 27);
			this->p1_ExitBTn->TabIndex = 8;
			this->p1_ExitBTn->Text = L"Exit";
			this->p1_ExitBTn->UseVisualStyleBackColor = true;
			this->p1_ExitBTn->Click += gcnew System::EventHandler(this, &UserID::p1_ExitBTn_Click);
			// 
			// CreateBtn
			// 
			this->CreateBtn->Location = System::Drawing::Point(161, 105);
			this->CreateBtn->Margin = System::Windows::Forms::Padding(4);
			this->CreateBtn->Name = L"CreateBtn";
			this->CreateBtn->Size = System::Drawing::Size(100, 28);
			this->CreateBtn->TabIndex = 7;
			this->CreateBtn->Text = L"Create one";
			this->CreateBtn->UseVisualStyleBackColor = true;
			this->CreateBtn->Click += gcnew System::EventHandler(this, &UserID::CreateBtn_Click);
			// 
			// newUser
			// 
			this->newUser->AutoSize = true;
			this->newUser->Location = System::Drawing::Point(33, 111);
			this->newUser->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->newUser->Name = L"newUser";
			this->newUser->Size = System::Drawing::Size(118, 17);
			this->newUser->TabIndex = 6;
			this->newUser->Text = L"New Workspace\?";
			// 
			// selectID
			// 
			this->selectID->AutoSize = true;
			this->selectID->Location = System::Drawing::Point(33, 21);
			this->selectID->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->selectID->Name = L"selectID";
			this->selectID->Size = System::Drawing::Size(167, 17);
			this->selectID->TabIndex = 5;
			this->selectID->Text = L"Select your workspace ID";
			// 
			// panel2
			// 
			this->panel2->Controls->Add(this->ExitBtn);
			this->panel2->Controls->Add(this->CancelBtn);
			this->panel2->Controls->Add(this->OKBtn);
			this->panel2->Controls->Add(this->textBox1);
			this->panel2->Controls->Add(this->label1);
			this->panel2->Location = System::Drawing::Point(0, 0);
			this->panel2->Margin = System::Windows::Forms::Padding(4);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(404, 100);
			this->panel2->TabIndex = 4;
			// 
			// ExitBtn
			// 
			this->ExitBtn->Location = System::Drawing::Point(272, 59);
			this->ExitBtn->Margin = System::Windows::Forms::Padding(4);
			this->ExitBtn->Name = L"ExitBtn";
			this->ExitBtn->Size = System::Drawing::Size(100, 28);
			this->ExitBtn->TabIndex = 8;
			this->ExitBtn->Text = L"Exit";
			this->ExitBtn->UseVisualStyleBackColor = true;
			this->ExitBtn->Click += gcnew System::EventHandler(this, &UserID::ExitBtn_Click);
			// 
			// CancelBtn
			// 
			this->CancelBtn->Location = System::Drawing::Point(148, 59);
			this->CancelBtn->Margin = System::Windows::Forms::Padding(4);
			this->CancelBtn->Name = L"CancelBtn";
			this->CancelBtn->Size = System::Drawing::Size(100, 28);
			this->CancelBtn->TabIndex = 7;
			this->CancelBtn->Text = L"Cancel";
			this->CancelBtn->UseVisualStyleBackColor = true;
			this->CancelBtn->Click += gcnew System::EventHandler(this, &UserID::CancelBtn_Click);
			// 
			// OKBtn
			// 
			this->OKBtn->Location = System::Drawing::Point(12, 59);
			this->OKBtn->Margin = System::Windows::Forms::Padding(4);
			this->OKBtn->Name = L"OKBtn";
			this->OKBtn->Size = System::Drawing::Size(100, 28);
			this->OKBtn->TabIndex = 1;
			this->OKBtn->Text = L"OK ";
			this->OKBtn->UseVisualStyleBackColor = true;
			this->OKBtn->Click += gcnew System::EventHandler(this, &UserID::OKBtn_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(211, 23);
			this->textBox1->Margin = System::Windows::Forms::Padding(4);
			this->textBox1->MaxLength = 12;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(160, 22);
			this->textBox1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(23, 27);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(170, 17);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Enter your workspace ID :";
			// 
			// UserID
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(407, 274);
			this->ControlBox = false;
			this->Controls->Add(this->panel3);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Margin = System::Windows::Forms::Padding(4);
			this->MaximizeBox = false;
			this->Name = L"UserID";
			this->Opacity = 0.92;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Load += gcnew System::EventHandler(this, &UserID::UserID_Load);
			this->panel3->ResumeLayout(false);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
		static String^listPath="..\\Files\\list\\registry.xrec";
		static String^singlesPath="..\\Files\\universities\\";
private: System::Void CreateBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->ClientSize = panel2->Size::get();
			 this->Text = L"Create new Workspace";
			 panel1->Visible::set(false);
			 this->panel2->Location = System::Drawing::Point(0, 0);
			 panel2->Visible::set(true);
			 textBox1->Clear();
		 }
private: System::Void UserID_Load(System::Object^  sender, System::EventArgs^  e) {
			 try{
				 comboBox1->Text::set(String::Empty);
				 if(save::isCreatingOne()){
					 CreateBtn_Click(sender,e);
					 save::create_One(false);
				 }else{
					 this->ClientSize = panel1->Size::get();
					 this->panel1->Location = System::Drawing::Point(0, 0);
					 panel1->Visible::set(true);
					 panel2->Visible::set(false);
					 foldersInitialization();
					 upDatingList();
					 if(!(File::Exists(listPath) && comboBox1->Items->Count::get())){
						 Directory::Delete("..\\Files\\list",true);
						 Directory::Delete(singlesPath,true);
						 foldersInitialization();
						 CancelBtn->Enabled::set(false);
						 CreateBtn_Click(sender,e);
						 this->Text = L"There isn't any registered workspace!";
					 }
				 }
			 }catch(Exception^ e){
				 MessageBox::Show(e->Message,"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
				 Application::Restart();
			 }
		 }
private: System::Void CancelBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(File::Exists(listPath)){
				 save::create_One(false);
				 UserID_Load(sender,e);
			 }
		 }
private: System::Void OKBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 bool reLoad_panel2=false;
			 String^newUser=textBox1->Text::get(),^path;
			 try{
				 save::isValidUserID(newUser);
				 if(!String::IsNullOrEmpty(newUser)){
					 path=singlesPath+newUser;
					 if(!Directory::Exists(path)){
						 Directory::CreateDirectory(singlesPath+newUser+"\\");
						 StreamWriter^last=gcnew StreamWriter(singlesPath+newUser+"\\"+newUser+".lrec");
						 last->WriteLine("your Last Log in was at \t\t"+DateTime::Now::get());
						 MessageBox::Show("Registration successfully completed","Completed!",MessageBoxButtons::OK,MessageBoxIcon::Information);
						 last->Close();
						 if(File::Exists(listPath)){
							 StreamWriter^userList=File::AppendText(listPath);
							 userList->WriteLine(newUser);
							 userList->Close();
							 upDatingList();
						 }else{
							 StreamWriter^userList=File::CreateText(listPath);
							 userList->WriteLine(newUser);
							 userList->Close();
						 }
						 save::setUserID(newUser);
						 save::setProceed();
						 this->Close();
					 }else
						 throw gcnew Exception("NONAME");
				 }else{
					 MessageBox::Show("You haven't entered any ID yet!","Invalid user ID!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 CreateBtn_Click(sender,e);
				 }
			 }catch(Exception^e){
				 if(e->Message::get()=="NONAME"){
					 MessageBox::Show("Sorry, this user has already registered, Choose another one.","Choose another one!?",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 reLoad_panel2=true;
				 }else{
					 MessageBox::Show(e->Message::get(),"Choose another one!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 reLoad_panel2=true;
				 }
			 }
			 if(reLoad_panel2)CreateBtn_Click(sender,e);
		 }
private:void foldersInitialization(){
			if(!Directory::Exists("..\\Files\\"))
				Directory::CreateDirectory("..\\Files\\");
			if(!Directory::Exists("..\\Files\\list\\"))
				Directory::CreateDirectory("..\\Files\\list\\");
			if(!Directory::Exists(singlesPath))
				Directory::CreateDirectory(singlesPath);
			DirectoryInfo^diMyDir=gcnew DirectoryInfo("..\\Files\\");
			diMyDir->Attributes=FileAttributes::Hidden;	
		}
private:void upDatingList(){
			comboBox1->Items->Clear();
			if(File::Exists(listPath)){
				File::Delete("..\\Files\\list\\temp.xrec");
				File::Copy(listPath,"..\\Files\\list\\temp.xrec");
				StreamReader^userList=File::OpenText(listPath);
				String^reading;
				while((reading=userList->ReadLine())){
					String^path=singlesPath+reading+"\\"+reading;
					if(!File::Exists(path+".lrec")){
						userList->Close();
						StreamWriter^list=gcnew StreamWriter(listPath);
						StreamReader^read=File::OpenText("..\\Files\\list\\temp.xrec");
						String^reading;
						while((reading=read->ReadLine()))
							if(Directory::Exists(singlesPath+reading))
								if(File::Exists(singlesPath+reading+"\\"+reading+".lrec"))
									list->WriteLine(reading);
								else if(Directory::Exists(singlesPath+reading))
									Directory::Delete(singlesPath+reading,true);
						list->Close();
						read->Close();
						break;
					}
				}
				userList->Close();
				File::Delete("..\\Files\\list\\temp.xrec");
				StreamReader^read=File::OpenText(listPath);
				String^users;
				while((users=read->ReadLine())){
					comboBox1->Items->Add(users);
				}
				read->Close();
			}
		}
private: System::Void ExitBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure?","Sure about it?",MessageBoxButtons::YesNo,MessageBoxIcon::Question,MessageBoxDefaultButton::Button2);
			 if(result==System::Windows::Forms::DialogResult::Yes){
				 save::ShouldExit();
				 Application::Exit();
			 }
		 }
private: System::Void p1_ExitBTn_Click(System::Object^  sender, System::EventArgs^  e) {
			 ExitBtn_Click(sender,e);
		 }
private: System::Void refreshBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 UserID_Load(sender,e);
		 }
private: System::Void ClearTotBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 System::Windows::Forms::DialogResult result=MessageBox::Show("Are you sure to clear list?\n"
				 "All information will be removed.....","Sure about it?",
				 MessageBoxButtons::YesNo,MessageBoxIcon::Warning,MessageBoxDefaultButton::Button2);
			 if(result ==  System::Windows::Forms::DialogResult::Yes){
				 Directory::Delete("..\\Files\\",true);
				 foldersInitialization();
				 UserID_Load(sender,e);
			 }
		 }
private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 bool reLoad=false;
			 StreamReader^read=File::OpenText(listPath);
			 String^selectedUserID;
			 while((selectedUserID=read->ReadLine()))
				 if(selectedUserID==comboBox1->Text){
					 read->Close();
					 break;
				 }
			 String^path="..\\Files\\universities\\"+selectedUserID+"\\"+selectedUserID;
			 try{
				 if(Directory::Exists("..\\Files\\universities\\"+selectedUserID)){
					 if(File::Exists(path+".lrec")){
						 StreamReader^read=File::OpenText(path+".lrec");
						 save::lastLogIn(read->ReadLine());
						 read->Close();
						 StreamWriter^last=gcnew StreamWriter(path+".lrec");
						 last->WriteLine("your Last Log in was at \t\t"+DateTime::Now::get());
						 last->Close();
						 this->Close();
					 }else
						 throw gcnew Exception("File"); 
				 }else
					 throw gcnew Exception("List");
			 }catch(Exception^e){
				 if(e->Message::get()=="File"){
					 Directory::Delete("..\\Files\\universities\\"+save::getUserID(),true);
					 MessageBox::Show("This account has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 reLoad=true;
				 }else if(e->Message::get()=="List"){
					 MessageBox::Show("This account has been deleted somehow!","Unexpected error!",MessageBoxButtons::OK,MessageBoxIcon::Error);
					 reLoad=true;
				 }else
					 MessageBox::Show("code 430/473.\n"+e->Message::get(),"Oops!",MessageBoxButtons::OK,MessageBoxIcon::Error);
			 }
			 if(reLoad)UserID_Load(sender,e);
			 save::setUserID(selectedUserID);
			 save::setProceed();
		 }
};
}

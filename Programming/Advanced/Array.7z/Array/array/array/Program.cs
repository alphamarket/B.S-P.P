﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            menu menu1 = new menu();
            while(true)
                menu1.Menu();
        }
    }
}

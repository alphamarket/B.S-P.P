﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class arrLength
    {
        private static int[] lenght = new int[5];
        public static void setLength(int arrSize, int locate)
        {
            lenght[locate] = arrSize;
        }
        public static int getArrLength(int locate)
        {
            return lenght[locate];
        }
    }
}

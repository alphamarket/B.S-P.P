﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace array
{
    class menu
    {
        private int[][][][][] component;
        public void Menu()
        {
            try
            {
                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Enter length of field you want to info-feeding in format of :\n<--note that you should enter exactly as below format,otherwise program will restarted-->\n" +
                        "\nNumber Of Universities:Number Of year:Number Of term:Number Of Lectures\n");
                    String[] tmp = (Console.ReadLine()).Split(':');
                    for (int i = 0; i < 4; i++)
                    {
                        if (tmp.Length != 4) continue;
                        arrLength.setLength(Convert.ToInt32(tmp[i]), i);
                    }
                    if (tmp.Length == 4) break;
                }
                initilizeArray();
                mainMenu();
                return;
            }catch(Exception){
                return;
            }
        }
        private void initilizeArray()
        {
            component = new int[arrLength.getArrLength(0)][][][][];
            for (int i = 0; i < arrLength.getArrLength(0); i++)
            {
                component[i] = new int[arrLength.getArrLength(1)][][][];
            }
            for (int i = 0; i < arrLength.getArrLength(0); i++)
            {
                for (int j = 0; j < arrLength.getArrLength(1); j++)
                {
                    component[i][j] = new int[arrLength.getArrLength(2)][][];
                }
            }
            for (int i = 0; i < arrLength.getArrLength(0); i++)
            {
                for (int j = 0; j < arrLength.getArrLength(1); j++)
                {
                    for (int k = 0; k < arrLength.getArrLength(2); k++)
                    {
                        component[i][j][k] = new int[arrLength.getArrLength(3)][];
                    }
                }
            }
            for (int i = 0; i < arrLength.getArrLength(0); i++)
            {
                for (int j = 0; j < arrLength.getArrLength(1); j++)
                {
                    for (int k = 0; k < arrLength.getArrLength(2); k++)
                    {
                        for (int l = 0; l < arrLength.getArrLength(3); l++)
                        {
                            component[i][j][k][l] = new int[1];

                        }
                    }
                }
            }
        }
        private void mainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1/>Info-feeding.\n2/>Reset entered info.\n3/>Print info.\n4/>Reset first initialized.\n5/>Exit.");
                Console.Write("::/>\t\t");
                switch (Convert.ToInt16(Console.ReadLine()))
                {
                    case 1:
                        mainMenu_1();
                        break;
                    case 2:
                        mainMenu_2();
                        break;
                    case 3:
                        mainMenu_3();
                        break;
                    case 4:
                        return;
                    case 5:
                        Application.Exit();
                        break;
                    default:
                        Console.WriteLine("Please enter valid item number.\a");
                        break;
                }
            }
        }
        private void mainMenu_1()
        {
            try
            {
                while (true)
                {
                    Console.Clear();
                    Console.Write("Acceptable university number(s):\t");
                    for (int i = 1; i <= arrLength.getArrLength(0); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable year number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(1); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable term number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(2); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable lecture number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(3); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("\nNow enter your field address in order of:\nWhich Universities:Which year:Which term:Which Lectures\nOR PRESS -1 IN ONE OF FIELDS TO RETURN MAIN MENU!\n");
                    String[] tmp = (Console.ReadLine()).Split(':');
                    bool contin = false;
                    for (int i = 0; i < 4; i++)
                    {
                        if (Convert.ToInt16(tmp[i]) == -1 || tmp.Length != 4) return;
                        if (Convert.ToInt16(tmp[i]) > arrLength.getArrLength(i) || Convert.ToInt16(tmp[i]) < 0)
                        {
                            Console.WriteLine("You have entered wrong number,press any key to try again!!!\a");
                            Console.ReadKey(true);
                            contin = !contin;
                        }
                    }
                    if (contin) continue;
                    int[] locat = new int[4];
                    for (int j = 0; j < 4; j++)
                        locat[j] = Convert.ToInt32(tmp[j]);
                    int students;
                    while (true)
                    {
                        Console.WriteLine("\n\nHow many students have took this course?\nOR PRESS -1 IN ONE OF FIELDS TO RETURN MAIN MENU!");
                        students = (int)Convert.ToDouble(Console.ReadLine());
                        if (students == -1) return;
                        if (students <= 0)
                        {
                            Console.WriteLine("You have entered invalid student number,press any key to try agian!!!\a");
                            Console.ReadKey(true);
                            continue;
                        }
                        arrLength.setLength(students, 4);
                        break;
                    }
                    //
                    //
                    //
                    component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1] = new int[students];
                    Console.Clear();
                    for (int i = 0; i < arrLength.getArrLength(4); i++)
                    {
                        while (true)
                        {
                            Console.Write("Enter garde of student {0} : \t\t", i + 1);
                            int temp = (int)Convert.ToDouble(Console.ReadLine());
                            if (temp >= 0 && temp <= 20)
                            {
                                component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1][i] = temp;
                                break;
                            }
                            else
                                Console.WriteLine("You have entered invalid grade,try again!!!\a");
                        }
                    }
                    return;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("You have entered a wrong format, or vailent data,press any key to continue!!!\a");
                Console.ReadKey(true);
                return;
            }
        }
        private void mainMenu_2()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1/>Specific reset.\n2/>Total reset.\n3/>Back to main menu.");
                Console.WriteLine("::/>\t\t");
                int tmp = Convert.ToInt32(Console.ReadLine());
                switch (tmp)
                {
                    case 1:
                        if(subMenu2_1()==-1)return;
                        break;
                    case 2:
                        if (subMenu2_2() == -1) return;
                        break;
                    case 3: return;
                }
            }
        }
        private int subMenu2_1()
        {
            try
            {
                while (true)
                {
                    Console.Clear();
                    Console.Write("Acceptable university number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(0); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable year number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(1); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable term number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(2); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable lecture number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(3); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable student number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(4); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("\nNow enter your field address in order of:\nWhich Universities:Which year:Which term:Which Lectures:Which student\nOR PRESS -1 IN ONE OF FIELDS TO RETURN MAIN MENU!\n");
                    String[] tmp = (Console.ReadLine()).Split(':');
                    bool contin = false;
                    for (int i = 0; i < 5; i++)
                    {
                        if (-1 == Convert.ToInt16(tmp[i])) return -1;
                        if (Convert.ToInt16(tmp[i]) > arrLength.getArrLength(i) || Convert.ToInt16(tmp[i]) < 0)
                        {
                            Console.WriteLine("You have entered wrong number,press any key to try again!!!\a");
                            Console.ReadKey(true);
                            contin = !contin;
                        }
                    }
                    if (contin) continue;
                    int[] locat = new int[5];
                    for (int j = 0; j < 4; j++)
                        locat[j] = Convert.ToInt32(tmp[j]);
                    Console.Clear();
                    while (true)
                    {
                        Console.Write("Enter new grade of student {0} : \t\t", locat[4]);
                        int temp = Convert.ToInt16(Console.ReadLine());
                        if (temp >= 0 && temp <= 20)
                        {
                            component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1][locat[4] - 1] = temp;
                            break;
                        }
                        else
                            Console.WriteLine("<-----------You have entered invalid grade,try again!!!----------->\a");
                    }
                    return 0;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("You have entered a wrong format, or vailent data,press any key to continue!!!\a");
                Console.ReadKey(true);
                return 0;
            }
        }
        private int subMenu2_2()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Are you sure?<yes/no>\n(NOTE THAT THERE IS NO GOING BACK AFTER THIS, ALL STORED DATA WILL BE BE RESETED FOR GOOD!!)");
                String ans = Console.ReadLine();
                switch (ans)
                {
                    case "yes":
                    case "Yes":
                    case "YES":
                    case "yEs":
                    case "yeS":
                        for (int i = 0; i < arrLength.getArrLength(0); i++)
                            for (int j = 0; j < arrLength.getArrLength(1); j++)
                                for (int k = 0; k < arrLength.getArrLength(2); k++)
                                    for (int l = 0; l < arrLength.getArrLength(3); l++)
                                        for (int m = 0; m < arrLength.getArrLength(4); m++)
                                            component[i][j][k][l][m] = 0;
                        return 0;
                    case "no":
                    case "No":
                    case "nO":
                    case "NO":
                        return -1;
                    default:
                        Console.WriteLine("You have entered invalid item,press any key to try again!!!\a");
                        Console.ReadKey(true);
                        break;
                }
            }
        }
        private void mainMenu_3()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1/>Print all stored item(s).\n2/>Gratest and worst grade in a specific course.\n3/>Average grade in total universities.\n4/>Back to main menu.");
                Console.Write("::/>");
                int tmp = Convert.ToInt32(Console.ReadLine());
                switch (tmp)
                {
                    case 1:
                        subMenu3_1();
                        break;
                    case 2:
                        subMenu3_2();
                        break;
                    case 3:
                        subMenu3_3();
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("You have eneterd inavlid item number,Press any key to try again!!!\a");
                        Console.ReadKey(true);
                        break;
                }
            }
        }
        private void subMenu3_1()
        {
            Console.Clear();
            for (int i = 0; i < component.Length; i++)
            {
                for (int j = 0; j < component[i].Length; j++)
                {
                    for (int k = 0; k < component[i][j].Length; k++)
                    {
                        for (int l = 0; l < component[i][j][k].Length; l++)
                        {
                            for (int p = 0; p < component[i][j][k][l].Length; p++)
                            {
                                if (true)
                                {
                                    if (component[i][j][k][l][p] != 0)
                                    {
                                        Console.WriteLine("University:  {0}  Year:  {1}  Term:  {2}  Lecture:  {3}", i, j, k, l);
                                        Console.Write("Grades::>");
                                        for (int m = 0; m < component[i][j][k][l].Length; m++)
                                            Console.Write(component[i][j][k][l][m] + " , ");
                                        Console.WriteLine(" ");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine("\n\nPress any key to continue...");
            Console.ReadKey(true);
        }
        private void subMenu3_2()
        {
            Console.Clear();
            Console.WriteLine("1/>In specific course.\n2/>In total universities course.\n3/>Return to previous menu.");
            Console.Write("::/>\t");
            switch (Convert.ToInt16(Console.ReadLine()))
            {
                case 1:
                    subMenu_3_2_1();
                    break;
                case 2:
                    subMenu_3_2_2();
                    break;
                case 3:
                    return;
                default:
                    Console.WriteLine("You have entered a wrong item number,press any key to try again!!!\a");
                    Console.ReadKey(true);
                    break;
            }
        }
        private void subMenu_3_2_1()
        {
            try
            {
                while (true)
                {
                    Console.Clear();
                    Console.Write("Acceptable university number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(0); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable year number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(1); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable term number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(2); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("Acceptable lecture number(s):\t\t");
                    for (int i = 1; i <= arrLength.getArrLength(3); i++)
                        Console.Write(i + "\t");
                    Console.Write("\n");
                    //
                    //
                    //
                    Console.Write("\nNow enter your field address in order of:\nWhich Universities:Which year:Which term:Which Lectures\nOR PRESS -1 IN ONE OF FIELDS TO RETURN MAIN MENU!\n");
                    String[] tmp = (Console.ReadLine()).Split(':');
                    bool contin = false;
                    for (int i = 0; i < 4; i++)
                    {
                        if (-1 == Convert.ToInt16(tmp[i])) return;
                        if (Convert.ToInt16(tmp[i]) > arrLength.getArrLength(i) && Convert.ToInt16(tmp[i]) < 0)
                        {
                            Console.WriteLine("You have entered wrong number,press any key to try again!!!\a");
                            Console.ReadKey(true);
                            contin = !contin;
                        }
                    }
                    if (contin) continue;
                    int[] locat = new int[4];
                    for (int j = 0; j < 4; j++)
                        locat[j] = Convert.ToInt32(tmp[j]);
                    bool breakalbe = true;
                    for (int m = 0; m < arrLength.getArrLength(4); m++)
                    {
                        if (component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1][m] != 0)
                        {
                            breakalbe = !breakalbe;
                            break;
                        }
                    }
                    if (breakalbe)
                    {
                        Console.WriteLine("There isn't any registered grade in course {0}:{1}:{2}:{3} , maybe you have entered a wrong course address\n0/>Back to main menu.\nOtherwise you're about to trying again!");
                        if (Convert.ToInt16(Console.ReadLine()) == 0)
                            return;
                        else
                            continue;
                    }
                    int max = 0, min = 20;
                    foreach (int i in component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1])
                        if (i > max)
                            max = i;
                    foreach (int i in component[locat[0] - 1][locat[1] - 1][locat[2] - 1][locat[3] - 1])
                        if (i < min)
                            min = i;
                    Console.Clear();
                    Console.WriteLine("The minimun of {0}:{1}:{2}:{3} course grades is \"\"  {4}  \"\"\nthe maximum of {0}:{1}:{2}:{3} course grade is \"\"  {5}  \"\"", locat[0] + 1, locat[1] + 1, locat[2] + 1, locat[3] + 1, min, max);
                    Console.WriteLine("\n\nPress any key to continue....");
                    Console.ReadKey(true);
                    break;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("You have entered a wrong format, or vailent data,press any key to continue!!!\a");
                Console.ReadKey(true);
                return;
            }
        }
        private void subMenu_3_2_2()
        {
            Console.Clear();
            int max = 0, min = 20;
            foreach (int[][][][] i in component)
                foreach (int[][][] j in i)
                    foreach (int[][] k in j)
                        foreach (int[] l in k)
                            foreach (int m in l)
                                if (m > max)
                                    max = m;
            foreach (int[][][][] i in component)
                foreach (int[][][] j in i)
                    foreach (int[][] k in j)
                        foreach (int[] l in k)
                            foreach (int m in l)
                                if (m < min)
                                    min = m;
            Console.WriteLine("The minimun of total universities grades is \"\"  {0}  \"\"\nthe maximum of total universities grade is \"\"  {1}  \"\"", min, max);
            Console.WriteLine("\n\nPress any key to continue....");
            Console.ReadKey(true);
        }
        private void subMenu3_3()
        {
            Console.Clear();
            for (int i = 0; i < component.Length; i++)
            {
                for (int j = 0; j < component[i].Length; j++)
                {
                    for (int k = 0; k < component[i][j].Length; k++)
                    {
                        for (int l = 0; l < component[i][j][k].Length; l++)
                        {
                            for (int p = 0; p < component[i][j][k][l].Length; p++)
                            {
                                if (component[i][j][k][l][p] != 0)
                                {
                                    int tot = 0, sum = 0;
                                    for (int m = 0; m < component[i][j][k][l].Length; tot++, m++)
                                        sum += component[i][j][k][l][m];
                                    Console.WriteLine("University:  {0}  Year:  {1}  Term:  {2}  Lecture:  {3}  Average  {4}  .", i+1, j+1, k+1, l+1, Convert.ToDouble(sum) / tot);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine("\n\nPress any key to continue....");
            Console.ReadKey(true);
        }
    }
}

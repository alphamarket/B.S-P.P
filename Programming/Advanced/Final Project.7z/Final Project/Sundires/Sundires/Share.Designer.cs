﻿namespace Sundries
{
    partial class Share
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddBookGB = new System.Windows.Forms.GroupBox();
            this.CnclBtn = new System.Windows.Forms.Button();
            this.ClrBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.Day = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Month = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Year = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BookExpText = new System.Windows.Forms.TextBox();
            this.BookPublisherText = new System.Windows.Forms.TextBox();
            this.BookWriterText = new System.Windows.Forms.TextBox();
            this.IDText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.DagreeCB = new System.Windows.Forms.CheckBox();
            this.AgreeCB = new System.Windows.Forms.CheckBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ForGetCB = new System.Windows.Forms.CheckBox();
            this.CheckBtn = new System.Windows.Forms.Button();
            this.BookNameText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AddBookGB.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddBookGB
            // 
            this.AddBookGB.Controls.Add(this.BookNameText);
            this.AddBookGB.Controls.Add(this.label2);
            this.AddBookGB.Controls.Add(this.label11);
            this.AddBookGB.Controls.Add(this.DagreeCB);
            this.AddBookGB.Controls.Add(this.richTextBox1);
            this.AddBookGB.Controls.Add(this.CnclBtn);
            this.AddBookGB.Controls.Add(this.AgreeCB);
            this.AddBookGB.Controls.Add(this.ClrBtn);
            this.AddBookGB.Controls.Add(this.AddBtn);
            this.AddBookGB.Controls.Add(this.Day);
            this.AddBookGB.Controls.Add(this.label9);
            this.AddBookGB.Controls.Add(this.Month);
            this.AddBookGB.Controls.Add(this.label8);
            this.AddBookGB.Controls.Add(this.Year);
            this.AddBookGB.Controls.Add(this.label7);
            this.AddBookGB.Controls.Add(this.BookExpText);
            this.AddBookGB.Controls.Add(this.BookPublisherText);
            this.AddBookGB.Controls.Add(this.BookWriterText);
            this.AddBookGB.Controls.Add(this.CategoryCombo);
            this.AddBookGB.Controls.Add(this.label6);
            this.AddBookGB.Controls.Add(this.label5);
            this.AddBookGB.Controls.Add(this.label4);
            this.AddBookGB.Controls.Add(this.label1);
            this.AddBookGB.Enabled = false;
            this.AddBookGB.Location = new System.Drawing.Point(12, 121);
            this.AddBookGB.Name = "AddBookGB";
            this.AddBookGB.Size = new System.Drawing.Size(578, 592);
            this.AddBookGB.TabIndex = 2;
            this.AddBookGB.TabStop = false;
            this.AddBookGB.Text = "Add Book Panel";
            // 
            // CnclBtn
            // 
            this.CnclBtn.Location = new System.Drawing.Point(403, 550);
            this.CnclBtn.Name = "CnclBtn";
            this.CnclBtn.Size = new System.Drawing.Size(143, 23);
            this.CnclBtn.TabIndex = 77;
            this.CnclBtn.Text = "Cancel";
            this.CnclBtn.UseVisualStyleBackColor = true;
            this.CnclBtn.Click += new System.EventHandler(this.CnclBtn_Click);
            // 
            // ClrBtn
            // 
            this.ClrBtn.Location = new System.Drawing.Point(216, 549);
            this.ClrBtn.Name = "ClrBtn";
            this.ClrBtn.Size = new System.Drawing.Size(143, 23);
            this.ClrBtn.TabIndex = 76;
            this.ClrBtn.Text = "Clear fields";
            this.ClrBtn.UseVisualStyleBackColor = true;
            this.ClrBtn.Click += new System.EventHandler(this.ClrBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(26, 551);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(143, 23);
            this.AddBtn.TabIndex = 75;
            this.AddBtn.Text = "Add to database";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // Day
            // 
            this.Day.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Day.Location = new System.Drawing.Point(498, 172);
            this.Day.MaxLength = 4;
            this.Day.Name = "Day";
            this.Day.Size = new System.Drawing.Size(50, 20);
            this.Day.TabIndex = 69;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Location = new System.Drawing.Point(480, 175);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 13);
            this.label9.TabIndex = 73;
            this.label9.Text = "/";
            // 
            // Month
            // 
            this.Month.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Month.Location = new System.Drawing.Point(424, 172);
            this.Month.MaxLength = 4;
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(50, 20);
            this.Month.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(406, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 13);
            this.label8.TabIndex = 71;
            this.label8.Text = "/";
            // 
            // Year
            // 
            this.Year.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Year.Location = new System.Drawing.Point(350, 172);
            this.Year.MaxLength = 4;
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(50, 20);
            this.Year.TabIndex = 67;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 17);
            this.label7.TabIndex = 69;
            this.label7.Text = "Enter the date of the publish :";
            // 
            // BookExpText
            // 
            this.BookExpText.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BookExpText.Location = new System.Drawing.Point(29, 324);
            this.BookExpText.Multiline = true;
            this.BookExpText.Name = "BookExpText";
            this.BookExpText.Size = new System.Drawing.Size(520, 87);
            this.BookExpText.TabIndex = 71;
            // 
            // BookPublisherText
            // 
            this.BookPublisherText.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BookPublisherText.Location = new System.Drawing.Point(350, 230);
            this.BookPublisherText.Name = "BookPublisherText";
            this.BookPublisherText.Size = new System.Drawing.Size(198, 20);
            this.BookPublisherText.TabIndex = 70;
            // 
            // BookWriterText
            // 
            this.BookWriterText.ForeColor = System.Drawing.Color.Black;
            this.BookWriterText.Location = new System.Drawing.Point(350, 118);
            this.BookWriterText.Name = "BookWriterText";
            this.BookWriterText.Size = new System.Drawing.Size(198, 20);
            this.BookWriterText.TabIndex = 66;
            // 
            // IDText
            // 
            this.IDText.Location = new System.Drawing.Point(115, 26);
            this.IDText.Name = "IDText";
            this.IDText.Size = new System.Drawing.Size(235, 20);
            this.IDText.TabIndex = 65;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 266);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(547, 51);
            this.label6.TabIndex = 5;
            this.label6.Text = "Enter some explanation about this book :\r\n \r\n( to provide some idea what is this " +
                "book about, and also can be an \'Empty Field\' [No Explanation])";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter publisher name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(217, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enter the name of the book\'s writer :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter Your ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select the category of the target book :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(228, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 26);
            this.label10.TabIndex = 78;
            this.label10.Text = "Welcom to share file";
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(350, 34);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(198, 21);
            this.CategoryCombo.TabIndex = 63;
            // 
            // DagreeCB
            // 
            this.DagreeCB.AutoSize = true;
            this.DagreeCB.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DagreeCB.Location = new System.Drawing.Point(117, 508);
            this.DagreeCB.Name = "DagreeCB";
            this.DagreeCB.Size = new System.Drawing.Size(82, 21);
            this.DagreeCB.TabIndex = 85;
            this.DagreeCB.Text = "Dis Agree";
            this.DagreeCB.UseVisualStyleBackColor = true;
            // 
            // AgreeCB
            // 
            this.AgreeCB.AutoSize = true;
            this.AgreeCB.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgreeCB.Location = new System.Drawing.Point(30, 508);
            this.AgreeCB.Name = "AgreeCB";
            this.AgreeCB.Size = new System.Drawing.Size(74, 21);
            this.AgreeCB.TabIndex = 84;
            this.AgreeCB.Text = "I  Agree";
            this.AgreeCB.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(30, 433);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.richTextBox1.Size = new System.Drawing.Size(519, 53);
            this.richTextBox1.TabIndex = 83;
            this.richTextBox1.Text = "از آپلود کردن  کتابهای نا مربوط جدا خودداری نمایید  ودر صورت تخلف اکانت شما مسدود" +
                " خواهد شد";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 413);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 17);
            this.label11.TabIndex = 86;
            this.label11.Text = "Protocol  :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CheckBtn);
            this.groupBox1.Controls.Add(this.ForGetCB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.IDText);
            this.groupBox1.Location = new System.Drawing.Point(12, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(578, 55);
            this.groupBox1.TabIndex = 79;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Person Info";
            // 
            // ForGetCB
            // 
            this.ForGetCB.AutoSize = true;
            this.ForGetCB.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForGetCB.Location = new System.Drawing.Point(392, 25);
            this.ForGetCB.Name = "ForGetCB";
            this.ForGetCB.Size = new System.Drawing.Size(68, 21);
            this.ForGetCB.TabIndex = 87;
            this.ForGetCB.Text = "Forget ";
            this.ForGetCB.UseVisualStyleBackColor = true;
            this.ForGetCB.CheckedChanged += new System.EventHandler(this.ForGetCB_CheckedChanged);
            // 
            // CheckBtn
            // 
            this.CheckBtn.Location = new System.Drawing.Point(483, 23);
            this.CheckBtn.Name = "CheckBtn";
            this.CheckBtn.Size = new System.Drawing.Size(54, 21);
            this.CheckBtn.TabIndex = 88;
            this.CheckBtn.Text = "Check";
            this.CheckBtn.UseVisualStyleBackColor = true;
            this.CheckBtn.Click += new System.EventHandler(this.CheckBtn_Click);
            // 
            // BookNameText
            // 
            this.BookNameText.Location = new System.Drawing.Point(352, 75);
            this.BookNameText.Name = "BookNameText";
            this.BookNameText.Size = new System.Drawing.Size(198, 20);
            this.BookNameText.TabIndex = 88;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 18);
            this.label2.TabIndex = 87;
            this.label2.Text = "Enter the book name :";
            // 
            // Share
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(615, 456);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.AddBookGB);
            this.Name = "Share";
            this.Text = "Hi  Asghar Mahmoodi";
            this.Load += new System.EventHandler(this.Share_Load);
            this.AddBookGB.ResumeLayout(false);
            this.AddBookGB.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox AddBookGB;
        private System.Windows.Forms.CheckBox DagreeCB;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button CnclBtn;
        private System.Windows.Forms.CheckBox AgreeCB;
        private System.Windows.Forms.Button ClrBtn;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox Day;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox BookExpText;
        private System.Windows.Forms.TextBox BookPublisherText;
        private System.Windows.Forms.TextBox BookWriterText;
        private System.Windows.Forms.TextBox IDText;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox ForGetCB;
        private System.Windows.Forms.Button CheckBtn;
        private System.Windows.Forms.TextBox BookNameText;
        private System.Windows.Forms.Label label2;

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Sundries
{
    public class DataGridViewSetting
    {
        public enum DataGridEnum { VirtualDataGrid, OnlineDataGrid }
        public static void GetDataGridReady(DataGridEnum Status, ref DataGridView dgv)
        {
            switch (Status)
            {
                case DataGridEnum.VirtualDataGrid:
                    dgv.Columns[1].Visible = dgv.Columns[3].Visible = dgv.Columns[dgv.Columns.Count - 2].Visible = false;
                    dgv.Columns[2].Width += dgv.Columns[1].Width + dgv.Columns[3].Width;
                    dgv.Columns[dgv.Columns.Count - 1].Width += dgv.Columns[dgv.Columns.Count - 2].Width;
                    break;
                case DataGridEnum.OnlineDataGrid:
                    dgv.Columns[1].Visible = dgv.Columns[3].Visible = dgv.Columns[dgv.Columns.Count - 2].Visible = true;
                    dgv.Columns[2].Width -= (dgv.Columns[1].Width + dgv.Columns[3].Width);
                    dgv.Columns[dgv.Columns.Count - 1].Width -= dgv.Columns[dgv.Columns.Count - 2].Width;
                    break;
            }
        }
        public static void InitializeDataGrid(List<string> Data, ref DataGridView dgv,Communication.Protocol.ClientSendQueryType type)
        {
            switch (type)
            {
                case Communication.Protocol.ClientSendQueryType.SearchBook:
                    GetDataGridReady(DataGridEnum.OnlineDataGrid, ref dgv);
                    InitializeDataGrid(Data, ref dgv);
                    break;
                default:
                    throw new ArgumentException();
            }
        }
        public static void InitializeDataGrid(List<string> Data, ref DataGridView dgv)
        {
            dgv.Rows.Clear();
            int count = 0;
            for (int n = 0; n < Data.Count; n += 7)
            {

                try
                {
                    dgv.Rows.Add(new object[] { ++count, Data[n], Data[n + 1], Data[n + 2], Data[n + 3], Data[n + 4] });
                }
                catch
                {
                }
            }
        }
        public static void InitializeDataGrid(List<string> Data, ref DataGridView dgv, bool state)
        {
            dgv.Rows.Clear();
            int count = 0;
            for (int n = 0; n < Data.Count; n += 7)
            {
                try
                {
                    dgv.Rows.Add(new object[] { ++count, Data[n], Data[n + 1], Data[n + 2], Data[n + 3], Data[n + 4], Data[n + 5], });
                }
                catch
                {
                }
            }
        }
        public static void InitializeDataGrid(List<string> Data, ref DataGridView dgv,int Index6)
        {
            dgv.Rows.Clear();
            int count = 0;
            for (int n = 0; n < Data.Count; n += 7)
            {
                try
                {
                    dgv.Rows.Add(new object[] { ++count, Data[n], Data[n + 1], Data[n + 2], Data[n + 3], Data[n + 4], Data[n + 5], Data[n + 6] });
                }
                catch
                {
                }
            }
        }
        public static void InitializeDataGrid(List<string> Data, ref DataGridView dgv, string Index6)
        {
            dgv.Rows.Clear();
            int count = 0;
            for (int n = 0; n < Data.Count; n += 8)
            {
                try
                {
                    dgv.Rows.Add(new object[] { ++count, Data[n], Data[n + 1], Data[n + 2], Data[n + 3], Data[n + 4], Data[n + 5], Data[n + 6], Data[n + 7] });
                }
                catch
                {
                }
            }
        }
    }
}
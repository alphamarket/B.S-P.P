﻿using System;
using System.Collections.Generic;
using Communication.Protocol;
namespace Sundries
{
    namespace Save
    {
        public class Saving
        {
            struct Upcomming
            {
                public static List<string> SearchQuery(String[] strs, ClientSendQueryType QT) { return new List<string>(); }
                public static bool SetQuery(String[] strs, ClientSendQueryType QT) { return true; }
            }
            public static bool Save(SaveType ST, List<string> query)
            {
                switch (ST)
                {
                    case SaveType.SaveBook:
                        return Upcomming.SetQuery(query.ToArray(), ClientSendQueryType.AddBook);
                    case SaveType.SaveMember:
                        return Upcomming.SetQuery(query.ToArray(), ClientSendQueryType.JoinMember);
                }
                return false;
            }
        }
    }
}
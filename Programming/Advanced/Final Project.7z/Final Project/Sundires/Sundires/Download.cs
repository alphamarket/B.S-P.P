﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace Sundries
{
    public partial class Download : Form
    {
        string path;
        public Download(string path)
        {
            InitializeComponent();
            this.path = path;
        }

        private void Select_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog FB = new FolderBrowserDialog();
                FB.ShowDialog();
                File.Copy(path, FB.SelectedPath + "\\uut.pdf");
                int i = 0;
                while (i < 100)
                {
                    progressBar1.Value++;
                    i++;
                    Thread.Sleep(20);
                }
                Sundries.MessageBox.ShowMessage("The download processing success...! ");
                this.Close();
            }
            catch(Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

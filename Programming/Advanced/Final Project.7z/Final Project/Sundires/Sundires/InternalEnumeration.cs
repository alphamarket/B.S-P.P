﻿namespace Sundries
{
    namespace Save
    {
        public enum SaveType
        {
            SaveMember, SaveBook
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace Sundries
{
    internal class SetID
    {  
       
        public SetID(string category)
        {
            int countFile = 0;
            int countDir=0;
            try
            {
                DirectoryInfo FI = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual");
                DirectoryInfo[] DI = FI.GetDirectories();
                foreach (DirectoryInfo item in DI)
                {
                    if (item.Name == category)
                        countDir++;

                }
                if (countDir == 0)
                {
                    DirectoryInfo DInfo = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual\" + category);
                    DInfo.Create();
                }
                DirectoryInfo FIn = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual\" + category);
                DirectoryInfo[] DIN = FI.GetDirectories();
                for (int i = 0; i < DIN.Length; i++)
                {
                    countFile++;
                }

                ID = countFile.ToString() + "-" + category;
                try
                {
                    DirectoryInfo DInfo = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual\"+category+"\\"+ID);
                    if(!DInfo.Exists)
                        DInfo.Create();
                    else
                    {
                        Random r = new Random();
                       int A= r.Next(0, 10000);
                        DirectoryInfo DInfor = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual\" + category +"\\" +ID +A.ToString());
                        DInfor.Create();
                        ID +=A.ToString();
                    }
                }
                catch(Exception ex)
                {
                  
                   
                        Sundries.MessageBox.ShowMessage(ex.Message);
                 
                }

            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }

        }
        private string ID;
        public  string getIDText { get { return ID; } }

       
    }
}

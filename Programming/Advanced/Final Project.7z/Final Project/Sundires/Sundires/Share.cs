﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace Sundries
{
    public partial class Share : Form
    {
        string path;
        string UserName;
        List<string> personInfo;
        public Share(string Path,string username)
        {
            InitializeComponent();
            path = Path;
            personInfo = new List<string>();
            UserName = username;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        bool state = true;
        private void AddBtn_Click(object sender, EventArgs e)
        {
           
            if (AgreeCB.Checked)
            {
                for (int i = 0; i < BookNameText.Text.Length; i++)
                {
                    if (BookNameText.Text[i] != 32)
                    {
                        state = false;
                    }
                }
                for (int i = 0; i < BookWriterText.Text.Length; i++)
                {
                    if (BookWriterText.Text[i] != 32)
                    {
                        state = false;
                    }
                }

                if (!state)
                    try
                    {

                        DirectoryInfo info = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual");
                        if (!info.Exists)
                            info.Create();
                        SetID set = new SetID(CategoryCombo.Text);
                        File.Copy(path, Application.StartupPath + @"\Files\Virtual\" + CategoryCombo.Text +"\\"+set.getIDText + "\\" + BookNameText.Text + ".pdf");

                        FileStream FS = new FileStream(Application.StartupPath + @"\Files\Virtual\" + CategoryCombo.Text + "\\" + set.getIDText + "\\personInfo.PI", FileMode.Create, FileAccess.Write);
                        StreamWriter SW = new StreamWriter(FS);

                        for (int i = 0; i < personInfo.Count; i++)
                        {
                            SW.WriteLine(personInfo[i]);
                        }
                        SW.Close();
                        FS.Close();
                        FileStream FST = new FileStream(Application.StartupPath + @"\Files\Virtual\" + CategoryCombo.Text + "\\" + set.getIDText + "\\Bookinfo.BI", FileMode.Create, FileAccess.Write);
                        StreamWriter SWR = new StreamWriter(FST);
                        SWR.WriteLine(BookNameText.Text);
                        SWR.WriteLine(BookWriterText.Text);
                        SWR.WriteLine(set.getIDText);
                        SWR.WriteLine(set.getIDText + "  " + DateTime.Now);
                        SWR.WriteLine(CategoryCombo.Text);
                        Sundries.MessageBox.ShowMessage("Book has been added to database successfully ...");
                        SWR.Close();
                        FST.Close();
                    }
                    catch (Exception ex)
                    {
                        Sundries.MessageBox.ShowMessage(ex.Message);
                    }
                else
                {
                    Sundries.MessageBox.ShowMessage("Null text invalid...!");
                    BookNameText.Text = "Please fill where...!";
                    BookWriterText.Text = "Please fill where...!";
                }
            }

        }

        private void CheckBtn_Click(object sender, EventArgs e)
        {
            if (ForGetCB.Checked)
            {
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                personInfo.Add(UserName);
                AddBookGB.Enabled = true;
            }
            else
            {
                for (int i = 0; i < IDText.Text.Length; i++)
                {
                    if (IDText.Text[i] != 32)
                    {
                        state = false;
                    }
                }
                string[] value = new string[1];
                value[0] = IDText.Text;
                Search.Search S = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
                personInfo = S.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchMember);
                if (personInfo.Count != 0 && personInfo.Count != 1)
                {
                    AddBookGB.Enabled = true;
                }
                else
                    Sundries.MessageBox.ShowMessage("Not exist student by this id in database...!");
            }

        }

        private void ForGetCB_CheckedChanged(object sender, EventArgs e)
        {
            if (ForGetCB.Checked)
            {
                IDText.Enabled = false;
            }
            else
                IDText.Enabled = true;
        }

        private void Share_Load(object sender, EventArgs e)
        {
            this.Text =  " Hi "+ UserName+" Welcom to share book!";
        }

        private void CnclBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClrBtn_Click(object sender, EventArgs e)
        {
            foreach (Control item in AddBookGB.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
        }
    }
}

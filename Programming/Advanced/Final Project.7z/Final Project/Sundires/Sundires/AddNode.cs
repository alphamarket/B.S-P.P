﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Sundries
{
   
   public class AddNode
    {
       List<string> keepName = new List<string>();
        public AddNode(TreeNode TN,string path)
        {
           
            try
            {
                DirectoryInfo Di = new DirectoryInfo(path);
                if (Di.Exists)
                {
                    DirectoryInfo[] di = Di.GetDirectories();
                    foreach (DirectoryInfo item in di)
                    {
                        keepName.Add(item.Name);
                    }
                }
                for (int i = 0; i < keepName.Count; i++)
                {
                    TreeNode Newnodes = new TreeNode(i.ToString());
                    TN.Nodes.Add(Newnodes);                    
                }
                tmp = keepName;                
            }
            catch
            {
            }

        }
        public AddNode(string path)
        {
            DirectoryInfo Di = new DirectoryInfo(path);
            if (Di.Exists)
            {
                DirectoryInfo[] di = Di.GetDirectories();
                foreach (DirectoryInfo item in di)
                {
                    keepName.Add(item.Name);
                }
            }
            tmp = keepName;
        }
        private static List<string> tmp;
        public List<string> BookId { get {return tmp; } }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sundries
{
    public partial class StateMe : Form
    {
        public StateMe()
        {
            InitializeComponent();
        }

        private void show_Click(object sender, EventArgs e)
        {
            try
            {
                string[] value = new string[1];
                value[0] = KeySearch.Text;        
                Search.Search se = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
                Sundries.DataGridViewSetting.InitializeDataGrid(se.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBorrower), ref dataGridView2, true);
            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }
        }

        private void StateMe_Load(object sender, EventArgs e)
        {

        }
    }
}

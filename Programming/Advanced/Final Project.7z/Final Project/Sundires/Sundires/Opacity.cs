﻿using System.Threading;
using System.Windows.Forms;

namespace Sundries
{   
    public class Opacity
    {
        public static void OpacityClose(Form form)
        {
            double i = 1;
            while (i >= 0)
            {
                form.Opacity = i;
                i -= 0.1;
                Thread.Sleep(20);

            }
            form.Close();
        }
        public static void OpacityOpen(Form form)
        {
            form.Opacity = 0;
            form.Show();
            double i = 0;
            while (i <1.1)
            {
                form.Opacity = i;
                i += 0.1;
                Thread.Sleep(10);
            }
        }
    }
}

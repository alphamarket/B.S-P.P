﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace Sundries
{
    public class VBookinfo
    {
        public List<string> GetBookInfo(string nodeText,string path)
        {
            
                List<string> tmp = new List<string>();
                AddNode add = new AddNode(path);   
                FileInfo FI = new FileInfo(path + "\\" + add.BookId[int.Parse(nodeText)] + "\\personInfo.PI");
                if (FI.Exists)
                {
                    DirectoryInfo FIn = new DirectoryInfo(path + "\\" + add.BookId[int.Parse(nodeText)]);
                    FileInfo[] DIN = FIn.GetFiles();
                    foreach (FileInfo item in DIN )
                    {
                        if (item.Name != "personInfo.PI" && item.Name != "Bookinfo.BI")
                        {
                            PA = item.FullName;
                        }
                    }
                    StreamReader SR = new StreamReader(path + "\\" + add.BookId[int.Parse(nodeText)] + "\\Bookinfo.BI");
                    while (!SR.EndOfStream)
                    {
                        tmp.Add(SR.ReadLine());
                    }
                }
                else { throw new Exception("This file possible clear and Directory is not clear...! "); }

                return tmp;           
           
        }
        private static string PA;
        public string PdfAddress { get { return PA; } }
        public VBookinfo()
        {
        }
       
    }
}

﻿using System;

namespace Query
{
    public enum QueryExceptionType { ClientSendQueryType, ServerSendQueryType }
    public sealed class QueryException : Exception
    {
        Enum _enum;
        string message;
        public override string Message
        {
            get
            {
                return message;
            }
        }
        public QueryException(string passage, QueryExceptionType QT, Enum E)
        {
            message = passage;
            _enum = E;
        }
        public Enum GetEnum
        {
            get
            {
                return _enum;
            }
        }
    }
}

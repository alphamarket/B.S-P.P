﻿using System;
using System.Collections.Generic;
using Communication.Connection;
using Communication.Data;
using Communication.Protocol;
using Search;
using System.IO;
namespace Serve
{
    struct CurrentUserInfo
    {
        internal struct Query
        {
            private string[] demand;
            private string Time;
            private ClientSendQueryType qt;
            internal Query(string[] query, ClientSendQueryType QST)
            {
                Time = DateTime.Now.ToString();
                demand = query;
                qt = QST;
            }
            public override string ToString()
            {
                string tmp;
                tmp = "\' " + CurrentUserInfo.CurrentUser.ToUpper() + " \' demands \' " + qt.ToString().ToUpper() + " \' of \' ";
                foreach (string i in demand)
                    tmp += i.ToUpper() + " , ";
                tmp += " \' at \' " + DateTime.Now.ToString().ToUpper() + " \'";
                return tmp;
            }
        }
        private static string CurrentUser = "";
        internal static List<CurrentUserInfo.Query> query = new List<CurrentUserInfo.Query>();
        internal static void CreateHistory(string username, System.Net.IPEndPoint ipep)
        {
            //
            //TODO: INITIALIZE A HISTORY FOR THIS USER
            //
            using (FileStream fs = new FileStream(System.Windows.Forms.Application.StartupPath + @"\Files\DataBase\Recent\User\" + (CurrentUser = username) + ".rs", FileMode.Append, FileAccess.Write, FileShare.None))
            {
                using (StreamWriter write = new StreamWriter(fs))
                {
                    write.WriteLine();
                    write.WriteLine(new string('*', 20));
                    write.WriteLine();
                    write.WriteLine("\' " + username.ToUpper() + " \' just connect to server with ip \' " + ipep.ToString().ToUpper() + " \' at \' " + DateTime.Now.ToString().ToUpper() + " \'");
                }
            }
        }
        internal static void ClearUserHistory()
        {
            //
            //TODO: SAVE IN RELATED FILES
            //
            using (FileStream fs = new FileStream(System.Windows.Forms.Application.StartupPath + @"\Files\DataBase\Recent\User\" + CurrentUserInfo.CurrentUser + ".rs",
                FileMode.Append, FileAccess.Write, FileShare.None))
            {
                using (StreamWriter write = new StreamWriter(fs))
                {
                    foreach (CurrentUserInfo.Query i in CurrentUserInfo.query)
                    {
                        write.WriteLine(i.ToString());
                        write.Flush();
                    }
                }
            }
        }
        internal static void Add(string[] query, ClientSendQueryType QST)
        {
            CurrentUserInfo.query.Add(new Query(query, QST));
        }
    }
    public class Query
    {
        static Search.Search search = new Search.Search();
        public static void AddJoinQuery(List<string> query, ClientSendQueryType QT)
        {
            try
            {
                switch (QT)
                {
                    case ClientSendQueryType.JoinMember:
                        //
                        //TODO: ADD NEW DEMANED BOOK TO DATABASE HERE
                        //
                        SetData.SetMemberInfo mf = new SetData.SetMemberInfo();
                        if (mf.addNewMember(query))
                            Sundries.MessageBox.ShowMessage("User has been added to database successfully");
                        else
                            Sundries.MessageBox.ShowMessage("Something wrong happened while trying to save data, try later");
                        break;
                    case ClientSendQueryType.AddBook:
                        //
                        //
                        //
                        string target = query[0];
                        query.RemoveAt(0);
                        SetData.SetData.SetNewData(target, query, Communication.Protocol.ClientSendQueryType.AddBook);
                        break;
                    default:
                        throw new ArgumentException("Invalid Entery Argument", QT.ToString());
                }
            }
            catch (Exception e)
            {
                Sundries.MessageBox.ShowMessage(e.Message);
            }
        }
        public static List<string> DoSearchQuery(List<string> query, ClientSendQueryType QT)
        {
            try
            {
                Search.Search srch;
                switch (QT)
                {
                    case ClientSendQueryType.SearchBook:
                        //
                        //TODO: LUANCH A BOOK SEARCH AND RETURN THE RESULTS
                        //
                        srch = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByName);
                        return srch.newsearch(query.ToArray(), QT);
                    case ClientSendQueryType.SearchMember:
                        //
                        //TODO: LUANCH A MEMBER SEARCH AND RETURN THE RESULTS
                        //
                        srch = new Search.Search();
                        return srch.newsearch(query.ToArray(), QT);
                    case ClientSendQueryType.TreeSearch:
                        //
                        //TODO: LUANCH A TREE SEARCH AND RETURN THE RESULTS
                        //
                        srch = new Search.Search();
                        return srch.newsearch(query.ToArray(), QT);
                    default:
                        throw new ArgumentException("Invalid Entery Argument", QT.ToString());
                }
            }
            catch (Exception e)
            {
                Sundries.MessageBox.ShowMessage(e.Message);
            }
            return new List<string>();
        }
        public List<string> AddBook(List<string> query, Search.InternalEnumeration.ResultSearchBook SBR, Search.InternalEnumeration.SortType ST)
        {
            try
            {
                Search.Search srch = new Search.Search(SBR, ST);
                return srch.newsearch(query.ToArray(), ClientSendQueryType.SearchBook);
            }
            catch (Exception e)
            {
                Sundries.MessageBox.ShowMessage(e.Message);
            }
            return new List<string>();
        }
        public static void DoClientQuery(String[] query, Connection sock)
        {
            try
            {
                ClientSendQueryType TmpType;
                switch (TmpType = LPS.WhatISClientQuery())
                {
                    case ClientSendQueryType.TreeSearch:
                        //
                        //IN HERE THIS WILL RETURN ALL ASSOCIATED DATA WITH SERIES OF BOOK TYPES
                        //
                        FeedBack.DoFeedBack(search.newsearch(query, Communication.Protocol.ClientSendQueryType.TreeSearch));
                        break;
                    case ClientSendQueryType.SearchBook:
                        //
                        //DOES COMMON SEARCH
                        //
                        FeedBack.DoFeedBack(search.newsearch(query, Communication.Protocol.ClientSendQueryType.SearchBook));
                        //
                        //SAVE DEMANDED SEARCH
                        //
                        break;
                    case ClientSendQueryType.Login:
                        //
                        //IN HERE CHECK IF USER IS FILTERED OR NOT
                        //
                        if (Serve.Query.CheckUserFilter(query[0]))
                        {
                            //
                            // IN HERE THIS WILL GOING TO CHECK USER AND PASSWORD OF USER
                            //
                            List<string> tmp = search.newsearch(query, Communication.Protocol.ClientSendQueryType.Login);
                            FeedBack.DoFeedBack(tmp);
                            //
                            //TODO: OPEN NEW HISTORY SOCKET FOR THIS CLIENT AND FOR TODAY'S EVENTS-- OF COURSE THE RESULT IS TRUE
                            //
                            if (Convert.ToBoolean(tmp[0]))
                                CurrentUserInfo.CreateHistory(query[0], sock.JoinedIPEndPoint);
                            //
                            //REASON FOR THIS RETURN: TO DO NOT PERSUADE INORDER TO DO NOT SAVE LOGIN 'AGAIN' AFTER SWITCH/CASE
                            //
                        }
                        return;
                    case ClientSendQueryType.Logout:
                        //
                        //TODO: CLOSE THE CURRENT HISTORY SOCKET THIS IS ONE SIDED PROTOCOL DO NOT NOTIFY THE CLIENT SIDE APP' TO LOGOUT IT IS ALREADY LOGGED OUT
                        //
                        CurrentUserInfo.ClearUserHistory();
                        //
                        //REASON FOR THIS RETURN: TO DO NOT PERSUADE INORDER TO DO NOT SAVE LOGOUT AFTER SWITCH/CASE
                        //
                        return;
                    default:
                        throw new ArgumentException("Invalid Entery Argument!", TmpType.ToString());
                }
                //
                //TODO: KEEP TRACK OF WHAT IS CLIENT DEMAND
                //
                CurrentUserInfo.Add(query, TmpType);
            }
            catch (Exception er)
            {
                System.Windows.Forms.MessageBox.Show(er.Message);
            }
        }
        static bool CheckUserFilter(string username)
        {
            try
            {
                using (FileStream fs = new FileStream(System.Windows.Forms.Application.StartupPath + @"\Files\DataBase\UFilters.FILE", FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    using (StreamReader read = new StreamReader(fs))
                    {
                        while (!read.EndOfStream)
                        {
                            if (read.ReadLine() == username)
                            {
                                FeedBack.DoFeedBack(new List<string>());
                                return false;
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException) { return true; }
            return true;
        }
    }
}
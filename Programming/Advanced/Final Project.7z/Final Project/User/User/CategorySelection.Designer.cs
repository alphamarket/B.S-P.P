﻿namespace Client
{
    partial class CategorySelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10,
            treeNode13,
            treeNode18,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Other");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategorySelection));
            this.label1 = new System.Windows.Forms.Label();
            this.FileNameLabel = new System.Windows.Forms.Label();
            this.DoneBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.VirtualTree = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select category for :";
            // 
            // FileNameLabel
            // 
            this.FileNameLabel.AutoSize = true;
            this.FileNameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.FileNameLabel.Location = new System.Drawing.Point(24, 38);
            this.FileNameLabel.Name = "FileNameLabel";
            this.FileNameLabel.Size = new System.Drawing.Size(49, 13);
            this.FileNameLabel.TabIndex = 1;
            this.FileNameLabel.Text = "Filename";
            // 
            // DoneBtn
            // 
            this.DoneBtn.Location = new System.Drawing.Point(231, 269);
            this.DoneBtn.Name = "DoneBtn";
            this.DoneBtn.Size = new System.Drawing.Size(99, 23);
            this.DoneBtn.TabIndex = 66;
            this.DoneBtn.Text = "Ignore This Book";
            this.DoneBtn.UseVisualStyleBackColor = true;
            this.DoneBtn.Click += new System.EventHandler(this.IgnoreBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(336, 269);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(101, 23);
            this.CancelBtn.TabIndex = 67;
            this.CancelBtn.Text = "Cancel Uploading";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(27, 273);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(198, 17);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.Text = "Remember this for this upload series ";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // VirtualTree
            // 
            this.VirtualTree.Location = new System.Drawing.Point(27, 77);
            this.VirtualTree.Name = "VirtualTree";
            treeNode1.Name = "Node17";
            treeNode1.Text = "Computer";
            treeNode2.Name = "Node18";
            treeNode2.Text = "Chemistry";
            treeNode3.Name = "Node19";
            treeNode3.Text = "Mechanic";
            treeNode4.Name = "Node20";
            treeNode4.Text = "Mine";
            treeNode5.Name = "Node21";
            treeNode5.Text = "Antitrust";
            treeNode6.Name = "Node22";
            treeNode6.Text = "Electricity";
            treeNode7.Name = "Node23";
            treeNode7.Text = "OtherEngineer";
            treeNode8.Name = "Node12";
            treeNode8.Text = "Engineer";
            treeNode9.Name = "Node24";
            treeNode9.Text = "Math";
            treeNode10.Name = "Node25";
            treeNode10.Text = "Physic";
            treeNode11.Name = "Node28";
            treeNode11.Text = "Poem";
            treeNode12.Name = "Node29";
            treeNode12.Text = "Prose";
            treeNode13.Name = "Node26";
            treeNode13.Text = "Literary";
            treeNode14.Name = "Node34";
            treeNode14.Text = "Turkish";
            treeNode15.Name = "Node30";
            treeNode15.Text = "Enghlish";
            treeNode16.Name = "Node31";
            treeNode16.Text = "Russian";
            treeNode17.Name = "Node32";
            treeNode17.Text = "Other Language";
            treeNode18.Name = "Node27";
            treeNode18.Text = "LanguageBook";
            treeNode19.Name = "Node33";
            treeNode19.Text = "Cult";
            treeNode20.Name = "Node14";
            treeNode20.Text = "Public";
            treeNode21.Name = "Node16";
            treeNode21.Text = "Other";
            this.VirtualTree.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode8,
            treeNode20,
            treeNode21});
            this.VirtualTree.Size = new System.Drawing.Size(213, 181);
            this.VirtualTree.TabIndex = 69;
            this.VirtualTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.VirtualTree_AfterSelect);
            // 
            // CategorySelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(449, 305);
            this.Controls.Add(this.VirtualTree);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.DoneBtn);
            this.Controls.Add(this.FileNameLabel);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CategorySelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Select Category ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label FileNameLabel;
        private System.Windows.Forms.Button DoneBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TreeView VirtualTree;
    }
}
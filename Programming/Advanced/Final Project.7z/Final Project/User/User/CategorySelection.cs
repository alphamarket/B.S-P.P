﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace Client
{
    internal partial class CategorySelection : Form
    {
        string catPath;
        System.Windows.Forms.DialogResult Result=DialogResult.None;
        public CategorySelection()
        {
            InitializeComponent();
        }
        public string ShowCategoryAndSave(string[] BookPath, string[] BookName)
        {
            int j = 0, count = 0;
            for (int i = 0; i < BookPath.Length; i++)
            {

                FileNameLabel.Text = BookName[j];
                if (!checkBox1.Checked)
                    this.ShowDialog();
                switch (Result)
                {
                    case System.Windows.Forms.DialogResult.Retry:
                        Result = System.Windows.Forms.DialogResult.None;
                        i--;
                        continue;
                    case System.Windows.Forms.DialogResult.Abort:
                        return "Uploading has been canceled ...";
                    case System.Windows.Forms.DialogResult.Ignore:
                        Result = System.Windows.Forms.DialogResult.None;
                        j++;count++;
                        continue;
                }
                if (!Directory.Exists(catPath))
                    Directory.CreateDirectory(catPath);
                if (!File.Exists(catPath + @"\" + BookName[j]))
                    File.Copy(BookPath[i], catPath + @"\" + BookName[j]);
                j++;
            }
            return j-count + " file(s) uploaded successfully . . .";
        }
        private void IgnoreBtn_Click(object sender, EventArgs e)
        {
            Result = System.Windows.Forms.DialogResult.Ignore;
            this.Close();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            Result = System.Windows.Forms.DialogResult.Abort;
            this.Close();
        }

        private void VirtualTree_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.LastNode == null)
            {
                catPath = Application.StartupPath + @"\Files\DataBase\Virtual Library\All Book\" + VirtualTree.SelectedNode.Text;
                this.Close();
            }
            e.Node.Expand();
            TreeView t = (TreeView)sender;
            t.SelectedNode = null;
        }
    }
}
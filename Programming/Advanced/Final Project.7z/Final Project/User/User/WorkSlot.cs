﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Communication.ConnectionInfo;
enum ControlPanel
{
    LoginForm, LoginPanel, SlotPanel, DataGrid_1, DataGrid_2, SearchResultCountLabel, PublicMessageLabel, DataGrid1_Status
}
internal struct GlobalInfo
{
    internal static string LastSearch;
    internal static int LastComboBoxSelectedIndex = -1;
    internal static Queue<Client.TempData> _queue = new Queue<Client.TempData>();
    internal static void ChangeForm(InternalEnumeration.Status status)
    {
        switch (status)
        {
            case InternalEnumeration.Status.Login:
                GlobalInfo._queue.Enqueue(new Client.TempData((Panel)GlobalInfo.Globals[ControlPanel.SlotPanel], InternalEnumeration.Status.Login));
                GlobalInfo.IsLoggedIn = true;
                break;
            case InternalEnumeration.Status.Logout:
                StaticConnectionInfo.ClientConnetionRoot.Logout();
                GlobalInfo._queue.Enqueue(new Client.TempData((Panel)GlobalInfo.Globals[ControlPanel.LoginPanel], InternalEnumeration.Status.Logout));
                GlobalInfo.IsLoggedIn = false;
                Form tmp = (Form)GlobalInfo.Globals[ControlPanel.LoginForm];
                tmp.StartPosition = FormStartPosition.CenterScreen;
                break;
        }
    }
    internal static bool IsLoggedIn = false;
    internal static System.Collections.Hashtable Globals = new System.Collections.Hashtable();
    internal static System.Collections.Hashtable MonitoringQueue = new System.Collections.Hashtable();
    internal static System.Collections.Generic.List<Client.SearchResult.DataGrid1> RecentSearch_1 = new List<Client.SearchResult.DataGrid1>();
    internal static System.Collections.Generic.List<Client.SearchResult.DataGrid3> RecentSearch_3 = new List<Client.SearchResult.DataGrid3>();
}
namespace Client
{
    internal partial class main : Form
    {
        delegate void FormCalling(InternalEnumeration.Status st);
        void Calling(InternalEnumeration.Status status)
        {
            switch (status)
            {
                case InternalEnumeration.Status.Logout:
                    SetPanelRight(LogInPanel);
                    logOutToolStripMenuItem.Visible = false;
                    Sundries.Opacity.OpacityOpen((Form)GlobalInfo.Globals[ControlPanel.LoginForm]);
                    break;
                case InternalEnumeration.Status.Login:
                    SetPanelRight(MySlotPanel);
                    this.Location = new Point(0, 0);
                    logOutToolStripMenuItem.Visible = true;
                    break;
            }
        }
        void FormMonitoring(object set)
        {
            if (Convert.ToBoolean(set))
            {
                System.Threading.Thread tr = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(FormMonitoring));
                tr.Start(false);
            }
            else
            {
                TempData tmp = new TempData(null, InternalEnumeration.Status.Logout);
                while (true)
                {
                    try
                    {
                        while (GlobalInfo._queue.Count == 0) ;
                        tmp = GlobalInfo._queue.Dequeue();
                        if (tmp.panel != null)
                            if (tmp.panel.InvokeRequired)
                                tmp.panel.Invoke(new FormCalling(Calling), new object[] { tmp.status });
                            else
                                Calling(tmp.status);
                    }
                    catch
                    {
                        Calling(tmp.status);
                    }
                }
            }
        }
        void LoadMessages()
        {
            if (File.Exists(Application.StartupPath + @"\Files\DataBase\pblc.mes"))
            {
                System.IO.StreamReader read = System.IO.File.OpenText(Application.StartupPath + @"\Files\DataBase\pblc.mes");
                ((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Text = read.ReadToEnd();
            }
            //
            //TODO: THERE IS A PLACE FOR PRIVATE MESSAGE HANDLING
            //
        }
        public main()//****************************************CTOR***************************************************//
        {
            InitializeComponent();
            FormMonitoring(true);
            try
            {
                GlobalInfo.Globals.Add(ControlPanel.LoginForm, this);
                GlobalInfo.Globals.Add(ControlPanel.SlotPanel, MySlotPanel);
                GlobalInfo.Globals.Add(ControlPanel.LoginPanel, LogInPanel);
                GlobalInfo.Globals.Add(ControlPanel.DataGrid_1, DataGrid_1);
                GlobalInfo.Globals.Add(ControlPanel.SearchResultCountLabel, SearchNotificationLabel);
                GlobalInfo.Globals.Add(ControlPanel.PublicMessageLabel, PublicMessage);
                GlobalInfo.Globals.Add(ControlPanel.DataGrid1_Status, Sundries.DataGridViewSetting.DataGridEnum.OnlineDataGrid);
            }
            catch { }
            LoadMessages();
            if (!GlobalInfo.IsLoggedIn)
            {
                SetPanelRight(LogInPanel);
                logOutToolStripMenuItem.Visible = false;
                UserNameText.Focus();
            }
            else
            {
                SetPanelRight(MySlotPanel);
            }
            dwnldBtn.Visible = false;
            Sundries.Opacity.OpacityOpen(this);
        }
        public void SetPanelRight(Panel panel)
        {
            foreach (Control i in Controls)
                if (i is Panel)
                    if (i == panel)
                    {
                        panel.Visible = true;
                        ((Form)GlobalInfo.Globals[ControlPanel.LoginForm]).ClientSize = new Size(panel.Size.Width, menuStrip1.Size.Height + panel.Size.Height);
                        panel.Location = new Point(0, menuStrip1.Size.Height + 1);
                    }
                    else i.Visible = false;
        }
        private void SearchKeyText_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    CheckSearchSecurity(SearchKeyText.Text);
                    if (SearchTypeCombo.SelectedIndex == -1)
                        SearchTypeCombo.SelectedIndex = 0;
                    SearchBtn_Click(new object(), new EventArgs());
                }
            }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }
        void CheckSearchSecurity(string query)
        {
            string[] tmp = new string[] { "<", ">", "</", ":" };
            foreach (string i in tmp)
                if (query.Contains(i))
                {
                    SearchKeyText.Text = "";
                    throw new Exception("Client has not allowed to use these characters \r\n\' > \' , \' > \' , \' </ \' , \' : \'\r\nPlease do not enter such characters!");
                }
        }
        private void SearchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (SearchTypeCombo.SelectedIndex == -1)
                    SearchTypeCombo.SelectedIndex = 0;
                if (SearchKeyText.Text != GlobalInfo.LastSearch || SearchTypeCombo.SelectedIndex != GlobalInfo.LastComboBoxSelectedIndex)
                    SendQuery(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, (Search.InternalEnumeration.SortType)SearchTypeCombo.SelectedIndex + 1, SearchKeyText.Text);
                dwnldBtn.Visible = false;
            }
            catch (NullReferenceException) { }
        }
        public static void SendQuery(Search.InternalEnumeration.ResultSearchBook RSB, Search.InternalEnumeration.SortType ST, String Query)
        {
            try
            {
                StaticConnectionInfo.ClientConnetionRoot.SendData(Query,
                               Communication.Protocol.ClientSendQueryType.SearchBook, ST, RSB);
                GlobalInfo.LastComboBoxSelectedIndex = (int)ST;
                GlobalInfo.LastSearch = Query;
            }
            catch
            {
            }
        }
        private void networkSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Server.NetworkSetting net = new Server.NetworkSetting(Communication.Setting.SettingOptions.NotFirstTime, Communication.NetworkExceptionSide.Client);
            net.ShowDialog();
        }
        private void EnterBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (StaticConnectionInfo.ClientConnetionRoot == null)
                {
                    StaticConnectionInfo.ClientConnetionRoot
                        = new Connection.ClientConnection(StaticConnectionInfo.ConnectionEndPointInfo, new ToolStripStatusLabel());
                    StaticConnectionInfo.ClientConnetionRoot.Login(UserNameText.Text, PassWordText.Text);
                }
                else
                    StaticConnectionInfo.ClientConnetionRoot.Login(UserNameText.Text, PassWordText.Text);
                PassWordText.Text = "";
            }
            catch
            {
                Communication.Connection.Connection.RestartApplication();
            }
            SearchKeyText.Text = textBox1.Text = "";
            SearchTypeCombo.SelectedIndex = -1;
            CategoryCombo.SelectedIndex = -1;
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void WorkSlot_Load(object sender, EventArgs e)
        {
        }
        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {
            try
            {
                StaticConnectionInfo.ClientConnetionRoot.SendData(AllBookTV.SelectedNode.Text.Replace(" ", ""), Communication.Protocol.ClientSendQueryType.TreeSearch);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void See1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MoreResult more = new MoreResult();
            more.Show();
        }

        private void WorkSlot_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Communication.Connection.Connection.IsProgramRestarting())
            {
                Application.Restart();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void ClrDataLinkedLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sundries.DataGridViewSetting.GetDataGridReady(Sundries.DataGridViewSetting.DataGridEnum.OnlineDataGrid, ref DataGrid_1);
            Connection.ClientConnection.ClearDataGrid(ref DataGrid_1);
            SearchNotificationLabel.Text = "No Search Have Been Launched";
        }

        private void DataGrid_1_DoubleClick(object sender, EventArgs e)
        {
            switch ((Sundries.DataGridViewSetting.DataGridEnum)GlobalInfo.Globals[ControlPanel.DataGrid1_Status])
            {
                case Sundries.DataGridViewSetting.DataGridEnum.OnlineDataGrid:
                    //MessageBox.Show(book.BookID,
                    //
                    //
                    //THIS IS HOW WE SHOW INFO IN SEPERATE FORM
                    //
                    ShowBookInfo.ShowInfo(GlobalInfo.RecentSearch_1[GlobalInfo.RecentSearch_1.Count - 1][DataGrid_1.SelectedCells[0]]);
                    break;
                case Sundries.DataGridViewSetting.DataGridEnum.VirtualDataGrid:
                    VirtualDownLoad.Description = "Select a folder to save selected book(s) there :";
                    DialogResult res = VirtualDownLoad.ShowDialog();
                    if (res == System.Windows.Forms.DialogResult.Cancel) return;
                    string path = VirtualDownLoad.SelectedPath;
                    int count = 0;
                    foreach (DataGridViewRow i in DataGrid_1.SelectedRows)
                    {
                        try
                        {
                            string _path = Application.StartupPath + @"\Files\DataBase\Virtual Library\" + VirtualTree.SelectedNode.FullPath + "\\" + i.Cells[2].Value;
                            System.IO.File.Copy(_path, path + "\\" + i.Cells[2].Value);
                        }
                        catch { }
                        DataGrid_1.Rows.Remove(i);
                        count++;
                    }
                    string message;
                    if (count > 1)
                        message = count + " files have been downloaded to \" " + path + "\" successfully.";
                    else
                        message = "The selected file has been downloaded to \"" + path + "\" successfully.";
                    MessageBox.Show(message);
                    break;
            }

        }

        private void uploadBtn_Click(object sender, EventArgs e)
        {
            while (true)
            {
                DialogResult res = VirtualUpload.ShowDialog();
                if (res == System.Windows.Forms.DialogResult.Cancel)
                    return;
                string[] filePath = VirtualUpload.FileNames;
                string[] fileName = VirtualUpload.SafeFileNames;
                if (fileName.Length > 10)
                {
                    MessageBox.Show("you can not upload more than 8 book each time!");
                    return;
                }
                bool vail = false;
                foreach (string i in filePath)
                    if (i == "" || i == null)
                    {
                        MessageBox.Show("Invalid File Name . . .!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                if (vail)
                    continue;
                else
                {
                    try
                    {
                        CategorySelection aFrom = new CategorySelection();
                        uploadResult.Text = aFrom.ShowCategoryAndSave(filePath, fileName);
                        break;
                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(er.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                }
            }
        }

        private void UserNameText_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (PassWordText.Text == "")
                    PassWordText.Focus();
                else
                    EnterBtn_Click(new object(), new EventArgs());
            }
        }

        private void PassWordText_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (UserNameText.Text == "")
                    UserNameText.Focus();
                else
                    EnterBtn_Click(new object(), new EventArgs());
            }
        }

        private void VirtualView3_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.LastNode == null)
            {
                result.Text = "0 result has been found";
                SeeVirtualLibLinkedLabel_LinkClicked(new object(), new LinkLabelLinkClickedEventArgs(null));
                dwnldBtn.Visible = true;
            }
            else
                e.Node.Expand();
        }

        private void SeeVirtualLibLinkedLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataGrid_1.Rows.Clear();
            VirtualLibrary.ShowVirtualLibrary(VirtualTree.SelectedNode.Text, ref DataGrid_1, VirtualTree.SelectedNode.Text);
        }
        internal static void SetDataGridTo(Sundries.DataGridViewSetting.DataGridEnum status,ref DataGridView DataGrid_1)
        {
            if ((Sundries.DataGridViewSetting.DataGridEnum)GlobalInfo.Globals[ControlPanel.DataGrid1_Status] != status)
                Sundries.DataGridViewSetting.GetDataGridReady(status, ref DataGrid_1);
            GlobalInfo.Globals[ControlPanel.DataGrid1_Status] = status;
        }

        private void dwnldBtn_VisibleChanged(object sender, EventArgs e)
        {
            See1.Visible = !dwnldBtn.Visible;
        }

        private void dwnldBtn_Click(object sender, EventArgs e)
        {
            DataGrid_1_DoubleClick(new object(), new EventArgs());
        }

        private void DataGrid_1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            result.Text = DataGrid_1.RowCount + " result have been found";
        }

        private void SearchNotificationLabel_TextChanged(object sender, EventArgs e)
        {
            if (SearchNotificationLabel.Text != "")
            {
                result.Text = "";
                uploadResult.Text = "";
            }
        }

        private void result_TextChanged(object sender, EventArgs e)
        {
            if (result.Text != "")
            {
                SearchNotificationLabel.Text = "";
                uploadResult.Text = "";
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Control i in LogInGB.Controls)
            {
                if (i is TextBox)
                    i.Text = "";
            }
            GlobalInfo.ChangeForm(InternalEnumeration.Status.Logout);
        }

        private void VirtualSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (CategoryCombo.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a category!", "Notification ...", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                DirectoryInfo dir = new DirectoryInfo(Application.StartupPath + @"\Files\DataBase\Virtual Library\All Book\" + CategoryCombo.SelectedItem);
                FileInfo[] files = dir.GetFiles();
                if (files.Length == 0)
                {
                    throw new DirectoryNotFoundException();
                }
                int count = 0;
                DataGrid_1.Rows.Clear();
                SetDataGridTo(Sundries.DataGridViewSetting.DataGridEnum.VirtualDataGrid, ref DataGrid_1);
                foreach (FileInfo i in files)
                {
                    if (i.Name.ToLower().Contains(textBox1.Text.ToLower()))
                        DataGrid_1.Rows.Add(new object[] { ++count, null, i.Name, null, null, CategoryCombo.SelectedItem });
                }
                if (DataGrid_1.Rows.Count == 0)
                    throw new DirectoryNotFoundException();
                dwnldBtn.Visible = true;
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("There is no book in \' " + CategoryCombo.SelectedItem + " \' field of study!", "Notification ...", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
        }

        private void shutDownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process[] pros = System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName, System.Diagnostics.Process.GetCurrentProcess().MachineName);
            foreach (System.Diagnostics.Process i in pros)
            {
                i.Kill();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Communication;
using Communication.Setting;
using Server;
namespace Client
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                if (!ConnectionSetting.LoadConnectionSetting())
                    Application.Run(new NetworkSetting(SettingOptions.FirstTime, NetworkExceptionSide.Client));

            }
            catch (NetworkSideException e)
            {
                MessageBox.Show(e.Message);
                Application.Run(new NetworkSetting(SettingOptions.FirstTime, NetworkExceptionSide.Client));
            }
            Application.Run(new main());
            System.Diagnostics.Process[] pros = System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName, System.Diagnostics.Process.GetCurrentProcess().MachineName);
            foreach (System.Diagnostics.Process i in pros)
            {
                i.Kill();
            }
        }
    }
}
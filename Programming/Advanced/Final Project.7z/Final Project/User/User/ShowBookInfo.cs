﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    internal partial class ShowBookInfo : Form
    {
        internal ShowBookInfo(SearchResult.BookInfo Book)
        {
            InitializeComponent();
            Data.Rows.Add(new object[] { "Book's ID", Book.BookID });
            Data.Rows.Add(new object[] { "Book's Name", this.Text = Book.BookName });
            Data.Rows.Add(new object[] { "Writer's Name", Book.BookWriter });
            Data.Rows.Add(new object[] { "Publisher", Book.BookPublisher });
            Data.Rows.Add(new object[] { "Category", Book.Category });
            About.Text = Book.BookExplanation.Replace("\r\n", "\n");
            if (bool.Parse(Book.Availability))
            {
                Data.Rows.Add(new object[] { "Availblility", "Available" });
                Data.Rows[Data.Rows.Count - 1].DefaultCellStyle.BackColor=Color.Green;
            }
            else
            {
                Data.Rows.Add(new object[] { "Availblility", "Unavailable" });
                Data.Rows[Data.Rows.Count - 1].DefaultCellStyle.BackColor = Color.Red;
            }
        }
        public static void ShowInfo(SearchResult.BookInfo Book)
        {
            ShowBookInfo aForm = new ShowBookInfo(Book);
            aForm.Show();
        }
        private void ShowBookInfo_Deactivate(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ShowBookInfo_Load(object sender, EventArgs e)
        {
        }
    }
}

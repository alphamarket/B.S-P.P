﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
    class SearchResult
    {
        public struct BookInfo
        {
            public string BookID,
                BookName,
                BookWriter,
                BookPublisher,
                BookExplanation,
                Category,
                Availability;
            public BookInfo(List<string> Book)
            {
                BookID = Book[0];
                BookName = Book[1];
                BookWriter = Book[2];
                BookPublisher = Book[3];
                Category = Book[4];
                BookExplanation = Book[5];
                Availability = Book[6];
            }
        }
        public static void SaveResult(ControlPanel DataGrid, List<string> result)
        {
            List<BookInfo> TmpResult = new List<BookInfo>();
            List<string> tmp = new List<string>();
            int j = 6;
            for (int i = 0; i < result.Count; i++)
            {
                tmp.Add(result[i]);
                if (i == j )
                {
                    j += 7;
                    TmpResult.Add(new BookInfo(tmp));
                    tmp.Clear();
                }
            }
            switch (DataGrid)
            {
                case ControlPanel.DataGrid_1:
                    GlobalInfo.RecentSearch_1.Add(new DataGrid1(TmpResult));
                    break;
                case ControlPanel.DataGrid_2:
                    GlobalInfo.RecentSearch_3.Add(new DataGrid3(TmpResult));
                    break;
            }
        }
        public class DataGrid1
        {
            List<BookInfo> res;
            public DataGrid1(List<BookInfo> QueryResult)
            {
                res = QueryResult;
            }
            public BookInfo this[System.Windows.Forms.DataGridViewCell index]
            {
                get
                {
                    return res[index.RowIndex];
                }
            }
        }
        public class DataGrid3
        {
            List<BookInfo> res;
            public DataGrid3(List<BookInfo> QueryResult)
            {
                res = QueryResult;
            }
            public BookInfo this[int index]
            {
                get
                {
                    if (index > 1)
                        return res[index - 1];
                    return new BookInfo();
                }
            }
        }
    }
}
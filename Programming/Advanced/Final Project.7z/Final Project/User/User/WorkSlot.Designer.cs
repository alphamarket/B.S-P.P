﻿namespace Client
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46,
            treeNode47,
            treeNode48,
            treeNode49,
            treeNode50,
            treeNode51});
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode55,
            treeNode56});
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode58,
            treeNode59,
            treeNode60,
            treeNode61});
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode64 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode53,
            treeNode54,
            treeNode57,
            treeNode62,
            treeNode63});
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("Other");
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("All Book", new System.Windows.Forms.TreeNode[] {
            treeNode52,
            treeNode64,
            treeNode65});
            System.Windows.Forms.TreeNode treeNode67 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode68 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode69 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode70 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode71 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode72 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode73 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode74 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode67,
            treeNode68,
            treeNode69,
            treeNode70,
            treeNode71,
            treeNode72,
            treeNode73});
            System.Windows.Forms.TreeNode treeNode75 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode76 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode77 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode78 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode79 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode77,
            treeNode78});
            System.Windows.Forms.TreeNode treeNode80 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode81 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode82 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode83 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode84 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode80,
            treeNode81,
            treeNode82,
            treeNode83});
            System.Windows.Forms.TreeNode treeNode85 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode86 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode75,
            treeNode76,
            treeNode79,
            treeNode84,
            treeNode85});
            System.Windows.Forms.TreeNode treeNode87 = new System.Windows.Forms.TreeNode("Other");
            System.Windows.Forms.TreeNode treeNode88 = new System.Windows.Forms.TreeNode("All Book", new System.Windows.Forms.TreeNode[] {
            treeNode74,
            treeNode86,
            treeNode87});
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.networkSettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LogInPanel = new System.Windows.Forms.Panel();
            this.LogInGB = new System.Windows.Forms.GroupBox();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PassWordText = new System.Windows.Forms.TextBox();
            this.UserNameText = new System.Windows.Forms.TextBox();
            this.EnterBtn = new System.Windows.Forms.Button();
            this.MySlotPanel = new System.Windows.Forms.Panel();
            this.publicGB = new System.Windows.Forms.GroupBox();
            this.PublicMessage = new System.Windows.Forms.Label();
            this.ViewGB = new System.Windows.Forms.GroupBox();
            this.result = new System.Windows.Forms.Label();
            this.dwnldBtn = new System.Windows.Forms.Button();
            this.ClrDataLinkedLabel = new System.Windows.Forms.LinkLabel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.See1 = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.DataGrid_1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Writer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Publisher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PossibilityGB = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.VirtualSearch = new System.Windows.Forms.Button();
            this.uploadResult = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.uploadBtn = new System.Windows.Forms.Button();
            this.VirtualTree = new System.Windows.Forms.TreeView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.AllBookTV = new System.Windows.Forms.TreeView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.SearchNotificationLabel = new System.Windows.Forms.Label();
            this.SearchTypeCombo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SearchKeyText = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.VirtualUpload = new System.Windows.Forms.OpenFileDialog();
            this.VirtualDownLoad = new System.Windows.Forms.FolderBrowserDialog();
            this.shutDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.LogInPanel.SuspendLayout();
            this.LogInGB.SuspendLayout();
            this.MySlotPanel.SuspendLayout();
            this.publicGB.SuspendLayout();
            this.ViewGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid_1)).BeginInit();
            this.PossibilityGB.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.shutDownToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1713, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logOutToolStripMenuItem.Text = "&Logout";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.networkSettingToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.settingToolStripMenuItem.Text = "&Setting ";
            // 
            // networkSettingToolStripMenuItem
            // 
            this.networkSettingToolStripMenuItem.Name = "networkSettingToolStripMenuItem";
            this.networkSettingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.networkSettingToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.networkSettingToolStripMenuItem.Text = "&Network setting";
            this.networkSettingToolStripMenuItem.Click += new System.EventHandler(this.networkSettingToolStripMenuItem_Click);
            // 
            // LogInPanel
            // 
            this.LogInPanel.Controls.Add(this.LogInGB);
            this.LogInPanel.Location = new System.Drawing.Point(1365, 27);
            this.LogInPanel.Name = "LogInPanel";
            this.LogInPanel.Size = new System.Drawing.Size(317, 136);
            this.LogInPanel.TabIndex = 42;
            // 
            // LogInGB
            // 
            this.LogInGB.Controls.Add(this.CloseBtn);
            this.LogInGB.Controls.Add(this.label2);
            this.LogInGB.Controls.Add(this.label3);
            this.LogInGB.Controls.Add(this.PassWordText);
            this.LogInGB.Controls.Add(this.UserNameText);
            this.LogInGB.Controls.Add(this.EnterBtn);
            this.LogInGB.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInGB.Location = new System.Drawing.Point(3, 3);
            this.LogInGB.Name = "LogInGB";
            this.LogInGB.Size = new System.Drawing.Size(309, 127);
            this.LogInGB.TabIndex = 39;
            this.LogInGB.TabStop = false;
            this.LogInGB.Text = "Log in";
            // 
            // CloseBtn
            // 
            this.CloseBtn.Location = new System.Drawing.Point(185, 95);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(49, 23);
            this.CloseBtn.TabIndex = 6;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 14);
            this.label2.TabIndex = 12;
            this.label2.Text = "PassWord";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 14);
            this.label3.TabIndex = 11;
            this.label3.Text = "UserName";
            // 
            // PassWordText
            // 
            this.PassWordText.Location = new System.Drawing.Point(96, 52);
            this.PassWordText.Name = "PassWordText";
            this.PassWordText.Size = new System.Drawing.Size(192, 20);
            this.PassWordText.TabIndex = 2;
            this.PassWordText.UseSystemPasswordChar = true;
            this.PassWordText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PassWordText_KeyDown);
            // 
            // UserNameText
            // 
            this.UserNameText.Location = new System.Drawing.Point(96, 16);
            this.UserNameText.Name = "UserNameText";
            this.UserNameText.Size = new System.Drawing.Size(192, 20);
            this.UserNameText.TabIndex = 1;
            this.UserNameText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.UserNameText_KeyDown);
            // 
            // EnterBtn
            // 
            this.EnterBtn.Location = new System.Drawing.Point(240, 95);
            this.EnterBtn.Name = "EnterBtn";
            this.EnterBtn.Size = new System.Drawing.Size(48, 23);
            this.EnterBtn.TabIndex = 3;
            this.EnterBtn.Text = "Enter";
            this.EnterBtn.UseVisualStyleBackColor = true;
            this.EnterBtn.Click += new System.EventHandler(this.EnterBtn_Click);
            // 
            // MySlotPanel
            // 
            this.MySlotPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MySlotPanel.Controls.Add(this.publicGB);
            this.MySlotPanel.Controls.Add(this.ViewGB);
            this.MySlotPanel.Controls.Add(this.PossibilityGB);
            this.MySlotPanel.Location = new System.Drawing.Point(3, 30);
            this.MySlotPanel.Name = "MySlotPanel";
            this.MySlotPanel.Size = new System.Drawing.Size(1359, 824);
            this.MySlotPanel.TabIndex = 43;
            // 
            // publicGB
            // 
            this.publicGB.Controls.Add(this.PublicMessage);
            this.publicGB.Location = new System.Drawing.Point(11, 666);
            this.publicGB.Name = "publicGB";
            this.publicGB.Size = new System.Drawing.Size(1333, 155);
            this.publicGB.TabIndex = 39;
            this.publicGB.TabStop = false;
            this.publicGB.Text = "Public MessageGB";
            // 
            // PublicMessage
            // 
            this.PublicMessage.AutoSize = true;
            this.PublicMessage.Location = new System.Drawing.Point(24, 20);
            this.PublicMessage.Name = "PublicMessage";
            this.PublicMessage.Size = new System.Drawing.Size(203, 13);
            this.PublicMessage.TabIndex = 46;
            this.PublicMessage.Text = "No Public Message Has Been Released !";
            // 
            // ViewGB
            // 
            this.ViewGB.Controls.Add(this.result);
            this.ViewGB.Controls.Add(this.dwnldBtn);
            this.ViewGB.Controls.Add(this.ClrDataLinkedLabel);
            this.ViewGB.Controls.Add(this.groupBox6);
            this.ViewGB.Controls.Add(this.See1);
            this.ViewGB.Controls.Add(this.label5);
            this.ViewGB.Controls.Add(this.DataGrid_1);
            this.ViewGB.Location = new System.Drawing.Point(11, 335);
            this.ViewGB.Name = "ViewGB";
            this.ViewGB.Size = new System.Drawing.Size(1333, 325);
            this.ViewGB.TabIndex = 38;
            this.ViewGB.TabStop = false;
            this.ViewGB.Text = "Possibility";
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.ForeColor = System.Drawing.Color.DarkRed;
            this.result.Location = new System.Drawing.Point(322, 290);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(0, 13);
            this.result.TabIndex = 68;
            this.result.TextChanged += new System.EventHandler(this.result_TextChanged);
            // 
            // dwnldBtn
            // 
            this.dwnldBtn.Location = new System.Drawing.Point(83, 285);
            this.dwnldBtn.Name = "dwnldBtn";
            this.dwnldBtn.Size = new System.Drawing.Size(195, 23);
            this.dwnldBtn.TabIndex = 67;
            this.dwnldBtn.Text = "DownLoad Selected Books";
            this.dwnldBtn.UseVisualStyleBackColor = true;
            this.dwnldBtn.VisibleChanged += new System.EventHandler(this.dwnldBtn_VisibleChanged);
            this.dwnldBtn.Click += new System.EventHandler(this.dwnldBtn_Click);
            // 
            // ClrDataLinkedLabel
            // 
            this.ClrDataLinkedLabel.ActiveLinkColor = System.Drawing.Color.Blue;
            this.ClrDataLinkedLabel.AutoSize = true;
            this.ClrDataLinkedLabel.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.ClrDataLinkedLabel.Location = new System.Drawing.Point(1216, 290);
            this.ClrDataLinkedLabel.Name = "ClrDataLinkedLabel";
            this.ClrDataLinkedLabel.Size = new System.Drawing.Size(57, 13);
            this.ClrDataLinkedLabel.TabIndex = 46;
            this.ClrDataLinkedLabel.TabStop = true;
            this.ClrDataLinkedLabel.Text = "Clear Data";
            this.ClrDataLinkedLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ClrDataLinkedLabel_LinkClicked);
            // 
            // groupBox6
            // 
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox6.Location = new System.Drawing.Point(0, 331);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1333, 47);
            this.groupBox6.TabIndex = 39;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Public Message From Admin";
            // 
            // See1
            // 
            this.See1.ActiveLinkColor = System.Drawing.Color.Blue;
            this.See1.AutoSize = true;
            this.See1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.See1.Location = new System.Drawing.Point(80, 290);
            this.See1.Name = "See1";
            this.See1.Size = new System.Drawing.Size(86, 13);
            this.See1.TabIndex = 45;
            this.See1.TabStop = true;
            this.See1.Text = "See More Result";
            this.See1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.See1_LinkClicked);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 44;
            this.label5.Text = "Search Result :";
            // 
            // DataGrid_1
            // 
            this.DataGrid_1.AllowUserToAddRows = false;
            this.DataGrid_1.AllowUserToDeleteRows = false;
            this.DataGrid_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.BookID,
            this._Name,
            this.Writer,
            this.Publisher,
            this.Category});
            this.DataGrid_1.Location = new System.Drawing.Point(83, 39);
            this.DataGrid_1.Name = "DataGrid_1";
            this.DataGrid_1.ReadOnly = true;
            this.DataGrid_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGrid_1.Size = new System.Drawing.Size(1169, 240);
            this.DataGrid_1.TabIndex = 43;
            this.DataGrid_1.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DataGrid_1_RowsAdded);
            this.DataGrid_1.DoubleClick += new System.EventHandler(this.DataGrid_1_DoubleClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 75;
            // 
            // BookID
            // 
            this.BookID.HeaderText = "Book ID";
            this.BookID.Name = "BookID";
            this.BookID.ReadOnly = true;
            this.BookID.Width = 200;
            // 
            // _Name
            // 
            this._Name.HeaderText = "Name";
            this._Name.MinimumWidth = 100;
            this._Name.Name = "_Name";
            this._Name.ReadOnly = true;
            this._Name.Width = 250;
            // 
            // Writer
            // 
            this.Writer.HeaderText = "Writer";
            this.Writer.MinimumWidth = 100;
            this.Writer.Name = "Writer";
            this.Writer.ReadOnly = true;
            this.Writer.Width = 200;
            // 
            // Publisher
            // 
            this.Publisher.HeaderText = "Publisher";
            this.Publisher.MinimumWidth = 100;
            this.Publisher.Name = "Publisher";
            this.Publisher.ReadOnly = true;
            this.Publisher.Width = 200;
            // 
            // Category
            // 
            this.Category.HeaderText = "Category";
            this.Category.MinimumWidth = 100;
            this.Category.Name = "Category";
            this.Category.ReadOnly = true;
            this.Category.Width = 200;
            // 
            // PossibilityGB
            // 
            this.PossibilityGB.Controls.Add(this.groupBox1);
            this.PossibilityGB.Controls.Add(this.groupBox10);
            this.PossibilityGB.Controls.Add(this.groupBox4);
            this.PossibilityGB.Controls.Add(this.groupBox5);
            this.PossibilityGB.Location = new System.Drawing.Point(11, 4);
            this.PossibilityGB.Name = "PossibilityGB";
            this.PossibilityGB.Padding = new System.Windows.Forms.Padding(0);
            this.PossibilityGB.Size = new System.Drawing.Size(1333, 325);
            this.PossibilityGB.TabIndex = 14;
            this.PossibilityGB.TabStop = false;
            this.PossibilityGB.Text = "Possibility";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(983, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(319, 286);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "About";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(310, 156);
            this.label8.TabIndex = 1;
            this.label8.Text = resources.GetString("label8.Text");
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.VirtualSearch);
            this.groupBox10.Controls.Add(this.uploadResult);
            this.groupBox10.Controls.Add(this.label6);
            this.groupBox10.Controls.Add(this.CategoryCombo);
            this.groupBox10.Controls.Add(this.label4);
            this.groupBox10.Controls.Add(this.textBox1);
            this.groupBox10.Controls.Add(this.uploadBtn);
            this.groupBox10.Controls.Add(this.VirtualTree);
            this.groupBox10.Location = new System.Drawing.Point(528, 23);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(449, 287);
            this.groupBox10.TabIndex = 33;
            this.groupBox10.TabStop = false;
            this.groupBox10.Tag = "";
            this.groupBox10.Text = "All Book";
            // 
            // VirtualSearch
            // 
            this.VirtualSearch.Location = new System.Drawing.Point(148, 193);
            this.VirtualSearch.Name = "VirtualSearch";
            this.VirtualSearch.Size = new System.Drawing.Size(58, 23);
            this.VirtualSearch.TabIndex = 41;
            this.VirtualSearch.Text = "&Search";
            this.VirtualSearch.UseVisualStyleBackColor = true;
            this.VirtualSearch.Click += new System.EventHandler(this.VirtualSearch_Click);
            // 
            // uploadResult
            // 
            this.uploadResult.AutoSize = true;
            this.uploadResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.uploadResult.Location = new System.Drawing.Point(14, 228);
            this.uploadResult.Name = "uploadResult";
            this.uploadResult.Size = new System.Drawing.Size(0, 13);
            this.uploadResult.TabIndex = 66;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 65;
            this.label6.Text = "Select category:";
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(39, 161);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(167, 21);
            this.CategoryCombo.TabIndex = 64;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "Search Virtual Library :";
            // 
            // textBox1
            // 
            this.textBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox1.Location = new System.Drawing.Point(39, 99);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 20);
            this.textBox1.TabIndex = 34;
            // 
            // uploadBtn
            // 
            this.uploadBtn.Location = new System.Drawing.Point(6, 24);
            this.uploadBtn.Name = "uploadBtn";
            this.uploadBtn.Size = new System.Drawing.Size(133, 23);
            this.uploadBtn.TabIndex = 32;
            this.uploadBtn.Text = "Upload File(s)";
            this.uploadBtn.UseVisualStyleBackColor = true;
            this.uploadBtn.Click += new System.EventHandler(this.uploadBtn_Click);
            // 
            // VirtualTree
            // 
            this.VirtualTree.Location = new System.Drawing.Point(212, 26);
            this.VirtualTree.Name = "VirtualTree";
            treeNode45.Name = "Node17";
            treeNode45.Text = "Computer";
            treeNode46.Name = "Node18";
            treeNode46.Text = "Chemistry";
            treeNode47.Name = "Node19";
            treeNode47.Text = "Mechanic";
            treeNode48.Name = "Node20";
            treeNode48.Text = "Mine";
            treeNode49.Name = "Node21";
            treeNode49.Text = "Antitrust";
            treeNode50.Name = "Node22";
            treeNode50.Text = "Electricity";
            treeNode51.Name = "Node23";
            treeNode51.Text = "OtherEngineer";
            treeNode52.Name = "Node12";
            treeNode52.Text = "Engineer";
            treeNode53.Name = "Node24";
            treeNode53.Text = "Math";
            treeNode54.Name = "Node25";
            treeNode54.Text = "Physic";
            treeNode55.Name = "Node28";
            treeNode55.Text = "Poem";
            treeNode56.Name = "Node29";
            treeNode56.Text = "Prose";
            treeNode57.Name = "Node26";
            treeNode57.Text = "Literary";
            treeNode58.Name = "Node34";
            treeNode58.Text = "Turkish";
            treeNode59.Name = "Node30";
            treeNode59.Text = "Enghlish";
            treeNode60.Name = "Node31";
            treeNode60.Text = "Russian";
            treeNode61.Name = "Node32";
            treeNode61.Text = "Other Language";
            treeNode62.Name = "Node27";
            treeNode62.Text = "LanguageBook";
            treeNode63.Name = "Node33";
            treeNode63.Text = "Cult";
            treeNode64.Name = "Node14";
            treeNode64.Text = "Public";
            treeNode65.Name = "Node16";
            treeNode65.Text = "Other";
            treeNode66.Name = "Node11";
            treeNode66.Text = "All Book";
            this.VirtualTree.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode66});
            this.VirtualTree.Size = new System.Drawing.Size(213, 215);
            this.VirtualTree.TabIndex = 6;
            this.VirtualTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.VirtualView3_AfterSelect);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.linkLabel3);
            this.groupBox4.Controls.Add(this.AllBookTV);
            this.groupBox4.Location = new System.Drawing.Point(271, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(251, 288);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Tag = "";
            this.groupBox4.Text = "All Book";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel3.Location = new System.Drawing.Point(153, 229);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(53, 13);
            this.linkLabel3.TabIndex = 31;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "See More";
            // 
            // AllBookTV
            // 
            this.AllBookTV.Location = new System.Drawing.Point(17, 27);
            this.AllBookTV.Name = "AllBookTV";
            treeNode67.Name = "Node17";
            treeNode67.Text = "Computer";
            treeNode68.Name = "Node18";
            treeNode68.Text = "Chemistry";
            treeNode69.Name = "Node19";
            treeNode69.Text = "Mechanic";
            treeNode70.Name = "Node20";
            treeNode70.Text = "Mine";
            treeNode71.Name = "Node21";
            treeNode71.Text = "Antitrust";
            treeNode72.Name = "Node22";
            treeNode72.Text = "Electricity";
            treeNode73.Name = "Node23";
            treeNode73.Text = "OtherEngineer";
            treeNode74.Name = "Node12";
            treeNode74.Text = "Engineer";
            treeNode75.Name = "Node24";
            treeNode75.Text = "Math";
            treeNode76.Name = "Node25";
            treeNode76.Text = "Physic";
            treeNode77.Name = "Node28";
            treeNode77.Text = "Poem";
            treeNode78.Name = "Node29";
            treeNode78.Text = "Prose";
            treeNode79.Name = "Node26";
            treeNode79.Text = "Literary";
            treeNode80.Name = "Node34";
            treeNode80.Text = "Turkish";
            treeNode81.Name = "Node30";
            treeNode81.Text = "Enghlish";
            treeNode82.Name = "Node31";
            treeNode82.Text = "Russian";
            treeNode83.Name = "Node32";
            treeNode83.Text = "Other Language";
            treeNode84.Name = "Node27";
            treeNode84.Text = "LanguageBook";
            treeNode85.Name = "Node33";
            treeNode85.Text = "Cult";
            treeNode86.Name = "Node14";
            treeNode86.Text = "Public";
            treeNode87.Name = "Node16";
            treeNode87.Text = "Other";
            treeNode88.Name = "Node11";
            treeNode88.Text = "All Book";
            this.AllBookTV.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode88});
            this.AllBookTV.Size = new System.Drawing.Size(219, 181);
            this.AllBookTV.TabIndex = 6;
            this.AllBookTV.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect_1);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.SearchNotificationLabel);
            this.groupBox5.Controls.Add(this.SearchTypeCombo);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.SearchKeyText);
            this.groupBox5.Controls.Add(this.SearchBtn);
            this.groupBox5.Location = new System.Drawing.Point(8, 19);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(257, 288);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quick Search";
            // 
            // SearchNotificationLabel
            // 
            this.SearchNotificationLabel.AutoSize = true;
            this.SearchNotificationLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.SearchNotificationLabel.Location = new System.Drawing.Point(16, 197);
            this.SearchNotificationLabel.Name = "SearchNotificationLabel";
            this.SearchNotificationLabel.Size = new System.Drawing.Size(181, 13);
            this.SearchNotificationLabel.TabIndex = 40;
            this.SearchNotificationLabel.Text = "No Search Have Been Launched ...!";
            this.SearchNotificationLabel.TextChanged += new System.EventHandler(this.SearchNotificationLabel_TextChanged);
            // 
            // SearchTypeCombo
            // 
            this.SearchTypeCombo.FormattingEnabled = true;
            this.SearchTypeCombo.Items.AddRange(new object[] {
            "Name Book",
            "Writer",
            "Publisher",
            "Key Word",
            "ById"});
            this.SearchTypeCombo.Location = new System.Drawing.Point(73, 126);
            this.SearchTypeCombo.Name = "SearchTypeCombo";
            this.SearchTypeCombo.Size = new System.Drawing.Size(167, 21);
            this.SearchTypeCombo.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Search Type :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Search Key :";
            // 
            // SearchKeyText
            // 
            this.SearchKeyText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.SearchKeyText.Location = new System.Drawing.Point(73, 51);
            this.SearchKeyText.Name = "SearchKeyText";
            this.SearchKeyText.Size = new System.Drawing.Size(167, 20);
            this.SearchKeyText.TabIndex = 21;
            this.SearchKeyText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchKeyText_KeyDown);
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(182, 163);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(58, 23);
            this.SearchBtn.TabIndex = 19;
            this.SearchBtn.Text = "&Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // VirtualUpload
            // 
            this.VirtualUpload.FileName = "openFileDialog1";
            this.VirtualUpload.Filter = "PDF|*.pdf|Book|*.chm|Word Document|*.docx,*.doc|Simple web file|*.mht|Power Point" +
                "|*.ppt";
            this.VirtualUpload.Multiselect = true;
            // 
            // shutDownToolStripMenuItem
            // 
            this.shutDownToolStripMenuItem.Name = "shutDownToolStripMenuItem";
            this.shutDownToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.shutDownToolStripMenuItem.Text = "S&hutdown";
            this.shutDownToolStripMenuItem.Click += new System.EventHandler(this.shutDownToolStripMenuItem_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1713, 866);
            this.Controls.Add(this.LogInPanel);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.MySlotPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WorkSlot";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WorkSlot_FormClosing);
            this.Load += new System.EventHandler(this.WorkSlot_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.LogInPanel.ResumeLayout(false);
            this.LogInGB.ResumeLayout(false);
            this.LogInGB.PerformLayout();
            this.MySlotPanel.ResumeLayout(false);
            this.publicGB.ResumeLayout(false);
            this.publicGB.PerformLayout();
            this.ViewGB.ResumeLayout(false);
            this.ViewGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid_1)).EndInit();
            this.PossibilityGB.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem networkSettingToolStripMenuItem;
        private System.Windows.Forms.Panel LogInPanel;
        private System.Windows.Forms.GroupBox LogInGB;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PassWordText;
        private System.Windows.Forms.TextBox UserNameText;
        private System.Windows.Forms.Button EnterBtn;
        private System.Windows.Forms.Panel MySlotPanel;
        private System.Windows.Forms.GroupBox PossibilityGB;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TreeView VirtualTree;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.TreeView AllBookTV;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label SearchNotificationLabel;
        private System.Windows.Forms.ComboBox SearchTypeCombo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox SearchKeyText;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.GroupBox ViewGB;
        private System.Windows.Forms.LinkLabel See1;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.DataGridView DataGrid_1;
        private System.Windows.Forms.GroupBox publicGB;
        public System.Windows.Forms.Label PublicMessage;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.LinkLabel ClrDataLinkedLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookID;
        private System.Windows.Forms.DataGridViewTextBoxColumn _Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Writer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Publisher;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button uploadBtn;
        private System.Windows.Forms.OpenFileDialog VirtualUpload;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.Label uploadResult;
        private System.Windows.Forms.FolderBrowserDialog VirtualDownLoad;
        private System.Windows.Forms.Button dwnldBtn;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button VirtualSearch;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shutDownToolStripMenuItem;
    }
}
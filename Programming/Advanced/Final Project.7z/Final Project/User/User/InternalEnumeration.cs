﻿namespace InternalEnumeration
{
    enum Status { Login, Logout }
}
namespace Client
{
    class TempData
    {
        internal InternalEnumeration.Status status;
        internal System.Windows.Forms.Panel panel;
        public TempData(System.Windows.Forms.Panel Form, InternalEnumeration.Status status)
        {
            this.status = status;
            panel = Form;
        }
    }
}
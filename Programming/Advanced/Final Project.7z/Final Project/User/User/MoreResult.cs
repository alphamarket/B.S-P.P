﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    internal partial class MoreResult : Form
    {
        public MoreResult()
        {
            InitializeComponent();
            if (GlobalInfo.Globals[ControlPanel.DataGrid_2] == null)
                GlobalInfo.Globals.Add(ControlPanel.DataGrid_2, DataGrid_3);
            Communication.ConnectionInfo.StaticConnectionInfo.ClientConnetionRoot.SendData(GlobalInfo.LastSearch, Communication.Protocol.ClientSendQueryType.SearchBook,
                (Search.InternalEnumeration.SortType)GlobalInfo.LastComboBoxSelectedIndex + 1, Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle);
        }

        void SearchPanelResize(LinkLabel Limit)
        {
            SearchGB.Size = new Size(SearchGB.Size.Width, Limit.Location.Y + 20);
            SearchPanel.Size = new Size(SearchPanel.Size.Width, SearchGB.Size.Height + 10);
            ClientSize = new Size(new Point(SearchPanel.Size.Width, SearchPanel.Size.Height));
        }
        private void Less3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void MoreResult_Load(object sender, EventArgs e)
        {
        }

        private void DataGrid_3_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            result.Text = DataGrid_3.RowCount + " result have found!";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Connection
{
    class ClientConnection : Communication.Connection.ClientConnection
    {
        public ClientConnection(System.Net.IPEndPoint IPE, ToolStripStatusLabel TS)
            : base(IPE, TS)
        {
        }
        delegate void SetDataGridView(List<string> str);
        void DataGrid(List<string> str)
        {
            DataGridView Grid = new DataGridView();
            try
            {
                switch (Search.Search.getBookSearchResult())
                {
                    case Search.InternalEnumeration.ResultSearchBook.SimilerThisWord:
                        Grid = (DataGridView)GlobalInfo.Globals[ControlPanel.DataGrid_1];
                        Client.SearchResult.SaveResult(ControlPanel.DataGrid_1, str);
                        break;
                    case Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle:
                        Grid = (DataGridView)GlobalInfo.Globals[ControlPanel.DataGrid_2];
                        Client.SearchResult.SaveResult(ControlPanel.DataGrid_2, str);
                        break;
                }
            }
            catch { }
            if (Grid.InvokeRequired)
            {
                Grid.Invoke(new SetDataGridView(DataGrid), new object[] { str });
                Settext(Grid.Rows.Count + " Results Have Been Found ...", (Label)GlobalInfo.Globals[ControlPanel.SearchResultCountLabel]);
            }
            else
            {
                Sundries.DataGridViewSetting.InitializeDataGrid(str, ref Grid);
                Client.main.SetDataGridTo(Sundries.DataGridViewSetting.DataGridEnum.OnlineDataGrid, ref Grid);
            }
        }
        delegate void ClearDataGridView(ref DataGridView DG);
        public static void ClearDataGrid(ref DataGridView DG)
        {
            if (DG != null)
                if (DG.InvokeRequired)
                    DG.Invoke(new ClearDataGridView(ClearDataGrid), new object[] { DG });
                else
                {
                    Client.main.SetDataGridTo(Sundries.DataGridViewSetting.DataGridEnum.OnlineDataGrid, ref DG);
                    DG.Rows.Clear();
                }
        }
        delegate void Text(string text, Label label);
        void Settext(string text, Label label)
        {
            if (label.InvokeRequired)
                label.Invoke(new Text(Settext), new object[] { text, label });
            else
            {
                label.Text = text;
                if (label == GlobalInfo.Globals[ControlPanel.PublicMessageLabel])
                {
                    if (((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Height == 55)
                    {
                        ((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Size = new System.Drawing.Size(((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Size.Width, ((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Size.Height + 100);
                        ((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Parent.Size = new System.Drawing.Size(((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Parent.Size.Width, ((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Parent.Parent.Size.Height + 100);
                    }
                }
            }
        }
        protected override void ReceiveData()
        {
            Monitor.Enter(this);
            List<string> Qres = new List<string>();
            while (true)
            {
                try
                {
                    data = new byte[1024];
                    string response;
                    int recv = CurrentConnectionSocket.Receive(data);
                    if (base.CheckInfiniteRecive(response = Encoding.ASCII.GetString(data, 0, recv)))
                    {
                        Communication.Protocol.LPS.IsKeyWord(response, this);
                        //
                        //TODO: DO what ever needed to receive and handling client received responds from server
                        //
                        switch (Communication.Protocol.LPS.WhatIsServerQuery(ref response, ref Qres))
                        {
                            case Communication.Protocol.ServerSendQueryType.EndOfQueryOfBSR:// EndOfQueryOfBSR == Last index of book search query result
                                DataGrid(Qres);
                                //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                //    MessageBox.Show(Qres[i]);
                                //
                                //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                //
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.EndOfQueryOfMJR:// EndOfQueryOfMJR == last index of member join query result
                                //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                //    MessageBox.Show(Qres[i]);
                                //
                                //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                //
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.EndOfQueryOfMSR:// EndOfQueryOfMSR == last index of member search result where it will give user(s) info or a hash code of its password or "null" if there is not exist such user
                                //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                //    MessageBox.Show(Qres[i]);
                                //
                                //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                //
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.PublicMessageBody:
                                Settext(Qres[0] + "\r\n\r\n    " + response, (Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]);
                                System.IO.FileStream fs = new System.IO.FileStream(Application.StartupPath + @"\Files\DataBase\pblc.mes", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
                                System.IO.StreamWriter writer = new System.IO.StreamWriter(fs);
                                writer.WriteLine(((Label)GlobalInfo.Globals[ControlPanel.PublicMessageLabel]).Text);
                                writer.Flush();
                                writer.Close();
                                fs.Close();
                                //MessageBox.Show(response, Qres[0], MessageBoxButtons.OK, MessageBoxIcon.Information);//<!-- THIS IS JUST AN EXAMPLE, TO SHOW HOW TO HANDLE MESSAGES -->
                                //
                                //TODO: public message body which received from server will handleat this part of switch
                                //
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.PrivateMessageBody:
                                //MessageBox.Show(response, Qres[0], MessageBoxButtons.OK, MessageBoxIcon.Information);//<!-- THIS IS JUST AN EXAMPLE, TO SHOW HOW TO HANDLE MESSAGES -->
                                //
                                //TODO: private message body which received from server will be handled here!
                                //
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.EndOfQueryOfTSR:
                                Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord);
                                DataGrid(Qres);
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.Login://this will check entered user-name and password
                                if (Convert.ToBoolean(response) && !GlobalInfo.IsLoggedIn)
                                {
                                    GlobalInfo.ChangeForm(InternalEnumeration.Status.Login);
                                }
                                else
                                {
                                    Sundries.MessageBox.ShowMessage("The provided username or password is wrong!");
                                }
                                Qres.Clear();
                                break;
                            case Communication.Protocol.ServerSendQueryType.NotFound:
                                DataGridView Grid1 = (DataGridView)GlobalInfo.Globals[ControlPanel.DataGrid_1];
                                DataGridView Grid3 = (DataGridView)GlobalInfo.Globals[ControlPanel.DataGrid_2];
                                ClearDataGrid(ref Grid1);
                                ClearDataGrid(ref Grid3);
                                Settext("0 Result Has Been Found ...", (Label)GlobalInfo.Globals[ControlPanel.SearchResultCountLabel]);
                                Sundries.MessageBox.ShowMessage("The search has not found in our database!");
                                break;
                            case Communication.Protocol.ServerSendQueryType.Unknown://this is for internal programming bug reporter if any thing went wrong we will be noticed by this part of switch(this is just for precaution, a fuction handled this:D)
                                break;
                        }
                        //
                        //TODO: handle anything else beyond that switch/case 'bout Qres list
                        //
                    }
                }
                catch (Communication.InternalNetworkException ine)
                {
                    switch (ine.NetworkSide)
                    {
                        case Communication.NetworkExceptionSide.Client:
                            MessageBox.Show(ine.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CurrentConnectionSocket.Close();
                            Application.Exit();
                            break;
                    }
                    break;
                }
                catch (System.Net.Sockets.SocketException)
                {
                    Sundries.MessageBox.ShowMessage("Server has shutted down all his transactions with this client!!\r\nThe appliction will close ...");
                    System.Diagnostics.Process[] pros = System.Diagnostics.Process.GetProcessesByName(System.Diagnostics.Process.GetCurrentProcess().ProcessName, System.Diagnostics.Process.GetCurrentProcess().MachineName);
                    foreach (System.Diagnostics.Process i in pros)
                    {
                        i.Kill();
                    }
                }
                catch (ObjectDisposedException) { }
                catch (Exception)
                {
                    //TODO: Log the Exception Message ....
                }
            }
            CurrentConnectionSocket.Close();
            return;
        }
    }
}
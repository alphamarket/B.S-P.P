﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Client
{
    class VirtualLibrary
    {
        public static void ShowVirtualLibrary(string path, ref DataGridView DataGrid_1, string Category)
        {
            path = Application.StartupPath + @"\Files\DataBase\Virtual Library\All Book\" + path;
            main.SetDataGridTo(Sundries.DataGridViewSetting.DataGridEnum.VirtualDataGrid, ref DataGrid_1);

            try
            {
                DirectoryInfo di = new DirectoryInfo(path);
                FileInfo[] theFiles = di.GetFiles();
                int count = 0;
                foreach (FileInfo theFile in theFiles)
                {
                    DataGrid_1.Rows.Add(new object[] { ++count,null, theFile.Name,null,null, Category });
                }
            }
            catch { }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Tree
{
    class ShowFileinListView
    {
        public static void AddFile(string spath, ListBox lview)
        {
            lview.Items.Clear();
            try
            {
                DirectoryInfo di = new DirectoryInfo(spath);
                FileInfo[] theFiles = di.GetFiles();
                foreach (FileInfo theFile in theFiles)
                {
                    lview.Items.Add(theFile.Name);
                }
            }
            catch { }
        }
    }
}

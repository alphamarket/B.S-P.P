﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Communication
{
    namespace Protocol
    {
        public enum ClientSendQueryType { SearchMember, SearchBook, JoinMember, Unknown }
        public enum ServerSendQueryType { MemberSearchResult, BookSearchResult, MemberJoinResult, Unknown, EndOfQueryOfMSR, EndOfQueryOfBSR, EndOfQueryOfMJR, PrivateMessage, PublicMessage }
        internal class LPS
        {
            internal static ClientSendQueryType WhatISClientQuery(ref string query)
            {
                if (query.Contains("u:") || query.Contains("U:"))
                {
                    query.Remove(0, 2);
                    return ClientSendQueryType.SearchMember;
                }
                else if (query.Contains("b:") || query.Contains("B:"))
                {
                    query.Remove(0, 2);
                    return ClientSendQueryType.SearchBook;
                }
                else if (query.Contains("j:") || query.Contains("J:"))
                {
                    query.Remove(0, 2);
                    return ClientSendQueryType.JoinMember;
                }
                return ClientSendQueryType.Unknown;
            }

            internal static ServerSendQueryType WhatIsServerQuery(ref string query)
            {
                if (query.Contains("msr:") || query.Contains("MSR:"))
                {
                    query.Remove(0, 4);
                    return ServerSendQueryType.MemberSearchResult;
                }
                else if (query.Contains("bsr:") || query.Contains("BSR"))
                {
                    query.Remove(0, 4);
                    return ServerSendQueryType.BookSearchResult;
                }
                else if (query.Contains("mjr:") || query.Contains("MJR:"))
                {
                    query.Remove(0, 4);
                    return ServerSendQueryType.MemberJoinResult;
                }
                else if (query.Contains("emjr:") || query.Contains("EMJR:"))
                {
                    query.Remove(0, 5);
                    return ServerSendQueryType.EndOfQueryOfMJR;
                }
                else if (query.Contains("emsr:") || query.Contains("EMSR"))
                {
                    query.Remove(0, 5);
                    return ServerSendQueryType.EndOfQueryOfMSR;
                }
                else if (query.Contains("ebsr:") || query.Contains("EBSR:"))
                {
                    query.Remove(0, 5);
                    return ServerSendQueryType.EndOfQueryOfBSR;
                }
                else if (query.Contains("prm:") || query.Contains("PRM:"))
                {
                    query.Remove(0, 4);
                    return ServerSendQueryType.PrivateMessage;
                }
                else if (query.Contains("pum:") || query.Contains("PUM:"))
                {
                    query.Remove(0, 4);
                    return ServerSendQueryType.PublicMessage;
                }
                return ServerSendQueryType.Unknown;
            }

            internal static void SetClientSendProtocol(ref string query, ClientSendQueryType QT)
            {
                switch (QT)
                {
                    case ClientSendQueryType.JoinMember:
                        query = "j:" + query;
                        break;
                    case ClientSendQueryType.SearchBook:
                        query = "b:" + query;
                        break;
                    case ClientSendQueryType.SearchMember:
                        query = "u:" + query;
                        break;
                    case ClientSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set CLIENT send protocol!, it's end up with UNKNOW type!!", 
                            Query.QueryExceptionType.ClientSendQueryType, ClientSendQueryType.Unknown);
                }
            }

            internal static void SetServerSendProtocol(ref string query, ServerSendQueryType QT)
            {
                switch (QT)
                {
                    case ServerSendQueryType.BookSearchResult:
                        query = "bsr:" + query;
                        break;
                    case ServerSendQueryType.MemberJoinResult:
                        query = "mjr:" + query;
                        break;
                    case ServerSendQueryType.MemberSearchResult:
                        query = "msr:" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfMSR:
                        query = "emsr:" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfBSR:
                        query = "ebsr:" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfMJR:
                        query = "emjr:" + query;
                        break;
                    case ServerSendQueryType.PrivateMessage:
                        query = "prm:" + query;
                        break;
                    case ServerSendQueryType.PublicMessage:
                        query = "pum:" + query;
                        break;
                    case ServerSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set SERVER send protocol!, it's end up with UNKNOW type!!", Query.QueryExceptionType.ServerSendQueryType, ServerSendQueryType.Unknown);
                }
            }

            internal static ServerSendQueryType GetEndOFQuery(ServerSendQueryType QT)
            {
                switch (QT)
                {
                    case ServerSendQueryType.BookSearchResult: return ServerSendQueryType.EndOfQueryOfBSR;
                    case ServerSendQueryType.MemberJoinResult: return ServerSendQueryType.EndOfQueryOfMJR;
                    case ServerSendQueryType.MemberSearchResult: return ServerSendQueryType.EndOfQueryOfMSR;
                }
                return ServerSendQueryType.Unknown;
            }
            public static bool IsKeyWord(string str, Connection.Connection con)
            {
                try
                {
                    switch (str)
                    {
                        case "END_CON":
                            con.ConnectionStatusString = "receive end-connection protocol ......";
                            Thread.Sleep(10);
                            con.CurrentConnectionSocket.Close();
                            con.ConnectionStatusString = "Network disconnected ......";
                            switch (con is Connection.ClientConnection)
                            {
                                case true:
                                    throw new InternalNetworkException("The server-side program has just been shutted down!", NetworkExceptionSide.Client);
                                case false:
                                    throw new InternalNetworkException("Client-side of this program has just closed!!", NetworkExceptionSide.Server);
                            }
                            return true;
                        case "CON_CON":
                            con.SendData("CON_CON1");
                            return true;
                        case "CON_CON1":
                            return con.isConnected = true;
                    }
                    return false;
                }
                catch (SocketException) { return true; }
            }
        }
    }
}
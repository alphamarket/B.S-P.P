﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using Communication.Protocol;
using System.Windows.Forms;//THIS WILL BE DELETED AFTER MAKING SURE OF GETTYPE OF QUERYEXCEPTION CLASS WORKS!!!!
namespace Communication
{
    namespace Data
    {
        public class FeedBack
        {
            //List<string> FdBckList;
            public FeedBack(List<string> Qres, ref Connection.Connection sock, ServerSendQueryType QT)//Send FeedBack information of do_query!!
            {
                try
                {
                    for (int i = 0; i < Qres.Count; i++)
                    {
                        string tmp = Qres[i];
                        LPS.SetServerSendProtocol(ref tmp, i == Qres.Count - 1 ? LPS.GetEndOFQuery(QT) : QT);
                        sock.SendData(tmp);
                    }
                }
                catch (Query.QueryException e)
                {
                    MessageBox.Show(e.Message + " query type : " + e.GetEnum);//THIS WILL BE COME THE """throw e;"""
                }
            }
            public FeedBack(string str, ref Connection.Connection sock, ServerSendQueryType QT)
            {
                LPS.SetServerSendProtocol(ref str, QT);
                sock.SendData(str);
            }
        }
    }
}

﻿using System;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;
using Query;
namespace Communication
{
    namespace Connection
    {
        public class ServerConnection : Connection
        {
            ~ServerConnection()
            {
                root = null;
            }
            private ToolStripStatusLabel NetStatus;
            private Thread thrd;
            public delegate void DisconnectFuction(Object sender, EventArgs e);
            public delegate void ConnectFuction(Object sender, EventArgs e);
            DisconnectFuction DC;
            ConnectFuction CON;

            public override IPEndPoint JoinedIPEndPoint
            {
                get { return JoinedClientIPEP; }
            }
            public override string ConnectionStatusString
            {
                set
                {
                    if (!Protocol.LPS.IsKeyWord(value, this))
                    {
                        NetStatus.Text = value;
                        conStatString = value;
                    }
                }
                get
                {
                    return conStatString;
                }
            }

            public override IPEndPoint ConnetionIPEP
            {
                get
                {
                    return thisIPEP;
                }
                set
                {
                    thisIPEP = value;
                }
            }

            public override Socket CurrentConnectionSocket
            {
                set
                {
                    root = value;
                }
                get
                {
                    return root;
                }
            }

            public override bool IsConnected
            {
                get
                {
                    try
                    {
                        isConnected = false;
                        SendData("CON_CON");
                        Thread.Sleep(10);
                        if (!isConnected)
                            NetStatus.Text = "Network disconnected......";
                        return isConnected;
                    }
                    catch (SocketException) { return isConnected = false; }
                }
            }

            public override bool ShutDown
            {
                get
                {
                    if (CurrentConnectionSocket != null)
                    {
                        if (IsConnected)
                        {
                            SendData("END_CON");
                            Thread.Sleep(10);
                            return shuttingDown = IsConnected;
                        }
                        else
                        {
                            if (thrd != null)
                                thrd.Abort();
                            CurrentConnectionSocket.Close();
                            CurrentConnectionSocket = null;
                            NetStatus.Text = "Network connetion has just shutted down!";
                            return shuttingDown = true;
                        }
                    }
                    else
                        return shuttingDown = true;
                }
            }

            private void AcceptCon_SYNC(IAsyncResult iar)
            {
                try
                {
                    CurrentConnectionSocket = ((Socket)iar.AsyncState).EndAccept(iar);
                    ConnectionStatusString = "Connection has been made from " + (JoinedClientIPEP = (IPEndPoint)CurrentConnectionSocket.RemoteEndPoint).ToString();
                    thrd = new Thread(new ThreadStart(ReceiveData));
                    thrd.Start();
                }
                catch (ObjectDisposedException) { }
            }
            /// <summary>
            /// Create TCP, Internet, Stream Connetion and begin to recive any entery data.
            /// </summary>
            /// <param name="ipep">An IPEndPoint object to connection</param>
            /// <param name="netstatue">An ToolStripStatusLabel object for which show network status change.</param>
            public ServerConnection(IPEndPoint ipep, ToolStripStatusLabel netstatue, DisconnectFuction DC, ConnectFuction CN)
            {
                try
                {
                    NetStatus = netstatue;
                    this.DC = DC;
                    this.CON = CN;
                    CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    CurrentConnectionSocket.Bind(ConnetionIPEP = ipep);
                    CurrentConnectionSocket.Listen(1);
                    ConnectionStatusString = "Waitting for client connection  ....";
                    CurrentConnectionSocket.NoDelay = true;
                    CurrentConnectionSocket.BeginAccept(new AsyncCallback(AcceptCon_SYNC), CurrentConnectionSocket);

                }
                catch (SocketException) { }
            }

            public ServerConnection(String ip, int port, ToolStripStatusLabel netstatus)
            {
                try
                {
                    NetStatus = netstatus;
                    CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    CurrentConnectionSocket.Bind(new IPEndPoint(IPAddress.Parse(ip), port));
                    CurrentConnectionSocket.Listen(1);
                    ConnectionStatusString = "Waitting for clien connection  ....";
                    CurrentConnectionSocket.NoDelay = true;
                    CurrentConnectionSocket.BeginAccept(new AsyncCallback(AcceptCon_SYNC), CurrentConnectionSocket);
                }
                catch (SocketException) { }
            }

            public void SendData(string query, Protocol.ServerSendQueryType QT)//client side of this program will use this kind of SendData fuction, it's very critical!!!!!!!
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        Protocol.LPS.SetServerSendProtocol(ref query, QT);
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have not set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
            }

            protected void ReceiveData()
            {
                try
                {
                    while (true)
                    {
                        data = new byte[1024];
                        string query;
                        int recv = CurrentConnectionSocket.Receive(data);
                        switch (Protocol.LPS.IsKeyWord(query = Encoding.ASCII.GetString(data, 0, recv), this))
                        {
                            case false:
                                if (!string.IsNullOrEmpty(query))
                                    new Query.DoQuery(Protocol.LPS.WhatISClientQuery(ref query), query.Split(new string[] { ", ", " , ", "," }, StringSplitOptions.RemoveEmptyEntries), this);
                                break;
                        }
                        if (query == "END_CON")
                            break;
                    }
                    CurrentConnectionSocket.Close();
                    return;
                }
                catch (InternalNetworkException ine)
                {
                    switch (ine.NetworkSide)
                    {
                        case NetworkExceptionSide.Server:
                            MessageBox.Show(ine.Message);
                            DC(new object(), new EventArgs());
                            break;
                    }
                }
                catch (SocketException) { }
                catch (Exception e)
                {
                    //MessageBox.Show(e.Message);
                }
            }
        }
    }
}
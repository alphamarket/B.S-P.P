﻿using System;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;

namespace Communication
{
    namespace Connection
    {
        public abstract class Connection
        {
            protected Socket root;
            
            protected IPEndPoint thisIPEP, JoinedClientIPEP;
            
            protected string conStatString;
            
            protected byte[] data;
            
            internal bool isConnected, shuttingDown;

            abstract public IPEndPoint JoinedIPEndPoint
            {
                get;
            }
            
            abstract public bool IsConnected
            {
                get;
            }
            
            abstract public string ConnectionStatusString
            {
                set;
                get;
            }
            
            abstract public IPEndPoint ConnetionIPEP
            {
                get;
                set;
            }
            
            abstract public Socket CurrentConnectionSocket
            {
                set;
                get;
            }

            abstract public bool ShutDown
            {
                get;
            }
            protected virtual void SendData_SYNC(IAsyncResult iar)
            {
                try
                {
                    CurrentConnectionSocket = (Socket)iar.AsyncState;
                    CurrentConnectionSocket.EndSend(iar);
                }
                catch (ObjectDisposedException) { }
                catch (SocketException) { }
            }

            public virtual void SendData(string query)
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have not set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
            }
        }
    }
}
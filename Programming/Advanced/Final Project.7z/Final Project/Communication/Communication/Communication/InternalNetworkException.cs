﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Communication
{
    internal enum NetworkExceptionSide{Client, Server}
    internal class InternalNetworkException : Exception
    {
        string message;
        NetworkExceptionSide ntwrkExptionSid;
        internal InternalNetworkException(string passage, NetworkExceptionSide NS)
        {
            message = passage;
            ntwrkExptionSid = NS;
        }
        public override String Message
        {
            get
            {
                return message;
            }
        }
        internal NetworkExceptionSide NetworkSide
        {
            get
            {
                return ntwrkExptionSid;
            }
        }
    }
}

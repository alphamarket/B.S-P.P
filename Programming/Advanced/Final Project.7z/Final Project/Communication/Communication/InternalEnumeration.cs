﻿namespace Communication
{
    public enum MessageType { Private, Public }
    public enum Boolean { True, False }
    namespace Connection
    {
        public enum ConnectionMode { Connected, Disconnected, Listenning, NotSetted }
    }
    namespace Setting
    {
        public enum SettingSideOption { Client, Server }
        public enum DefaultSetting { LocalHost, AcceptAnyConnection }
        public enum SettingOptions { FirstTime, NotFirstTime }
    }
    namespace Protocol
    {
        public enum ClientSendQueryType { SearchMember, SearchBook, JoinMember, AddBook, Login, Logout, TreeSearch, CheckAdmin, SearchBorrower, EditBookslist, EditBorrowersList, EditUserAndPass, EditMembersList, Unknown }
        //public enum ClientSendQueryType { SearchMember, SearchBook, JoinMember, AddBook, Login, Logout, TreeSearch, RemoveBook, RemoveMember, Unknown }
        public enum ServerSendQueryType
        {
            Login, Logout, MemberSearchResult, BookSearchResult, MemberJoinResult, Unknown, EndOfQueryOfMSR, EndOfQueryOfBSR, TreeSearchResult, EndOfQueryOfTSR,
            EndOfQueryOfMJR, PrivateMessageBody, PublicMessageBody, PublicMessageTitle, PrivateMessageTitle, NotFound
        }
    }
    namespace Protocol
    {
        public enum MessageContextType { Body, Title, Unknown }
    }
}
﻿using System.Net.Sockets;
using System.Threading;

namespace Communication
{
    namespace Protocol
    {
        public class LPS
        {
            static ClientSendQueryType ForFeedBack = ClientSendQueryType.Unknown;
            public static ClientSendQueryType WhatISClientQuery()
            {
                return ForFeedBack;
            }
            public static ServerSendQueryType WhatIsServerSendType()
            {
                switch (ForFeedBack)
                {
                    case ClientSendQueryType.Login:
                        return ServerSendQueryType.Login;
                    case ClientSendQueryType.SearchBook:
                        return ServerSendQueryType.BookSearchResult;
                    case ClientSendQueryType.SearchMember:
                        return ServerSendQueryType.MemberSearchResult;
                    case ClientSendQueryType.JoinMember:
                        return ServerSendQueryType.MemberJoinResult;
                    case ClientSendQueryType.TreeSearch:
                        return ServerSendQueryType.TreeSearchResult;
                    case ClientSendQueryType.AddBook:
                        break;
                }
                ForFeedBack = ClientSendQueryType.Unknown;
                return ServerSendQueryType.Unknown;
            }
            public static void WhatISClientQuery(ref string query)
            {
                if (query.Contains("<login:>"))
                {
                    query = query.Remove(0, 8);
                    ForFeedBack = ClientSendQueryType.Login;
                    return;
                }
                else if (query.Contains("<Logout:>"))
                {
                    ForFeedBack = ClientSendQueryType.Logout;
                    query = "";
                    return;
                }
                else if (query.Contains("<u:>"))
                {
                    query = query.Remove(0, 4);
                    ForFeedBack = ClientSendQueryType.SearchMember;
                    return;
                }
                else if (query.Contains("<tree:>"))
                {
                    query = query.Remove(0, 7);
                    ForFeedBack = ClientSendQueryType.TreeSearch;
                    return;
                }
                else if (query.Contains("<b:>"))
                {
                    query = query.Remove(0, 4);

                    ///<Summary>
                    ///SET TYPE OF SEARCH SORTING
                    ///</Summary>

                    if (query.Contains("<BK:>"))
                    {
                        query = query.Remove(0, 5);
                        Search.Search.SetTypeofRank(Search.InternalEnumeration.SortType.ByKeyword);
                    }
                    else if (query.Contains("<BN:>"))
                    {
                        query = query.Remove(0, 5);
                        Search.Search.SetTypeofRank(Search.InternalEnumeration.SortType.ByName);
                    }
                    else if (query.Contains("<BW:>"))
                    {
                        query = query.Remove(0, 5);
                        Search.Search.SetTypeofRank(Search.InternalEnumeration.SortType.ByWritter);
                    }
                    else if (query.Contains("<BP:>"))
                    {
                        query = query.Remove(0, 5);
                        Search.Search.SetTypeofRank(Search.InternalEnumeration.SortType.ByPublisher);
                    }
                    else if (query.Contains("<BID:>"))
                    {
                        query = query.Remove(0, 6);
                        Search.Search.SetTypeofRank(Search.InternalEnumeration.SortType.ByID);
                    }

                    ///SEARCH WORD TYPE

                    if (query.Contains("<ATW:>"))
                    {
                        query = query.Remove(0, 6);
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.AloneThisWord);
                    }
                    else if (query.Contains("<STW:>"))
                    {
                        query = query.Remove(0, 6);
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord);
                    }
                    else if (query.Contains("<TWT:>"))
                    {
                        query = query.Remove(0, 6);
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle);
                    }

                    ForFeedBack = ClientSendQueryType.SearchBook;
                    return;
                }
                else if (query.Contains("<j:>"))
                {
                    query = query.Remove(0, 4);
                    ForFeedBack = ClientSendQueryType.JoinMember;
                    return;
                }
                ForFeedBack = ClientSendQueryType.Unknown;
            }
            static ServerSendQueryType TmpServerQeuryTyp = ServerSendQueryType.Unknown;
            public static ServerSendQueryType WhatIsServerQuery(ref string query, ref System.Collections.Generic.List<string> list)//bara handl kardane inke yebar dar aval no'e vorodiye data rou
            //moshakhas konim va ye bar dar akhar no'e payaniye data rou moshakhas konim neveshte shode, tamami ye element haii ke neveshte shode 100% morede niyaze!!![DO NOT DELETE ANYTHING!!!~X( :-S]
            {
                string[] tmp;
                ServerSendQueryType _tmp = ServerSendQueryType.Unknown;
                if (query.Contains("<not:>"))
                {
                    TmpServerQeuryTyp = ServerSendQueryType.Unknown;
                    return ServerSendQueryType.NotFound;
                }
                switch (TmpServerQeuryTyp)
                {
                    case ServerSendQueryType.Unknown:
                        return ChechProtocol(ref query, ref list);
                    case ServerSendQueryType.BookSearchResult:
                        if (query.Contains("</bsr:>"))
                        {
                            TmpServerQeuryTyp = ServerSendQueryType.Unknown;
                            _tmp = ServerSendQueryType.EndOfQueryOfBSR;
                        }
                        tmp = query.Split(new string[] { "<<>>", "</bsr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                        AddToList(ref list, tmp);
                        return _tmp;
                    case ServerSendQueryType.MemberJoinResult:
                        if (query.Contains("</mjr:>"))
                        {
                            TmpServerQeuryTyp = ServerSendQueryType.Unknown;
                            _tmp = ServerSendQueryType.EndOfQueryOfMJR;
                        }
                        tmp = query.Split(new string[] { "<<>>", "</mjr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                        AddToList(ref list, tmp);
                        return _tmp;
                    case ServerSendQueryType.MemberSearchResult:
                        if (query.Contains("</msr:>"))
                        {
                            TmpServerQeuryTyp = ServerSendQueryType.Unknown;
                            _tmp = ServerSendQueryType.EndOfQueryOfMSR;
                        }
                        tmp = query.Split(new string[] { "<<>>", "</msr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                        AddToList(ref list, tmp);
                        return _tmp;
                    case ServerSendQueryType.TreeSearchResult:
                        if (query.Contains("</Treer:>"))
                        {
                            TmpServerQeuryTyp = ServerSendQueryType.Unknown;
                            _tmp = ServerSendQueryType.EndOfQueryOfTSR;
                        }
                        tmp = query.Split(new string[] { "<<>>", "</Treer:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                        AddToList(ref list, tmp);
                        return _tmp;
                }
                return ServerSendQueryType.Unknown;
            }

            static void AddToList(ref System.Collections.Generic.List<string> list, string[] tmp)
            {
                foreach (string i in tmp)
                {
                    list.Add(i);
                }
            }
            static ServerSendQueryType ChechProtocol(ref string query, ref System.Collections.Generic.List<string> list)
            {
                if (query.Contains("<not:>"))
                {
                    query = query.Remove(0, 6);
                    return ServerSendQueryType.NotFound;
                }
                else if (query.Contains("<loginr:>"))
                {
                    query = query.Remove(0, 9);
                    return ServerSendQueryType.Login;
                }
                else if (query.Contains("<msr:>"))
                {
                    ServerSendQueryType _tmp;
                    if (!query.Contains("</msr:>"))
                        TmpServerQeuryTyp = _tmp = ServerSendQueryType.MemberSearchResult;
                    else
                        _tmp = ServerSendQueryType.EndOfQueryOfMSR;
                    string[] tmp = query.Split(new string[] { "<msr:>", "<<>>", "</msr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    return _tmp;
                }
                else if (query.Contains("<bsr:>"))
                {
                    ServerSendQueryType _tmp;
                    if (!query.Contains("</bsr:>"))
                        TmpServerQeuryTyp = _tmp = ServerSendQueryType.BookSearchResult;
                    else
                        _tmp = ServerSendQueryType.EndOfQueryOfBSR;
                    if (query.Contains("<ATW:>"))
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.AloneThisWord);
                    else if (query.Contains("<TWT:>"))
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle);
                    else if (query.Contains("<STW:>"))
                        Search.Search.setBookSearchResult(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord);
                    string[] tmp = query.Split(new string[] { "<<>>", "<ATW:>", "<TWT:>", "<STW:>", "<bsr:>", "</bsr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    AddToList(ref list, tmp);
                    return _tmp;
                }
                else if (query.Contains("<mjr:>"))
                {
                    ServerSendQueryType _tmp;
                    if (!query.Contains("</mjr:>"))
                        TmpServerQeuryTyp = _tmp = ServerSendQueryType.MemberJoinResult;
                    else
                        _tmp = ServerSendQueryType.EndOfQueryOfMJR;
                    string[] tmp = query.Split(new string[] { "<<>>", "<mjr:>", "</mjr:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    AddToList(ref list, tmp);
                    return _tmp;
                }
                else if (query.Contains("<prm:><bdy:>"))
                {
                    query = query.Remove(0, 12);
                    return ServerSendQueryType.PrivateMessageBody;
                }
                else if (query.Contains("<prm:><ttl:>"))
                {
                    string[] tmp = query.Split(new string[] { "<prm:><ttl:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    AddToList(ref list, tmp);
                    return ServerSendQueryType.PrivateMessageTitle;
                }
                else if (query.Contains("<pum:><bdy:>"))
                {
                    query = query.Remove(0, 12);
                    return ServerSendQueryType.PublicMessageBody;
                }
                else if (query.Contains("<pum:><ttl:>"))
                {
                    string[] tmp = query.Split(new string[] { "<pum:><ttl:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    foreach (string i in tmp)
                        list.Add(i);
                    return ServerSendQueryType.PublicMessageTitle;
                }
                else if (query.Contains("<Treer:>"))
                {
                    ServerSendQueryType _tmp;
                    if (!query.Contains("</Treer:>"))
                        TmpServerQeuryTyp = _tmp = ServerSendQueryType.TreeSearchResult;
                    else
                        _tmp = ServerSendQueryType.EndOfQueryOfTSR;
                    string[] tmp = query.Split(new string[] { "<<>>", "<Treer:>", "<Treer:>" }, System.StringSplitOptions.RemoveEmptyEntries);
                    AddToList(ref list, tmp);
                    return _tmp;
                }
                return ServerSendQueryType.Unknown;
            }
            public static MessageContextType WhatIsContextType(ref string message)
            {
                if (message.Contains("<bdy:>"))
                {
                    message = message.Remove(0, 6);
                    return MessageContextType.Body;
                }
                else if (message.Contains("<ttl:>"))
                {
                    message = message.Remove(0, 6);
                    return MessageContextType.Title;
                }
                return MessageContextType.Unknown;
            }

            public static void SetClientSendProtocol(ref string query, ClientSendQueryType QT, Search.InternalEnumeration.SortType ST)
            {
                switch (ST)
                {
                    case Search.InternalEnumeration.SortType.ByID:
                        query = "<BID:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByKeyword:
                        query = "<BK:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByName:
                        query = "<BN:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByPublisher:
                        query = "<BP:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByWritter:
                        query = "<BW:>" + query;
                        break;
                }
                switch (QT)
                {
                    case ClientSendQueryType.JoinMember:
                        query = "<j:>" + query;
                        break;
                    case ClientSendQueryType.SearchBook:
                        query = "<b:>" + query;
                        break;
                    case ClientSendQueryType.SearchMember:
                        query = "<u:>" + query;
                        break;
                    case ClientSendQueryType.Login:
                        query = "<login:>" + query;
                        break;
                    case ClientSendQueryType.TreeSearch:
                        query = "<tree:>" + query;
                        break;
                    case ClientSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set CLIENT send protocol!, it's end up with UNKNOW type!!",
                            Query.QueryExceptionType.ClientSendQueryType, ClientSendQueryType.Unknown);
                }
            }

            internal static void SetClientSendProtocol(ClientSendQueryType QT, out string Field)
            {
                Field = "";
                switch (QT)
                {
                    case ClientSendQueryType.Logout:
                        Field = "<Logout:>";
                        break;
                }
            }
            public static void SetClientSendProtocol(ref string query, ClientSendQueryType QT)
            {
                switch (QT)
                {
                    case ClientSendQueryType.JoinMember:
                        query = "<j:>" + query;
                        break;
                    case ClientSendQueryType.SearchBook:
                        query = "<b:>" + query;
                        break;
                    case ClientSendQueryType.SearchMember:
                        query = "<u:>" + query;
                        break;
                    case ClientSendQueryType.Login:
                        query = "<login:>" + query;
                        break;
                    case ClientSendQueryType.TreeSearch:
                        query = "<tree:>" + query;
                        break;
                    case ClientSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set CLIENT send protocol!, it's end up with UNKNOW type!!",
                            Query.QueryExceptionType.ClientSendQueryType, ClientSendQueryType.Unknown);
                }
            }

            public static void SetClientSendProtocol(ref string query, ClientSendQueryType QT, Search.InternalEnumeration.SortType ST, Search.InternalEnumeration.ResultSearchBook SRB)
            {
                switch (SRB)
                {
                    case Search.InternalEnumeration.ResultSearchBook.AloneThisWord:
                        query = "<ATW:>" + query;
                        break;
                    case Search.InternalEnumeration.ResultSearchBook.SimilerThisWord:
                        query = "<STW:>" + query;
                        break;
                    case Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle:
                        query = "<TWT:>" + query;
                        break;
                }

                switch (ST)
                {
                    case Search.InternalEnumeration.SortType.ByID:
                        query = "<BID:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByKeyword:
                        query = "<BK:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByName:
                        query = "<BN:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByPublisher:
                        query = "<BP:>" + query;
                        break;
                    case Search.InternalEnumeration.SortType.ByWritter:
                        query = "<BW:>" + query;
                        break;
                }
                switch (QT)
                {
                    case ClientSendQueryType.JoinMember:
                        query = "<j:>" + query;
                        break;
                    case ClientSendQueryType.SearchBook:
                        query = "<b:>" + query;
                        break;
                    case ClientSendQueryType.SearchMember:
                        query = "<u:>" + query;
                        break;
                    case ClientSendQueryType.Login:
                        query = "<login:>" + query;
                        break;
                    case ClientSendQueryType.TreeSearch:
                        query = "<tree:>" + query;
                        break;
                    case ClientSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set CLIENT send protocol!, it's end up with UNKNOW type!!",
                            Query.QueryExceptionType.ClientSendQueryType, ClientSendQueryType.Unknown);
                }
            }
            public static void SetServerSendProtocol(ref string query, ServerSendQueryType QT)
            {
                switch (QT)
                {
                    case ServerSendQueryType.BookSearchResult:
                        query = "<bsr:>" + query;
                        switch (Search.Search.getBookSearchResult())
                        {
                            case Search.InternalEnumeration.ResultSearchBook.AloneThisWord:
                                query = "<ATW:>" + query;
                                break;
                            case Search.InternalEnumeration.ResultSearchBook.SimilerThisWord:
                                query = "<STW:>" + query;
                                break;
                            case Search.InternalEnumeration.ResultSearchBook.ThisWordInTitle:
                                query = "<TWT:>" + query;
                                break;
                        }
                        break;
                    case ServerSendQueryType.MemberJoinResult:
                        query = "<mjr:>" + query;
                        break;
                    case ServerSendQueryType.MemberSearchResult:
                        query = "<msr:>" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfMSR:
                        query = "</msr:>" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfBSR:
                        query = "</bsr:>" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfMJR:
                        query = "</mjr:>" + query;
                        break;
                    case ServerSendQueryType.PrivateMessageTitle:
                        SetContextProtocol(ref query, MessageContextType.Title);
                        query = "<prm:>" + query;
                        break;
                    case ServerSendQueryType.PublicMessageTitle:
                        SetContextProtocol(ref query, MessageContextType.Title);
                        query = "<pum:>" + query;
                        break;
                    case ServerSendQueryType.PublicMessageBody:
                        SetContextProtocol(ref query, MessageContextType.Body);
                        query = "<pum:>" + query;
                        break;
                    case ServerSendQueryType.PrivateMessageBody:
                        SetContextProtocol(ref query, MessageContextType.Body);
                        query = "<pum:>" + query;
                        break;
                    case ServerSendQueryType.Login:
                        query = "<loginr:>" + query;
                        break;
                    case ServerSendQueryType.NotFound:
                        query = "<not:>" + query;
                        break;
                    case ServerSendQueryType.TreeSearchResult:
                        query = "<Treer:>" + query;
                        break;
                    case ServerSendQueryType.EndOfQueryOfTSR:
                        query = "</Treer:>" + query;
                        break;
                    case ServerSendQueryType.Unknown:
                        throw new Query.QueryException("Something went wrong when trying to set SERVER send protocol!, it's end up with UNKNOW type!!", Query.QueryExceptionType.ServerSendQueryType, ServerSendQueryType.Unknown);
                }
            }

            private static void SetContextProtocol(ref string message, MessageContextType MT)
            {
                switch (MT)
                {
                    case MessageContextType.Title:
                        message = "<ttl:>" + message;
                        break;
                    case MessageContextType.Body:
                        message = "<bdy:>" + message;
                        break;
                }
            }

            public static ServerSendQueryType GetEndOFQuery(ServerSendQueryType QT)
            {
                switch (QT)
                {
                    case ServerSendQueryType.MemberJoinResult: return ServerSendQueryType.EndOfQueryOfMJR;
                    case ServerSendQueryType.MemberSearchResult: return ServerSendQueryType.EndOfQueryOfMSR;
                    case ServerSendQueryType.BookSearchResult: return ServerSendQueryType.EndOfQueryOfBSR;
                    case ServerSendQueryType.Login: return ServerSendQueryType.Login;
                    case ServerSendQueryType.TreeSearchResult: return ServerSendQueryType.EndOfQueryOfTSR;
                    default: return QT;
                }
            }
            public static void WhatIsQuery(ref string query, Connection.Connection con)
            {
                try
                {
                    Protocol.LPS.WhatISClientQuery(ref query);
                    if (query.Contains("<<END_CON>>"))
                    {
                        con.CurrentConnectionSocket.Disconnect(true);
                        Communication.ConnectionInfo.StaticConnectionInfo.ConnectionRootMode = Connection.ConnectionMode.Disconnected;
                        switch (con is Connection.ClientConnection)
                        {
                            case true:
                                throw new InternalNetworkException("The server-side program has just been shutted down!", NetworkExceptionSide.Client);
                            case false:
                                throw new InternalNetworkException("Client-side of this program has just closed!!", NetworkExceptionSide.Server);
                        }
                    }
                }
                catch (SocketException) { }
            }
            public static void IsKeyWord(string query, Connection.Connection con)
            {
                try
                {
                    if (query.Contains("<<END_CON>>"))
                    {
                        con.CurrentConnectionSocket.Disconnect(true);
                        Communication.ConnectionInfo.StaticConnectionInfo.ConnectionRootMode = Connection.ConnectionMode.Disconnected;
                        switch (con is Connection.ClientConnection)
                        {
                            case true:
                                throw new InternalNetworkException("The server-side program has just been shutted down!", NetworkExceptionSide.Client);
                            case false:
                                throw new InternalNetworkException("Client-side of this program has just closed!!", NetworkExceptionSide.Server);
                        }
                    }
                }
                catch (SocketException) { }
            }
        }
    }
}
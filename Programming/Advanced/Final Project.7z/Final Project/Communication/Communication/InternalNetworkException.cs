﻿using System;

namespace Communication
{
    public enum NetworkExceptionSide{Client, Server}
    public class InternalNetworkException : Exception
    {
        string message;
        NetworkExceptionSide ntwrkExptionSid;
        public InternalNetworkException(string passage, NetworkExceptionSide NS)
        {
            message = passage;
            ntwrkExptionSid = NS;
        }
        public InternalNetworkException(NetworkExceptionSide NS)
        {
            ntwrkExptionSid = NS;
        }
        public override String Message
        {
            get
            {
                return string.IsNullOrEmpty(message) ? "publicExceptionSide" : message;
            }
        }
        public NetworkExceptionSide NetworkSide
        {
            get
            {
                return ntwrkExptionSid;
            }
        }
        public InternalNetworkException(string passage)
        {
            message = passage;
        }
    }
}

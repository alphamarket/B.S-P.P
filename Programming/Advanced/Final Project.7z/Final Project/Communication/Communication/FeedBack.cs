﻿using System.Collections.Generic;
using Communication.Protocol;
namespace Communication
{
    namespace Data
    {
        public class FeedBack
        {
            public static void DoFeedBack(List<string> Qres)//Send FeedBack information of do_query!!
            {
                try
                {
                    if (Qres.Count == 0)
                    {
                        string tmp = "NOT_FOUND";
                        LPS.SetServerSendProtocol(ref tmp, ServerSendQueryType.NotFound);
                        Communication.ConnectionInfo.StaticConnectionInfo.ServerConnectionRoot.SendData(tmp);
                        return;
                    }                    
                    ServerSendQueryType QT = LPS.WhatIsServerSendType();
                    for (int i = 0; i < Qres.Count; i++)
                    {
                        string tmp = Qres[i];
                        if (i == 0)
                            LPS.SetServerSendProtocol(ref tmp, QT);
                        else if (i == Qres.Count - 1)
                            LPS.SetServerSendProtocol(ref tmp, LPS.GetEndOFQuery(QT));
                        else
                            tmp += "<<>>";
                        Communication.ConnectionInfo.StaticConnectionInfo.ServerConnectionRoot.SendData(tmp);
                    }
                }
                catch (Query.QueryException e)
                {
                    //THIS WILL BE COME THE """throw e;"""
                }
            }
            public static void DoFeedBack(string str, ref Connection.Connection sock, ServerSendQueryType QT)
            {
                switch (QT)
                {
                    case ServerSendQueryType.BookSearchResult:
                        QT = ServerSendQueryType.EndOfQueryOfBSR;
                        break;
                    case ServerSendQueryType.MemberJoinResult:
                        QT = ServerSendQueryType.EndOfQueryOfMJR;
                        break;
                    case ServerSendQueryType.MemberSearchResult:
                        QT = ServerSendQueryType.EndOfQueryOfMSR;
                        break;
                }
                LPS.SetServerSendProtocol(ref str, QT);
                sock.SendData(str);
            }
        }
    }
}

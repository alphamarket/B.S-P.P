﻿using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Net.Sockets;
using System.Windows.Forms;
using Communication.ConnectionInfo;
namespace Communication
{
    namespace Setting
    {
        public class ConnectionSetting
        {
            public ConnectionSetting() { }
            static string BackPath = Application.StartupPath + @"\Files\Connection\BackNET.xml",
                        mainPath = Application.StartupPath + @"\Files\Connection\NET.xml",
                        tmpPath = Application.StartupPath + @"\Files\Connection\TmpNET.xml";
            public static void SaveConnectionSetting(Communication.Setting.SettingSideOption SSO, string ip, string port)
            {
                if (string.IsNullOrEmpty(port) || string.IsNullOrWhiteSpace(port))
                    throw new ArgumentException("Port can not be null", "port");
                if (string.IsNullOrEmpty(ip) || string.IsNullOrWhiteSpace(ip))
                    throw new ArgumentException("IP can not be null", "ip");
                bool FirstTime = true;
                if (File.Exists(mainPath))
                    FirstTime = false;
                switch (SSO)
                {
                    case SettingSideOption.Server:

                        Socket test = null;
                        try
                        {
                            test = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                            test.Bind(new IPEndPoint(IPAddress.Parse(ip), int.Parse(port)));
                            test.Listen(1);
                        }
                        catch
                        {
                            throw new InternalNetworkException("Selected ' IP ' or ' PORT ' is not valid!");
                        }
                        finally
                        {
                            try
                            {
                                test.Close();
                            }
                            catch { }
                        }
                        break;
                }
                using (XmlTextWriter write = new XmlTextWriter(mainPath, null))
                {
                    write.Formatting = Formatting.Indented;
                    write.WriteStartDocument();
                    write.WriteStartElement("Setting");
                    switch (SSO)
                    {
                        case SettingSideOption.Client:
                            write.WriteStartElement("Client");
                            StaticConnectionInfo.NetworkSideOption = SettingSideOption.Client;
                            break;
                        case SettingSideOption.Server:
                            write.WriteStartElement("Server");
                            StaticConnectionInfo.NetworkSideOption = SettingSideOption.Server;
                            break;
                    }
                    write.WriteStartElement("Network");
                    write.WriteStartElement("IP");
                    write.WriteString(ip);
                    write.WriteEndElement();
                    write.WriteStartElement("Port");
                    write.WriteString(port);
                    write.WriteEndElement();
                    write.WriteEndElement();
                    write.WriteEndElement();
                    write.WriteEndDocument();
                    write.Flush();
                }
                StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse(ip), int.Parse(port));
                if (!FirstTime)
                {
                    MessageBox.Show("Program have to restart to work correctly as you set in network option", "Restarting ...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Connection.Connection.RestartApplication();
                }
            }
            enum Address { PORT, IP, NONE }
            enum Setting { CURRENTSETTING, PREVIOUSSETTING }
            public static void BackupConnectionSetting()
            {
                if (File.Exists(mainPath))
                {
                    if (File.Exists(BackPath))
                        File.Delete(BackPath);
                    File.Copy(mainPath, BackPath);
                }
            }
            private static bool LoadConnectionSetting(Setting witch)
            {
                CreateEssentialDirectory();
                StaticConnectionInfo.ConnectionRootMode = Connection.ConnectionMode.NotSetted;
                string path = "", ip = "", port = "";
                switch (witch)
                {
                    case Setting.CURRENTSETTING:
                        path = mainPath;
                        break;
                    case Setting.PREVIOUSSETTING:
                        path = BackPath;
                        break;
                }
                if (!File.Exists(path))
                    return false;
                using (XmlTextReader read = new XmlTextReader(path))
                {
                    Address type = Address.NONE;
                    while (read.Read())
                    {
                        switch (read.NodeType)
                        {
                            case XmlNodeType.Element:
                                switch (read.Name)
                                {
                                    case "Client":
                                        StaticConnectionInfo.NetworkSideOption = SettingSideOption.Client;
                                        break;
                                    case "Server":
                                        StaticConnectionInfo.NetworkSideOption = SettingSideOption.Server;
                                        break;
                                    case "IP":
                                        type = Address.IP;
                                        break;
                                    case "Port":
                                        type = Address.PORT;
                                        break;
                                }
                                break;
                            case XmlNodeType.Text:
                                switch (type)
                                {
                                    case Address.PORT:
                                        if (string.IsNullOrEmpty(read.Value) || string.IsNullOrWhiteSpace(read.Value))
                                            return false;
                                        port = read.Value;
                                        type = Address.NONE;
                                        break;
                                    case Address.IP:
                                        if (string.IsNullOrEmpty(read.Value) || string.IsNullOrWhiteSpace(read.Value))
                                            return false;
                                        ip = read.Value;
                                        break;
                                }
                                break;
                        }
                    }
                }
                StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse(ip), int.Parse(port));
                return true;
            }
            public static bool LoadConnectionSetting()
            {
                return LoadConnectionSetting(Setting.CURRENTSETTING);
            }
            public static void CreateEssentialDirectory()
            {

                if (!Directory.Exists(Application.StartupPath + @"\Files\"))
                {
                    Directory.CreateDirectory(Application.StartupPath + @"\Files\");
                    System.IO.DirectoryInfo info = new System.IO.DirectoryInfo(Application.StartupPath + @"\Files");
                    info.Attributes = System.IO.FileAttributes.Hidden;
                }
                if (!Directory.Exists(Application.StartupPath + @"\Files\Connection\"))
                    Directory.CreateDirectory(Application.StartupPath + @"\Files\Connection\");
                if (!Directory.Exists(Application.StartupPath + @"\Files\DataBase\"))
                    Directory.CreateDirectory(Application.StartupPath + @"\Files\DataBase\Recent\");
                if (!Directory.Exists(Application.StartupPath + @"\Files\DataBase\Recent\"))
                    Directory.CreateDirectory(Application.StartupPath + @"\Files\DataBase\Recent\");
                if (!Directory.Exists(Application.StartupPath + @"\Files\DataBase\Virtual Library\All Book\"))
                    Directory.CreateDirectory(Application.StartupPath + @"\Files\DataBase\Virtual Library\All Book\");
                if (!System.IO.Directory.Exists(Application.StartupPath + @"\Files\DataBase\Recent\User"))
                    System.IO.Directory.CreateDirectory(Application.StartupPath + @"\Files\DataBase\Recent\User");
            }
            public static void DeleteConnectionSettings()
            {
                if (Directory.Exists(Application.StartupPath + @"\Files\Connection\"))
                    Directory.Delete(Application.StartupPath + @"\Files\Connection\", true);
                Directory.CreateDirectory(Application.StartupPath + @"\Files\Connection\");
            }
            public static void DefaultConnectionSetting(Communication.Setting.SettingSideOption Side, Communication.Setting.DefaultSetting Setting)
            {
                switch (Setting)
                {
                    case DefaultSetting.AcceptAnyConnection:
                        SaveConnectionSetting(Side, "0.0.0.0", "34139");
                        StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse("0.0.0.0"), int.Parse("34139"));
                        break;
                    case DefaultSetting.LocalHost:
                        SaveConnectionSetting(Side, "127.0.0.1", "34139");
                        StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse("127.0.0.1"), int.Parse("34139"));
                        break;
                }
            }
            public static void DefaultConnectionSetting(Communication.Setting.SettingSideOption Side, Communication.Setting.DefaultSetting Setting, string port)
            {
                if (string.IsNullOrEmpty(port) || string.IsNullOrWhiteSpace(port))
                    throw new ArgumentException("Port can not be null", "port");
                switch (Setting)
                {
                    case DefaultSetting.AcceptAnyConnection:
                        SaveConnectionSetting(Side, "0.0.0.0", port);
                        StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse("0.0.0.0"), int.Parse("34139"));
                        break;
                    case DefaultSetting.LocalHost:
                        SaveConnectionSetting(Side, "127.0.0.1", port);
                        StaticConnectionInfo.ConnectionEndPointInfo = new IPEndPoint(IPAddress.Parse("127.0.0.1"), int.Parse("34139"));
                        break;
                }
            }
            public static void LoadLastConnectionSetting()
            {
                if (!LoadConnectionSetting(Setting.PREVIOUSSETTING))
                    MessageBox.Show("Unable to upload last saved Setting!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    if (File.Exists(mainPath))
                    {
                        File.Replace(BackPath, mainPath, tmpPath);
                        File.Delete(BackPath);
                        File.Copy(tmpPath, BackPath);
                        File.Delete(tmpPath);
                    }
                    MessageBox.Show("Program have to restart to undo last network option", "Restarting ...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Connection.Connection.RestartApplication();
                }
            }
        }
    }
}
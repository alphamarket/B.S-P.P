﻿using System;

namespace Communication
{
    public class NetworkSideException : Exception
    {
        private Setting.SettingSideOption SSO;
        private string message;
        public NetworkSideException(string message)
        {
            this.message = message;
        }
        public NetworkSideException(string message, Setting.SettingSideOption SSO)
        {
            this.message = message;
            this.SSO = SSO;
        }
        public override string Message
        {
            get
            {
                return message;
            }
        }
        public Setting.SettingSideOption NetworkSide
        {
            get
            {
                return SSO;
            }
        }
    }
}

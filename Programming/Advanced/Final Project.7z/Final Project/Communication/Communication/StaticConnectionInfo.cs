﻿using System.Net;

namespace Communication
{
    namespace ConnectionInfo
    {
        public class StaticConnectionInfo
        {
            private static Setting.SettingSideOption SSO;
            public static Setting.SettingSideOption NetworkSideOption
            {
                get
                {
                    return SSO;
                }
                set
                {
                    SSO = value;
                }
            }
            public static IPEndPoint ConnectionEndPointInfo
            {
                set
                {
                    ip = value.Address.ToString();
                    port = value.Port;
                }
                get
                {
                    if (ip == "0.0.0.0")
                        return new IPEndPoint(IPAddress.Any, port);
                    return new IPEndPoint(IPAddress.Parse(ip), port);
                }
            }
            private static int port;
            public static int Port
            {
                set
                {
                    port = value;
                }
                get
                {
                    return port;
                }
            }
            private static string ip;
            public static string IP
            {
                set
                {
                    ip = value;
                }
                get
                {
                    return ip;
                }
            }
            private static Communication.Connection.ServerConnection srvrCon;
            public static Communication.Connection.ServerConnection ServerConnectionRoot
            {
                get
                {
                    if (SSO != Setting.SettingSideOption.Server)
                        throw new CodeAccessException("You have no such permission to use this property.", Setting.SettingSideOption.Client);
                    return srvrCon;
                }
                set
                {
                    if (SSO != Setting.SettingSideOption.Server)
                        throw new CodeAccessException("You have no such permission to use this property.", Setting.SettingSideOption.Client);
                    srvrCon = value;
                }
            }
            private static MessageType MT=MessageType.Private;
            public static MessageType MessageKind
            {
                set
                {
                    MT = value;
                }
                get
                {
                    return MT;
                }
            }
            private static Communication.Connection.ClientConnection clntCon;
            public static Communication.Connection.ClientConnection ClientConnetionRoot
            {
                get
                {
                    if (SSO != Setting.SettingSideOption.Client)
                        throw new CodeAccessException("You have no such permission to use this property.", Setting.SettingSideOption.Server);
                    return clntCon;
                }
                set
                {
                    if (SSO != Setting.SettingSideOption.Client)
                        throw new CodeAccessException("You have no such permission to use this property.", Setting.SettingSideOption.Server);
                    clntCon = value;
                }
            }
            private static Communication.Connection.ConnectionMode connectionMode=Connection.ConnectionMode.NotSetted;
            public static Communication.Connection.ConnectionMode ConnectionRootMode
            {
                set
                {
                    connectionMode = value;
                }
                get
                {
                    return connectionMode;
                }
            }
        }
    }
}
﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Communication.ConnectionInfo;
namespace Communication
{
    namespace Connection
    {
        public class ServerConnection : Connection
        {
            static public DisconnectFuction FuntionOfDisconnection;
            static public ConnectFuction FuntionOfConnection;
            private ToolStripStatusLabel NetStatus;
            private Thread thrd;
            public delegate void DisconnectFuction(Object sender, EventArgs e);
            public delegate void ConnectFuction(Object sender, EventArgs e);

            public override IPEndPoint JoinedIPEndPoint
            {
                get { return JoinedClientIPEP; }
            }

            public override string ConnectionStatusString
            {
                set
                {
                    try
                    {
                        Protocol.LPS.IsKeyWord(value, this);

                        NetStatus.Text = value;
                        conStatString = value;
                    }
                    catch { }
                }
                get
                {
                    return conStatString;
                }
            }

            public override IPEndPoint ConnetionIPEP
            {
                get
                {
                    return thisIPEP;
                }
                set
                {
                    thisIPEP = value;
                }
            }

            public override Socket CurrentConnectionSocket
            {
                set
                {
                    root = value;
                }
                get
                {
                    return root;
                }
            }

            public override bool IsConnected
            {
                get
                {
                    try
                    {
                        if (!base.root.Connected)
                        {
                            NetStatus.Text = "Network disconnected......";
                            FuntionOfDisconnection(NetworkExceptionSide.Client, new EventArgs());
                            StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Disconnected;
                            return false;
                        }
                        return true;
                    }
                    catch (SocketException)
                    {
                        NetStatus.Text = "Network Disconnected.......";
                        StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Disconnected;
                        return false;
                    }
                }
            }

            private bool ShutDown
            {
                get
                {
                    if (CurrentConnectionSocket != null)
                    {
                        if (IsConnected)
                        {
                            //
                            //USE <<END_CON>>
                            //
                            Thread.Sleep(10);
                            return shuttingDown = IsConnected;
                        }
                        else
                        {
                            CurrentConnectionSocket.Close();
                            CurrentConnectionSocket = null;
                            NetStatus.Text = "Network connetion has just shutted down!";
                            return shuttingDown = true;
                        }
                    }
                    else
                        return shuttingDown = true;
                }
                set
                {
                    throw new CodeAccessException(StaticConnectionInfo.NetworkSideOption);
                }
            }

            private void AcceptCon_SYNC(IAsyncResult iar)
            {
                try
                {
                    CurrentConnectionSocket = ((Socket)iar.AsyncState).EndAccept(iar);
                    ConnectionStatusString = "Connection has been made from " + (JoinedClientIPEP = (IPEndPoint)CurrentConnectionSocket.RemoteEndPoint).ToString();
                    thrd = new Thread(new ThreadStart(ReceiveData));
                    thrd.Start();
                    StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Connected;
                }
                catch (ObjectDisposedException) { }
            }
            //
            // Summary:
            //      Create TCP, Internet, Stream Connetion and begin to recive any entery data.
            // Parameters:
            //      ipep:
            //          An IPEndPoint object to connection
            //      netstatue:
            //          An ToolStripStatusLabel object for which show network status change.
            public ServerConnection(IPEndPoint ipep, ToolStripStatusLabel netstatue, DisconnectFuction DisconnectFunction, ConnectFuction ConnectFunction)
            {
                if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.NotSetted || StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected)
                {
                    try
                    {
                        NetStatus = netstatue;
                        FuntionOfDisconnection = DisconnectFunction;
                        FuntionOfConnection = ConnectFunction;
                        CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        CurrentConnectionSocket.Bind(ConnetionIPEP = ipep);
                        CurrentConnectionSocket.Listen(int.MaxValue);
                        ConnectionStatusString = "Waitting for client connection  ....";
                        CurrentConnectionSocket.NoDelay = true;
                        StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Listenning;
                        CurrentConnectionSocket.BeginAccept(new AsyncCallback(AcceptCon_SYNC), CurrentConnectionSocket);
                        StaticConnectionInfo.NetworkSideOption = Setting.SettingSideOption.Server;
                        StaticConnectionInfo.ServerConnectionRoot = this;
                    }
                    catch (SocketException) { Application.Exit(); }
                }
            }

            public ServerConnection(String ip, int port, ToolStripStatusLabel netstatus)
            {
                if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.NotSetted || StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected)
                {
                    try
                    {
                        NetStatus = netstatus;
                        CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        CurrentConnectionSocket.Bind(new IPEndPoint(IPAddress.Parse(ip), port));
                        CurrentConnectionSocket.Listen(1);
                        ConnectionStatusString = "Waitting for clien connection  ....";
                        CurrentConnectionSocket.NoDelay = true;
                        CurrentConnectionSocket.BeginAccept(new AsyncCallback(AcceptCon_SYNC), CurrentConnectionSocket);
                        StaticConnectionInfo.NetworkSideOption = Setting.SettingSideOption.Server;
                        StaticConnectionInfo.ServerConnectionRoot = this;
                    }
                    catch (SocketException) { Application.Exit(); }
                }
            }

            public void SendData(string query, Protocol.ServerSendQueryType QT)//client side of this program will use this kind of SendData fuction, it's very critical!!!!!!!
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        Protocol.LPS.SetServerSendProtocol(ref query, QT);
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have not set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
            }

            public void Disconnect(bool reuse)
            {
                try
                {
                    if (StaticConnectionInfo.ConnectionRootMode != ConnectionMode.NotSetted)
                    {
                        if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected) { }
                        base.root.Disconnect(reuse);
                        if (!reuse)
                            base.root = null;
                        GC.Collect();
                    }
                }
                catch (NullReferenceException) { }
            }
            public string ConnectionStatus
            {
                get
                {
                    if (StaticConnectionInfo.ServerConnectionRoot == null || !StaticConnectionInfo.ServerConnectionRoot.IsConnected)
                        return "No client has been connected to server......!";
                    return "The connection has been made .......";
                }
            }

            public bool BoolianConnectionStatus
            {
                get
                {
                    if (StaticConnectionInfo.ServerConnectionRoot == null || !StaticConnectionInfo.ServerConnectionRoot.IsConnected)
                        return false;
                    return true;
                }
            }
            System.Collections.Generic.List<string> LoadFilters()
            {
                System.Collections.Generic.List<string> tmp = new System.Collections.Generic.List<string>();
                try
                {
                    using (FileStream fs = new FileStream(Application.StartupPath + @"\Files\DataBase\Filters.FILE", FileMode.Open, FileAccess.Read, FileShare.None))
                    {
                        using (StreamReader read = new StreamReader(fs))
                        {
                            while (!read.EndOfStream)
                            {
                                tmp.Add(read.ReadLine());
                            }
                        }
                    }
                }
                catch
                {
                    return new System.Collections.Generic.List<string>();
                }
                return tmp;
            }
            protected void ReceiveData()
            {
                System.Collections.Generic.List<string> Filters = LoadFilters();
                try
                {
                    while (true)
                    {
                        data = new byte[1024];
                        string query;
                        int recv = CurrentConnectionSocket.Receive(data, SocketFlags.None);
                        if (CheckInfiniteRecive(query = Encoding.ASCII.GetString(data, 0, recv)))
                        {
                            Protocol.LPS.WhatIsQuery(ref query, this);
                            if (FilterChecker(Filters, query))
                                Serve.Query.DoClientQuery(query.Split(new string[] { "<<>>", " <<>> ", "<<>>" }, StringSplitOptions.RemoveEmptyEntries), this);
                            if (!root.Connected) break;
                        }
                    }
                    CurrentConnectionSocket.Disconnect(true);
                    return;
                }
                catch (InternalNetworkException ine)
                {
                    switch (ine.NetworkSide)
                    {
                        case NetworkExceptionSide.Server:
                            //
                            //TODO:
                            //      HANDLE RECONNTION MATTER OF DICCONECTION OF CLIENT SIDE PROGRAM HERE
                            //
                            //      OR
                            //
                            //      HANDLE IF CLIENT HAS SHUTED DOWN
                            //
                            //
                            break;
                    }
                }
                catch (SocketException) { RestartApplication(); }//vagti network gat misge in raise mikone!!!!!!! HANDLE THIS
                catch (Exception)
                { }
            }

            private bool FilterChecker(System.Collections.Generic.List<string> Filters, string query)
            {
                foreach (string i in Filters)
                {
                    if (query.Contains(i))
                    {
                        Communication.Data.FeedBack.DoFeedBack(new System.Collections.Generic.List<string>());
                        return false;
                    }
                }
                return true;
            }
            ~ServerConnection()
            {
                root = null;
            }
        }
    }
}
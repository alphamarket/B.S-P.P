﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Communication.ConnectionInfo;
namespace Communication
{
    namespace Connection
    {
        public class ClientConnection:Connection
        {

            private ToolStripStatusLabel NetStatus;
            Thread thrd;
            public delegate void DC(object sender, EventArgs e);//Functions when network set a connetion or disconnection
            public delegate void CON(object sender, EventArgs e);//

            public override IPEndPoint JoinedIPEndPoint
            {
                get { return JoinedClientIPEP; }
            }

            public override string ConnectionStatusString
            {
                set
                {
                    try
                    {
                        Protocol.LPS.IsKeyWord(value, this);
                        NetStatus.Text = value;
                        conStatString = value;
                    }
                    catch { }
                }
                get
                {
                    return conStatString;
                }
            }

            public override IPEndPoint ConnetionIPEP
            {
                get
                {
                    return thisIPEP;
                }
                set
                {
                    thisIPEP = value;
                }
            }

            public override Socket CurrentConnectionSocket
            {
                set
                {
                    root = value;
                }
                get
                {
                    return root;
                }
            }
            public override bool IsConnected
            {
                get
                {
                    try
                    {
                        if (!CurrentConnectionSocket.Connected)
                        {
                            NetStatus.Text = "Network disconnected ...";
                            StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Disconnected;
                            return false;
                        }
                        return true;
                    }
                    catch (SocketException)
                    {
                        NetStatus.Text = "Network disconnected ...";
                        StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Disconnected;
                        return false;
                    }
                }
            }

            private void Connected(IAsyncResult iar)
            {
                try
                {
                    CurrentConnectionSocket.EndConnect(iar);
                    thrd = new Thread(new ThreadStart(ReceiveData));
                    thrd.Start();
                    ConnectionStatusString = "Connection from: " + CurrentConnectionSocket.RemoteEndPoint.ToString();
                    StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Connected;
                }
                catch (ObjectDisposedException) { }
                catch (NullReferenceException) { }
                catch (SocketException)
                {
                    MessageBox.Show("Unable to Connect .....");
                }
            }


            private bool ShutDown
            {
                get
                {
                    if (CurrentConnectionSocket != null)
                    {
                        if (IsConnected)
                        {
                            SendData("END_CON");
                            Thread.Sleep(20);
                            if (!CurrentConnectionSocket.Connected)
                            {
                                NetStatus.Text = "Network disconnected .....";
                                StaticConnectionInfo.ConnectionRootMode = ConnectionMode.Disconnected;
                            }
                            return !(shuttingDown = IsConnected);
                        }
                        else
                        {
                            CurrentConnectionSocket.Close();
                            CurrentConnectionSocket = null;
                           StaticConnectionInfo.ConnectionRootMode= ConnectionMode.Disconnected;
                            ConnectionStatusString = "Network connetion has just shutted down ...";
                            return shuttingDown = true;
                        }
                    }
                    else
                        return shuttingDown = true;
                }
                set
                {
                    throw new CodeAccessException(StaticConnectionInfo.NetworkSideOption);
                }
            }

            public ClientConnection(IPEndPoint ipep, ToolStripStatusLabel netstatus)
            {
                if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.NotSetted || StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected)
                {
                    try
                    {
                        NetStatus = netstatus;
                        CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        CurrentConnectionSocket.NoDelay = true;
                        CurrentConnectionSocket.BeginConnect(ConnetionIPEP = ipep, new AsyncCallback(Connected), CurrentConnectionSocket);
                        StaticConnectionInfo.NetworkSideOption = Setting.SettingSideOption.Client;
                        StaticConnectionInfo.ClientConnetionRoot = this;
                    }
                    catch (SocketException) { }
                    catch (Exception)
                    {
                        //TODO: Log the Exception Message ....
                    }
                }
            }


            public ClientConnection(string ip, int port, ToolStripStatusLabel netstatus)
            {
                if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.NotSetted || StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected)
                {
                    try
                    {
                        NetStatus = netstatus;
                        CurrentConnectionSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        CurrentConnectionSocket.NoDelay = true;
                        ConnetionIPEP.Address = IPAddress.Parse(ip);
                        ConnetionIPEP.Port = port;
                        CurrentConnectionSocket.BeginConnect(ConnetionIPEP, new AsyncCallback(Connected), CurrentConnectionSocket);
                        StaticConnectionInfo.NetworkSideOption = Setting.SettingSideOption.Client;
                        StaticConnectionInfo.ClientConnetionRoot = this;
                    }
                    catch (SocketException) { }
                    catch (Exception)
                    {
                        //TODO: Log the Exception Message ....
                    }
                }
            }

            public void SendData(string query, Protocol.ClientSendQueryType QT)//client side of this program will use this kind of SendData fuction, it's very critical!!!!!!!
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        Protocol.LPS.SetClientSendProtocol(ref query, QT);
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have to set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
            }

            public void SendData(string query, Protocol.ClientSendQueryType QT, Search.InternalEnumeration.SortType ST)//client side of this program will use this kind of SendData fuction, it's very critical!!!!!!!
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        Protocol.LPS.SetClientSendProtocol(ref query, QT, ST);
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have not set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
                catch (SocketException e) { MessageBox.Show(e.Message, "Oops!"); }
            }

            public void SendData(string query, Protocol.ClientSendQueryType QT, Search.InternalEnumeration.SortType ST, Search.InternalEnumeration.ResultSearchBook RSB)//client side of this program will use this kind of SendData fuction, it's very critical!!!!!!!
            {
                try
                {
                    if (CurrentConnectionSocket != null)
                    {
                        Protocol.LPS.SetClientSendProtocol(ref query, QT, ST, RSB);
                        CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0,
                            new AsyncCallback(SendData_SYNC), CurrentConnectionSocket);
                    }
                    else
                        throw new Exception("You have not set a socket root to send demanded data!!");
                }
                catch (ObjectDisposedException) { }
                catch (SocketException) { }
            }


            public void Disconnect(bool reuse)
            {
                try
                {
                    if (StaticConnectionInfo.ConnectionRootMode != ConnectionMode.NotSetted)
                    {
                        if (StaticConnectionInfo.ConnectionRootMode == ConnectionMode.Disconnected) { }
                        base.root.Disconnect(reuse);
                        if (!reuse)
                        {
                            root.Close();
                            base.root = null;
                        }
                        GC.Collect();
                    }
                    else
                        throw new InternalNetworkException("You are not connected, To disconnect now!");
                }
                catch (NullReferenceException) { }
            }
            public string ConnectionStatus
            {
                get
                {
                    if (StaticConnectionInfo.ClientConnetionRoot == null || StaticConnectionInfo.ClientConnetionRoot.IsConnected)
                        return "No connection has been made ...!";
                    return "The connection to server has been made ....";
                }
            }
            public bool BoolianConnectionStatus
            {
                get
                {
                    if (StaticConnectionInfo.ClientConnetionRoot == null || StaticConnectionInfo.ClientConnetionRoot.IsConnected)
                        return false;
                    return true;
                }
            }
            public void Login(string username, string password)
            {
                SendData(username + "<<>>" + password.GetHashCode(), Protocol.ClientSendQueryType.Login);
            }
            private void SendData(Protocol.ClientSendQueryType CSQ)
            {
                string tmp;
                Communication.Protocol.LPS.SetClientSendProtocol(CSQ,out tmp);
                SendData(tmp);
            }
            public void Logout()
            {
                SendData(Protocol.ClientSendQueryType.Logout);
            }
            protected virtual void ReceiveData()
            {
                try
                {
                    List<string> Qres = new List<string>();
                    while (true)
                    {
                        data = new byte[1024];
                        string response;
                        int recv = CurrentConnectionSocket.Receive(data);
                        if (!string.IsNullOrEmpty(response = Encoding.ASCII.GetString(data, 0, recv)) && !string.IsNullOrWhiteSpace(response))
                        {
                            Protocol.LPS.IsKeyWord(response, this);
                            //TODO: DO what ever needed to receive and handling client received responds from server
                            //
                            switch (Protocol.LPS.WhatIsServerQuery(ref response, ref Qres))
                            {
                                case Protocol.ServerSendQueryType.MemberSearchResult:
                                    Qres.Add(response);
                                    //
                                    //TODO: do whatever needs to handle entry query depends of the type of entery which has been determined by this switch/case
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.MemberJoinResult:
                                    Qres.Add(response);
                                    //
                                    //TODO: do whatever needs to handle entry query depends of the type of entery which has been determined by this switch/case
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.BookSearchResult:
                                    Qres.Add(response);
                                    //
                                    //TODO: do whatever needs to handle entry query depends of the type of entery which has been determined by this switch/case
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.EndOfQueryOfBSR:// EndOfQueryOfBSR == Last index of book search query result 
                                    Qres.Add(response);
                                    //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                    //    MessageBox.Show(Qres[i]);
                                    //
                                    //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                    //
                                    Qres.Clear();
                                    break;
                                case Protocol.ServerSendQueryType.EndOfQueryOfMJR:// EndOfQueryOfMJR == last index of member join query result
                                    Qres.Add(response);
                                    //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                    //    MessageBox.Show(Qres[i]);
                                    //
                                    //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                    //
                                    Qres.Clear();
                                    break;
                                case Protocol.ServerSendQueryType.EndOfQueryOfMSR:// EndOfQueryOfMSR == last index of member search result where it will give user(s) info or a hash code of its password or "null" if there is not exist such user
                                    Qres.Add(response);
                                    //for (int i = 0; i < Qres.Count; i++)<!--- Just an example --->
                                    //    MessageBox.Show(Qres[i]);
                                    //
                                    //TODO: this part of switch/case denote that this entry is the last of the requested query result it depends on you to how to hanldle this part, read from saved list to a specific place or .....
                                    //
                                    Qres.Clear();
                                    break;
                                case Protocol.ServerSendQueryType.PublicMessageTitle:
                                    Qres.Add(response);
                                    //
                                    //TODO: public message title which received from server will handle at this part of switch
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.PublicMessageBody:
                                    MessageBox.Show(response, Qres[0], MessageBoxButtons.OK, MessageBoxIcon.Information);//<!-- THIS IS JUST AN EXAMPLE, TO SHOW HOW TO HANDLE MESSAGES -->
                                     
                                     //
                                    //TODO: public message body which received from server will handleat this part of switch
                                    //
                                    Qres.Clear();
                                    break;
                                case Protocol.ServerSendQueryType.PrivateMessageTitle:
                                    Qres.Add(response);
                                    //
                                    //TODO: public message title which received from server will handle this part of switch
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.PrivateMessageBody:
                                    MessageBox.Show(response, Qres[0], MessageBoxButtons.OK, MessageBoxIcon.Information);//<!-- THIS IS JUST AN EXAMPLE, TO SHOW HOW TO HANDLE MESSAGES -->
                                    //
                                    //TODO: private message body which received from server will be handled here!
                                    //
                                    Qres.Clear();
                                    break;
                                case Protocol.ServerSendQueryType.Login://this will check entered user-name and password
                                    if (Convert.ToBoolean(response))
                                    {
                                    }
                                    else
                                    {
                                    }
                                    break;
                                case Protocol.ServerSendQueryType.TreeSearchResult:
                                    Qres.Add(response);
                                    //
                                    //TODO: SEARCH RESULT FOR TREE VIEWING!
                                    //
                                    break;
                                case Protocol.ServerSendQueryType.Unknown://this is for internal programming bug reporter if any thing went wrong we will be noticed by this part of switch(this is just for precaution, a fuction handled this:D)
                                    break;
                            }
                            //
                            //TODO: handle anything else beyond that switch/case 'bout Qres list
                            //
                        }
                        if (response == "END_CON")
                            break;
                    }
                    CurrentConnectionSocket.Close();
                    return;
                }
                catch (InternalNetworkException ine)
                {
                    switch (ine.NetworkSide)
                    {
                        case NetworkExceptionSide.Client:
                            MessageBox.Show(ine.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CurrentConnectionSocket.Close();
                            Application.Exit();
                            break;
                        case NetworkExceptionSide.Server:
                            MessageBox.Show(ine.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CurrentConnectionSocket.Close();
                            break;
                    }
                }
                catch (SocketException) { }
                catch (ObjectDisposedException) { }
                catch (Exception)
                {
                    //TODO: Log the Exception Message ....
                }
            }
        }
    }
}
﻿using System;

namespace Communication
{
    public class CodeAccessException:Exception
    {
        string message;
        Setting.SettingSideOption SSO;
        public override string Message
        {
            get
            {
                return string.IsNullOrEmpty(message) ? "CodeAccessException::\\You have tried to access some code which is unrreachable for you in this circumstance!!" : message;
            }
        }
        public Setting.SettingSideOption SideCodeException
        {
            get
            {
                return SSO;
            }
        }
        public CodeAccessException(String message, Setting.SettingSideOption SSO)
        {
            this.message = message;
            this.SSO = SSO;
        }
        public CodeAccessException(Setting.SettingSideOption SSO)
        {
            this.SSO = SSO;
        }
    }
}

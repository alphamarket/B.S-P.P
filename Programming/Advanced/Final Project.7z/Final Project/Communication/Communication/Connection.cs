﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Communication
{
    namespace Connection
    {
        struct GlobalInfo
        {
            public static System.Windows.Forms.FormClosingEventArgs e = new System.Windows.Forms.FormClosingEventArgs(System.Windows.Forms.CloseReason.None, false);
            public static System.Windows.Forms.FormClosingEventArgs eCopy = new System.Windows.Forms.FormClosingEventArgs(System.Windows.Forms.CloseReason.None, false);
        }
        public abstract class Connection
        {
            protected Socket root;

            protected Socket client;

            protected IPEndPoint thisIPEP, JoinedClientIPEP;

            protected string conStatString;

            protected byte[] data;

            internal bool shuttingDown;

            abstract public IPEndPoint JoinedIPEndPoint
            {
                get;
            }

            abstract public bool IsConnected
            {
                get;
            }

            abstract public string ConnectionStatusString
            {
                set;
                get;
            }

            abstract public IPEndPoint ConnetionIPEP
            {
                get;
                set;
            }

            abstract public Socket CurrentConnectionSocket
            {
                set;
                get;
            }

            protected virtual void SendData_SYNC(IAsyncResult iar) { try { CurrentConnectionSocket = (Socket)iar.AsyncState; CurrentConnectionSocket.EndSend(iar); } catch (ObjectDisposedException) { } catch (SocketException) { } }

            public virtual void SendData(string query) { try { if (CurrentConnectionSocket != null) { CurrentConnectionSocket.BeginSend(Encoding.ASCII.GetBytes(query), 0, query.Length, 0, new AsyncCallback(SendData_SYNC), CurrentConnectionSocket); } else throw new Exception("You have not set a socket root to send demanded data!!"); } catch (ObjectDisposedException) { } catch (StackOverflowException) { System.Windows.Forms.MessageBox.Show("Unable To Send Data ....!", "Oops!"); } }

            static int InfinitRecieve = 0;
            protected bool CheckInfiniteRecive(string Query)//This will check if client has been dicoonected or not, cause as experiences when each side close the connection bye exitting from app' recieve funtion 
            //recieve NULL string which in infinite WHILE it changes to infinite recieve !!! THIS IS ESSETIAL DO NOT DELETE THIS ...
            {
                if (string.IsNullOrEmpty(Query))
                {
                    InfinitRecieve++;
                    if (InfinitRecieve > 50)
                        throw new SocketException();
                    return false;
                }
                else
                    InfinitRecieve = 0;
                return true;
            }
            public static bool IsProgramRestarting()
            {
                if (GlobalInfo.e.CloseReason == System.Windows.Forms.CloseReason.MdiFormClosing)
                {
                    GlobalInfo.e = new System.Windows.Forms.FormClosingEventArgs(System.Windows.Forms.CloseReason.None, false);
                    return true;
                }
                return false;
            }
            protected static bool IsInternalyProgramRestarting()
            {
                if (GlobalInfo.eCopy.CloseReason == System.Windows.Forms.CloseReason.MdiFormClosing)
                {
                    GlobalInfo.eCopy = new System.Windows.Forms.FormClosingEventArgs(System.Windows.Forms.CloseReason.None, false);
                    return true;
                }
                return false;
            }
            public static void RestartApplication()
            {
                GlobalInfo.e = new System.Windows.Forms.FormClosingEventArgs(System.Windows.Forms.CloseReason.MdiFormClosing, true);
                System.Windows.Forms.Application.Restart();
            }
        }
    }
}
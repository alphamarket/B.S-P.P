﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Edit
{
    public class Edit
    {
       public Edit(string username,Communication.Protocol.ClientSendQueryType section)
       {
           switch (section)
           {
               case Communication.Protocol.ClientSendQueryType.EditBookslist:
                   EditBooks EB = new EditBooks();
                   EB.ShowDialog();
                   break;
               case Communication.Protocol.ClientSendQueryType.EditBorrowersList:
                   EditBorrow EBOR = new EditBorrow();
                   EBOR.ShowDialog();
                   break;
               case Communication.Protocol.ClientSendQueryType.EditMembersList:
                   EditMember EM = new EditMember();
                   EM.ShowDialog();
                   break;
               case Communication.Protocol.ClientSendQueryType.EditUserAndPass:
                   EditUP EUP = new EditUP(username);
                   EUP.ShowDialog();
                   break;
           }
       }
    }
}

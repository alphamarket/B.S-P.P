﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace Edit
{
    class EditBooklist : IEdit
    {
        private bool Isupdate = false;
        List<string> UpdateInfo = new List<string>();
        public bool IsUpdate
        {
            get { throw new NotImplementedException(); }
        }

        public void newEdit(string KeyEdit)
        {
            try
            {
                bool StartClean = false;
                int countCleanValue = 0;
                List<string> tmp = new List<string>();
                FileStream FS = new FileStream(Application.StartupPath + @"\Files\DataBase\BookDate.xml", FileMode.Open, FileAccess.Read);
                StreamReader SR = new StreamReader(FS);
                // bool EndClean=false;

                while (!SR.EndOfStream)
                {
                    string KeeplineString = SR.ReadLine().ToString();
                    if (StartClean)
                    {
                        if (countCleanValue == 3)
                        {
                            StartClean = false;
                            countCleanValue = 0;
                        }
                        countCleanValue++;
                        continue;
                    }
                    else
                        if (KeeplineString == "<BookId>" + KeyEdit + "</BookId>")
                        {
                            StartClean = true;
                            continue;
                        }
                        else
                        {
                            UpdateInfo.Add(KeeplineString);
                            tmp.Add(KeeplineString);
                        }
                }
                SR.Close();
                FS.Close();
                SetUpdateInformation();
            }
            catch (Exception ex) { Sundries.MessageBox.ShowMessage(ex.Message); }
        }

        public void SetUpdateInformation()
        {
            try
            {
                FileInfo FI = new FileInfo(Application.StartupPath + @"\Files\DataBase\BookDate.xml");
                if (FI.Exists)
                {
                    FI.Delete();
                }
                StreamWriter SW = new StreamWriter(Application.StartupPath + @"\Files\DataBase\BookDate.xml");
                int j = 0;
                while (UpdateInfo.Count > j)
                {
                    SW.WriteLine(UpdateInfo[j]);
                    j++;
                }
                SW.Close();
                Sundries.MessageBox.ShowMessage("BooksList has been Update....!");
            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }

        }

    }
}

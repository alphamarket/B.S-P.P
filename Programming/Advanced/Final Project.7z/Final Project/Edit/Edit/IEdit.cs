﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Edit
{
    interface IEdit
    {
        
        void newEdit(String KeyEdit);
        void SetUpdateInformation();
    }
}

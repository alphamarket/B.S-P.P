﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Edit
{
    public partial class EditMember : Form
    {
        public EditMember()
        {
            InitializeComponent();
        }
        bool IsAgree = false;
        string keyedit = "";
        private void Delete_Click(object sender, EventArgs e)
        {
            string[] value = new string[1];
            List<string> bookinfo = new List<string>();
            value[0] = KeyEdit.Text;
            Search.Search se = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
            bookinfo = se.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchMember);
            if (bookinfo.Count != 0 && bookinfo.Count != 1)
            {
                keyedit = KeyEdit.Text;
                ITB.Text = bookinfo[0];
                NTB.Text = bookinfo[1];
                WTB.Text = bookinfo[2];
                PTB.Text = bookinfo[3];
                CTB.Text = bookinfo[4];
                ETB.Text = bookinfo[5];
                Address.Text = bookinfo[6];
                IsAgree = false;
                timer1.Enabled = true;
            }
            else
                Sundries.MessageBox.ShowMessage("Student by this Id Not found in data base....!");
        }
        static int x = 131;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!IsAgree)
            {
                this.Size = new Size(522, x);
                x+=5;
                if (x > 440)
                    timer1.Enabled = false;
            }

            else
            {
                this.Size = new Size(522, x);
                x-=3;
                if (x < 120)
                    timer1.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditMemberList EM = new EditMemberList();
            EM.newEdit(keyedit);
            IsAgree = true;
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IsAgree = true;
            timer1.Enabled = true;
        }

        private void EditMember_Load(object sender, EventArgs e)
        {

        }
    }
}

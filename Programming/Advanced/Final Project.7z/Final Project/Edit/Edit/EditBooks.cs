﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Edit
{
    public partial class EditBooks : Form
    {
        public EditBooks()
        {
            InitializeComponent();
        }
        bool IsAgree = false;
        string keyEdit="";
        private void button1_Click(object sender, EventArgs e)
        {
            string[] value=new string[1];
            List<string> bookinfo = new List<string>();
            value[0]=KeyEdit.Text;
            Search.Search se = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);
            bookinfo= se.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBook);
            if (bookinfo.Count != 0 && bookinfo.Count != 1)
            {
                keyEdit = KeyEdit.Text;
                ITB.Text = bookinfo[0];
                NTB.Text = bookinfo[1];
                WTB.Text = bookinfo[2];
                PTB.Text = bookinfo[3];
                CTB.Text = bookinfo[4];
                ETB.Text = bookinfo[5];
                IsAgree = false;
                timer1.Enabled = true;
            }
            else
                Sundries.MessageBox.ShowMessage("Not exist in database this book ...!");
        }
        static int x = 137;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!IsAgree)
            {
                this.Size = new Size(516,x);
                x+=5;
                if (x > 430)
                    timer1.Enabled = false;
            }

            else
            {
                this.Size = new Size(516,x);
                x-=3;
                if (x < 137)
                    timer1.Enabled = false;
            }
               

        }

        private void EditBooks_Load(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditBooklist EB = new EditBooklist();
            EB.newEdit(keyEdit);
            IsAgree = true;
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IsAgree = true;
            timer1.Enabled = true;
        }
        
    }
}

﻿namespace Edit
{
    partial class EditUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditUP));
            this.UPGB = new System.Windows.Forms.GroupBox();
            this.Save = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CoPassTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.NpassTB = new System.Windows.Forms.TextBox();
            this.NUserNameTB = new System.Windows.Forms.TextBox();
            this.PassTB = new System.Windows.Forms.TextBox();
            this.UserNameTB = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.UPGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // UPGB
            // 
            this.UPGB.BackColor = System.Drawing.Color.DimGray;
            this.UPGB.Controls.Add(this.Save);
            this.UPGB.Controls.Add(this.button2);
            this.UPGB.Controls.Add(this.label7);
            this.UPGB.Controls.Add(this.label6);
            this.UPGB.Controls.Add(this.label5);
            this.UPGB.Controls.Add(this.label4);
            this.UPGB.Controls.Add(this.label3);
            this.UPGB.Controls.Add(this.CoPassTB);
            this.UPGB.Controls.Add(this.label2);
            this.UPGB.Controls.Add(this.UserName);
            this.UPGB.Controls.Add(this.NpassTB);
            this.UPGB.Controls.Add(this.NUserNameTB);
            this.UPGB.Controls.Add(this.PassTB);
            this.UPGB.Controls.Add(this.UserNameTB);
            this.UPGB.Controls.Add(this.pictureBox1);
            this.UPGB.Location = new System.Drawing.Point(1, 5);
            this.UPGB.Name = "UPGB";
            this.UPGB.Size = new System.Drawing.Size(323, 350);
            this.UPGB.TabIndex = 0;
            this.UPGB.TabStop = false;
            this.UPGB.Text = "Edit User And Password";
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(247, 322);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(56, 23);
            this.Save.TabIndex = 6;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(187, 321);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Conform pass";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "New Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "New UserName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "User Name";
            // 
            // CoPassTB
            // 
            this.CoPassTB.ForeColor = System.Drawing.Color.Black;
            this.CoPassTB.Location = new System.Drawing.Point(105, 287);
            this.CoPassTB.Name = "CoPassTB";
            this.CoPassTB.Size = new System.Drawing.Size(198, 20);
            this.CoPassTB.TabIndex = 4;
            this.CoPassTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(102, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "User";
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.Location = new System.Drawing.Point(100, 44);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(69, 17);
            this.UserName.TabIndex = 13;
            this.UserName.Text = "User Name";
            // 
            // NpassTB
            // 
            this.NpassTB.ForeColor = System.Drawing.Color.Black;
            this.NpassTB.Location = new System.Drawing.Point(105, 243);
            this.NpassTB.Name = "NpassTB";
            this.NpassTB.Size = new System.Drawing.Size(198, 20);
            this.NpassTB.TabIndex = 3;
            this.NpassTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NUserNameTB
            // 
            this.NUserNameTB.ForeColor = System.Drawing.Color.Black;
            this.NUserNameTB.Location = new System.Drawing.Point(105, 203);
            this.NUserNameTB.Name = "NUserNameTB";
            this.NUserNameTB.Size = new System.Drawing.Size(198, 20);
            this.NUserNameTB.TabIndex = 2;
            this.NUserNameTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PassTB
            // 
            this.PassTB.ForeColor = System.Drawing.Color.Black;
            this.PassTB.Location = new System.Drawing.Point(105, 168);
            this.PassTB.Name = "PassTB";
            this.PassTB.Size = new System.Drawing.Size(198, 20);
            this.PassTB.TabIndex = 1;
            this.PassTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UserNameTB
            // 
            this.UserNameTB.ForeColor = System.Drawing.Color.Black;
            this.UserNameTB.Location = new System.Drawing.Point(105, 133);
            this.UserNameTB.Name = "UserNameTB";
            this.UserNameTB.Size = new System.Drawing.Size(198, 20);
            this.UserNameTB.TabIndex = 0;
            this.UserNameTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // EditUP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(327, 360);
            this.Controls.Add(this.UPGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EditUP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Username And Password";
            this.UPGB.ResumeLayout(false);
            this.UPGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox UPGB;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CoPassTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label UserName;
        private System.Windows.Forms.TextBox NpassTB;
        private System.Windows.Forms.TextBox NUserNameTB;
        private System.Windows.Forms.TextBox PassTB;
        private System.Windows.Forms.TextBox UserNameTB;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
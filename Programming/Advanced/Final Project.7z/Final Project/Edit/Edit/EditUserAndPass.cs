﻿using System.Xml;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Edit
{
    class EditUserAndPass : IEdit
    {
        List<string> updateinfo = new List<string>();
        public void newEdit(string KeyEdit)
        {
            bool isupdate=false;
            List<string> tmp = new List<string>();
            int count2 = 0;
            XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml");
            string[] value;
            value = KeyEdit.Split(',');
            try
            {
                int count = 0;
                while (reader.Read())
                {
                    if (count2 != 0)
                    {
                        count2 = 0;
                        updateinfo.Clear();
                        for (int i = 0; i < tmp.Count - 2; i++)
                        {
                            updateinfo.Add(tmp[i]);
                            

                        }
                        isupdate = true;
                        updateinfo.Add(value[2]);
                        updateinfo.Add(value[3]);
                    }
                    if (count != 0)
                    {
                        if (reader.NodeType == XmlNodeType.Text)
                        {
                            if (reader.Value == value[1])
                                count2++;
                            count = 0;
                        }
                    }
                    if (reader.NodeType == XmlNodeType.Text)
                    {
                        if (reader.Value == value[0])
                            count++;
                    }
                    if (reader.NodeType == XmlNodeType.Text)
                    {
                        updateinfo.Add(reader.Value);
                        tmp.Add(reader.Value);
                    }
                }
                reader.Close();
                if(isupdate)
                    SetUpdateInformation();
                else
                    Sundries.MessageBox.ShowMessage("this username and pass not found in database...!");

            }
            catch
            {

            }
            finally
            {
                reader.Close();
            }
        }

        public void SetUpdateInformation()
        {
            XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml", null);
            objXmlTextWriter.Formatting = Formatting.Indented;
            objXmlTextWriter.WriteStartDocument();
            objXmlTextWriter.WriteStartElement("AllUserAndPass");
            int j = 0;
            while (j < updateinfo.Count)
            {
                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartElement("UserName");
                objXmlTextWriter.WriteString(updateinfo[j].ToString());
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteStartElement("passName");
                objXmlTextWriter.WriteString(updateinfo[j + 1].ToString());
                objXmlTextWriter.WriteEndElement();
                j += 2;
            }
            objXmlTextWriter.WriteEndDocument();
            objXmlTextWriter.Flush();
            objXmlTextWriter.Close();
            Sundries.MessageBox.ShowMessage("Change UserName And Pass successfully....!");
        }
    }
}

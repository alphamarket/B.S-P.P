﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Edit
{
    public partial class EditUP : Form
    {
        public EditUP(string username)
        {
            InitializeComponent();
            UserName.Text = username;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            bool state=false;
            string tmp = "";
            foreach (Control con in UPGB.Controls)
            {
                if(con is TextBox)
                    if (con.Text == "")
                    {
                        con.Text = "Please fill  where ....!";
                        state = true;
                        tmp = "Empity TextBox Not Valid....! ";
                    }
            }
            if (NpassTB.Text != CoPassTB.Text)
            {
                NpassTB.Text = "";
                CoPassTB.Text = "PLEASE ENTER CARFULL";
                state = true;
                tmp="   must be equal value of newpass and conform TextBox...!";
            }
            if (!state)
            {
                EditUserAndPass EUP = new EditUserAndPass();
                EUP.newEdit(UserNameTB.Text + "," + PassTB.Text + "," + NUserNameTB.Text + "," + NpassTB.Text);
            }
            else
            {
                Sundries.MessageBox.ShowMessage(tmp);
            }

            
        }

       
        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}

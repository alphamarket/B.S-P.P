﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;

namespace Edit
{
  public class EditBorrwList : IEdit
    {
        private bool Isupdate = false;
        List<string> UpdateInfo = new List<string>();
        public bool IsUpdate
        {
            get { return Isupdate; }
        }

        public void newEdit(string KeyEdit)
        {
            try
            {
                bool StartClean = false;
                int countCleanValue = 0;
                List<string> tmp = new List<string>();
                // bool EndClean=false;
                XmlTextReader XMLR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowlist.xml");
                while (XMLR.Read())
                {
                    if (StartClean)
                    {
                        if (XMLR.NodeType == XmlNodeType.Text)
                        {
                            if (countCleanValue == 0)
                            {
                                StartClean = false;
                                countCleanValue = 0;
                                UpdateInfo.Clear();
                                for (int i = 0; i < tmp.Count - 6; i++)
                                {
                                    UpdateInfo.Add(tmp[i]);
                                }
                            }
                            countCleanValue++;
                            continue;
                        }
                    }
                    else
                        if (XMLR.NodeType == XmlNodeType.Text)
                            if (XMLR.Value == KeyEdit)
                            {
                                StartClean = true;
                                continue;
                            }
                            else
                            {
                                UpdateInfo.Add(XMLR.Value);
                                tmp.Add(XMLR.Value);
                            }
                }
                XMLR.Close();
                SetUpdateInformation();

            }
            catch {Sundries.MessageBox.ShowMessage("The Borrowlist Info Update  failed ..."); }
        }

        public void SetUpdateInformation()
        {

            try
            {
                int count1 = 1;
                XmlTextWriter xmlW = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\borrowlist.xml", null);
                xmlW.Formatting = Formatting.Indented;
                xmlW.WriteStartDocument();
                xmlW.WriteStartElement("ListBorrowed");
                for (int i = 0; i < UpdateInfo.Count; i += 8)
                {

                    xmlW.WriteStartElement("Borrowing");
                    xmlW.WriteStartElement("BookName");
                    xmlW.WriteString(UpdateInfo[i]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("BookId");
                    xmlW.WriteString(UpdateInfo[i + 1]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("Date");
                    xmlW.WriteStartElement("BorrowDate");
                    xmlW.WriteStartElement("Year");
                    xmlW.WriteString(UpdateInfo[i + 2]);
                    xmlW.WriteEndElement();
                    xmlW.WriteStartElement("Month");
                    xmlW.WriteString(UpdateInfo[i + 3]);
                    xmlW.WriteEndElement();
                    xmlW.WriteStartElement("Day");
                    xmlW.WriteString(UpdateInfo[i + 4]);
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("ReturnDate");
                    xmlW.WriteString(UpdateInfo[i + 5]);
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("borrowserID");
                    xmlW.WriteString(UpdateInfo[i + 6]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("borrowserName");
                    xmlW.WriteString(UpdateInfo[i + 7]);
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    count1++;
                }
                xmlW.WriteEndElement();
                xmlW.WriteEndDocument();
                xmlW.Flush();
                xmlW.Close();
                Sundries.MessageBox.ShowMessage("The Borrowlist Info Update  successfully ...");

            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }
        }
    }
}

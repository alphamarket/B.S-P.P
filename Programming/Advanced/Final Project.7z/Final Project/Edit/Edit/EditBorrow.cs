﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Edit
{
    public partial class EditBorrow : Form
    {
        public EditBorrow()
        {
            InitializeComponent();
        }
        string keyedit;
        bool IsAgree = false;
        private void Delete_Click(object sender, EventArgs e)
        {
             string[] value = new string[1];
             value[0] = KeyEdit.Text;
             List<string> borrowerinfo = new List<string>();
            Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
            borrowerinfo=search.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBorrower);
            if (borrowerinfo.Count != 0 && borrowerinfo.Count != 1)
            {
                keyedit = KeyEdit.Text;
                ITB.Text = borrowerinfo[0];
                NTB.Text = borrowerinfo[1];
                WTB.Text = borrowerinfo[2];
                PTB.Text = borrowerinfo[3];
                CTB.Text = borrowerinfo[4];
                ETB.Text = borrowerinfo[5];
                IsAgree = false;
                timer1.Enabled = true;
            }
            else
                Sundries.MessageBox.ShowMessage("Not exist student by this ID in Borrowlist...!");
        }

        static int x = 115;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!IsAgree)
            {
                this.Size = new Size(550, x);
                x+=5;
                if (x > 420)
                    timer1.Enabled = false;
            }

            else
            {
                this.Size = new Size(550, x);
                x-=2;
                if (x < 115)
                    timer1.Enabled = false;
            }
        }

        private void EditBorrow_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditBorrwList EBL = new EditBorrwList();
            EBL.newEdit(keyedit);
            IsAgree = true;
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IsAgree = true;
            timer1.Enabled = true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;


namespace Edit
{
    class EditMemberList : IEdit
    {
        private bool Isupdate = false;
        List<string> UpdateInfo = new List<string>();
        public bool IsUpdate
        {
            get { return Isupdate; }
        }
        public void newEdit(string KeyEdit)
        {
            try
            {
                bool StartClean = false;
                int countCleanValue = 0;
                List<string> tmp = new List<string>();
                // bool EndClean=false;
                XmlTextReader XMLR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml");
                while (XMLR.Read())
                {
                    if (StartClean)
                    {
                        if (XMLR.NodeType == XmlNodeType.Text)
                        {
                            if (countCleanValue == 4)
                            {
                                StartClean = false;
                                countCleanValue = 0;
                                UpdateInfo.Clear();
                                for (int i = 0; i < tmp.Count - 2; i++)
                                {
                                    UpdateInfo.Add(tmp[i]);
                                }
                            }
                            countCleanValue++;
                            continue;
                        }
                    }
                    else
                        if (XMLR.NodeType == XmlNodeType.Text)
                            if (XMLR.Value == KeyEdit)
                            {
                                StartClean = true;
                                continue;
                            }
                            else
                            {
                                UpdateInfo.Add(XMLR.Value);
                                tmp.Add(XMLR.Value);
                            }
                }
                XMLR.Close();
                SetUpdateInformation();
                //SetData.SetData.SetNewData("",UpdateInfo,Communication.Protocol.ClientSendQueryType.JoinMember);
                //Sundries.MessageBox.ShowMessage("The Members Info Update  successfully ...");
            }
            catch { Sundries.MessageBox.ShowMessage("The Members Info Update  failed ..."); }

        }
        public void SetUpdateInformation()
        {
            XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml", null);
            objXmlTextWriter.Formatting = Formatting.Indented;
            int j = 0;
            objXmlTextWriter.WriteStartDocument();
            objXmlTextWriter.WriteStartElement("Member");
            while (j < UpdateInfo.Count)
            {
                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartElement("Name");
                objXmlTextWriter.WriteString(UpdateInfo[j].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("LastName");
                objXmlTextWriter.WriteString(UpdateInfo[j + 1].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("IdStudent");
                objXmlTextWriter.WriteString(UpdateInfo[j + 2].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("UserName");
                objXmlTextWriter.WriteString(UpdateInfo[j + 3].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("PassWord");
                objXmlTextWriter.WriteString(UpdateInfo[j + 4].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("PhoneNumber");
                objXmlTextWriter.WriteString(UpdateInfo[j + 5].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("Address");
                objXmlTextWriter.WriteString(UpdateInfo[j + 6].ToString());
                objXmlTextWriter.WriteEndElement();
                //
                objXmlTextWriter.WriteStartElement("Rank");
                objXmlTextWriter.WriteString(UpdateInfo[j + 7].ToString());
                objXmlTextWriter.WriteEndElement();
                j += 8;

            }
            objXmlTextWriter.WriteEndDocument();
            objXmlTextWriter.Flush();
            objXmlTextWriter.Close();
            SetData.SetUser_Pass set = new SetData.SetUser_Pass();
            set.setNew_User_Password();
            Isupdate = true;
            Sundries.MessageBox.ShowMessage("The Members Info Update  successfully ...");
        }
    }
}

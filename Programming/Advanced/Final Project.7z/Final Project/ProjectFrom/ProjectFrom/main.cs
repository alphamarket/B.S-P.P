﻿using System;
using System.Windows.Forms;
using Communication;
using Communication.Connection;
using Communication.ConnectionInfo;
using System.Xml;
using System.Collections.Generic;
struct GlobalInfo
{
    public static bool IsAdmin = false;
}
namespace Server
{
    internal partial class main : Form
    {
        public main()
        {
            InitializeComponent();
            Server.ReturnDate.Load(ref numericUpDown1);
            Application.DoEvents();
            Sundries.Opacity.OpacityOpen(this);
            if (numericUpDown1.Value != 1) Save.Enabled = false;
        }
        public void ConnectionChecker()
        {
            while (true)
            {
                while (StaticConnectionInfo.ConnectionRootMode != ConnectionMode.Disconnected)
                {
                    System.Threading.Thread.Sleep(5000);
                }
                StaticConnectionInfo.ServerConnectionRoot = new ServerConnection(StaticConnectionInfo.ConnectionEndPointInfo, ntwrkStatus,
                    new ServerConnection.DisconnectFuction(disconnectToolStripMenuItem_Click), new ServerConnection.ConnectFuction(connectToAClientToolStripMenuItem_Click));
                System.Threading.Thread.Sleep(5000);
            }
        }

        private void networkSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NetworkSetting aForm = new NetworkSetting(Communication.Setting.SettingOptions.NotFirstTime, NetworkExceptionSide.Server);
            aForm.ShowDialog();
        }

        private void connectToAClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (StaticConnectionInfo.ServerConnectionRoot == null)
                    StaticConnectionInfo.ServerConnectionRoot = new ServerConnection(StaticConnectionInfo.ConnectionEndPointInfo, ntwrkStatus,
                        new ServerConnection.DisconnectFuction(disconnectToolStripMenuItem_Click),
                        new ServerConnection.ConnectFuction(connectToAClientToolStripMenuItem_Click));
            }
            catch (InternalNetworkException ine)
            {
                MessageBox.Show(ine.Message, "Oops!");
            }
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (StaticConnectionInfo.ServerConnectionRoot != null)
                    StaticConnectionInfo.ServerConnectionRoot.Disconnect(true);
            }
            catch (Communication.InternalNetworkException ine)
            {
                MessageBox.Show(ine.Message);
            }
            catch (Exception) { }
        }
        private void publicMessageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (StaticConnectionInfo.ConnectionRootMode != ConnectionMode.Connected)
            {
                MessageBox.Show("Your network did not well-connected, check your network environment, and network options/connection");
                return;
            }
            Messenger frm = new Messenger(MessageType.Public);
            frm.ShowDialog();
        }

        private void connectionStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(StaticConnectionInfo.ServerConnectionRoot.ConnectionStatusString, "Connetion Status Reporter...", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disconnectToolStripMenuItem_Click(sender, e);
            Application.Exit();
        }
        private void hiddenMessageToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void main_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                StaticConnectionInfo.ServerConnectionRoot.Disconnect(false);
            }
            catch (Exception) { }
            if (Communication.Connection.Connection.IsProgramRestarting())
            {
                Application.Restart();
            }
            else
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }
        }

        private void joinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LocalLibrary.JoinNewMember LocalLibrary = new LocalLibrary.JoinNewMember();
            LocalLibrary.Show();
        }

        private void breakOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Edit.Edit obj = new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditMembersList);
        }

        private void searchToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Search.Member_L_Search obj = new Search.Member_L_Search();
            obj.ShowDialog();
        }

        private void amanatDadanToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            BorrowBook frm = new BorrowBook();
            frm.Show();
        }

        private void pasGerftanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditBorrowersList);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Communication.Connection.Connection.RestartApplication();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now.AddDays((double)numericUpDown1.Value);
            DateCount.Text = "Return Date Will Be :           " + dt.Date.Year + " / " + dt.Date.Month + " / " + dt.Date.Day;
            Save.Enabled = true;
        }

        private void main_Load(object sender, EventArgs e)
        {
            connectToAClientToolStripMenuItem_Click(new object(), new EventArgs());
            numericUpDown1_ValueChanged(new object(), new EventArgs());
            TodayDateLabel.Text += "           " + DateTime.Now.Year + " / " + DateTime.Now.Month + " / " + DateTime.Now.Day;
            DayNews.PersonTarydy PT = new DayNews.PersonTarydy();
            Sundries.DataGridViewSetting.InitializeDataGrid(PT.TrydyInfo, ref DayNewsDG, 0);
        }

        private void DateCount_Click(object sender, EventArgs e)
        {

        }

        private void ReturnsTabBookID_KeyDown(object sender, KeyEventArgs e)
        {
            //
            //SEARCH DEMANDED BOOK ID 
            //
        }

        private void dataGridView4_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            //
            //DELETE DELETED ROW BOOK FROM BORROW LIST
            //
        }

        private void BorrowBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(string.IsNullOrEmpty(textBox2.Text) && string.IsNullOrEmpty(textBox3.Text)))
                {
                    Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);

                    System.Collections.Generic.List<string> res = search.newsearch(new string[] { textBox2.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);

                    if (res.Count != 0)
                    {
                        LibraryTransactionSystem.BookStatus bs = new LibraryTransactionSystem.BookStatus(res[0]);
                        if (!bs.IsBorrow)
                        {
                            DateTime dt = DateTime.Now.AddDays((double)numericUpDown1.Value);
                            System.Collections.Generic.List<string> brw = new System.Collections.Generic.List<string>(5);
                            brw.Add(textBox1.Text);
                            brw.Add(textBox2.Text);
                            brw.Add(dt.Date.Year + " / " + dt.Date.Month + " / " + dt.Date.Day);
                            brw.Add(textBox3.Text);
                            brw.Add(textBox3.Text);
                            LibraryTransactionSystem.Deposit dpst = new LibraryTransactionSystem.Deposit();
                            dpst.BorrowBook(brw);
                            Sundries.MessageBox.ShowMessage("The book has put in library borrow list successfully ...");
                        }
                        else
                            Sundries.MessageBox.ShowMessage("This book has been borrowed already ...");
                        ClrBtn_Click(ClrBtn_f1, e);
                    }
                    else
                    {
                        Sundries.MessageBox.ShowMessage("Book with this 'Book ID' has not found !");
                    }
                }
                else
                    Sundries.MessageBox.ShowMessage("Please fill '<-Ciritical->' fields");
            }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }

        private void addBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Server.AddBook addbook = new Server.AddBook();
            addbook.Show();
        }

        private void filterQueryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Server.QueryFiltering aForm = new QueryFiltering(QueryFiltering.Filter.Query);
            aForm.Show();
        }

        private void ClrBtn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            foreach (Control i in btn.Parent.Controls)
            {
                if (i is TextBox)
                {
                    i.Text = "";
                }
            }
        }

        private void returnBtn_Click(object sender, EventArgs e)
        {
            if (keyEdit.Text == "" || textBox7.Text == "")
            {
                Sundries.MessageBox.ShowMessage("Please fill '<-Ciritical->' fields");
                return;
            }
            //
            //Check kon bebin in ketab be amant borde shode ya na(lazem nis bebini ke 2 liste ketaba hast ya na!);
            //
            string[] value1 = new string[1];
            value1[0] = textBox7.Text;
            List<string> borrowerinfo = new List<string>();
            Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
            borrowerinfo = search.newsearch(value1, Communication.Protocol.ClientSendQueryType.SearchBorrower);
            if (borrowerinfo.Count != 0 && borrowerinfo.Count != 1)
            {

                Edit.EditBorrwList EBL = new Edit.EditBorrwList();
                EBL.newEdit(textBox7.Text);
                //Sundries.MessageBox.ShowMessage("This Book Not Exist In DataBase...! ");
            }
            else
                Sundries.MessageBox.ShowMessage("This Book Not Exist In DataBase...! ");
            
            ClrBtn_Click(ClrBtn_f2, e);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aForm = new About();
            aForm.Show();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            ReturnDate.Save(numericUpDown1.Value.ToString());
            Save.Enabled = false;
        }

        private void main_Activated(object sender, EventArgs e)
        {
            ReturnDate.Load(ref numericUpDown1);
            Save.Enabled = false;
            DayNews.PersonTarydy PT = new DayNews.PersonTarydy();
            Sundries.DataGridViewSetting.InitializeDataGrid(PT.TrydyInfo, ref DayNewsDG, 0);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Edit.Edit obj = new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditBookslist);
        }

        private void searchLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search.Search_L_Form1 obj = new Search.Search_L_Form1();
            obj.ShowDialog();
        }

        private void filterUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Server.QueryFiltering aForm = new QueryFiltering(QueryFiltering.Filter.User);
            aForm.Show();
        }
    }
}
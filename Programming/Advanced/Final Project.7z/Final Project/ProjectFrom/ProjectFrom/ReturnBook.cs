﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Server
{
    internal partial class ReturnBook : Form
    {
        public ReturnBook()
        {
            InitializeComponent();
        }

        private void clrBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i  in this.Controls)
            {
                if (i is TextBox)
                    i.Text = "";
            }
        }

        private void rtrnBtn_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "" && textBox3.Text != "")
            {
                throw new NotImplementedException();
            }
            else
                Sundries.MessageBox.ShowMessage("Please enter '<-Ciritical->' fields");
        }
    }
}

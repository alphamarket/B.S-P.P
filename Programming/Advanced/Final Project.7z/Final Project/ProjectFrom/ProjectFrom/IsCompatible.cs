﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LocalLibrary
{
    public partial class IsCompatible : Form
    {
        public IsCompatible(string name, string Id, string Writer,string Poblisher, string category,string  explanation)
        {
            InitializeComponent();
            textBox1.Text = category;
            textBox2.Text = name;
            textBox3.Text = Id;
            textBox4.Text = Poblisher;
            textBox6.Text = Writer;
            textBox5.Text = explanation;
        }
        private bool isagree=false;
        public bool IsAgree { get { return isagree; } }
        private void button1_Click(object sender, EventArgs e)
        {
            isagree=true;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             isagree=false;
            this.Close();
        }
        public IsCompatible(string rank, string id, string name, string lastname, string username, string pass, string phoneN, string address)
        {
            InitializeComponent();
            InitializeForm IF = new InitializeForm(this,  panel1, false, panel3, true, 0, 0);
            panel1.Visible = false;
            Rank.Text = rank; IdTB.Text = id; NameTB.Text = name; LNameTB.Text = lastname; UNameTB.Text = username; PassTB.Text = pass; PhoneNTB.Text = phoneN; AddressTB.Text = address;
           
        }
        private void IsCompatible_Load(object sender, EventArgs e)
        {

        }


       
    }
}

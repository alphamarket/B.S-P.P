﻿namespace Server
{
    partial class NetworkSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NetworkSetting));
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.AdminInfo = new System.Windows.Forms.Button();
            this.dltBtn = new System.Windows.Forms.Button();
            this.ClntSidRB = new System.Windows.Forms.RadioButton();
            this.SrvrSidRB = new System.Windows.Forms.RadioButton();
            this.ClntGB = new System.Windows.Forms.GroupBox();
            this.clntCkbx = new System.Windows.Forms.CheckBox();
            this.clntPortNotifiaction = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.clntIP1 = new System.Windows.Forms.TextBox();
            this.clntPort = new System.Windows.Forms.TextBox();
            this.clntIP4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.clntIP3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.clntIP2 = new System.Windows.Forms.TextBox();
            this.SrvrGB = new System.Windows.Forms.GroupBox();
            this.SrvrAnyRB = new System.Windows.Forms.RadioButton();
            this.SrvrLcalHstRB = new System.Windows.Forms.RadioButton();
            this.srvrCstmRb = new System.Windows.Forms.RadioButton();
            this.SrvrCstmGB = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.srvrIP1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.srvrIP2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.srvrIP3 = new System.Windows.Forms.TextBox();
            this.srvrIP4 = new System.Windows.Forms.TextBox();
            this.UndoBtn = new System.Windows.Forms.Button();
            this.CnclBtn = new System.Windows.Forms.Button();
            this.ClrFldBtn = new System.Windows.Forms.Button();
            this.SetBtn = new System.Windows.Forms.Button();
            this.srvrCkbx = new System.Windows.Forms.CheckBox();
            this.portNotificationLabel = new System.Windows.Forms.Label();
            this.srvrPort = new System.Windows.Forms.TextBox();
            this.groupBox8.SuspendLayout();
            this.ClntGB.SuspendLayout();
            this.SrvrGB.SuspendLayout();
            this.SrvrCstmGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.AdminInfo);
            this.groupBox8.Controls.Add(this.dltBtn);
            this.groupBox8.Controls.Add(this.ClntSidRB);
            this.groupBox8.Controls.Add(this.SrvrSidRB);
            this.groupBox8.Controls.Add(this.ClntGB);
            this.groupBox8.Controls.Add(this.SrvrGB);
            this.groupBox8.Controls.Add(this.UndoBtn);
            this.groupBox8.Controls.Add(this.CnclBtn);
            this.groupBox8.Controls.Add(this.ClrFldBtn);
            this.groupBox8.Controls.Add(this.SetBtn);
            this.groupBox8.Location = new System.Drawing.Point(12, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(620, 356);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Network setting";
            // 
            // AdminInfo
            // 
            this.AdminInfo.Location = new System.Drawing.Point(499, 320);
            this.AdminInfo.Name = "AdminInfo";
            this.AdminInfo.Size = new System.Drawing.Size(110, 23);
            this.AdminInfo.TabIndex = 15;
            this.AdminInfo.Text = "Change Admin Info";
            this.AdminInfo.UseVisualStyleBackColor = true;
            this.AdminInfo.Click += new System.EventHandler(this.AdminInfo_Click);
            // 
            // dltBtn
            // 
            this.dltBtn.Location = new System.Drawing.Point(325, 320);
            this.dltBtn.Name = "dltBtn";
            this.dltBtn.Size = new System.Drawing.Size(83, 23);
            this.dltBtn.TabIndex = 14;
            this.dltBtn.Text = "Reset Setting";
            this.dltBtn.UseVisualStyleBackColor = true;
            this.dltBtn.Click += new System.EventHandler(this.dltBtn_Click);
            // 
            // ClntSidRB
            // 
            this.ClntSidRB.AutoSize = true;
            this.ClntSidRB.Location = new System.Drawing.Point(6, 212);
            this.ClntSidRB.Name = "ClntSidRB";
            this.ClntSidRB.Size = new System.Drawing.Size(92, 17);
            this.ClntSidRB.TabIndex = 13;
            this.ClntSidRB.Text = "On Client Side";
            this.ClntSidRB.UseVisualStyleBackColor = true;
            this.ClntSidRB.CheckedChanged += new System.EventHandler(this.ClntSidRB_CheckedChanged);
            // 
            // SrvrSidRB
            // 
            this.SrvrSidRB.AutoSize = true;
            this.SrvrSidRB.Checked = true;
            this.SrvrSidRB.Location = new System.Drawing.Point(6, 27);
            this.SrvrSidRB.Name = "SrvrSidRB";
            this.SrvrSidRB.Size = new System.Drawing.Size(95, 17);
            this.SrvrSidRB.TabIndex = 12;
            this.SrvrSidRB.TabStop = true;
            this.SrvrSidRB.Text = "On server Side";
            this.SrvrSidRB.UseVisualStyleBackColor = true;
            this.SrvrSidRB.CheckedChanged += new System.EventHandler(this.SrvrSidRB_CheckedChanged);
            // 
            // ClntGB
            // 
            this.ClntGB.Controls.Add(this.clntCkbx);
            this.ClntGB.Controls.Add(this.clntPortNotifiaction);
            this.ClntGB.Controls.Add(this.label5);
            this.ClntGB.Controls.Add(this.clntIP1);
            this.ClntGB.Controls.Add(this.clntPort);
            this.ClntGB.Controls.Add(this.clntIP4);
            this.ClntGB.Controls.Add(this.label7);
            this.ClntGB.Controls.Add(this.clntIP3);
            this.ClntGB.Controls.Add(this.label9);
            this.ClntGB.Controls.Add(this.label8);
            this.ClntGB.Controls.Add(this.clntIP2);
            this.ClntGB.Enabled = false;
            this.ClntGB.Location = new System.Drawing.Point(6, 232);
            this.ClntGB.Name = "ClntGB";
            this.ClntGB.Size = new System.Drawing.Size(603, 82);
            this.ClntGB.TabIndex = 12;
            this.ClntGB.TabStop = false;
            // 
            // clntCkbx
            // 
            this.clntCkbx.AutoSize = true;
            this.clntCkbx.Location = new System.Drawing.Point(6, 41);
            this.clntCkbx.Name = "clntCkbx";
            this.clntCkbx.Size = new System.Drawing.Size(172, 17);
            this.clntCkbx.TabIndex = 22;
            this.clntCkbx.Text = "Set Connection Port: (Optional)";
            this.clntCkbx.UseVisualStyleBackColor = true;
            this.clntCkbx.CheckedChanged += new System.EventHandler(this.clntCkbx_CheckedChanged);
            // 
            // clntPortNotifiaction
            // 
            this.clntPortNotifiaction.AutoSize = true;
            this.clntPortNotifiaction.Location = new System.Drawing.Point(262, 42);
            this.clntPortNotifiaction.Name = "clntPortNotifiaction";
            this.clntPortNotifiaction.Size = new System.Drawing.Size(335, 13);
            this.clntPortNotifiaction.TabIndex = 21;
            this.clntPortNotifiaction.Text = "If you set this you should have exactly set this on server side program ";
            this.clntPortNotifiaction.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Connect to this server";
            // 
            // clntIP1
            // 
            this.clntIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clntIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.clntIP1.Location = new System.Drawing.Point(179, 14);
            this.clntIP1.MaxLength = 3;
            this.clntIP1.Name = "clntIP1";
            this.clntIP1.Size = new System.Drawing.Size(33, 20);
            this.clntIP1.TabIndex = 12;
            this.clntIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // clntPort
            // 
            this.clntPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clntPort.Enabled = false;
            this.clntPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.clntPort.Location = new System.Drawing.Point(196, 40);
            this.clntPort.MaxLength = 5;
            this.clntPort.Name = "clntPort";
            this.clntPort.Size = new System.Drawing.Size(49, 20);
            this.clntPort.TabIndex = 19;
            this.clntPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clntPort.Enter += new System.EventHandler(this.srvrPort_Enter);
            this.clntPort.Leave += new System.EventHandler(this.srvrPort_Leave);
            // 
            // clntIP4
            // 
            this.clntIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clntIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.clntIP4.Location = new System.Drawing.Point(344, 14);
            this.clntIP4.MaxLength = 3;
            this.clntIP4.Name = "clntIP4";
            this.clntIP4.Size = new System.Drawing.Size(33, 20);
            this.clntIP4.TabIndex = 15;
            this.clntIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(328, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = ".";
            // 
            // clntIP3
            // 
            this.clntIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clntIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.clntIP3.Location = new System.Drawing.Point(289, 14);
            this.clntIP3.MaxLength = 3;
            this.clntIP3.Name = "clntIP3";
            this.clntIP3.Size = new System.Drawing.Size(33, 20);
            this.clntIP3.TabIndex = 14;
            this.clntIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(218, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = ".";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(273, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = ".";
            // 
            // clntIP2
            // 
            this.clntIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clntIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.clntIP2.Location = new System.Drawing.Point(234, 14);
            this.clntIP2.MaxLength = 3;
            this.clntIP2.Name = "clntIP2";
            this.clntIP2.Size = new System.Drawing.Size(33, 20);
            this.clntIP2.TabIndex = 13;
            this.clntIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SrvrGB
            // 
            this.SrvrGB.Controls.Add(this.srvrCkbx);
            this.SrvrGB.Controls.Add(this.portNotificationLabel);
            this.SrvrGB.Controls.Add(this.srvrPort);
            this.SrvrGB.Controls.Add(this.SrvrAnyRB);
            this.SrvrGB.Controls.Add(this.SrvrLcalHstRB);
            this.SrvrGB.Controls.Add(this.srvrCstmRb);
            this.SrvrGB.Controls.Add(this.SrvrCstmGB);
            this.SrvrGB.Location = new System.Drawing.Point(6, 50);
            this.SrvrGB.Name = "SrvrGB";
            this.SrvrGB.Size = new System.Drawing.Size(603, 156);
            this.SrvrGB.TabIndex = 11;
            this.SrvrGB.TabStop = false;
            // 
            // SrvrAnyRB
            // 
            this.SrvrAnyRB.AutoSize = true;
            this.SrvrAnyRB.Location = new System.Drawing.Point(342, 97);
            this.SrvrAnyRB.Name = "SrvrAnyRB";
            this.SrvrAnyRB.Size = new System.Drawing.Size(244, 17);
            this.SrvrAnyRB.TabIndex = 12;
            this.SrvrAnyRB.TabStop = true;
            this.SrvrAnyRB.Text = "Accept any connection at program default port";
            this.SrvrAnyRB.UseVisualStyleBackColor = true;
            // 
            // SrvrLcalHstRB
            // 
            this.SrvrLcalHstRB.AutoSize = true;
            this.SrvrLcalHstRB.Location = new System.Drawing.Point(6, 97);
            this.SrvrLcalHstRB.Name = "SrvrLcalHstRB";
            this.SrvrLcalHstRB.Size = new System.Drawing.Size(89, 17);
            this.SrvrLcalHstRB.TabIndex = 11;
            this.SrvrLcalHstRB.TabStop = true;
            this.SrvrLcalHstRB.Text = "Use localhost";
            this.SrvrLcalHstRB.UseVisualStyleBackColor = true;
            // 
            // srvrCstmRb
            // 
            this.srvrCstmRb.AutoSize = true;
            this.srvrCstmRb.Location = new System.Drawing.Point(6, 19);
            this.srvrCstmRb.Name = "srvrCstmRb";
            this.srvrCstmRb.Size = new System.Drawing.Size(60, 17);
            this.srvrCstmRb.TabIndex = 10;
            this.srvrCstmRb.TabStop = true;
            this.srvrCstmRb.Text = "Custom";
            this.srvrCstmRb.UseVisualStyleBackColor = true;
            this.srvrCstmRb.CheckedChanged += new System.EventHandler(this.srvrCstmRb_CheckedChanged);
            // 
            // SrvrCstmGB
            // 
            this.SrvrCstmGB.Controls.Add(this.label1);
            this.SrvrCstmGB.Controls.Add(this.label4);
            this.SrvrCstmGB.Controls.Add(this.srvrIP1);
            this.SrvrCstmGB.Controls.Add(this.label3);
            this.SrvrCstmGB.Controls.Add(this.srvrIP2);
            this.SrvrCstmGB.Controls.Add(this.label2);
            this.SrvrCstmGB.Controls.Add(this.srvrIP3);
            this.SrvrCstmGB.Controls.Add(this.srvrIP4);
            this.SrvrCstmGB.Enabled = false;
            this.SrvrCstmGB.Location = new System.Drawing.Point(6, 42);
            this.SrvrCstmGB.Name = "SrvrCstmGB";
            this.SrvrCstmGB.Size = new System.Drawing.Size(582, 49);
            this.SrvrCstmGB.TabIndex = 8;
            this.SrvrCstmGB.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "To connect to specific client root :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(333, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = ".";
            // 
            // srvrIP1
            // 
            this.srvrIP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.srvrIP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srvrIP1.Location = new System.Drawing.Point(184, 14);
            this.srvrIP1.MaxLength = 3;
            this.srvrIP1.Name = "srvrIP1";
            this.srvrIP1.Size = new System.Drawing.Size(33, 20);
            this.srvrIP1.TabIndex = 1;
            this.srvrIP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(278, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = ".";
            // 
            // srvrIP2
            // 
            this.srvrIP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.srvrIP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srvrIP2.Location = new System.Drawing.Point(239, 14);
            this.srvrIP2.MaxLength = 3;
            this.srvrIP2.Name = "srvrIP2";
            this.srvrIP2.Size = new System.Drawing.Size(33, 20);
            this.srvrIP2.TabIndex = 2;
            this.srvrIP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(223, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = ".";
            // 
            // srvrIP3
            // 
            this.srvrIP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.srvrIP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srvrIP3.Location = new System.Drawing.Point(294, 14);
            this.srvrIP3.MaxLength = 3;
            this.srvrIP3.Name = "srvrIP3";
            this.srvrIP3.Size = new System.Drawing.Size(33, 20);
            this.srvrIP3.TabIndex = 3;
            this.srvrIP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // srvrIP4
            // 
            this.srvrIP4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.srvrIP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srvrIP4.Location = new System.Drawing.Point(349, 14);
            this.srvrIP4.MaxLength = 3;
            this.srvrIP4.Name = "srvrIP4";
            this.srvrIP4.Size = new System.Drawing.Size(33, 20);
            this.srvrIP4.TabIndex = 4;
            this.srvrIP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UndoBtn
            // 
            this.UndoBtn.Location = new System.Drawing.Point(208, 320);
            this.UndoBtn.Name = "UndoBtn";
            this.UndoBtn.Size = new System.Drawing.Size(111, 23);
            this.UndoBtn.TabIndex = 10;
            this.UndoBtn.Text = "Last Setted Options";
            this.UndoBtn.UseVisualStyleBackColor = true;
            this.UndoBtn.Click += new System.EventHandler(this.UndoBtn_Click);
            // 
            // CnclBtn
            // 
            this.CnclBtn.Location = new System.Drawing.Point(414, 320);
            this.CnclBtn.Name = "CnclBtn";
            this.CnclBtn.Size = new System.Drawing.Size(79, 23);
            this.CnclBtn.TabIndex = 9;
            this.CnclBtn.Text = "Cancel";
            this.CnclBtn.UseVisualStyleBackColor = true;
            this.CnclBtn.Click += new System.EventHandler(this.CnclBtn_Click);
            // 
            // ClrFldBtn
            // 
            this.ClrFldBtn.Location = new System.Drawing.Point(107, 320);
            this.ClrFldBtn.Name = "ClrFldBtn";
            this.ClrFldBtn.Size = new System.Drawing.Size(95, 23);
            this.ClrFldBtn.TabIndex = 8;
            this.ClrFldBtn.Text = "Clear Fields";
            this.ClrFldBtn.UseVisualStyleBackColor = true;
            this.ClrFldBtn.Click += new System.EventHandler(this.ClrFldBtn_Click);
            // 
            // SetBtn
            // 
            this.SetBtn.Location = new System.Drawing.Point(6, 320);
            this.SetBtn.Name = "SetBtn";
            this.SetBtn.Size = new System.Drawing.Size(95, 23);
            this.SetBtn.TabIndex = 7;
            this.SetBtn.Text = "Set";
            this.SetBtn.UseVisualStyleBackColor = true;
            this.SetBtn.Click += new System.EventHandler(this.SetBtn_Click);
            // 
            // srvrCkbx
            // 
            this.srvrCkbx.AutoSize = true;
            this.srvrCkbx.Location = new System.Drawing.Point(7, 125);
            this.srvrCkbx.Name = "srvrCkbx";
            this.srvrCkbx.Size = new System.Drawing.Size(172, 17);
            this.srvrCkbx.TabIndex = 15;
            this.srvrCkbx.Text = "Set Connection Port: (Optional)";
            this.srvrCkbx.UseVisualStyleBackColor = true;
            this.srvrCkbx.CheckedChanged += new System.EventHandler(this.srvrCkbx_CheckedChanged_1);
            // 
            // portNotificationLabel
            // 
            this.portNotificationLabel.AutoSize = true;
            this.portNotificationLabel.Location = new System.Drawing.Point(255, 126);
            this.portNotificationLabel.Name = "portNotificationLabel";
            this.portNotificationLabel.Size = new System.Drawing.Size(331, 13);
            this.portNotificationLabel.TabIndex = 14;
            this.portNotificationLabel.Text = "If you set this you should have exactly set this on client side program ";
            this.portNotificationLabel.Visible = false;
            // 
            // srvrPort
            // 
            this.srvrPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.srvrPort.Enabled = false;
            this.srvrPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.srvrPort.Location = new System.Drawing.Point(191, 122);
            this.srvrPort.MaxLength = 5;
            this.srvrPort.Name = "srvrPort";
            this.srvrPort.Size = new System.Drawing.Size(49, 20);
            this.srvrPort.TabIndex = 13;
            this.srvrPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NetworkSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 362);
            this.Controls.Add(this.groupBox8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "NetworkSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Set Network Protocols";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NetworkSetting_FormClosing);
            this.Load += new System.EventHandler(this.NetworkSetting_Load);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ClntGB.ResumeLayout(false);
            this.ClntGB.PerformLayout();
            this.SrvrGB.ResumeLayout(false);
            this.SrvrGB.PerformLayout();
            this.SrvrCstmGB.ResumeLayout(false);
            this.SrvrCstmGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton ClntSidRB;
        private System.Windows.Forms.RadioButton SrvrSidRB;
        private System.Windows.Forms.GroupBox ClntGB;
        private System.Windows.Forms.Label clntPortNotifiaction;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox clntIP1;
        private System.Windows.Forms.TextBox clntPort;
        private System.Windows.Forms.TextBox clntIP4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox clntIP3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox clntIP2;
        private System.Windows.Forms.GroupBox SrvrGB;
        private System.Windows.Forms.RadioButton SrvrAnyRB;
        private System.Windows.Forms.RadioButton SrvrLcalHstRB;
        private System.Windows.Forms.RadioButton srvrCstmRb;
        private System.Windows.Forms.GroupBox SrvrCstmGB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox srvrIP1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox srvrIP2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox srvrIP3;
        private System.Windows.Forms.TextBox srvrIP4;
        private System.Windows.Forms.Button UndoBtn;
        private System.Windows.Forms.Button CnclBtn;
        private System.Windows.Forms.Button ClrFldBtn;
        private System.Windows.Forms.Button SetBtn;
        private System.Windows.Forms.CheckBox clntCkbx;
        private System.Windows.Forms.Button dltBtn;
        private System.Windows.Forms.Button AdminInfo;
        private System.Windows.Forms.CheckBox srvrCkbx;
        private System.Windows.Forms.Label portNotificationLabel;
        private System.Windows.Forms.TextBox srvrPort;

    }
}


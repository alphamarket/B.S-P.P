﻿using System;
using System.Windows.Forms;
using Communication.ConnectionInfo;
using Communication.Setting;
namespace Server
{
    public partial class NetworkSetting : Form
    {
        SettingOptions SO;
        bool set = true;
        public NetworkSetting(SettingOptions SO,Communication.NetworkExceptionSide NES)
        {
            this.SO = SO;
            if (NES == Communication.NetworkExceptionSide.Client && SO == SettingOptions.FirstTime)
            {
                Server.AdminLogin aForm = new Server.AdminLogin(SettingOptions.FirstTime);
                aForm.ShowDialog();
            }
            InitializeComponent();
            switch (NES)
            {
                case Communication.NetworkExceptionSide.Client:
                    ClntSidRB.Checked = true;
                    SrvrSidRB.Enabled = false;
                    break;
                case Communication.NetworkExceptionSide.Server:
                    SrvrSidRB.Checked = true;
                    ClntSidRB.Enabled = false;
                    break;
            }
            if (SO == SettingOptions.FirstTime)
            {
                set = UndoBtn.Enabled = dltBtn.Enabled = false;
            }
        }
        private void SrvrSidRB_CheckedChanged(object sender, EventArgs e)
        {
            SrvrGB.Enabled = srvrCstmRb.Checked;
            ClntGB.Enabled = !srvrCstmRb.Checked;
            ClntSidRB.Checked = !srvrCstmRb.Checked;
            srvrCkbx.Checked = SrvrSidRB.Checked;
            ClrFldBtn_Click(sender, e);
        }

        private void srvrCkbx_CheckedChanged(object sender, EventArgs e)
        {
            srvrPort.Enabled = this.srvrCkbx.Checked;
            portNotificationLabel.Visible = srvrCkbx.Checked;
        }

        private void ClntSidRB_CheckedChanged(object sender, EventArgs e)
        {
            ClntGB.Enabled = ClntSidRB.Checked;
            srvrCstmRb.Checked = !ClntSidRB.Checked;
            SrvrLcalHstRB.Checked = !ClntSidRB.Checked;
            SrvrAnyRB.Checked = !ClntSidRB.Checked;
            ClrFldBtn_Click(sender, e);
        }

        private void clntCkbx_CheckedChanged(object sender, EventArgs e)
        {
            clntPort.Enabled = clntCkbx.Checked;
            clntPortNotifiaction.Visible = clntCkbx.Checked;
        }

        private void ClrFldBtn_Click(object sender, EventArgs e)
        {
            clntIP1.Text = string.Empty;
            clntIP2.Text = string.Empty;
            clntIP3.Text = string.Empty;
            clntIP4.Text = string.Empty;
            srvrIP1.Text = string.Empty;
            srvrIP2.Text = string.Empty;
            srvrIP3.Text = string.Empty;
            srvrIP4.Text = string.Empty;
            srvrPort.Text = string.Empty;
            clntPort.Text = string.Empty;
        }

        private void srvrCstmRb_CheckedChanged(object sender, EventArgs e)
        {
            SrvrCstmGB.Enabled = srvrCstmRb.Checked;
        }

        private void CnclBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SetBtn_Click(object sender, EventArgs e)
        {
            try
            {
                switch (SrvrSidRB.Checked)
                {
                    case true:
                        //TODO:
                        //
                        //save the program side option and setted ip/port
                        //
                        if (SO == SettingOptions.NotFirstTime)
                            ConnectionSetting.BackupConnectionSetting();
                        if (srvrCstmRb.Checked)
                        {
                            Check_IP_Port(new TextBox[] { srvrIP1, srvrIP2, srvrIP3, srvrIP4, srvrPort });
                            ConnectionSetting.SaveConnectionSetting(Communication.Setting.SettingSideOption.Server, srvrIP1.Text + "." + srvrIP2.Text + "." + srvrIP3.Text + "." + srvrIP4.Text, srvrPort.Text == "" ? "34139" : srvrPort.Text);
                        }
                        else if (SrvrLcalHstRB.Checked)
                        {
                            ConnectionSetting.DefaultConnectionSetting(Communication.Setting.SettingSideOption.Server, Communication.Setting.DefaultSetting.LocalHost, srvrPort.Text == "" ? "34139" : srvrPort.Text);
                        }
                        else if (SrvrAnyRB.Checked)
                        {
                            ConnectionSetting.DefaultConnectionSetting(Communication.Setting.SettingSideOption.Server, Communication.Setting.DefaultSetting.AcceptAnyConnection, srvrPort.Text == "" ? "34139" : srvrPort.Text);
                        }
                        if (SO == SettingOptions.FirstTime)
                            ConnectionSetting.BackupConnectionSetting();
                        break;
                    case false:
                        Check_IP_Port(new TextBox[] { clntIP1, clntIP2, clntIP3, clntIP4, clntPort });
                        //TODO:
                        //
                        //save the program side option and setted ip/port
                        //
                        if (SO == SettingOptions.NotFirstTime)
                            ConnectionSetting.BackupConnectionSetting();
                        ConnectionSetting.SaveConnectionSetting(Communication.Setting.SettingSideOption.Client, clntIP1.Text + "." + clntIP2.Text + "." + clntIP3.Text + "." + clntIP4.Text, clntPort.Text == "" ? "34139" : clntPort.Text);
                        if (SO == SettingOptions.FirstTime)
                            ConnectionSetting.BackupConnectionSetting();
                        break;
                }
                set = true;
                MessageBox.Show("Setting have been saved successfully!", "You can close this page now ...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.Message + "\nIPs and port should be integeral, check them out!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Communication.InternalNetworkException ine)
            {
                MessageBox.Show(ine.Message, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                srvrPort.Text = "";
            }
        }
        private void Check_IP_Port(TextBox[] txt)
        {
            foreach (TextBox i in txt)
            {
                Convert.ToInt64(string.IsNullOrEmpty(i.Text)?"0":i.Text);
            }
        }

        private void NetworkSetting_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!Communication.Connection.Connection.IsProgramRestarting())
                if (!set)
                {
                    System.Diagnostics.Process This = System.Diagnostics.Process.GetCurrentProcess();
                    This.Kill();
                }
        }

        private void NetworkSetting_Load(object sender, EventArgs e)
        {
            ClrFldBtn_Click(sender, e);
            if (SO != SettingOptions.FirstTime)
            {
                switch (StaticConnectionInfo.NetworkSideOption)
                {
                    case SettingSideOption.Client:
                        if (!GlobalInfo.IsAdmin)
                        {
                            this.Visible = false;
                            Application.DoEvents();
                            Server.AdminLogin aForm = new Server.AdminLogin();
                            aForm.ShowDialog();
                        }
                        if (GlobalInfo.IsAdmin)
                        {
                            SrvrSidRB.Enabled = false;
                            SrvrSidRB.Checked = false;
                            SrvrCstmGB.Enabled = srvrCstmRb.Enabled = SrvrLcalHstRB.Enabled = SrvrAnyRB.Enabled = false;
                            string[] Cip = StaticConnectionInfo.IP.Split('.');
                            clntIP1.Text = Cip[0];
                            clntIP2.Text = Cip[1];
                            clntIP3.Text = Cip[2];
                            clntIP4.Text = Cip[3];
                            if (StaticConnectionInfo.Port != 34139)
                            {
                                clntCkbx.Checked = true;
                                clntPort.Text = StaticConnectionInfo.Port.ToString();
                            }
                            else
                                clntCkbx.Checked = false;
                            GlobalInfo.IsAdmin = false;
                        }
                        else
                            this.Close();
                        break;
                    case SettingSideOption.Server:
                        AdminInfo.Enabled = false;
                        srvrCstmRb.Enabled = true;
                        srvrCstmRb.Checked = true;
                        ClntSidRB.Enabled = false;
                        if (StaticConnectionInfo.IP == "127.0.0.1")
                        {
                            SrvrLcalHstRB.Checked = true;
                        }
                        else if (StaticConnectionInfo.IP == "0.0.0.0")
                        {
                            SrvrAnyRB.Checked = true;
                        }
                        else
                        {
                            string[] Sip = StaticConnectionInfo.IP.Split('.');
                            srvrIP1.Text = Sip[0];
                            srvrIP2.Text = Sip[1];
                            srvrIP3.Text = Sip[2];
                            srvrIP4.Text = Sip[3];
                        }
                        if (StaticConnectionInfo.Port != 34139)
                        {
                            srvrCkbx.Checked = true;
                            srvrPort.Text = StaticConnectionInfo.Port.ToString();
                        }
                        else
                            srvrCkbx.Checked = false;
                        break;
                }
            }
            this.Visible = true;
        }

        private void dltBtn_Click(object sender, EventArgs e)
        {
            NetworkSetting_Load(new object(), new EventArgs());
        }

        private void AdminInfo_Click(object sender, EventArgs e)
        {
            Server.AdminLogin admin = new Server.AdminLogin(true);
            admin.ShowDialog();
        }

        private void srvrPort_Enter(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            txt.Text = "";
        }

        private void srvrPort_Leave(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (txt.Text == "")
                if (txt == srvrPort)
                    srvrCkbx.Checked = false;
                else
                    clntCkbx.Checked = false;
        }

        private void srvrCkbx_CheckedChanged_1(object sender, EventArgs e)
        {
            srvrPort.Enabled = srvrCkbx.Checked;
            portNotificationLabel.Visible = srvrCkbx.Checked;
        }

        private void UndoBtn_Click(object sender, EventArgs e)
        {
            Communication.Setting.ConnectionSetting.LoadLastConnectionSetting();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LocalLibrary
{
    class InitializeForm
    {
        public InitializeForm(MenuStrip M, bool state)
        {
            M.Visible = state;
        }
        public InitializeForm(Control control, int x, int y)
        {

            control.Location = new System.Drawing.Point(x, y);

        }
        public InitializeForm(Form form, bool state)
        {

            foreach (Control co in form.Controls)
            {
                if (co is MenuStrip)
                    continue;
                co.Visible = state;
            }
        }
        public InitializeForm(Form form, bool state, string[] controlName, bool state2)
        {
            form.WindowState = System.Windows.Forms.FormWindowState.Normal;
            foreach (Control co in form.Controls)
            {
                if (co is MenuStrip)
                    continue;
                co.Visible = state;
            }
            foreach (Control co in form.Controls)
            {
                if (co is MenuStrip)
                    continue;
                for (int i = 0; i < controlName.Length; i++)
                {
                    if (co.Name == controlName[i])
                    {
                        co.Visible = state2;
                    }
                }
            }
        }
        public InitializeForm(Form form, int sizeX, int sizeY)
        {
            form.WindowState = System.Windows.Forms.FormWindowState.Normal;
            form.Size = new System.Drawing.Size(sizeX, sizeY);
        }
        public InitializeForm(Control control)
        {
            control.Location = new System.Drawing.Point(12, 28);

        }
        public InitializeForm(Form form, Control control, Control[] control1)
        {
            control.Location = new System.Drawing.Point(0, 28);
            for (int i = 0; i < control1.Length; i++)
            {
                control1[i].Visible = false;
            }
        }
        public InitializeForm(Form form, Control control, Control[] control1, Control control2, int X, int Y)
        {
            control.Visible = true;
            control.Location = new System.Drawing.Point(0, 3);
            for (int i = 0; i < control1.Length; i++)
            {
                control1[i].Visible = false;
            }
            control2.Visible = true;
            control2.Location = new System.Drawing.Point(X, Y);
        }
        public InitializeForm(Form form, Control con, bool state, Control con2, bool state2, int _x, int _y)
        {
            form.WindowState = System.Windows.Forms.FormWindowState.Normal;
            form.Size = new System.Drawing.Size(395, 405);
            con.Visible = state;
            con2.Location = new System.Drawing.Point(_x, _y);

        }
    }
}

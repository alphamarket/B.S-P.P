﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Server
{
    internal partial class AddBook : Form
    {
        public AddBook()
        {
            InitializeComponent();
        }

        private void BookId_Enter(object sender, EventArgs e)
        {
            BookIdText.Text = "";
            BookIdText.ForeColor = Color.Black;
            BookIdText.TextAlign = HorizontalAlignment.Left;
        }

        private void BookIdText_Leave(object sender, EventArgs e)
        {
            if (BookIdText.Text == "")
            {
                BookIdText.Text = "To automatic setting ID leave empty ";
                BookIdText.ForeColor = SystemColors.ScrollBar;
                BookIdText.TextAlign = HorizontalAlignment.Center;
            }
        }

        private void ClrBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in Controls)
            {
                if (i is TextBox && i.Text != "To automatic setting ID leave empty ")
                    i.Text = "";
            }
        }

        private void CnclBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        bool messagebox = false;
        String BookPublishDate
        {
            get
            {
                return Date.Value.Month + " / " + Date.Value.Day + " / " + Date.Value.Year;
            }
        }
        private void AddBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in AddBookGB.Controls)
            {
                if (i is TextBox && i != BookExpText || CategoryCombo.SelectedIndex == -1)
                    if (string.IsNullOrEmpty(i.Text) || CategoryCombo.SelectedIndex == -1)
                    {
                        messagebox = true;
                        Sundries.MessageBox.ShowMessage("Please fill empty field ...\r\nExplanation text box could be an empty field but others could not be!");
                        return;
                    }
            }
            if (BookExpText.Text.Length > 400)
            {
                Sundries.MessageBox.ShowMessage("About note of the book is too long!");
                return;
            }
            Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);
            List<string> tmplist = new List<string>();// = search.newsearch(new string[] { BookIdText.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);
            if (tmplist.Count != 0)
            {
                Sundries.MessageBox.ShowMessage("A book with this ID has exist in database already ...\r\nChange ID OR let us set ID ...");
                BookIdText_Leave(new object(), new EventArgs());
                return;
            }
            search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByName);
            tmplist = search.newsearch(new string[] { BookPublishDate, BookNameText.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);
            if (tmplist.Count != 0)
            {
                Sundries.MessageBox.ShowMessage("There is a same book with this 'Name and 'Year Of Publish' in our database, data couldn't be saved becuase of possibility of mistake ...");
                return;
            }
            tmplist.Clear();
            tmplist.Capacity=5;
            string explanataion = (string.IsNullOrEmpty(BookExpText.Text)?"":BookExpText.Text+", ")+"Year Of Publish : "+BookPublishDate;
            string bookId = Math.Abs(((CategoryCombo.SelectedIndex + 10)).GetHashCode() % 100) + " " + CategoryCombo.SelectedItem.ToString().Remove(2).ToUpper() + " " + Math.Abs((double)(BookNameText.Text+BookPublishDate).GetHashCode()) % 10000000;
            tmplist.Add(CategoryCombo.SelectedItem.ToString());
            tmplist.Add(bookId);
            tmplist.Add(BookNameText.Text);
            tmplist.Add(BookWriterText.Text);
            tmplist.Add(BookPublisherText.Text);
            tmplist.Add(explanataion);
            Serve.Query.AddJoinQuery(tmplist, Communication.Protocol.ClientSendQueryType.AddBook);
            ClrBtn_Click(new object(), new EventArgs());
        }

        private void Date_Leave(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            int input;
            if (!string.IsNullOrEmpty(tb.Text) && !int.TryParse(tb.Text, out input))
            {
                tb.Focus();
                tb.Text = "";
            }
        }

        private void AddBook_Deactivate(object sender, EventArgs e)
        {
            if (!messagebox)
                this.Close();
            messagebox = false;
        }
    }
}
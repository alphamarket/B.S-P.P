﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
namespace Server
{
    internal partial class UserXForm : Form
    {
        public UserXForm(MemberFormFunctionality MFF)
        {
            InitializeComponent();
            switch (MFF)
            {
                case MemberFormFunctionality.Join:
                    this.Text = "Member Join Form ...";
                    SetPanelRight(JoinPanel);
                    break;
                case MemberFormFunctionality.Remove:
                    this.Text = "Member Remove Form ...";
                    SetPanelRight(RemovePanel);
                    break;
                case MemberFormFunctionality.Search:
                    this.Text = "Member Search Form ...";
                    SetPanelRight(SearchPanel);
                    break;
            }
            this.TopMost = true;
            Location = new System.Drawing.Point(0, 0);
        }

        private void Remove(object sender, EventArgs e)
        {
            if (rem_id_txt.Text != "")
            {

                DialogResult res = MessageBox.Show("Are you sure to delete this user??", "Confirmation...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == System.Windows.Forms.DialogResult.Yes)
                {
                    //
                    //TODO: REMOVE THIS SPECIFIC STUDENT FROM DB
                    //
                    throw new NotImplementedException("REMOVE NEVESHTE NASHODE!!!!");
                }
            }
            else
                rem_id_txt.Focus();
        }
        public void SetPanelRight(Panel panel)
        {
            foreach (Control i in Controls)
                if (i is Panel)
                    if (i == panel)
                    {
                        panel.Visible = true;
                        ClientSize = new System.Drawing.Size(panel.Size.Width, panel.Size.Height);
                        panel.Location = new System.Drawing.Point(0, 0);
                    }
                    else i.Visible = false;
        }
        void clrbtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in ((Control)sender).Parent.Controls)
                if (i is TextBox && i != set_field_txt)
                    i.Text = "";
                else if (i is ComboBox)
                    CategoryCombo.SelectedIndex = -1;
        }

        private void Cancels_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MemSetBtn_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (Control i in ((Button)sender).Parent.Controls)
                {
                    if (i is ComboBox || i is TextBox && i != set_phone_txt && i != set_add_txt && i.Text != "Type here if is not in list")
                        if ((i is ComboBox ? ((ComboBox)i).SelectedIndex == -1 : i.Text == ""))
                        {
                            Sundries.MessageBox.ShowMessage("Please fill essential empty fields .");
                            i.Focus();
                            return;
                        }
                }
                System.Windows.Forms.DialogResult res = MessageBox.Show("Are you sure?", "Persuade?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == System.Windows.Forms.DialogResult.Yes)
                {
                    if (set_pass_txt.Text != set_conf_txt.Text)
                    {
                        set_conf_txt.Text = set_pass_txt.Text = "";
                        Sundries.MessageBox.ShowMessage("Passwords does not matches ...!");
                        return;
                    }
                    List<string> meminfo = new List<string>(8);
                    meminfo.Add(set_name_txt.Text);
                    meminfo.Add(set_last_txt.Text);
                    meminfo.Add(set_id_txt.Text);
                    meminfo.Add(set_username_txt.Text);
                    meminfo.Add(set_pass_txt.Text.GetHashCode().ToString());
                    meminfo.Add(set_phone_txt.Text==""?"NULL":set_phone_txt.Text);
                    meminfo.Add(set_add_txt.Text == "" ? "NULL" : set_add_txt.Text);
                    meminfo.Add(CategoryCombo.SelectedIndex==-1?set_field_txt.Text:CategoryCombo.SelectedItem.ToString());
                    Serve.Query.AddJoinQuery(meminfo, Communication.Protocol.ClientSendQueryType.JoinMember);
                    clrbtn_Click(sender, e);
                }
            }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }
        private void OptionalFields_Leave(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (txt.Text == "")
            {
                txt.Text = (txt == set_field_txt ? "Type here if is not in list" : "Could be an empty field . . .");
                txt.ForeColor = System.Drawing.SystemColors.ScrollBar;
                txt.TextAlign = HorizontalAlignment.Center;
            }
        }

        private void OptionalFields_Enter(object sender, EventArgs e)
        {
            ((TextBox)sender).TextAlign = HorizontalAlignment.Left;
            ((TextBox)sender).ForeColor = System.Drawing.Color.Black;
            ((TextBox)sender).Text = "";
            if (((TextBox)sender) == set_field_txt)
                CategoryCombo.SelectedIndex = -1;
        }
        private void sea_search_btn_Click(object sender, EventArgs e)
        {
            if (sea_id_txt.Text != "")
            {
                List<string> query = new List<string>();
                Search.Search search = new Search.Search();
                foreach (Control i in ((Button)sender).Parent.Controls)
                {
                    if (i is TextBox && i.Text != "")
                        query.Add(i.Text);
                }
                //
                //IN SEARCH DOROS KAR NEMIKONE
                //
                throw new NotImplementedException("IN SEARCH DOROS KAR NEMIKONE!!!");
                //
                //
                //
            }
            else
                sea_id_txt.Focus();
        }

        private void UserXForm_Load(object sender, EventArgs e)
        {

        }

        private void sea_id_txt_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter && sea_id_txt.Text != "")
                sea_search_btn_Click(sender, e);
        }
    }
}
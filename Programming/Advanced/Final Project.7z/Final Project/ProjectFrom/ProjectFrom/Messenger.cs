﻿using System;
using System.Windows.Forms;
using Communication;
using Communication.ConnectionInfo;
namespace Server
{
    internal partial class Messenger : Form
    {
        public Messenger(MessageType MessageKind)
        {
            InitializeComponent();
            StaticConnectionInfo.MessageKind = MessageKind;
            switch (MessageKind)
            {
                case MessageType.Public:
                    Text = "Public Message Sender ...";
                    textBox1.Enabled = false;
                    textBox1.Text = "Public Message";
                    break;
                case MessageType.Private:
                    Text = "Private Message Sender ...";
                    break;
            }
            this.TopMost = true;
        }

        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Control && e.KeyCode == Keys.Enter) || e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(richTextBox1.Text))
                {
                    MessageBox.Show("To send message you have to fill message body first ......", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    richTextBox1.Focus();
                    return;
                }
                button1_Click(sender, e);
                button3_Click(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            richTextBox1.Text = "\r\r";
            textBox2.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("To Send Message you have to fill title bar first ......", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return;
            }
            string[] i=richTextBox1.Text.Split(new char[]{'\n'});
            if (richTextBox1.Text.Length > 420 || i.Length > 8)
            {
                MessageBox.Show("Message is too long[OR has more than 8 line!] to send!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            StaticConnectionInfo.ServerConnectionRoot.SendData(textBox2.Text, StaticConnectionInfo.MessageKind == MessageType.Public ?
                Communication.Protocol.ServerSendQueryType.PublicMessageTitle : Communication.Protocol.ServerSendQueryType.PrivateMessageTitle);

            StaticConnectionInfo.ServerConnectionRoot.SendData(richTextBox1.Text, StaticConnectionInfo.MessageKind == MessageType.Public ?
                Communication.Protocol.ServerSendQueryType.PublicMessageBody : Communication.Protocol.ServerSendQueryType.PrivateMessageBody);

            button3_Click(sender, e);
        }
    }
}
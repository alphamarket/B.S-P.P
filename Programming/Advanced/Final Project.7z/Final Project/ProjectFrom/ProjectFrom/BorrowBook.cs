﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Server
{
    public partial class BorrowBook : Form
    {
        public BorrowBook()
        {
            InitializeComponent();
            Server.ReturnDate.Load(ref numericUpDown1);
            Application.DoEvents();
            if (numericUpDown1.Value != 1) Save.Enabled = false;
        }

        private void clrBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in Controls)
                if (i is TextBox)
                    i.Text = "";
        }

        private void brwBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBox2.Text) && !string.IsNullOrEmpty(textBox3.Text))
                {
                    Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);

                    System.Collections.Generic.List<string> res = search.newsearch(new string[] { textBox1.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);

                    if (res.Count != 0)
                    {
                        LibraryTransactionSystem.BookStatus bs = new LibraryTransactionSystem.BookStatus(res[0]);
                        if (!bs.IsBorrow)
                        {
                            DateTime dt = DateTime.Now.AddDays((double)numericUpDown1.Value);
                            System.Collections.Generic.List<string> brw = new System.Collections.Generic.List<string>(5);
                            brw.Add(textBox1.Text);
                            brw.Add(textBox2.Text);
                            brw.Add(dt.Date.Year + " / " + dt.Date.Month + " / " + dt.Date.Day);
                            brw.Add(textBox3.Text);
                            brw.Add(textBox3.Text);
                            LibraryTransactionSystem.Deposit dpst = new LibraryTransactionSystem.Deposit();
                            dpst.BorrowBook(brw);
                            Sundries.MessageBox.ShowMessage("The book has put in library borrow list successfully ...");
                        }
                        else
                            Sundries.MessageBox.ShowMessage("This book has been borrowed already ...");
                    }
                    else
                    {
                        Sundries.MessageBox.ShowMessage("Book with this 'Book ID' has not found !");
                    }
                }
                else
                    Sundries.MessageBox.ShowMessage("Please enter '<-Ciritical->' fields");
            }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            ReturnDate.Save(numericUpDown1.Value.ToString());
            Save.Enabled = false;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now.AddDays((double)numericUpDown1.Value);
            DateCount.Text = "Return Date Will Be :           " + dt.Date.Year + " / " + dt.Date.Month + " / " + dt.Date.Day;
            Save.Enabled = true;
        }
    }
}

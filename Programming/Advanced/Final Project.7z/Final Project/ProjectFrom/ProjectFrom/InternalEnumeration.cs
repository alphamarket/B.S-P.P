﻿namespace Server
{
    internal enum MemberFormFunctionality { Remove, Join, Search }
}
﻿using System;
using System.Windows.Forms;
using Communication;
using Communication.Setting;
namespace Server
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            try
            {
                if (!ConnectionSetting.LoadConnectionSetting())
                    Application.Run(new NetworkSetting(SettingOptions.FirstTime,NetworkExceptionSide.Server));

            }
            catch (NetworkSideException e)
            {
                MessageBox.Show(e.Message);
                Application.Run(new NetworkSetting(SettingOptions.FirstTime,NetworkExceptionSide.Server));
            }
            Application.Run(new main());
        }
    }
}

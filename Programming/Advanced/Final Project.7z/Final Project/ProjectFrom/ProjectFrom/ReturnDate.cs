﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
namespace Server
{
    class ReturnDate
    {
        static string path = System.Windows.Forms.Application.StartupPath + @"\Files\DataBase\Sundries.xml";
        public static void Save(string date)
        {
            using (XmlTextWriter write = new XmlTextWriter(path, null))
            {
                write.WriteStartDocument();
                write.WriteStartElement("Library");
                write.WriteStartElement("ReturnPeriod");
                write.WriteString(date);
                write.WriteEndElement();
                write.WriteEndElement();
                write.WriteEndDocument();
            }
        }
        enum node { Period, NONE }
        public static void Load(ref System.Windows.Forms.NumericUpDown obj)
        {
            try
            {
                node jj = node.NONE;
                using (XmlTextReader read = new XmlTextReader(path))
                {
                    while (read.Read())
                    {
                        switch (read.NodeType)
                        {
                            case XmlNodeType.Element:
                                switch (read.Name)
                                {
                                    case "ReturnPeriod":
                                        jj = node.Period;
                                        break;
                                }
                                break;
                            case XmlNodeType.Text:
                                switch (jj)
                                {
                                    case node.Period:
                                        obj.Value = int.Parse(read.Value);
                                        read.Close();
                                        return;
                                }
                                break;
                        }
                    }
                }
            }
            catch { obj.Value = 1; }
        }
        public static void Delete()
        {
            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }
        }
    }
}
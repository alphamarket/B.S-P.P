﻿namespace Server
{
    partial class AdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLogin));
            this.LogInPanel = new System.Windows.Forms.Panel();
            this.LogInGB = new System.Windows.Forms.GroupBox();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PassWordText = new System.Windows.Forms.TextBox();
            this.UserNameText = new System.Windows.Forms.TextBox();
            this.EnterBtn = new System.Windows.Forms.Button();
            this.CreateAdminPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CAdminPassC = new System.Windows.Forms.TextBox();
            this.CCloseBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CAdminPass = new System.Windows.Forms.TextBox();
            this.CAdminUserText = new System.Windows.Forms.TextBox();
            this.AdminCreationBtn = new System.Windows.Forms.Button();
            this.LogInPanel.SuspendLayout();
            this.LogInGB.SuspendLayout();
            this.CreateAdminPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LogInPanel
            // 
            this.LogInPanel.Controls.Add(this.LogInGB);
            this.LogInPanel.Location = new System.Drawing.Point(2, 1);
            this.LogInPanel.Name = "LogInPanel";
            this.LogInPanel.Size = new System.Drawing.Size(317, 114);
            this.LogInPanel.TabIndex = 43;
            // 
            // LogInGB
            // 
            this.LogInGB.Controls.Add(this.CloseBtn);
            this.LogInGB.Controls.Add(this.label2);
            this.LogInGB.Controls.Add(this.label3);
            this.LogInGB.Controls.Add(this.PassWordText);
            this.LogInGB.Controls.Add(this.UserNameText);
            this.LogInGB.Controls.Add(this.EnterBtn);
            this.LogInGB.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInGB.Location = new System.Drawing.Point(3, 3);
            this.LogInGB.Name = "LogInGB";
            this.LogInGB.Size = new System.Drawing.Size(309, 109);
            this.LogInGB.TabIndex = 39;
            this.LogInGB.TabStop = false;
            this.LogInGB.Text = "Log in";
            // 
            // CloseBtn
            // 
            this.CloseBtn.Location = new System.Drawing.Point(185, 78);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(49, 23);
            this.CloseBtn.TabIndex = 13;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 14);
            this.label2.TabIndex = 12;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 14);
            this.label3.TabIndex = 11;
            this.label3.Text = "UserName";
            // 
            // PassWordText
            // 
            this.PassWordText.Location = new System.Drawing.Point(96, 52);
            this.PassWordText.Name = "PassWordText";
            this.PassWordText.Size = new System.Drawing.Size(192, 20);
            this.PassWordText.TabIndex = 9;
            this.PassWordText.UseSystemPasswordChar = true;
            // 
            // UserNameText
            // 
            this.UserNameText.Location = new System.Drawing.Point(96, 16);
            this.UserNameText.Name = "UserNameText";
            this.UserNameText.Size = new System.Drawing.Size(192, 20);
            this.UserNameText.TabIndex = 8;
            // 
            // EnterBtn
            // 
            this.EnterBtn.Location = new System.Drawing.Point(240, 78);
            this.EnterBtn.Name = "EnterBtn";
            this.EnterBtn.Size = new System.Drawing.Size(48, 23);
            this.EnterBtn.TabIndex = 7;
            this.EnterBtn.Text = "Enter";
            this.EnterBtn.UseVisualStyleBackColor = true;
            this.EnterBtn.Click += new System.EventHandler(this.EnterBtn_Click);
            // 
            // CreateAdminPanel
            // 
            this.CreateAdminPanel.Controls.Add(this.groupBox1);
            this.CreateAdminPanel.Location = new System.Drawing.Point(363, 4);
            this.CreateAdminPanel.Name = "CreateAdminPanel";
            this.CreateAdminPanel.Size = new System.Drawing.Size(317, 144);
            this.CreateAdminPanel.TabIndex = 44;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.CAdminPassC);
            this.groupBox1.Controls.Add(this.CCloseBtn);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.CAdminPass);
            this.groupBox1.Controls.Add(this.CAdminUserText);
            this.groupBox1.Controls.Add(this.AdminCreationBtn);
            this.groupBox1.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(309, 138);
            this.groupBox1.TabIndex = 39;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log in";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 14);
            this.label5.TabIndex = 15;
            this.label5.Text = "Confirm Password";
            // 
            // CAdminPassC
            // 
            this.CAdminPassC.Location = new System.Drawing.Point(127, 88);
            this.CAdminPassC.MaxLength = 20;
            this.CAdminPassC.Name = "CAdminPassC";
            this.CAdminPassC.Size = new System.Drawing.Size(161, 20);
            this.CAdminPassC.TabIndex = 10;
            this.CAdminPassC.UseSystemPasswordChar = true;
            // 
            // CCloseBtn
            // 
            this.CCloseBtn.Location = new System.Drawing.Point(185, 109);
            this.CCloseBtn.Name = "CCloseBtn";
            this.CCloseBtn.Size = new System.Drawing.Size(49, 23);
            this.CCloseBtn.TabIndex = 13;
            this.CCloseBtn.Text = "Close";
            this.CCloseBtn.UseVisualStyleBackColor = true;
            this.CCloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 14);
            this.label1.TabIndex = 12;
            this.label1.Text = "PassWord";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 14);
            this.label4.TabIndex = 11;
            this.label4.Text = "UserName";
            // 
            // CAdminPass
            // 
            this.CAdminPass.Location = new System.Drawing.Point(96, 52);
            this.CAdminPass.MaxLength = 20;
            this.CAdminPass.Name = "CAdminPass";
            this.CAdminPass.Size = new System.Drawing.Size(192, 20);
            this.CAdminPass.TabIndex = 9;
            this.CAdminPass.UseSystemPasswordChar = true;
            // 
            // CAdminUserText
            // 
            this.CAdminUserText.Location = new System.Drawing.Point(96, 16);
            this.CAdminUserText.MaxLength = 25;
            this.CAdminUserText.Name = "CAdminUserText";
            this.CAdminUserText.Size = new System.Drawing.Size(192, 20);
            this.CAdminUserText.TabIndex = 8;
            // 
            // AdminCreationBtn
            // 
            this.AdminCreationBtn.Location = new System.Drawing.Point(240, 109);
            this.AdminCreationBtn.Name = "AdminCreationBtn";
            this.AdminCreationBtn.Size = new System.Drawing.Size(48, 23);
            this.AdminCreationBtn.TabIndex = 11;
            this.AdminCreationBtn.Text = "Enter";
            this.AdminCreationBtn.UseVisualStyleBackColor = true;
            this.AdminCreationBtn.Click += new System.EventHandler(this.AdminCreationBtn_Click);
            // 
            // AdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 160);
            this.Controls.Add(this.CreateAdminPanel);
            this.Controls.Add(this.LogInPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminLogin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminLogin_FormClosing);
            this.LogInPanel.ResumeLayout(false);
            this.LogInGB.ResumeLayout(false);
            this.LogInGB.PerformLayout();
            this.CreateAdminPanel.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel LogInPanel;
        private System.Windows.Forms.GroupBox LogInGB;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PassWordText;
        private System.Windows.Forms.TextBox UserNameText;
        private System.Windows.Forms.Button EnterBtn;
        private System.Windows.Forms.Panel CreateAdminPanel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox CAdminPassC;
        private System.Windows.Forms.Button CCloseBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CAdminPass;
        private System.Windows.Forms.TextBox CAdminUserText;
        private System.Windows.Forms.Button AdminCreationBtn;
    }
}
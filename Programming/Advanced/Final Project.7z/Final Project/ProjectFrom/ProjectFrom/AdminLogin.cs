﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml;
namespace Server
{
    public partial class AdminLogin : Form
    {
        struct Admin
        {
            public Admin(string[] info)
            {
                this.pass = info[1];
                //TODO: WE GONNA USE HASHED USER AND PASS
                this.username = info[0];
            }
            public string pass;
            public string username;
        }
        string path = Application.StartupPath + @"\Files\DataBase\Admin.xml";
        List<Admin> admins = new List<Admin>();
        Admin CurrentAdmin = new Admin();
        int count = 0;
        bool change = false;
        public AdminLogin(bool ChangeUserAndPass)
        {
            InitializeComponent();
            change = ChangeUserAndPass;
            ReadAdmin();
        }
        public AdminLogin()
        {
            InitializeComponent();
            ReadAdmin();
        }
        Communication.Setting.SettingOptions so;
        public AdminLogin(Communication.Setting.SettingOptions SO)
        {
            so = SO;
            InitializeComponent();
            ReadAdmin();
        }
        void ReadAdmin()
        {
            try
            {
                FileInfo drinfo = new FileInfo(path);
                if (!File.Exists(path))
                {
                    SetPanelRight(CreateAdminPanel);
                }
                else
                {
                    node NODE = node.NONE;
                    using (XmlTextReader read = new XmlTextReader(path))
                    {
                        string tmp = "";
                        while (read.Read())
                        {
                            switch (read.NodeType)
                            {
                                case XmlNodeType.Element:
                                    switch (read.Name)
                                    {
                                        case "UserName":
                                            NODE = node.UserName;
                                            break;
                                        case "Password":
                                            NODE = node.Password;
                                            break;
                                    }
                                    break;
                                case XmlNodeType.Text:
                                    switch (NODE)
                                    {
                                        case node.UserName:
                                            tmp = read.Value;
                                            NODE = node.NONE;
                                            break;
                                        case node.Password:
                                            admins.Add(new Admin(new string[] { tmp, read.Value }));
                                            tmp = "";
                                            NODE = node.NONE;
                                            break;
                                    }
                                    break;
                            }
                        }
                    }
                    SetPanelRight(LogInPanel);
                }
            }
            catch (Exception e)
            {
                Sundries.MessageBox.ShowMessage(e.Message);
            }
        }
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            //
            //TODO: Search For This Admin
            //
            //IF(IS TRUE) SET GlobalInfo.IsAdmin=TRUE;
            //
            //ELSE MESSAGE TO USER THAT ITS NOT CURRECT
            //
            if (count < 3)
            {
                foreach (Admin i in admins)
                {
                    if (int.Parse(i.pass) == PassWordText.Text.GetHashCode() && int.Parse(i.username) == UserNameText.Text.GetHashCode())
                    {
                        GlobalInfo.IsAdmin = true;
                        this.Close();
                        return;
                    }
                }
                Sundries.MessageBox.ShowMessage("The User Name And Password Which You Provide To Us is Wrong!!");
                count++;
            }
            else
            {
                Sundries.MessageBox.ShowMessage("You Had Your Try, The Form Will Close, Try Later !");
                this.Close();
            }
        }

        public void SetPanelRight(Panel panel)
        {
            foreach (Control i in Controls)
                if (i is Panel)
                    if (i == panel)
                    {
                        panel.Visible = true;
                        this.ClientSize = new Size(panel.Size.Width, panel.Size.Height);
                        panel.Location = new Point(0, 0);
                    }
                    else i.Visible = false;
        }
        enum node { UserName, Password, NONE }
        private void AdminCreationBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (CAdminPass.Text != CAdminPassC.Text)
                {
                    Sundries.MessageBox.ShowMessage("The Provided Passwords Do Not Match!");
                    return;
                }
                List<Admin> tmpList = new List<Admin>();
                if (admins.Count == 0)
                    tmpList.Add(new Admin(new string[] { CAdminUserText.Text.GetHashCode().ToString(), CAdminPassC.Text.GetHashCode().ToString() }));
                else
                    for (int i = 0; i < admins.Count; i++)
                    {
                        if (admins[i].username == CurrentAdmin.username)
                        {
                            tmpList.Add(new Admin(new string[] { CAdminUserText.Text.GetHashCode().ToString(), CAdminPassC.Text.GetHashCode().ToString() }));
                        }
                        else
                            tmpList.Add(new Admin(new string[] { admins[i].username, admins[i].pass }));
                    }
                using (XmlTextWriter write = new XmlTextWriter(path, null))
                {
                    write.WriteStartDocument();
                    write.WriteStartElement("Admin");
                    foreach (Admin i in tmpList)
                    {
                        write.WriteStartElement("UserName");
                        write.WriteString(i.username);
                        write.WriteEndElement();
                        write.WriteStartElement("Password");
                        write.WriteString(i.pass);
                        write.WriteEndElement();
                        write.Flush();
                    }
                    write.WriteEndElement();
                    write.WriteEndDocument();
                    write.Flush();
                }
                MessageBox.Show("Your accont has been activated successfully!", "Activated . . .", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GlobalInfo.IsAdmin = true;
                this.Close();
            }

            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }

        private void AdminLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!GlobalInfo.IsAdmin && so == Communication.Setting.SettingOptions.FirstTime)
                System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
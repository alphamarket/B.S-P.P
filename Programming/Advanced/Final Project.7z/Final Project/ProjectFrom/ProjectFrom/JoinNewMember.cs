﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LocalLibrary
{
    public partial class JoinNewMember : Form
    {
        public JoinNewMember()
        {
            InitializeComponent();
        }

        private void SetBT_Click(object sender, EventArgs e)
        {
            
            try
            {
                foreach (Control con in groupBox2.Controls)
                {
                    if (con is TextBox)
                        if (con.Text == "")
                            throw new Exception("Fill empty textboxes!");

                }
                if (CategoryCombo.Text == "")
                {
                    CategoryCombo.Text = "Computer";
                }
                string[]id=new string[3];
                id[0]=UNameTB.Text;
                id[1] = PassTB.Text;
                id[2] = IdTB.Text;
                LibraryTransactionSystem.IsJoinMember IJM = new LibraryTransactionSystem.IsJoinMember(id);
                if (!IJM.IsJoin&&!IJM.IsIdExist)
                {
                    IsCompatible Ic = new IsCompatible(CategoryCombo.Text, IdTB.Text, NameTB.Text, LNameTB.Text, UNameTB.Text, PassTB.Text, PhoneNTB.Text, AddressTB.Text);
                    Ic.ShowDialog();
                    if (Ic.IsAgree)
                    {
                        List<string> memberinfo = new List<string>();
                        memberinfo.Add(NameTB.Text);
                        memberinfo.Add(LNameTB.Text);
                        memberinfo.Add(IdTB.Text);
                        memberinfo.Add(UNameTB.Text);
                        memberinfo.Add(PassTB.Text);
                        memberinfo.Add(PhoneNTB.Text);
                        memberinfo.Add(AddressTB.Text);
                        memberinfo.Add(CategoryCombo.Text);
                        SetData.SetData.SetNewData("", memberinfo, Communication.Protocol.ClientSendQueryType.JoinMember);

                    }
                }
                else
                {
                    Sundries.MessageBox.ShowMessage("A mem with this UserName and password or ID has exist in database already ...\r\nChange UserName OR passwod ORI ID...");
                }
               
            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }
        }
    }
}

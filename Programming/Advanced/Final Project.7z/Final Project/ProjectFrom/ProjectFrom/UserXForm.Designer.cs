﻿namespace Server
{
    partial class UserXForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserXForm));
            this.JoinPanel = new System.Windows.Forms.Panel();
            this.SetGB = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.set_conf_txt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.MemSetBtn = new System.Windows.Forms.Button();
            this.set_id_txt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.set_add_txt = new System.Windows.Forms.TextBox();
            this.set_field_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.set_phone_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.set_name_txt = new System.Windows.Forms.TextBox();
            this.set_last_txt = new System.Windows.Forms.TextBox();
            this.set_pass_txt = new System.Windows.Forms.TextBox();
            this.set_username_txt = new System.Windows.Forms.TextBox();
            this.RemovePanel = new System.Windows.Forms.Panel();
            this.RemoveGB = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rem_id_txt = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.rem_remove_btn = new System.Windows.Forms.Button();
            this.SearchPanel = new System.Windows.Forms.Panel();
            this.SearchGB = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.DataGridResultLabel = new System.Windows.Forms.Label();
            this.sea_empty_field = new System.Windows.Forms.Button();
            this.MemberSearchDataGrid = new System.Windows.Forms.DataGridView();
            this.count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.field = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sea_name_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.sea_user_txt = new System.Windows.Forms.TextBox();
            this.sea_id_txt = new System.Windows.Forms.TextBox();
            this.sea_last_txt = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.sea_search_btn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.sea_field_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.JoinPanel.SuspendLayout();
            this.SetGB.SuspendLayout();
            this.RemovePanel.SuspendLayout();
            this.RemoveGB.SuspendLayout();
            this.SearchPanel.SuspendLayout();
            this.SearchGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemberSearchDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // JoinPanel
            // 
            this.JoinPanel.Controls.Add(this.SetGB);
            this.JoinPanel.Location = new System.Drawing.Point(4, 2);
            this.JoinPanel.Name = "JoinPanel";
            this.JoinPanel.Size = new System.Drawing.Size(490, 418);
            this.JoinPanel.TabIndex = 0;
            // 
            // SetGB
            // 
            this.SetGB.Controls.Add(this.label21);
            this.SetGB.Controls.Add(this.label22);
            this.SetGB.Controls.Add(this.label23);
            this.SetGB.Controls.Add(this.label19);
            this.SetGB.Controls.Add(this.label18);
            this.SetGB.Controls.Add(this.label17);
            this.SetGB.Controls.Add(this.label16);
            this.SetGB.Controls.Add(this.CategoryCombo);
            this.SetGB.Controls.Add(this.button1);
            this.SetGB.Controls.Add(this.label15);
            this.SetGB.Controls.Add(this.set_conf_txt);
            this.SetGB.Controls.Add(this.label13);
            this.SetGB.Controls.Add(this.button3);
            this.SetGB.Controls.Add(this.MemSetBtn);
            this.SetGB.Controls.Add(this.set_id_txt);
            this.SetGB.Controls.Add(this.label10);
            this.SetGB.Controls.Add(this.label11);
            this.SetGB.Controls.Add(this.set_add_txt);
            this.SetGB.Controls.Add(this.set_field_txt);
            this.SetGB.Controls.Add(this.label12);
            this.SetGB.Controls.Add(this.set_phone_txt);
            this.SetGB.Controls.Add(this.label1);
            this.SetGB.Controls.Add(this.label2);
            this.SetGB.Controls.Add(this.label3);
            this.SetGB.Controls.Add(this.label4);
            this.SetGB.Controls.Add(this.set_name_txt);
            this.SetGB.Controls.Add(this.set_last_txt);
            this.SetGB.Controls.Add(this.set_pass_txt);
            this.SetGB.Controls.Add(this.set_username_txt);
            this.SetGB.Location = new System.Drawing.Point(3, 3);
            this.SetGB.Name = "SetGB";
            this.SetGB.Size = new System.Drawing.Size(480, 412);
            this.SetGB.TabIndex = 40;
            this.SetGB.TabStop = false;
            this.SetGB.Text = "Set Member Info";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(406, 254);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(11, 13);
            this.label21.TabIndex = 70;
            this.label21.Text = "*";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(406, 217);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(11, 13);
            this.label22.TabIndex = 69;
            this.label22.Text = "*";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(406, 180);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 13);
            this.label23.TabIndex = 68;
            this.label23.Text = "*";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(406, 142);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(11, 13);
            this.label19.TabIndex = 67;
            this.label19.Text = "*";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(406, 106);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 13);
            this.label18.TabIndex = 66;
            this.label18.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(406, 69);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(11, 13);
            this.label17.TabIndex = 65;
            this.label17.Text = "*";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(406, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(11, 13);
            this.label16.TabIndex = 64;
            this.label16.Text = "*";
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(130, 28);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(148, 21);
            this.CategoryCombo.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Resest Fields";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.clrbtn_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(31, 256);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 13);
            this.label15.TabIndex = 63;
            this.label15.Text = "Confirm Password";
            // 
            // set_conf_txt
            // 
            this.set_conf_txt.Location = new System.Drawing.Point(129, 253);
            this.set_conf_txt.Name = "set_conf_txt";
            this.set_conf_txt.Size = new System.Drawing.Size(271, 20);
            this.set_conf_txt.TabIndex = 7;
            this.set_conf_txt.UseSystemPasswordChar = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 61;
            this.label13.Text = "Student\'s ID";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(176, 365);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(128, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Cancels_Click);
            // 
            // MemSetBtn
            // 
            this.MemSetBtn.Location = new System.Drawing.Point(347, 365);
            this.MemSetBtn.Name = "MemSetBtn";
            this.MemSetBtn.Size = new System.Drawing.Size(127, 23);
            this.MemSetBtn.TabIndex = 10;
            this.MemSetBtn.Text = "Set";
            this.MemSetBtn.UseVisualStyleBackColor = true;
            this.MemSetBtn.Click += new System.EventHandler(this.MemSetBtn_Click);
            // 
            // set_id_txt
            // 
            this.set_id_txt.Location = new System.Drawing.Point(129, 66);
            this.set_id_txt.Name = "set_id_txt";
            this.set_id_txt.Size = new System.Drawing.Size(271, 20);
            this.set_id_txt.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 327);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 56;
            this.label10.Text = "Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 291);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 55;
            this.label11.Text = "PhoneNumber";
            // 
            // set_add_txt
            // 
            this.set_add_txt.ForeColor = System.Drawing.SystemColors.InfoText;
            this.set_add_txt.Location = new System.Drawing.Point(129, 324);
            this.set_add_txt.Name = "set_add_txt";
            this.set_add_txt.Size = new System.Drawing.Size(271, 20);
            this.set_add_txt.TabIndex = 9;
            // 
            // set_field_txt
            // 
            this.set_field_txt.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.set_field_txt.Location = new System.Drawing.Point(284, 29);
            this.set_field_txt.Name = "set_field_txt";
            this.set_field_txt.Size = new System.Drawing.Size(116, 20);
            this.set_field_txt.TabIndex = 57;
            this.set_field_txt.Text = "Type here if is not in list";
            this.set_field_txt.Enter += new System.EventHandler(this.OptionalFields_Enter);
            this.set_field_txt.Leave += new System.EventHandler(this.OptionalFields_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "Field Of Study";
            // 
            // set_phone_txt
            // 
            this.set_phone_txt.ForeColor = System.Drawing.SystemColors.InfoText;
            this.set_phone_txt.Location = new System.Drawing.Point(129, 287);
            this.set_phone_txt.Name = "set_phone_txt";
            this.set_phone_txt.Size = new System.Drawing.Size(271, 20);
            this.set_phone_txt.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 52;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 51;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "UserName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 49;
            this.label4.Text = "Name";
            // 
            // set_name_txt
            // 
            this.set_name_txt.Location = new System.Drawing.Point(129, 103);
            this.set_name_txt.Name = "set_name_txt";
            this.set_name_txt.Size = new System.Drawing.Size(271, 20);
            this.set_name_txt.TabIndex = 3;
            // 
            // set_last_txt
            // 
            this.set_last_txt.Location = new System.Drawing.Point(129, 139);
            this.set_last_txt.Name = "set_last_txt";
            this.set_last_txt.Size = new System.Drawing.Size(271, 20);
            this.set_last_txt.TabIndex = 4;
            // 
            // set_pass_txt
            // 
            this.set_pass_txt.Location = new System.Drawing.Point(129, 214);
            this.set_pass_txt.Name = "set_pass_txt";
            this.set_pass_txt.Size = new System.Drawing.Size(271, 20);
            this.set_pass_txt.TabIndex = 6;
            this.set_pass_txt.UseSystemPasswordChar = true;
            // 
            // set_username_txt
            // 
            this.set_username_txt.Location = new System.Drawing.Point(129, 177);
            this.set_username_txt.Name = "set_username_txt";
            this.set_username_txt.Size = new System.Drawing.Size(271, 20);
            this.set_username_txt.TabIndex = 5;
            // 
            // RemovePanel
            // 
            this.RemovePanel.Controls.Add(this.RemoveGB);
            this.RemovePanel.Location = new System.Drawing.Point(524, 2);
            this.RemovePanel.Name = "RemovePanel";
            this.RemovePanel.Size = new System.Drawing.Size(489, 112);
            this.RemovePanel.TabIndex = 66;
            // 
            // RemoveGB
            // 
            this.RemoveGB.Controls.Add(this.label6);
            this.RemoveGB.Controls.Add(this.rem_id_txt);
            this.RemoveGB.Controls.Add(this.button5);
            this.RemoveGB.Controls.Add(this.rem_remove_btn);
            this.RemoveGB.Location = new System.Drawing.Point(3, 3);
            this.RemoveGB.Name = "RemoveGB";
            this.RemoveGB.Size = new System.Drawing.Size(483, 108);
            this.RemoveGB.TabIndex = 0;
            this.RemoveGB.TabStop = false;
            this.RemoveGB.Text = "Discount Member Panel";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 69;
            this.label6.Text = "Student\'s ID";
            // 
            // rem_id_txt
            // 
            this.rem_id_txt.Location = new System.Drawing.Point(145, 29);
            this.rem_id_txt.Name = "rem_id_txt";
            this.rem_id_txt.Size = new System.Drawing.Size(271, 20);
            this.rem_id_txt.TabIndex = 13;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(145, 68);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(128, 23);
            this.button5.TabIndex = 15;
            this.button5.Text = "Cancel";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Cancels_Click);
            // 
            // rem_remove_btn
            // 
            this.rem_remove_btn.Location = new System.Drawing.Point(289, 68);
            this.rem_remove_btn.Name = "rem_remove_btn";
            this.rem_remove_btn.Size = new System.Drawing.Size(127, 23);
            this.rem_remove_btn.TabIndex = 14;
            this.rem_remove_btn.Text = "Remove";
            this.rem_remove_btn.UseVisualStyleBackColor = true;
            this.rem_remove_btn.Click += new System.EventHandler(this.Remove);
            // 
            // SearchPanel
            // 
            this.SearchPanel.Controls.Add(this.SearchGB);
            this.SearchPanel.Location = new System.Drawing.Point(24, 426);
            this.SearchPanel.Name = "SearchPanel";
            this.SearchPanel.Size = new System.Drawing.Size(1288, 355);
            this.SearchPanel.TabIndex = 67;
            // 
            // SearchGB
            // 
            this.SearchGB.Controls.Add(this.label25);
            this.SearchGB.Controls.Add(this.label26);
            this.SearchGB.Controls.Add(this.label24);
            this.SearchGB.Controls.Add(this.label20);
            this.SearchGB.Controls.Add(this.DataGridResultLabel);
            this.SearchGB.Controls.Add(this.sea_empty_field);
            this.SearchGB.Controls.Add(this.MemberSearchDataGrid);
            this.SearchGB.Controls.Add(this.sea_name_txt);
            this.SearchGB.Controls.Add(this.label5);
            this.SearchGB.Controls.Add(this.sea_user_txt);
            this.SearchGB.Controls.Add(this.sea_id_txt);
            this.SearchGB.Controls.Add(this.sea_last_txt);
            this.SearchGB.Controls.Add(this.button2);
            this.SearchGB.Controls.Add(this.label14);
            this.SearchGB.Controls.Add(this.sea_search_btn);
            this.SearchGB.Controls.Add(this.label9);
            this.SearchGB.Controls.Add(this.label7);
            this.SearchGB.Controls.Add(this.sea_field_txt);
            this.SearchGB.Controls.Add(this.label8);
            this.SearchGB.Location = new System.Drawing.Point(3, 3);
            this.SearchGB.Name = "SearchGB";
            this.SearchGB.Size = new System.Drawing.Size(1279, 343);
            this.SearchGB.TabIndex = 74;
            this.SearchGB.TabStop = false;
            this.SearchGB.Text = "Search Panel";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(797, 55);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(11, 13);
            this.label25.TabIndex = 77;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(796, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(11, 13);
            this.label26.TabIndex = 76;
            this.label26.Text = "*";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(387, 55);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(11, 13);
            this.label24.TabIndex = 75;
            this.label24.Text = "*";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(386, 29);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(11, 13);
            this.label20.TabIndex = 71;
            this.label20.Text = "*";
            // 
            // DataGridResultLabel
            // 
            this.DataGridResultLabel.AutoSize = true;
            this.DataGridResultLabel.Location = new System.Drawing.Point(12, 309);
            this.DataGridResultLabel.Name = "DataGridResultLabel";
            this.DataGridResultLabel.Size = new System.Drawing.Size(0, 13);
            this.DataGridResultLabel.TabIndex = 65;
            // 
            // sea_empty_field
            // 
            this.sea_empty_field.Location = new System.Drawing.Point(1147, 42);
            this.sea_empty_field.Name = "sea_empty_field";
            this.sea_empty_field.Size = new System.Drawing.Size(102, 26);
            this.sea_empty_field.TabIndex = 23;
            this.sea_empty_field.Text = "Resest Fields";
            this.sea_empty_field.UseVisualStyleBackColor = true;
            this.sea_empty_field.Click += new System.EventHandler(this.clrbtn_Click);
            // 
            // MemberSearchDataGrid
            // 
            this.MemberSearchDataGrid.AllowUserToAddRows = false;
            this.MemberSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MemberSearchDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.count,
            this.name,
            this.lastname,
            this.ID,
            this.username,
            this.password,
            this.phone,
            this.address,
            this.field});
            this.MemberSearchDataGrid.Location = new System.Drawing.Point(13, 78);
            this.MemberSearchDataGrid.Name = "MemberSearchDataGrid";
            this.MemberSearchDataGrid.ReadOnly = true;
            this.MemberSearchDataGrid.Size = new System.Drawing.Size(1236, 217);
            this.MemberSearchDataGrid.TabIndex = 74;
            // 
            // count
            // 
            this.count.HeaderText = "No";
            this.count.Name = "count";
            this.count.ReadOnly = true;
            this.count.Width = 50;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // lastname
            // 
            this.lastname.HeaderText = "Last Name";
            this.lastname.Name = "lastname";
            this.lastname.ReadOnly = true;
            // 
            // ID
            // 
            this.ID.HeaderText = "Student ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 150;
            // 
            // username
            // 
            this.username.HeaderText = "User name";
            this.username.Name = "username";
            this.username.ReadOnly = true;
            this.username.Width = 150;
            // 
            // password
            // 
            this.password.HeaderText = "Password";
            this.password.Name = "password";
            this.password.ReadOnly = true;
            this.password.Width = 120;
            // 
            // phone
            // 
            this.phone.HeaderText = "Phone";
            this.phone.Name = "phone";
            this.phone.ReadOnly = true;
            this.phone.Width = 120;
            // 
            // address
            // 
            this.address.HeaderText = "Address";
            this.address.Name = "address";
            this.address.ReadOnly = true;
            this.address.Width = 200;
            // 
            // field
            // 
            this.field.HeaderText = "Field of study";
            this.field.Name = "field";
            this.field.ReadOnly = true;
            this.field.Width = 200;
            // 
            // sea_name_txt
            // 
            this.sea_name_txt.ForeColor = System.Drawing.Color.Black;
            this.sea_name_txt.Location = new System.Drawing.Point(110, 26);
            this.sea_name_txt.Name = "sea_name_txt";
            this.sea_name_txt.Size = new System.Drawing.Size(271, 20);
            this.sea_name_txt.TabIndex = 18;
            this.sea_name_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(866, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 73;
            this.label5.Text = "Student\'s ID";
            // 
            // sea_user_txt
            // 
            this.sea_user_txt.ForeColor = System.Drawing.Color.Black;
            this.sea_user_txt.Location = new System.Drawing.Point(110, 52);
            this.sea_user_txt.Name = "sea_user_txt";
            this.sea_user_txt.Size = new System.Drawing.Size(271, 20);
            this.sea_user_txt.TabIndex = 20;
            this.sea_user_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // sea_id_txt
            // 
            this.sea_id_txt.Location = new System.Drawing.Point(978, 22);
            this.sea_id_txt.Name = "sea_id_txt";
            this.sea_id_txt.Size = new System.Drawing.Size(271, 20);
            this.sea_id_txt.TabIndex = 16;
            this.sea_id_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sea_id_txt_KeyDown);
            // 
            // sea_last_txt
            // 
            this.sea_last_txt.ForeColor = System.Drawing.Color.Black;
            this.sea_last_txt.Location = new System.Drawing.Point(519, 23);
            this.sea_last_txt.Name = "sea_last_txt";
            this.sea_last_txt.Size = new System.Drawing.Size(271, 20);
            this.sea_last_txt.TabIndex = 19;
            this.sea_last_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1015, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 26);
            this.button2.TabIndex = 22;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Cancels_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 65;
            this.label14.Text = "Name";
            // 
            // sea_search_btn
            // 
            this.sea_search_btn.Location = new System.Drawing.Point(869, 42);
            this.sea_search_btn.Name = "sea_search_btn";
            this.sea_search_btn.Size = new System.Drawing.Size(104, 26);
            this.sea_search_btn.TabIndex = 18;
            this.sea_search_btn.Text = "Search";
            this.sea_search_btn.UseVisualStyleBackColor = true;
            this.sea_search_btn.Click += new System.EventHandler(this.sea_search_btn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 67;
            this.label9.Text = "UserName";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(420, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 70;
            this.label7.Text = "Field Of Study";
            // 
            // sea_field_txt
            // 
            this.sea_field_txt.ForeColor = System.Drawing.Color.Black;
            this.sea_field_txt.Location = new System.Drawing.Point(519, 48);
            this.sea_field_txt.Name = "sea_field_txt";
            this.sea_field_txt.Size = new System.Drawing.Size(271, 20);
            this.sea_field_txt.TabIndex = 21;
            this.sea_field_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(421, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 68;
            this.label8.Text = "Last Name";
            // 
            // UserXForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1429, 843);
            this.Controls.Add(this.SearchPanel);
            this.Controls.Add(this.RemovePanel);
            this.Controls.Add(this.JoinPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UserXForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Member Join";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.UserXForm_Load);
            this.JoinPanel.ResumeLayout(false);
            this.SetGB.ResumeLayout(false);
            this.SetGB.PerformLayout();
            this.RemovePanel.ResumeLayout(false);
            this.RemoveGB.ResumeLayout(false);
            this.RemoveGB.PerformLayout();
            this.SearchPanel.ResumeLayout(false);
            this.SearchGB.ResumeLayout(false);
            this.SearchGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemberSearchDataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel JoinPanel;
        private System.Windows.Forms.GroupBox SetGB;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox set_id_txt;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button MemSetBtn;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox set_field_txt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox set_add_txt;
        private System.Windows.Forms.TextBox set_phone_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox set_name_txt;
        private System.Windows.Forms.TextBox set_last_txt;
        private System.Windows.Forms.TextBox set_pass_txt;
        private System.Windows.Forms.TextBox set_username_txt;
        private System.Windows.Forms.Panel RemovePanel;
        private System.Windows.Forms.GroupBox RemoveGB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox rem_id_txt;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button rem_remove_btn;
        private System.Windows.Forms.Panel SearchPanel;
        private System.Windows.Forms.GroupBox SearchGB;
        private System.Windows.Forms.DataGridView MemberSearchDataGrid;
        private System.Windows.Forms.TextBox sea_name_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox sea_user_txt;
        private System.Windows.Forms.TextBox sea_id_txt;
        private System.Windows.Forms.TextBox sea_last_txt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button sea_search_btn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox sea_field_txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox set_conf_txt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button sea_empty_field;
        private System.Windows.Forms.Label DataGridResultLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn count;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn username;
        private System.Windows.Forms.DataGridViewTextBoxColumn password;
        private System.Windows.Forms.DataGridViewTextBoxColumn phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn field;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label20;

    }
}
﻿namespace Server
{
    partial class AddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddBook));
            this.AddBookGB = new System.Windows.Forms.GroupBox();
            this.Date = new System.Windows.Forms.DateTimePicker();
            this.CnclBtn = new System.Windows.Forms.Button();
            this.ClrBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.BookExpText = new System.Windows.Forms.TextBox();
            this.BookPublisherText = new System.Windows.Forms.TextBox();
            this.BookWriterText = new System.Windows.Forms.TextBox();
            this.BookNameText = new System.Windows.Forms.TextBox();
            this.BookIdText = new System.Windows.Forms.TextBox();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AddBookGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddBookGB
            // 
            this.AddBookGB.Controls.Add(this.Date);
            this.AddBookGB.Controls.Add(this.CnclBtn);
            this.AddBookGB.Controls.Add(this.ClrBtn);
            this.AddBookGB.Controls.Add(this.AddBtn);
            this.AddBookGB.Controls.Add(this.label7);
            this.AddBookGB.Controls.Add(this.BookExpText);
            this.AddBookGB.Controls.Add(this.BookPublisherText);
            this.AddBookGB.Controls.Add(this.BookWriterText);
            this.AddBookGB.Controls.Add(this.BookNameText);
            this.AddBookGB.Controls.Add(this.BookIdText);
            this.AddBookGB.Controls.Add(this.CategoryCombo);
            this.AddBookGB.Controls.Add(this.label6);
            this.AddBookGB.Controls.Add(this.label5);
            this.AddBookGB.Controls.Add(this.label4);
            this.AddBookGB.Controls.Add(this.label3);
            this.AddBookGB.Controls.Add(this.label2);
            this.AddBookGB.Controls.Add(this.label1);
            this.AddBookGB.Location = new System.Drawing.Point(3, 4);
            this.AddBookGB.Name = "AddBookGB";
            this.AddBookGB.Size = new System.Drawing.Size(578, 583);
            this.AddBookGB.TabIndex = 0;
            this.AddBookGB.TabStop = false;
            this.AddBookGB.Text = "Add Book Panel";
            // 
            // Date
            // 
            this.Date.Location = new System.Drawing.Point(350, 227);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(200, 20);
            this.Date.TabIndex = 81;
            // 
            // CnclBtn
            // 
            this.CnclBtn.Location = new System.Drawing.Point(405, 546);
            this.CnclBtn.Name = "CnclBtn";
            this.CnclBtn.Size = new System.Drawing.Size(143, 23);
            this.CnclBtn.TabIndex = 77;
            this.CnclBtn.Text = "Cancel";
            this.CnclBtn.UseVisualStyleBackColor = true;
            this.CnclBtn.Click += new System.EventHandler(this.CnclBtn_Click);
            // 
            // ClrBtn
            // 
            this.ClrBtn.Location = new System.Drawing.Point(218, 546);
            this.ClrBtn.Name = "ClrBtn";
            this.ClrBtn.Size = new System.Drawing.Size(143, 23);
            this.ClrBtn.TabIndex = 76;
            this.ClrBtn.Text = "Clear fields";
            this.ClrBtn.UseVisualStyleBackColor = true;
            this.ClrBtn.Click += new System.EventHandler(this.ClrBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(28, 546);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(143, 23);
            this.AddBtn.TabIndex = 75;
            this.AddBtn.Text = "Add to database";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 13);
            this.label7.TabIndex = 69;
            this.label7.Text = "Enter the date of the publish :";
            // 
            // BookExpText
            // 
            this.BookExpText.Location = new System.Drawing.Point(28, 389);
            this.BookExpText.Multiline = true;
            this.BookExpText.Name = "BookExpText";
            this.BookExpText.Size = new System.Drawing.Size(520, 141);
            this.BookExpText.TabIndex = 71;
            // 
            // BookPublisherText
            // 
            this.BookPublisherText.Location = new System.Drawing.Point(350, 281);
            this.BookPublisherText.Name = "BookPublisherText";
            this.BookPublisherText.Size = new System.Drawing.Size(198, 20);
            this.BookPublisherText.TabIndex = 70;
            // 
            // BookWriterText
            // 
            this.BookWriterText.Location = new System.Drawing.Point(350, 179);
            this.BookWriterText.Name = "BookWriterText";
            this.BookWriterText.Size = new System.Drawing.Size(198, 20);
            this.BookWriterText.TabIndex = 66;
            // 
            // BookNameText
            // 
            this.BookNameText.Location = new System.Drawing.Point(350, 126);
            this.BookNameText.Name = "BookNameText";
            this.BookNameText.Size = new System.Drawing.Size(198, 20);
            this.BookNameText.TabIndex = 65;
            // 
            // BookIdText
            // 
            this.BookIdText.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.BookIdText.Location = new System.Drawing.Point(350, 77);
            this.BookIdText.Name = "BookIdText";
            this.BookIdText.Size = new System.Drawing.Size(198, 20);
            this.BookIdText.TabIndex = 64;
            this.BookIdText.TabStop = false;
            this.BookIdText.Text = "To automatic setting ID leave empty ";
            this.BookIdText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BookIdText.Enter += new System.EventHandler(this.BookId_Enter);
            this.BookIdText.Leave += new System.EventHandler(this.BookIdText_Leave);
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(350, 34);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(198, 21);
            this.CategoryCombo.TabIndex = 63;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 341);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(465, 39);
            this.label6.TabIndex = 5;
            this.label6.Text = "Enter some explanation about this book :\r\n \r\n( to provide some idea what is this " +
                "book about, and also can be an \'Empty Field\' [No Explanation])";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 284);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter publisher name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enter the name of the book\'s writer :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter the book name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(265, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter an ID for this book [ And this should be unique ] :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select the category of the target book :";
            // 
            // AddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 589);
            this.Controls.Add(this.AddBookGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddBook";
            this.Text = "AddBook";
            this.Deactivate += new System.EventHandler(this.AddBook_Deactivate);
            this.AddBookGB.ResumeLayout(false);
            this.AddBookGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AddBookGB;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox BookExpText;
        private System.Windows.Forms.TextBox BookPublisherText;
        private System.Windows.Forms.TextBox BookWriterText;
        private System.Windows.Forms.TextBox BookNameText;
        private System.Windows.Forms.TextBox BookIdText;
        private System.Windows.Forms.Button CnclBtn;
        private System.Windows.Forms.Button ClrBtn;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.DateTimePicker Date;
    }
}
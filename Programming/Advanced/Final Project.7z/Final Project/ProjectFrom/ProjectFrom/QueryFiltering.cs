﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace Server
{
    internal partial class QueryFiltering : Form
    {
        internal enum Filter { Query, User }
        string FilePath;
        public QueryFiltering(Filter filter)
        {
            InitializeComponent();
            this.TopMost = true;
            this.Opacity = 94;
            try
            {
                switch (filter)
                {
                    case QueryFiltering.Filter.Query:
                        label1.Text = "Filter these search query : [Seperate them with ',']";
                        using (FileStream fs = new FileStream(FilePath = Application.StartupPath + @"\Files\DataBase\QFilters.FILE", FileMode.Open, FileAccess.Read, FileShare.None))
                        {
                            using (StreamReader read = new StreamReader(fs))
                            {
                                while (!read.EndOfStream)
                                {
                                    richTextBox1.Text += read.ReadLine() + ",";
                                }
                            }
                        }
                        break;
                    case QueryFiltering.Filter.User:
                        label1.Text = "Filter these users, Enter ONLY their usernames: [Seperate them with ',']";
                        using (FileStream fs = new FileStream(FilePath = Application.StartupPath + @"\Files\DataBase\UFilters.FILE", FileMode.Open, FileAccess.Read, FileShare.None))
                        {
                            using (StreamReader read = new StreamReader(fs))
                            {
                                while (!read.EndOfStream)
                                {
                                    richTextBox1.Text += read.ReadLine() + ",";
                                }
                            }
                        }
                        break;
                }
            }
            catch (FileNotFoundException) { }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }

        private void discardBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void svBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    using (StreamWriter write = new StreamWriter(fs))
                    {
                        string[] tmp = richTextBox1.Text.Split(new string[] { ",", " , ", " ," }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string i in tmp)
                        {
                            write.WriteLine(i);
                            write.Flush();
                        }
                    }
                }
                Sundries.MessageBox.ShowMessage("Filters have been saved successfully.");
                Sundries.Opacity.OpacityClose(this);
            }
            catch (Exception er)
            {
                Sundries.MessageBox.ShowMessage(er.Message);
            }
        }
    }
}

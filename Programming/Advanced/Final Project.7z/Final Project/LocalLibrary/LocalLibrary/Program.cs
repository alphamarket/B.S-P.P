﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace LocalLibrary
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Communication.Setting.ConnectionSetting.CreateEssentialDirectory();
            Application.Run(new Login());
        }
    }
}

﻿namespace LocalLibrary
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10,
            treeNode13,
            treeNode18,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Other");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("All Book", new System.Windows.Forms.TreeNode[] {
            treeNode8,
            treeNode20,
            treeNode21});
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27,
            treeNode28,
            treeNode29});
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode36,
            treeNode37,
            treeNode38,
            treeNode39});
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode31,
            treeNode32,
            treeNode35,
            treeNode40,
            treeNode41});
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Other");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("AllBook", new System.Windows.Forms.TreeNode[] {
            treeNode30,
            treeNode42,
            treeNode43});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.EnterUser = new System.Windows.Forms.Button();
            this.UserNametext = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.UserGB = new System.Windows.Forms.GroupBox();
            this.Guest = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Passtext = new System.Windows.Forms.TextBox();
            this.AdminGB = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.AdminPassTB = new System.Windows.Forms.TextBox();
            this.AdminTB = new System.Windows.Forms.TextBox();
            this.AdminB = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PossibilityGB = new System.Windows.Forms.GroupBox();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.dvgfdsfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sdfsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fsfsdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fdfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.DepositGB = new System.Windows.Forms.GroupBox();
            this.AllBook = new System.Windows.Forms.Button();
            this.StateMe = new System.Windows.Forms.Button();
            this.NewSerch = new System.Windows.Forms.Button();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.DepositBT = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.treeView3 = new System.Windows.Forms.TreeView();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.EditUP = new System.Windows.Forms.Button();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.SearchTV = new System.Windows.Forms.TreeView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.SearchNotificationLabel = new System.Windows.Forms.Label();
            this.SearchTypeCombo = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.SearchKeyText = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button3 = new System.Windows.Forms.Button();
            this.SearchBT = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.ViewGB = new System.Windows.Forms.GroupBox();
            this.Similerword = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.See1 = new System.Windows.Forms.LinkLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.Admin = new System.Windows.Forms.GroupBox();
            this.DayNewsDG = new System.Windows.Forms.DataGridView();
            this.Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BorroserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BorrowDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NowDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.BorrowerIDTB = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.BookId = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.BorrowPanel = new System.Windows.Forms.Panel();
            this.Save = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.DateCount = new System.Windows.Forms.Label();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.button4 = new System.Windows.Forms.Button();
            this.BorrowBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.mainToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchLibraryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.libraryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.todaysBorrowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borrowBookToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.membershipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.joinToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.addBookToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.UserGB.SuspendLayout();
            this.AdminGB.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.PossibilityGB.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.DepositGB.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.ViewGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Similerword)).BeginInit();
            this.Admin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DayNewsDG)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.BorrowPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // EnterUser
            // 
            this.EnterUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EnterUser.Location = new System.Drawing.Point(277, 108);
            this.EnterUser.Name = "EnterUser";
            this.EnterUser.Size = new System.Drawing.Size(58, 23);
            this.EnterUser.TabIndex = 1;
            this.EnterUser.Text = "Enter";
            this.EnterUser.UseVisualStyleBackColor = true;
            this.EnterUser.Click += new System.EventHandler(this.EnterUser_Click);
            // 
            // UserNametext
            // 
            this.UserNametext.Location = new System.Drawing.Point(86, 36);
            this.UserNametext.Name = "UserNametext";
            this.UserNametext.Size = new System.Drawing.Size(249, 20);
            this.UserNametext.TabIndex = 2;
            this.UserNametext.Text = "ffahafd";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "User Name";
            // 
            // UserGB
            // 
            this.UserGB.Controls.Add(this.Guest);
            this.UserGB.Controls.Add(this.button1);
            this.UserGB.Controls.Add(this.label2);
            this.UserGB.Controls.Add(this.Passtext);
            this.UserGB.Controls.Add(this.UserNametext);
            this.UserGB.Controls.Add(this.EnterUser);
            this.UserGB.Controls.Add(this.label1);
            this.UserGB.Location = new System.Drawing.Point(6, 144);
            this.UserGB.Name = "UserGB";
            this.UserGB.Size = new System.Drawing.Size(347, 143);
            this.UserGB.TabIndex = 4;
            this.UserGB.TabStop = false;
            this.UserGB.Text = "Log As User";
            // 
            // Guest
            // 
            this.Guest.AutoSize = true;
            this.Guest.Location = new System.Drawing.Point(9, 112);
            this.Guest.Name = "Guest";
            this.Guest.Size = new System.Drawing.Size(54, 17);
            this.Guest.TabIndex = 8;
            this.Guest.Text = "Guest";
            this.Guest.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(214, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Pass";
            // 
            // Passtext
            // 
            this.Passtext.Location = new System.Drawing.Point(86, 77);
            this.Passtext.Name = "Passtext";
            this.Passtext.Size = new System.Drawing.Size(249, 20);
            this.Passtext.TabIndex = 4;
            this.Passtext.Text = "ffahfsah";
            this.Passtext.UseSystemPasswordChar = true;
            // 
            // AdminGB
            // 
            this.AdminGB.Controls.Add(this.button2);
            this.AdminGB.Controls.Add(this.label3);
            this.AdminGB.Controls.Add(this.AdminPassTB);
            this.AdminGB.Controls.Add(this.AdminTB);
            this.AdminGB.Controls.Add(this.AdminB);
            this.AdminGB.Controls.Add(this.label4);
            this.AdminGB.Location = new System.Drawing.Point(6, 318);
            this.AdminGB.Name = "AdminGB";
            this.AdminGB.Size = new System.Drawing.Size(347, 138);
            this.AdminGB.TabIndex = 5;
            this.AdminGB.TabStop = false;
            this.AdminGB.Text = "Log As Admin";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(214, 101);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Pass";
            // 
            // AdminPassTB
            // 
            this.AdminPassTB.Location = new System.Drawing.Point(81, 67);
            this.AdminPassTB.Name = "AdminPassTB";
            this.AdminPassTB.Size = new System.Drawing.Size(254, 20);
            this.AdminPassTB.TabIndex = 4;
            this.AdminPassTB.Text = "123456";
            this.AdminPassTB.UseSystemPasswordChar = true;
            // 
            // AdminTB
            // 
            this.AdminTB.Location = new System.Drawing.Point(81, 25);
            this.AdminTB.Name = "AdminTB";
            this.AdminTB.Size = new System.Drawing.Size(254, 20);
            this.AdminTB.TabIndex = 2;
            this.AdminTB.Text = "asghar";
            // 
            // AdminB
            // 
            this.AdminB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AdminB.Location = new System.Drawing.Point(285, 101);
            this.AdminB.Name = "AdminB";
            this.AdminB.Size = new System.Drawing.Size(50, 23);
            this.AdminB.TabIndex = 1;
            this.AdminB.Text = "Enter";
            this.AdminB.UseVisualStyleBackColor = true;
            this.AdminB.Click += new System.EventHandler(this.AdminB_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "ID";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(1386, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.userToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.fileToolStripMenuItem.Text = "&Log as";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.adminToolStripMenuItem.Text = "User";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // userToolStripMenuItem
            // 
            this.userToolStripMenuItem.Name = "userToolStripMenuItem";
            this.userToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.userToolStripMenuItem.Text = "Admin";
            this.userToolStripMenuItem.Click += new System.EventHandler(this.userToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // PossibilityGB
            // 
            this.PossibilityGB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PossibilityGB.Controls.Add(this.menuStrip3);
            this.PossibilityGB.Controls.Add(this.DepositGB);
            this.PossibilityGB.Controls.Add(this.DepositBT);
            this.PossibilityGB.Controls.Add(this.groupBox10);
            this.PossibilityGB.Controls.Add(this.button12);
            this.PossibilityGB.Controls.Add(this.button9);
            this.PossibilityGB.Controls.Add(this.groupBox7);
            this.PossibilityGB.Controls.Add(this.groupBox4);
            this.PossibilityGB.Controls.Add(this.groupBox5);
            this.PossibilityGB.Controls.Add(this.groupBox6);
            this.PossibilityGB.Controls.Add(this.button3);
            this.PossibilityGB.Controls.Add(this.SearchBT);
            this.PossibilityGB.Controls.Add(this.button7);
            this.PossibilityGB.Location = new System.Drawing.Point(73, 54);
            this.PossibilityGB.Name = "PossibilityGB";
            this.PossibilityGB.Padding = new System.Windows.Forms.Padding(0);
            this.PossibilityGB.Size = new System.Drawing.Size(1424, 325);
            this.PossibilityGB.TabIndex = 14;
            this.PossibilityGB.TabStop = false;
            this.PossibilityGB.Text = "Possibility";
            // 
            // menuStrip3
            // 
            this.menuStrip3.BackColor = System.Drawing.Color.Thistle;
            this.menuStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dvgfdsfToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 13);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip3.Size = new System.Drawing.Size(1424, 24);
            this.menuStrip3.TabIndex = 41;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // dvgfdsfToolStripMenuItem
            // 
            this.dvgfdsfToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sdfsToolStripMenuItem,
            this.fsfsdToolStripMenuItem,
            this.fdfToolStripMenuItem,
            this.backToolStripMenuItem1,
            this.exitToolStripMenuItem3});
            this.dvgfdsfToolStripMenuItem.Name = "dvgfdsfToolStripMenuItem";
            this.dvgfdsfToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.dvgfdsfToolStripMenuItem.Text = "&File";
            // 
            // sdfsToolStripMenuItem
            // 
            this.sdfsToolStripMenuItem.Name = "sdfsToolStripMenuItem";
            this.sdfsToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.sdfsToolStripMenuItem.Text = "sdfs";
            // 
            // fsfsdToolStripMenuItem
            // 
            this.fsfsdToolStripMenuItem.Name = "fsfsdToolStripMenuItem";
            this.fsfsdToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.fsfsdToolStripMenuItem.Text = "fsfsd";
            // 
            // fdfToolStripMenuItem
            // 
            this.fdfToolStripMenuItem.Name = "fdfToolStripMenuItem";
            this.fdfToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.fdfToolStripMenuItem.Text = "fdf";
            // 
            // backToolStripMenuItem1
            // 
            this.backToolStripMenuItem1.Name = "backToolStripMenuItem1";
            this.backToolStripMenuItem1.Size = new System.Drawing.Size(99, 22);
            this.backToolStripMenuItem1.Text = "B&ack";
            this.backToolStripMenuItem1.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem3
            // 
            this.exitToolStripMenuItem3.Name = "exitToolStripMenuItem3";
            this.exitToolStripMenuItem3.Size = new System.Drawing.Size(99, 22);
            this.exitToolStripMenuItem3.Text = "E&xit";
            // 
            // DepositGB
            // 
            this.DepositGB.Controls.Add(this.AllBook);
            this.DepositGB.Controls.Add(this.StateMe);
            this.DepositGB.Controls.Add(this.NewSerch);
            this.DepositGB.Controls.Add(this.linkLabel6);
            this.DepositGB.Location = new System.Drawing.Point(1088, 72);
            this.DepositGB.Name = "DepositGB";
            this.DepositGB.Size = new System.Drawing.Size(237, 250);
            this.DepositGB.TabIndex = 35;
            this.DepositGB.TabStop = false;
            this.DepositGB.Tag = "";
            this.DepositGB.Text = "Deposit Book";
            // 
            // AllBook
            // 
            this.AllBook.Location = new System.Drawing.Point(17, 186);
            this.AllBook.Name = "AllBook";
            this.AllBook.Size = new System.Drawing.Size(189, 23);
            this.AllBook.TabIndex = 34;
            this.AllBook.Text = "View all book";
            this.AllBook.UseVisualStyleBackColor = true;
            this.AllBook.Click += new System.EventHandler(this.AllBook_Click);
            // 
            // StateMe
            // 
            this.StateMe.Location = new System.Drawing.Point(17, 146);
            this.StateMe.Name = "StateMe";
            this.StateMe.Size = new System.Drawing.Size(189, 23);
            this.StateMe.TabIndex = 33;
            this.StateMe.Text = "State Me";
            this.StateMe.UseVisualStyleBackColor = true;
            this.StateMe.Click += new System.EventHandler(this.StateMe_Click);
            // 
            // NewSerch
            // 
            this.NewSerch.Location = new System.Drawing.Point(17, 105);
            this.NewSerch.Name = "NewSerch";
            this.NewSerch.Size = new System.Drawing.Size(189, 23);
            this.NewSerch.TabIndex = 32;
            this.NewSerch.Text = "Search Book";
            this.NewSerch.UseVisualStyleBackColor = true;
            this.NewSerch.Click += new System.EventHandler(this.SearchBT_Click);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel6.Location = new System.Drawing.Point(153, 229);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(53, 13);
            this.linkLabel6.TabIndex = 31;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "See More";
            // 
            // DepositBT
            // 
            this.DepositBT.Location = new System.Drawing.Point(1088, 43);
            this.DepositBT.Name = "DepositBT";
            this.DepositBT.Size = new System.Drawing.Size(228, 23);
            this.DepositBT.TabIndex = 34;
            this.DepositBT.Text = "Deposit Book";
            this.DepositBT.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.linkLabel5);
            this.groupBox10.Controls.Add(this.treeView3);
            this.groupBox10.Location = new System.Drawing.Point(806, 78);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(254, 241);
            this.groupBox10.TabIndex = 33;
            this.groupBox10.TabStop = false;
            this.groupBox10.Tag = "";
            this.groupBox10.Text = "All Book";
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel5.Location = new System.Drawing.Point(172, 221);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(53, 13);
            this.linkLabel5.TabIndex = 31;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "See More";
            // 
            // treeView3
            // 
            this.treeView3.Location = new System.Drawing.Point(17, 27);
            this.treeView3.Name = "treeView3";
            treeNode1.Name = "Node17";
            treeNode1.Text = "Computer";
            treeNode2.Name = "Node18";
            treeNode2.Text = "Chemistry";
            treeNode3.Name = "Node19";
            treeNode3.Text = "Mechanic";
            treeNode4.Name = "Node20";
            treeNode4.Text = "Mine";
            treeNode5.Name = "Node21";
            treeNode5.Text = "Antitrust";
            treeNode6.Name = "Node22";
            treeNode6.Text = "Electricity";
            treeNode7.Name = "Node23";
            treeNode7.Text = "OtherEngineer";
            treeNode8.Name = "Node12";
            treeNode8.Text = "Engineer";
            treeNode9.Name = "Node24";
            treeNode9.Text = "Math";
            treeNode10.Name = "Node25";
            treeNode10.Text = "Physic";
            treeNode11.Name = "Node28";
            treeNode11.Text = "Poem";
            treeNode12.Name = "Node29";
            treeNode12.Text = "Prose";
            treeNode13.Name = "Node26";
            treeNode13.Text = "Literary";
            treeNode14.Name = "Node34";
            treeNode14.Text = "Turkish";
            treeNode15.Name = "Node30";
            treeNode15.Text = "Enghlish";
            treeNode16.Name = "Node31";
            treeNode16.Text = "Russian";
            treeNode17.Name = "Node32";
            treeNode17.Text = "Other Language";
            treeNode18.Name = "Node27";
            treeNode18.Text = "LanguageBook";
            treeNode19.Name = "Node33";
            treeNode19.Text = "Cult";
            treeNode20.Name = "Node14";
            treeNode20.Text = "Public";
            treeNode21.Name = "Node16";
            treeNode21.Text = "Other";
            treeNode22.Name = "Node11";
            treeNode22.Text = "All Book";
            this.treeView3.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode22});
            this.treeView3.Size = new System.Drawing.Size(212, 181);
            this.treeView3.TabIndex = 6;
            this.treeView3.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView3_AfterSelect);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(806, 45);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(247, 23);
            this.button12.TabIndex = 32;
            this.button12.Text = "Virtual library";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(134, 45);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(77, 23);
            this.button9.TabIndex = 32;
            this.button9.Text = "State Me";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.EditUP);
            this.groupBox7.Controls.Add(this.linkLabel4);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox7.Location = new System.Drawing.Point(19, 196);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 123);
            this.groupBox7.TabIndex = 31;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Share";
            // 
            // EditUP
            // 
            this.EditUP.Location = new System.Drawing.Point(5, 27);
            this.EditUP.Name = "EditUP";
            this.EditUP.Size = new System.Drawing.Size(177, 23);
            this.EditUP.TabIndex = 30;
            this.EditUP.Text = "Edit Username And Password";
            this.EditUP.UseVisualStyleBackColor = true;
            this.EditUP.Click += new System.EventHandler(this.EditUP_Click);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel4.Location = new System.Drawing.Point(42, 100);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(140, 13);
            this.linkLabel4.TabIndex = 20;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Edit Usernme and Password";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.linkLabel3);
            this.groupBox4.Controls.Add(this.SearchTV);
            this.groupBox4.Location = new System.Drawing.Point(518, 79);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(260, 240);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Tag = "";
            this.groupBox4.Text = "All Book";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel3.Location = new System.Drawing.Point(175, 225);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(53, 13);
            this.linkLabel3.TabIndex = 31;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "See More";
            // 
            // SearchTV
            // 
            this.SearchTV.Location = new System.Drawing.Point(17, 27);
            this.SearchTV.Name = "SearchTV";
            treeNode23.Name = "Node17";
            treeNode23.Text = "Computer";
            treeNode24.Name = "Node18";
            treeNode24.Text = "Chemistry";
            treeNode25.Name = "Node19";
            treeNode25.Text = "Mechanic";
            treeNode26.Name = "Node20";
            treeNode26.Text = "Mine";
            treeNode27.Name = "Node21";
            treeNode27.Text = "Antitrust";
            treeNode28.Name = "Node22";
            treeNode28.Text = "Electricity";
            treeNode29.Name = "Node23";
            treeNode29.Text = "OtherEngineer";
            treeNode30.Name = "Node12";
            treeNode30.Text = "Engineer";
            treeNode31.Name = "Node24";
            treeNode31.Text = "Math";
            treeNode32.Name = "Node25";
            treeNode32.Text = "Physic";
            treeNode33.Name = "Node28";
            treeNode33.Text = "Poem";
            treeNode34.Name = "Node29";
            treeNode34.Text = "Prose";
            treeNode35.Name = "Node26";
            treeNode35.Text = "Literary";
            treeNode36.Name = "Node34";
            treeNode36.Text = "Turkish";
            treeNode37.Name = "Node30";
            treeNode37.Text = "Enghlish";
            treeNode38.Name = "Node31";
            treeNode38.Text = "Russian";
            treeNode39.Name = "Node32";
            treeNode39.Text = "Other Language";
            treeNode40.Name = "Node27";
            treeNode40.Text = "LanguageBook";
            treeNode41.Name = "Node33";
            treeNode41.Text = "Cult";
            treeNode42.Name = "Node14";
            treeNode42.Text = "Public";
            treeNode43.Name = "Node16";
            treeNode43.Text = "Other";
            treeNode44.Name = "Node11";
            treeNode44.Text = "AllBook";
            this.SearchTV.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode44});
            this.SearchTV.Size = new System.Drawing.Size(219, 181);
            this.SearchTV.TabIndex = 6;
            this.SearchTV.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.SearchNotificationLabel);
            this.groupBox5.Controls.Add(this.SearchTypeCombo);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.linkLabel2);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.SearchKeyText);
            this.groupBox5.Controls.Add(this.SearchBtn);
            this.groupBox5.Location = new System.Drawing.Point(225, 81);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(278, 238);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quick Search";
            // 
            // SearchNotificationLabel
            // 
            this.SearchNotificationLabel.AutoSize = true;
            this.SearchNotificationLabel.Location = new System.Drawing.Point(16, 187);
            this.SearchNotificationLabel.Name = "SearchNotificationLabel";
            this.SearchNotificationLabel.Size = new System.Drawing.Size(97, 13);
            this.SearchNotificationLabel.TabIndex = 40;
            this.SearchNotificationLabel.Text = "Search Notification";
            // 
            // SearchTypeCombo
            // 
            this.SearchTypeCombo.FormattingEnabled = true;
            this.SearchTypeCombo.Items.AddRange(new object[] {
            "By ID",
            "Name Book",
            "Writer",
            "Publisher",
            "Key Word"});
            this.SearchTypeCombo.Location = new System.Drawing.Point(73, 126);
            this.SearchTypeCombo.Name = "SearchTypeCombo";
            this.SearchTypeCombo.Size = new System.Drawing.Size(167, 21);
            this.SearchTypeCombo.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Search Type :";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel2.Location = new System.Drawing.Point(169, 218);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(87, 13);
            this.linkLabel2.TabIndex = 30;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Advance Search";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.button5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Search Key :";
            // 
            // SearchKeyText
            // 
            this.SearchKeyText.Location = new System.Drawing.Point(73, 51);
            this.SearchKeyText.Name = "SearchKeyText";
            this.SearchKeyText.Size = new System.Drawing.Size(167, 20);
            this.SearchKeyText.TabIndex = 21;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(182, 163);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(58, 23);
            this.SearchBtn.TabIndex = 19;
            this.SearchBtn.Text = "&Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Controls.Add(this.linkLabel1);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox6.Location = new System.Drawing.Point(22, 81);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 113);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Share";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(5, 27);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(177, 23);
            this.button6.TabIndex = 30;
            this.button6.Text = "&Share Book";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.Location = new System.Drawing.Point(147, 90);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(35, 13);
            this.linkLabel1.TabIndex = 20;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Share";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(521, 45);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(253, 23);
            this.button3.TabIndex = 24;
            this.button3.Text = "View All Book";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // SearchBT
            // 
            this.SearchBT.Location = new System.Drawing.Point(237, 45);
            this.SearchBT.Name = "SearchBT";
            this.SearchBT.Size = new System.Drawing.Size(244, 23);
            this.SearchBT.TabIndex = 23;
            this.SearchBT.Text = "&Search";
            this.SearchBT.UseVisualStyleBackColor = true;
            this.SearchBT.Click += new System.EventHandler(this.SearchBT_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(27, 45);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(79, 23);
            this.button7.TabIndex = 22;
            this.button7.Text = "&Share Book";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // ViewGB
            // 
            this.ViewGB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ViewGB.Controls.Add(this.Similerword);
            this.ViewGB.Controls.Add(this.See1);
            this.ViewGB.Controls.Add(this.label6);
            this.ViewGB.Location = new System.Drawing.Point(371, 419);
            this.ViewGB.Name = "ViewGB";
            this.ViewGB.Size = new System.Drawing.Size(1423, 325);
            this.ViewGB.TabIndex = 38;
            this.ViewGB.TabStop = false;
            this.ViewGB.Text = "Possibility";
            // 
            // Similerword
            // 
            this.Similerword.AllowUserToAddRows = false;
            this.Similerword.AllowUserToDeleteRows = false;
            this.Similerword.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Similerword.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn36});
            this.Similerword.Location = new System.Drawing.Point(29, 56);
            this.Similerword.Name = "Similerword";
            this.Similerword.ReadOnly = true;
            this.Similerword.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Similerword.Size = new System.Drawing.Size(1300, 210);
            this.Similerword.TabIndex = 62;
            this.Similerword.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Similerword_CellContentClick);
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "ID";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 75;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Book ID";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Width = 240;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "name";
            this.dataGridViewTextBoxColumn34.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Width = 280;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "Writer";
            this.dataGridViewTextBoxColumn35.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Width = 230;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "Publisher";
            this.dataGridViewTextBoxColumn31.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 230;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "Category";
            this.dataGridViewTextBoxColumn36.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 220;
            // 
            // See1
            // 
            this.See1.ActiveLinkColor = System.Drawing.Color.Blue;
            this.See1.AutoSize = true;
            this.See1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.See1.Location = new System.Drawing.Point(77, 290);
            this.See1.Name = "See1";
            this.See1.Size = new System.Drawing.Size(86, 13);
            this.See1.TabIndex = 45;
            this.See1.TabStop = true;
            this.See1.Text = "See More Result";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 44;
            this.label6.Text = "Search Result :";
            // 
            // Admin
            // 
            this.Admin.Controls.Add(this.DayNewsDG);
            this.Admin.Controls.Add(this.tabControl1);
            this.Admin.Controls.Add(this.menuStrip2);
            this.Admin.Location = new System.Drawing.Point(12, 520);
            this.Admin.Name = "Admin";
            this.Admin.Size = new System.Drawing.Size(1350, 726);
            this.Admin.TabIndex = 39;
            this.Admin.TabStop = false;
            this.Admin.Text = "Admin";
            // 
            // DayNewsDG
            // 
            this.DayNewsDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DayNewsDG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column,
            this.Name,
            this.BorroserID,
            this.BookName,
            this.BorrowDate,
            this.NowDate,
            this.Column7,
            this.Column8});
            this.DayNewsDG.Location = new System.Drawing.Point(11, 439);
            this.DayNewsDG.Name = "DayNewsDG";
            this.DayNewsDG.Size = new System.Drawing.Size(1330, 268);
            this.DayNewsDG.TabIndex = 7;
            this.DayNewsDG.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DayNewsDG_CellContentClick);
            // 
            // Column
            // 
            this.Column.HeaderText = "Column9";
            this.Column.Name = "Column";
            this.Column.Width = 30;
            // 
            // Name
            // 
            this.Name.HeaderText = "User";
            this.Name.Name = "Name";
            this.Name.Width = 190;
            // 
            // BorroserID
            // 
            this.BorroserID.HeaderText = "BorroserID";
            this.BorroserID.Name = "BorroserID";
            this.BorroserID.Width = 190;
            // 
            // BookName
            // 
            this.BookName.HeaderText = "BookName";
            this.BookName.Name = "BookName";
            this.BookName.Width = 190;
            // 
            // BorrowDate
            // 
            this.BorrowDate.HeaderText = "BookID";
            this.BorrowDate.Name = "BorrowDate";
            this.BorrowDate.Width = 190;
            // 
            // NowDate
            // 
            this.NowDate.HeaderText = "BorrowDate";
            this.NowDate.Name = "NowDate";
            this.NowDate.Width = 170;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Subsequence";
            this.Column7.Name = "Column7";
            this.Column7.Width = 170;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Fine";
            this.Column8.Name = "Column8";
            this.Column8.Width = 170;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(10, 43);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1330, 353);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DimGray;
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.BorrowPanel);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1322, 327);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Library Transaction System";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Location = new System.Drawing.Point(1177, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(139, 313);
            this.panel3.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.button10);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.BorrowerIDTB);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.BookId);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(615, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(556, 314);
            this.panel2.TabIndex = 4;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(384, 253);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(149, 23);
            this.button10.TabIndex = 5;
            this.button10.Text = "Clear Fields";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(58, 253);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(149, 23);
            this.button11.TabIndex = 4;
            this.button11.Text = "Return Confirmation";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(220, 7);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 13);
            this.label22.TabIndex = 58;
            this.label22.Text = "Return Book";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(463, 73);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 13);
            this.label19.TabIndex = 70;
            this.label19.Text = "<-- Ciritical -->";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Location = new System.Drawing.Point(463, 156);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 69;
            this.label20.Text = "* Optional";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(463, 37);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 13);
            this.label21.TabIndex = 68;
            this.label21.Text = "* Optional";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(463, 114);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 13);
            this.label23.TabIndex = 67;
            this.label23.Text = "<-- Ciritical -->";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(178, 160);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(217, 20);
            this.textBox8.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(28, 169);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 13);
            this.label24.TabIndex = 65;
            this.label24.Text = "Borrower Name :";
            // 
            // BorrowerIDTB
            // 
            this.BorrowerIDTB.Location = new System.Drawing.Point(178, 118);
            this.BorrowerIDTB.Name = "BorrowerIDTB";
            this.BorrowerIDTB.Size = new System.Drawing.Size(217, 20);
            this.BorrowerIDTB.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(28, 127);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(92, 13);
            this.label25.TabIndex = 63;
            this.label25.Text = "Borrower user ID :";
            // 
            // BookId
            // 
            this.BookId.Location = new System.Drawing.Point(178, 77);
            this.BookId.Name = "BookId";
            this.BookId.Size = new System.Drawing.Size(217, 20);
            this.BookId.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(28, 86);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 13);
            this.label26.TabIndex = 61;
            this.label26.Text = "Book ID : ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(178, 41);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(217, 20);
            this.textBox5.TabIndex = 0;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(29, 50);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 13);
            this.label27.TabIndex = 59;
            this.label27.Text = "Book name : ";
            // 
            // BorrowPanel
            // 
            this.BorrowPanel.BackColor = System.Drawing.Color.DimGray;
            this.BorrowPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BorrowPanel.Controls.Add(this.Save);
            this.BorrowPanel.Controls.Add(this.button17);
            this.BorrowPanel.Controls.Add(this.label8);
            this.BorrowPanel.Controls.Add(this.DateCount);
            this.BorrowPanel.Controls.Add(this.linkLabel7);
            this.BorrowPanel.Controls.Add(this.numericUpDown1);
            this.BorrowPanel.Controls.Add(this.button4);
            this.BorrowPanel.Controls.Add(this.BorrowBtn);
            this.BorrowPanel.Controls.Add(this.label11);
            this.BorrowPanel.Controls.Add(this.label10);
            this.BorrowPanel.Controls.Add(this.label9);
            this.BorrowPanel.Controls.Add(this.label12);
            this.BorrowPanel.Controls.Add(this.label13);
            this.BorrowPanel.Controls.Add(this.label14);
            this.BorrowPanel.Controls.Add(this.textBox4);
            this.BorrowPanel.Controls.Add(this.label15);
            this.BorrowPanel.Controls.Add(this.textBox3);
            this.BorrowPanel.Controls.Add(this.label16);
            this.BorrowPanel.Controls.Add(this.label17);
            this.BorrowPanel.Controls.Add(this.textBox2);
            this.BorrowPanel.Controls.Add(this.label18);
            this.BorrowPanel.Controls.Add(this.textBox1);
            this.BorrowPanel.Controls.Add(this.label28);
            this.BorrowPanel.Location = new System.Drawing.Point(28, 7);
            this.BorrowPanel.Name = "BorrowPanel";
            this.BorrowPanel.Size = new System.Drawing.Size(581, 314);
            this.BorrowPanel.TabIndex = 2;
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(439, 104);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(44, 23);
            this.Save.TabIndex = 66;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // button17
            // 
            this.button17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button17.BackgroundImage")));
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button17.Location = new System.Drawing.Point(181, 253);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(46, 23);
            this.button17.TabIndex = 65;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(199, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 13);
            this.label8.TabIndex = 64;
            this.label8.Text = "Borrow Book";
            // 
            // DateCount
            // 
            this.DateCount.AutoSize = true;
            this.DateCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DateCount.Location = new System.Drawing.Point(13, 225);
            this.DateCount.Name = "DateCount";
            this.DateCount.Size = new System.Drawing.Size(70, 13);
            this.DateCount.TabIndex = 63;
            this.DateCount.Text = "Book name : ";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel7.Location = new System.Drawing.Point(23, 291);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(96, 13);
            this.linkLabel7.TabIndex = 62;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "Restart Application";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(162, 106);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(271, 20);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(413, 253);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(149, 23);
            this.button4.TabIndex = 7;
            this.button4.Text = "Clear Fields";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // BorrowBtn
            // 
            this.BorrowBtn.Location = new System.Drawing.Point(16, 253);
            this.BorrowBtn.Name = "BorrowBtn";
            this.BorrowBtn.Size = new System.Drawing.Size(149, 23);
            this.BorrowBtn.TabIndex = 6;
            this.BorrowBtn.Text = "Borrow ...";
            this.BorrowBtn.UseVisualStyleBackColor = true;
            this.BorrowBtn.Click += new System.EventHandler(this.BorrowBtn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(492, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 58;
            this.label11.Text = "<-- Ciritical -->";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(492, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 57;
            this.label10.Text = "<-- Ciritical -->";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(492, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "* Optional";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(492, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 55;
            this.label12.Text = "* Optional";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(492, 153);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 13);
            this.label13.TabIndex = 54;
            this.label13.Text = "<-- Ciritical -->";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(157, -16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 13);
            this.label14.TabIndex = 44;
            this.label14.Text = "Borrow Book";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(162, 190);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(271, 20);
            this.textBox4.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 193);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 13);
            this.label15.TabIndex = 52;
            this.label15.Text = "Borrower Name :";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(162, 150);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(271, 20);
            this.textBox3.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 153);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 13);
            this.label16.TabIndex = 50;
            this.label16.Text = "Borrower user ID :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 13);
            this.label17.TabIndex = 49;
            this.label17.Text = "Return Date : (After ? day)";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(162, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(271, 20);
            this.textBox2.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 13);
            this.label18.TabIndex = 47;
            this.label18.Text = "Book ID : ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(162, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(271, 20);
            this.textBox1.TabIndex = 0;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(13, 34);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(70, 13);
            this.label28.TabIndex = 45;
            this.label28.Text = "Book name : ";
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.Thistle;
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainToolStripMenuItem1,
            this.searchToolStripMenuItem1,
            this.libraryToolStripMenuItem1,
            this.membershipToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(3, 16);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip2.Size = new System.Drawing.Size(1344, 24);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // mainToolStripMenuItem1
            // 
            this.mainToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem,
            this.exitToolStripMenuItem2});
            this.mainToolStripMenuItem1.Name = "mainToolStripMenuItem1";
            this.mainToolStripMenuItem1.Size = new System.Drawing.Size(46, 20);
            this.mainToolStripMenuItem1.Text = "&Main";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.backToolStripMenuItem.Text = "&Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.userToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem2
            // 
            this.exitToolStripMenuItem2.Name = "exitToolStripMenuItem2";
            this.exitToolStripMenuItem2.Size = new System.Drawing.Size(99, 22);
            this.exitToolStripMenuItem2.Text = "E&xit";
            this.exitToolStripMenuItem2.Click += new System.EventHandler(this.exitToolStripMenuItem2_Click);
            // 
            // searchToolStripMenuItem1
            // 
            this.searchToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchLibraryToolStripMenuItem});
            this.searchToolStripMenuItem1.Name = "searchToolStripMenuItem1";
            this.searchToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.searchToolStripMenuItem1.Text = "&Search";
            // 
            // searchLibraryToolStripMenuItem
            // 
            this.searchLibraryToolStripMenuItem.Name = "searchLibraryToolStripMenuItem";
            this.searchLibraryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.searchLibraryToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.searchLibraryToolStripMenuItem.Text = "Search &Library";
            this.searchLibraryToolStripMenuItem.Click += new System.EventHandler(this.searchLibraryToolStripMenuItem_Click);
            // 
            // libraryToolStripMenuItem1
            // 
            this.libraryToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borrowBookToolStripMenuItem,
            this.returnBookToolStripMenuItem,
            this.todaysBorrowsToolStripMenuItem,
            this.borrowBookToolStripMenuItem1});
            this.libraryToolStripMenuItem1.Name = "libraryToolStripMenuItem1";
            this.libraryToolStripMenuItem1.Size = new System.Drawing.Size(55, 20);
            this.libraryToolStripMenuItem1.Text = "&Library";
            // 
            // borrowBookToolStripMenuItem
            // 
            this.borrowBookToolStripMenuItem.Name = "borrowBookToolStripMenuItem";
            this.borrowBookToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.borrowBookToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.borrowBookToolStripMenuItem.Text = "AddBook";
            this.borrowBookToolStripMenuItem.Click += new System.EventHandler(this.borrowBookToolStripMenuItem_Click);
            // 
            // returnBookToolStripMenuItem
            // 
            this.returnBookToolStripMenuItem.Name = "returnBookToolStripMenuItem";
            this.returnBookToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.returnBookToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.returnBookToolStripMenuItem.Text = "&Remove Book";
            this.returnBookToolStripMenuItem.Click += new System.EventHandler(this.returnBookToolStripMenuItem_Click);
            // 
            // todaysBorrowsToolStripMenuItem
            // 
            this.todaysBorrowsToolStripMenuItem.Name = "todaysBorrowsToolStripMenuItem";
            this.todaysBorrowsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.todaysBorrowsToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.todaysBorrowsToolStripMenuItem.Text = "R&eturn Book";
            this.todaysBorrowsToolStripMenuItem.Click += new System.EventHandler(this.todaysBorrowsToolStripMenuItem_Click);
            // 
            // borrowBookToolStripMenuItem1
            // 
            this.borrowBookToolStripMenuItem1.Name = "borrowBookToolStripMenuItem1";
            this.borrowBookToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.borrowBookToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.borrowBookToolStripMenuItem1.Text = "&Borrow Book";
            this.borrowBookToolStripMenuItem1.Click += new System.EventHandler(this.borrowBookToolStripMenuItem1_Click);
            // 
            // membershipToolStripMenuItem
            // 
            this.membershipToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.joinToolStripMenuItem2,
            this.addBookToolStripMenuItem1,
            this.searchToolStripMenuItem});
            this.membershipToolStripMenuItem.Name = "membershipToolStripMenuItem";
            this.membershipToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.membershipToolStripMenuItem.Text = "&Membership";
            // 
            // joinToolStripMenuItem2
            // 
            this.joinToolStripMenuItem2.Name = "joinToolStripMenuItem2";
            this.joinToolStripMenuItem2.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.J)));
            this.joinToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.joinToolStripMenuItem2.Text = "&Join";
            this.joinToolStripMenuItem2.Click += new System.EventHandler(this.joinToolStripMenuItem2_Click);
            // 
            // addBookToolStripMenuItem1
            // 
            this.addBookToolStripMenuItem1.Name = "addBookToolStripMenuItem1";
            this.addBookToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.addBookToolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.addBookToolStripMenuItem1.Text = "R&emove";
            this.addBookToolStripMenuItem1.Click += new System.EventHandler(this.addBookToolStripMenuItem1_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.searchToolStripMenuItem.Text = "&Search";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1386, 750);
            this.Controls.Add(this.Admin);
            this.Controls.Add(this.ViewGB);
            this.Controls.Add(this.UserGB);
            this.Controls.Add(this.PossibilityGB);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.AdminGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            //this.Name = "Login";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Log in";
            this.Activated += new System.EventHandler(this.Login_Activated);
            this.Load += new System.EventHandler(this.LogIn_Load);
            this.UserGB.ResumeLayout(false);
            this.UserGB.PerformLayout();
            this.AdminGB.ResumeLayout(false);
            this.AdminGB.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.PossibilityGB.ResumeLayout(false);
            this.PossibilityGB.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.DepositGB.ResumeLayout(false);
            this.DepositGB.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ViewGB.ResumeLayout(false);
            this.ViewGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Similerword)).EndInit();
            this.Admin.ResumeLayout(false);
            this.Admin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DayNewsDG)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.BorrowPanel.ResumeLayout(false);
            this.BorrowPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EnterUser;
        private System.Windows.Forms.TextBox UserNametext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox UserGB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Passtext;
        private System.Windows.Forms.GroupBox AdminGB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AdminPassTB;
        private System.Windows.Forms.TextBox AdminTB;
        private System.Windows.Forms.Button AdminB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.GroupBox PossibilityGB;
        private System.Windows.Forms.GroupBox DepositGB;
        private System.Windows.Forms.Button AllBook;
        private System.Windows.Forms.Button StateMe;
        private System.Windows.Forms.Button NewSerch;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.Button DepositBT;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.TreeView treeView3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button EditUP;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.TreeView SearchTV;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label SearchNotificationLabel;
        private System.Windows.Forms.ComboBox SearchTypeCombo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox SearchKeyText;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button SearchBT;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox ViewGB;
        private System.Windows.Forms.LinkLabel See1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox Admin;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem mainToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem libraryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem borrowBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem todaysBorrowsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membershipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem joinToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem addBookToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.DataGridView DayNewsDG;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn BorroserID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BorrowDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn NowDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem2;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem dvgfdsfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sdfsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fsfsdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fdfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem3;
        public System.Windows.Forms.DataGridView Similerword;
        private System.Windows.Forms.ToolStripMenuItem borrowBookToolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAme;
        private System.Windows.Forms.DataGridViewTextBoxColumn nAme;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox BorrowerIDTB;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox BookId;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel BorrowPanel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label DateCount;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button BorrowBtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.CheckBox Guest;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchLibraryToolStripMenuItem;
    }
}


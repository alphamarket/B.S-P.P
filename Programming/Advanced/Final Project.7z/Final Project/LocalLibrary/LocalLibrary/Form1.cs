﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Search;
using DayNews;
using SetData;
using LibraryTransactionSystem;

namespace LocalLibrary
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            ReturnDate.Load(ref numericUpDown1);
            Application.DoEvents();
            Save.Enabled = false;
        }
        Final.Opacity op = new Final.Opacity();
        string[] keyssearch;
        InitializeForm IF;
        Control[] control;
        string[] controlname;
        string KeepUsername;
        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            controlname = new string[1];
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            controlname[0] = "UserGB";
            IF = new InitializeForm(this, UserGB.Size.Width+10,UserGB.Size.Height+34);
            IF = new InitializeForm(this, false, controlname, true);
            IF = new InitializeForm(menuStrip1, true);
            IF = new InitializeForm(UserGB, 0, 24);
            op.OpacityOpen(this);
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IF = new InitializeForm(AdminGB, 12, 24);
            controlname = new string[1];
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            IF = new InitializeForm(this, AdminGB.Size.Width+22,AdminGB.Size.Height+34);
            controlname[0] = "AdminGB";
            IF = new InitializeForm(menuStrip1, true);
            IF = new InitializeForm(this, false, controlname, true);
            op.OpacityOpen(this);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            op.OpacityClose(this);
        }

        private void EnterUser_Click(object sender, EventArgs e)
        {
            if (!Guest.Checked)
            {
                DepositBT.Enabled = true;
                DepositGB.Enabled = true;
                keyssearch = new string[2];
                keyssearch[0] = UserNametext.Text;
                keyssearch[1] = Passtext.Text.GetHashCode().ToString();
                Search.Search search = new Search.Search();
                if (search.newsearch(keyssearch, Communication.Protocol.ClientSendQueryType.Login)[0] == "true")
                {
                    KeepUsername = UserNametext.Text;
                    control = new Control[2];
                    control[0] = UserGB;
                    control[1] = AdminGB;
                    this.Size = new System.Drawing.Size(1386, 750);
                    this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
                    IF = new InitializeForm(this, PossibilityGB, control, ViewGB, 0, 370);
                    IF = new InitializeForm(menuStrip1, false);
                    op.OpacityOpen(this);

                }
            }
            else
            {
                DepositBT.Enabled = false;
                DepositGB.Enabled = false;
                KeepUsername = UserNametext.Text;
                control = new Control[2];
                control[0] = UserGB;
                control[1] = AdminGB;
                this.Size = new System.Drawing.Size(1386, 750);
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
                IF = new InitializeForm(this, PossibilityGB, control, ViewGB, 0, 370);
                IF = new InitializeForm(menuStrip1, false);
                op.OpacityOpen(this);
            }
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            IF = new InitializeForm(this, false);
            IF = new InitializeForm(this, 360, 150);
            Final.Opacity OP = new Final.Opacity();
            OP.OpacityOpen(this);
            DayNews.PersonTarydy PT = new PersonTarydy();
            Sundries.DataGridViewSetting.InitializeDataGrid(PT.TrydyInfo, ref DayNewsDG);
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            string []keySearch=new string[1];
            keySearch[0]=SearchKeyText.Text;
            Search.Search search;
            try
            {
                switch (SearchTypeCombo.Text)
                {
                    case "By ID":
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByID);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                    case "Name Book":
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByName);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                    case "Writer":
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByWritter);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                    case "Publisher":
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByWritter);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                    case "Key Word":
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByWritter);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                    default:
                        search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.SimilerThisWord, Search.InternalEnumeration.SortType.ByName);
                        Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(keySearch, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                        break;
                }
            }catch(Exception ex){Sundries.MessageBox.ShowMessage(ex.Message);}
        }

        private void addBookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Edit.Edit edit = new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditMembersList);
        }

        private void AdminB_Click(object sender, EventArgs e)
        {
            string[] checker = new string[2];
            checker[0] = AdminTB.Text;
            checker[1] = AdminPassTB.Text;
            Search.Search adminCheck = new Search.Search();
            if (adminCheck.newsearch(checker, Communication.Protocol.ClientSendQueryType.CheckAdmin)[0] == "True")
            {

                control = new Control[2];
                control[0] = UserGB;
                control[1] = AdminGB;
                this.Size = new System.Drawing.Size(1386, 750);
                //this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
                IF = new InitializeForm(this, Admin, control, ViewGB, 0, 370);
                IF = new InitializeForm(menuStrip1, false);
                op.OpacityOpen(this);
                DayNews.PersonTarydy PT = new PersonTarydy();
                Sundries.DataGridViewSetting.InitializeDataGrid(PT.TrydyInfo, ref DayNewsDG, 0);
            }
        }

        private void basicSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void DayNewsDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BorrowBtn_Click(object sender, EventArgs e)
        {
            try
            {
                bool isnull = false;
                foreach (Control co in BorrowPanel.Controls)
                {
                    if (co is TextBox)
                    {
                        int count = 0;
                        for (int i = 0; i < co.Text.Length; i++)
                        {
                            if (co.Text[i] == 32)
                            {
                                count++;
                            }
                            if (count == co.Text.Length)
                            {
                                isnull = true;
                            }
                        }
                        if (co.Text == "" || isnull)
                        {
                            throw new Exception("Empity value is invalid");
                        }


                    }
                }
                //if (string.IsEmpty(textBox1.Text)&&string.IsNullOrEmpty(textBox2.Text)&&string.IsNullOrEmpty(textBox3.Text)&&string.IsNullOrEmpty(textBox4.Text)&&string.IsNullOrEmpty(textBox5.Text))
                //   {  }


                Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);

                System.Collections.Generic.List<string> res = search.newsearch(new string[] { textBox2.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);

                if (res.Count != 0)
                {
                    LibraryTransactionSystem.BookStatus bs = new LibraryTransactionSystem.BookStatus(res[0]);
                    if (!bs.IsBorrow)
                    {
                        DateTime dt = DateTime.Now.AddDays((double)numericUpDown1.Value);
                        System.Collections.Generic.List<string> brw = new System.Collections.Generic.List<string>(5);
                        brw.Add(textBox1.Text);
                        brw.Add(textBox2.Text);
                        brw.Add(dt.Date.Year + " / " + dt.Date.Month + " / " + dt.Date.Day);
                        brw.Add(textBox3.Text);
                        brw.Add(textBox3.Text);
                        LibraryTransactionSystem.Deposit dpst = new LibraryTransactionSystem.Deposit();
                        dpst.BorrowBook(brw);
                        Sundries.MessageBox.ShowMessage("The book has put in library borrow list successfully ...");
                    }
                    else
                        Sundries.MessageBox.ShowMessage("This book has been borrowed already ...");
                }
                else
                {
                    Sundries.MessageBox.ShowMessage("Book with this 'Book ID' has not found !");
                }
                //}
                //else
                //    Sundries.MessageBox.ShowMessage("Please enter '<-Ciritical->' fields");
            }
            catch (Exception er)
            {
                Sundries.MessageBox ms = new Sundries.MessageBox(er.Message);
                ms.Show();
            }
        }



        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            Hide();
        }

        private void returnBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Edit.Edit edit = new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditBookslist);
        }

        private void searchLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search.Search_L_Form1 SlF = new Search_L_Form1();
            SlF.ShowDialog();
        }

        private void borrowBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBook Add = new AddBook();
            Add.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Restart();
        }

        private void joinToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            JoinNewMember join = new JoinNewMember();
            join.Show();
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search.Member_L_Search MLS = new Member_L_Search();
            MLS.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void todaysBorrowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Edit.Edit("", Communication.Protocol.ClientSendQueryType.EditBorrowersList);
        }

        private void exitToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void SearchBT_Click(object sender, EventArgs e)
        {
            Search.Search_L_Form1 SLF = new Search_L_Form1();
            SLF.ShowDialog();
        }
        bool typetree=false;
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

            if (typetree)
            {
                Similerword.Columns[6].Visible = false;
                typetree = false;
            }

            try
            {
                dow.HeaderText = "Deposit";
              
                string[] value = new string[1];
                value[0] = SearchTV.SelectedNode.Text;
                Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
                Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(value, Communication.Protocol.ClientSendQueryType.TreeSearch), ref  Similerword);
               // Similerword.Rows[3].Visible = false;
            }
            catch (Exception ex)
            {
                Sundries.MessageBox.ShowMessage(ex.Message);
            }
           
        }


        private void button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "pdf Files|*.pdf";
            DialogResult DR= op.ShowDialog();
            switch (DR)
            {
                case System.Windows.Forms.DialogResult.OK:
                    Sundries.Share share = new Sundries.Share(op.FileName, KeepUsername);
                    share.ShowDialog();
                    break;
                case System.Windows.Forms.DialogResult.Ignore:
                    break;
            }
        }
        System.Windows.Forms.DataGridViewButtonColumn dow = new DataGridViewButtonColumn();
        private void addDownloadBTN()
        {
           // System.Windows.Forms.DataGridViewButtonColumn dow = new DataGridViewButtonColumn();
            dow.HeaderText = "Download";
            this.Similerword.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            dow});
        }
        static int count = 0;
        private void treeView3_AfterSelect(object sender, TreeViewEventArgs e)
        {
            
            if (treeView3.SelectedNode.Text != "All Book" && treeView3.SelectedNode.Text != "Enigneer" && treeView3.SelectedNode.Text != "Public" && treeView3.SelectedNode.Text != "Other" && treeView3.SelectedNode.Text != "literary" && treeView3.SelectedNode.Text != "languageBook") ;
            {
                try
                {
                   
                    int.Parse(e.Node.Text);
                    if (count == 0)
                    {
                        addDownloadBTN();
                    }
                    count++;                    
                    Sundries.VBookinfo VB = new Sundries.VBookinfo();
                    System.Windows.Forms.DataGridViewButtonColumn dow=new DataGridViewButtonColumn();
                   Sundries.DataGridViewSetting.InitializeDataGrid(VB.GetBookInfo(e.Node.Text,  Application.StartupPath + @"\Files\Virtual\" + e.Node.Parent.Text),ref Similerword);
                   if (!typetree)
                   {
                       Similerword.Columns[6].Visible = true;
                       typetree = true;
                   }
                   
                }
                catch
                {
                    Sundries.AddNode Add = new Sundries.AddNode(e.Node, Application.StartupPath + @"\Files\Virtual\" + e.Node.Text);
                    
                }
                
            }
        }

        private void Similerword_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            typetree = false;
            if (!typetree)
            {
                Sundries.VBookinfo BI = new Sundries.VBookinfo();
                Sundries.Download D = new Sundries.Download(BI.PdfAddress);
                D.ShowDialog();
            }
            else
            {
            }
        }

        private void EditUP_Click(object sender, EventArgs e)
        {
            Edit.Edit edit = new Edit.Edit(KeepUsername, Communication.Protocol.ClientSendQueryType.EditUserAndPass);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            op.OpacityClose(this);
        }

        private void StateMe_Click(object sender, EventArgs e)
        {
            Sundries.StateMe SM = new Sundries.StateMe();
            SM.ShowDialog();
        }

        private void AllBook_Click(object sender, EventArgs e)
        {
            try
            {
                string[] value = new string[1];
                value[0] = "AllBook";
                Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
                Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(value, Communication.Protocol.ClientSendQueryType.TreeSearch), ref  Similerword);
            }
            catch
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            op.OpacityClose(this);
        }

        private void borrowBookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BorrowBook BB = new BorrowBook();
            BB.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
           
            string[] value1 = new string[1];
            value1[0] = BorrowerIDTB.Text;
            List<string> borrowerinfo = new List<string>();
            Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.NotNeeded, Search.InternalEnumeration.SortType.NotNeeded);
            borrowerinfo = search.newsearch(value1, Communication.Protocol.ClientSendQueryType.SearchBorrower);
            if (borrowerinfo.Count != 0 && borrowerinfo.Count != 1)
                {

                    Edit.EditBorrwList EBL = new Edit.EditBorrwList();
                    EBL.newEdit(BorrowerIDTB.Text);
                    Sundries.MessageBox.ShowMessage("This Book Not Exist In DataBase...! ");
                }
                else
                    Sundries.MessageBox.ShowMessage("This Book Not Exist In DataBase...! ");
            
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            Save.Enabled = true;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            ReturnDate.Save(numericUpDown1.Value.ToString());
            Save.Enabled = false;
        }

        private void Login_Activated(object sender, EventArgs e)
        {
            ReturnDate.Load(ref numericUpDown1);
            Application.DoEvents();
            Save.Enabled = false;
        }

     

        

       

       
       

       

       
    }

       
}

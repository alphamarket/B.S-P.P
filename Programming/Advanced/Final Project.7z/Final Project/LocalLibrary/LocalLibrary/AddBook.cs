﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LocalLibrary
{
    public partial class AddBook : Form
    {
        public AddBook()
        {
            InitializeComponent();
           
        }
        private void BookIdText_Leave(object sender, EventArgs e)
        {
            if (BookIdText.Text == "")
            {
                BookIdText.Text = "To automatic setting ID leave empty ";
                BookIdText.ForeColor = SystemColors.ScrollBar;
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in AddBookGB.Controls)
            {
                if (i is TextBox && i != BookExpText || CategoryCombo.SelectedIndex == -1)
                    if (string.IsNullOrEmpty(i.Text) || CategoryCombo.SelectedIndex == -1)
                    {
                        //messagebox = true;
                        Sundries.MessageBox.ShowMessage("Please fill empty field ...\r\nExplanation text box could be an empty field but others could not be!");
                        return;
                    }
            }
            Search.Search search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByID);
            List<string> tmplist = new List<string>();// = search.newsearch(new string[] { BookIdText.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);
            if (tmplist.Count != 0)
            {
                Sundries.MessageBox.ShowMessage("A book with this ID has exist in database already ...\r\nChange ID OR let us set ID ...");
                BookIdText_Leave(new object(), new EventArgs());
                return;
            }
            search = new Search.Search(Search.InternalEnumeration.ResultSearchBook.AloneThisWord, Search.InternalEnumeration.SortType.ByName);
            tmplist = search.newsearch(new string[] { BookPublishDate, BookNameText.Text }, Communication.Protocol.ClientSendQueryType.SearchBook);
            if (tmplist.Count != 0)
            {
                Sundries.MessageBox.ShowMessage("There is a same book with this 'Name and 'Year Of Publish' in our database, data couldn't be saved becuase of possibility of mistake ...");
                return;
            }
            tmplist.Clear();
            tmplist.Capacity = 5;
            string explanataion = (string.IsNullOrEmpty(BookExpText.Text) ? "" : BookExpText.Text + ", ") + "Year Of Publish : " + BookPublishDate;
            string bookId = Math.Abs(((CategoryCombo.SelectedIndex + 10)).GetHashCode() % 100) + " " + CategoryCombo.SelectedItem.ToString().Remove(2).ToUpper() + " " + Math.Abs((double)(BookNameText.Text + BookPublishDate).GetHashCode()) % 10000000;
            IsCompatible com = new IsCompatible(BookNameText.Text,bookId,BookWriterText.Text,BookPublisherText.Text,CategoryCombo.Text,explanataion);
            com.ShowDialog();
            if (com.IsAgree)
            {
                tmplist.Add(bookId);
                tmplist.Add(BookNameText.Text);
                tmplist.Add(BookWriterText.Text);
                tmplist.Add(BookPublisherText.Text);
                tmplist.Add(explanataion);
                SetData.SetData.SetNewData(CategoryCombo.SelectedItem.ToString(), tmplist, Communication.Protocol.ClientSendQueryType.AddBook);
            }
        }
        String BookPublishDate
        {
            get
            {
                return Year.Text + " / " + Month.Text + " / " + Day.Text;
            }
        }
        private void ClrBtn_Click(object sender, EventArgs e)
        {
            foreach (Control i in Controls)
            {
                if (i is TextBox && i.Text != "To automatic setting ID leave empty ")
                    i.Text = "";
            }
        }

        private void CnclBtn_Click(object sender, EventArgs e)
        {
            InitializeComponent();
            this.Close();
        }
    }
}

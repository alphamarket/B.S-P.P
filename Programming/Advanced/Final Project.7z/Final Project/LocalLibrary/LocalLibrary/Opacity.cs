﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;


namespace Final
{
    class Opacity
    {
        public void OpacityClose(Form form)
        {
            double i = 1;
            while (i >= 0)
            {
                form.Opacity = i;
                i -= 0.1;
                Thread.Sleep(50);

            }
            form.Close();
        }
        public void OpacityOpen(Form form)
        {
            form.Show();
            double i = 0;
            while (i <1.1)
            {
                form.Opacity = i;
                i += 0.1;
                Thread.Sleep(50);
            }
        }

    }
}

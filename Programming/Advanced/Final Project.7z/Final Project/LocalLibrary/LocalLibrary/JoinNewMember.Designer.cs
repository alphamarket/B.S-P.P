﻿namespace LocalLibrary
{
    partial class JoinNewMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.CancelTB = new System.Windows.Forms.Button();
            this.SetBT = new System.Windows.Forms.Button();
            this.IdTB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.AddressTB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.PhoneNTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.NameTB = new System.Windows.Forms.TextBox();
            this.LNameTB = new System.Windows.Forms.TextBox();
            this.PassTB = new System.Windows.Forms.TextBox();
            this.UNameTB = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox2.Controls.Add(this.CategoryCombo);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.CancelTB);
            this.groupBox2.Controls.Add(this.SetBT);
            this.groupBox2.Controls.Add(this.IdTB);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.AddressTB);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.PhoneNTB);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.NameTB);
            this.groupBox2.Controls.Add(this.LNameTB);
            this.groupBox2.Controls.Add(this.PassTB);
            this.groupBox2.Controls.Add(this.UNameTB);
            this.groupBox2.Location = new System.Drawing.Point(10, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(480, 385);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Set Member Info";
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(129, 29);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(271, 21);
            this.CategoryCombo.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "Student\'s ID";
            // 
            // CancelTB
            // 
            this.CancelTB.Location = new System.Drawing.Point(129, 350);
            this.CancelTB.Name = "CancelTB";
            this.CancelTB.Size = new System.Drawing.Size(128, 23);
            this.CancelTB.TabIndex = 8;
            this.CancelTB.Text = "Cancel";
            this.CancelTB.UseVisualStyleBackColor = true;
            // 
            // SetBT
            // 
            this.SetBT.Location = new System.Drawing.Point(273, 350);
            this.SetBT.Name = "SetBT";
            this.SetBT.Size = new System.Drawing.Size(127, 23);
            this.SetBT.TabIndex = 9;
            this.SetBT.Text = "Set";
            this.SetBT.UseVisualStyleBackColor = true;
            this.SetBT.Click += new System.EventHandler(this.SetBT_Click);
            // 
            // IdTB
            // 
            this.IdTB.Location = new System.Drawing.Point(129, 66);
            this.IdTB.Name = "IdTB";
            this.IdTB.Size = new System.Drawing.Size(271, 20);
            this.IdTB.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 306);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 265);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "PhoneNumber";
            // 
            // AddressTB
            // 
            this.AddressTB.Location = new System.Drawing.Point(129, 303);
            this.AddressTB.Name = "AddressTB";
            this.AddressTB.Size = new System.Drawing.Size(271, 20);
            this.AddressTB.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Field Of Study";
            // 
            // PhoneNTB
            // 
            this.PhoneNTB.Location = new System.Drawing.Point(129, 262);
            this.PhoneNTB.Name = "PhoneNTB";
            this.PhoneNTB.Size = new System.Drawing.Size(271, 20);
            this.PhoneNTB.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "PassWord";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "UserName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Name";
            // 
            // NameTB
            // 
            this.NameTB.Location = new System.Drawing.Point(129, 103);
            this.NameTB.Name = "NameTB";
            this.NameTB.Size = new System.Drawing.Size(271, 20);
            this.NameTB.TabIndex = 2;
            // 
            // LNameTB
            // 
            this.LNameTB.Location = new System.Drawing.Point(129, 139);
            this.LNameTB.Name = "LNameTB";
            this.LNameTB.Size = new System.Drawing.Size(271, 20);
            this.LNameTB.TabIndex = 3;
            // 
            // PassTB
            // 
            this.PassTB.Location = new System.Drawing.Point(129, 220);
            this.PassTB.Name = "PassTB";
            this.PassTB.Size = new System.Drawing.Size(271, 20);
            this.PassTB.TabIndex = 5;
            this.PassTB.UseSystemPasswordChar = true;
            // 
            // UNameTB
            // 
            this.UNameTB.Location = new System.Drawing.Point(129, 177);
            this.UNameTB.Name = "UNameTB";
            this.UNameTB.Size = new System.Drawing.Size(271, 20);
            this.UNameTB.TabIndex = 4;
            // 
            // JoinNewMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(500, 393);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "JoinNewMember";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JoinNewMember";
            this.Load += new System.EventHandler(this.JoinNewMember_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button CancelTB;
        private System.Windows.Forms.Button SetBT;
        private System.Windows.Forms.TextBox IdTB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox AddressTB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox PhoneNTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox NameTB;
        private System.Windows.Forms.TextBox LNameTB;
        private System.Windows.Forms.TextBox PassTB;
        private System.Windows.Forms.TextBox UNameTB;
        private System.Windows.Forms.ComboBox CategoryCombo;
    }
}
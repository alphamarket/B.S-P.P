﻿namespace LocalLibrary
{
    partial class AddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddBookGB = new System.Windows.Forms.GroupBox();
            this.CnclBtn = new System.Windows.Forms.Button();
            this.ClrBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.Day = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Month = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Year = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BookExpText = new System.Windows.Forms.TextBox();
            this.BookPublisherText = new System.Windows.Forms.TextBox();
            this.BookWriterText = new System.Windows.Forms.TextBox();
            this.BookNameText = new System.Windows.Forms.TextBox();
            this.BookIdText = new System.Windows.Forms.TextBox();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AddBookGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddBookGB
            // 
            this.AddBookGB.Controls.Add(this.CnclBtn);
            this.AddBookGB.Controls.Add(this.ClrBtn);
            this.AddBookGB.Controls.Add(this.AddBtn);
            this.AddBookGB.Controls.Add(this.Day);
            this.AddBookGB.Controls.Add(this.label9);
            this.AddBookGB.Controls.Add(this.Month);
            this.AddBookGB.Controls.Add(this.label8);
            this.AddBookGB.Controls.Add(this.Year);
            this.AddBookGB.Controls.Add(this.label7);
            this.AddBookGB.Controls.Add(this.BookExpText);
            this.AddBookGB.Controls.Add(this.BookPublisherText);
            this.AddBookGB.Controls.Add(this.BookWriterText);
            this.AddBookGB.Controls.Add(this.BookNameText);
            this.AddBookGB.Controls.Add(this.BookIdText);
            this.AddBookGB.Controls.Add(this.CategoryCombo);
            this.AddBookGB.Controls.Add(this.label6);
            this.AddBookGB.Controls.Add(this.label5);
            this.AddBookGB.Controls.Add(this.label4);
            this.AddBookGB.Controls.Add(this.label3);
            this.AddBookGB.Controls.Add(this.label2);
            this.AddBookGB.Controls.Add(this.label1);
            this.AddBookGB.Location = new System.Drawing.Point(3, 5);
            this.AddBookGB.Name = "AddBookGB";
            this.AddBookGB.Size = new System.Drawing.Size(578, 583);
            this.AddBookGB.TabIndex = 0;
            this.AddBookGB.TabStop = false;
            this.AddBookGB.Text = "Add Book Panel";
            // 
            // CnclBtn
            // 
            this.CnclBtn.Location = new System.Drawing.Point(405, 546);
            this.CnclBtn.Name = "CnclBtn";
            this.CnclBtn.Size = new System.Drawing.Size(143, 23);
            this.CnclBtn.TabIndex = 77;
            this.CnclBtn.Text = "Cancel";
            this.CnclBtn.UseVisualStyleBackColor = true;
            this.CnclBtn.Click += new System.EventHandler(this.CnclBtn_Click);
            // 
            // ClrBtn
            // 
            this.ClrBtn.Location = new System.Drawing.Point(218, 546);
            this.ClrBtn.Name = "ClrBtn";
            this.ClrBtn.Size = new System.Drawing.Size(143, 23);
            this.ClrBtn.TabIndex = 76;
            this.ClrBtn.Text = "Clear fields";
            this.ClrBtn.UseVisualStyleBackColor = true;
            this.ClrBtn.Click += new System.EventHandler(this.ClrBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(28, 546);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(143, 23);
            this.AddBtn.TabIndex = 75;
            this.AddBtn.Text = "Add to database";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // Day
            // 
            this.Day.Location = new System.Drawing.Point(498, 230);
            this.Day.MaxLength = 4;
            this.Day.Name = "Day";
            this.Day.Size = new System.Drawing.Size(50, 20);
            this.Day.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(480, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 13);
            this.label9.TabIndex = 73;
            this.label9.Text = "/";
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(424, 230);
            this.Month.MaxLength = 4;
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(50, 20);
            this.Month.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(406, 233);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 13);
            this.label8.TabIndex = 71;
            this.label8.Text = "/";
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(350, 230);
            this.Year.MaxLength = 4;
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(50, 20);
            this.Year.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Enter the date of the publish :";
            // 
            // BookExpText
            // 
            this.BookExpText.Location = new System.Drawing.Point(28, 389);
            this.BookExpText.Multiline = true;
            this.BookExpText.Name = "BookExpText";
            this.BookExpText.Size = new System.Drawing.Size(520, 141);
            this.BookExpText.TabIndex = 8;
            // 
            // BookPublisherText
            // 
            this.BookPublisherText.Location = new System.Drawing.Point(350, 281);
            this.BookPublisherText.Name = "BookPublisherText";
            this.BookPublisherText.Size = new System.Drawing.Size(198, 20);
            this.BookPublisherText.TabIndex = 7;
            // 
            // BookWriterText
            // 
            this.BookWriterText.Location = new System.Drawing.Point(350, 179);
            this.BookWriterText.Name = "BookWriterText";
            this.BookWriterText.Size = new System.Drawing.Size(198, 20);
            this.BookWriterText.TabIndex = 3;
            // 
            // BookNameText
            // 
            this.BookNameText.Location = new System.Drawing.Point(350, 126);
            this.BookNameText.Name = "BookNameText";
            this.BookNameText.Size = new System.Drawing.Size(198, 20);
            this.BookNameText.TabIndex = 2;
            // 
            // BookIdText
            // 
            this.BookIdText.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.BookIdText.Location = new System.Drawing.Point(350, 77);
            this.BookIdText.Name = "BookIdText";
            this.BookIdText.Size = new System.Drawing.Size(198, 20);
            this.BookIdText.TabIndex = 1;
            this.BookIdText.Text = "To automatic setting ID leave empty ";
            this.BookIdText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BookIdText.Enter += new System.EventHandler(this.BookIdText_Leave);
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Items.AddRange(new object[] {
            "Computer",
            "Mechanic",
            "Chemistry",
            "Mine",
            "Antitrust",
            "Electricity",
            "Other Engineer",
            "Math",
            "Physic",
            "Poem",
            "Prose",
            "Turkish",
            "Enghlish",
            "Russian",
            "Other Language",
            "Member",
            "Cult",
            "Other"});
            this.CategoryCombo.Location = new System.Drawing.Point(350, 34);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(198, 21);
            this.CategoryCombo.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 341);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(465, 39);
            this.label6.TabIndex = 15;
            this.label6.Text = "Enter some explanation about this book :\r\n \r\n( to provide some idea what is this " +
                "book about, and also can be an \'Empty Field\' [No Explanation])";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 284);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Enter publisher name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Enter the name of the book\'s writer :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Enter the book name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Enter an ID for this book [ And this should be a unique ] :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Select the category of the target book :";
            // 
            // AddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 601);
            this.Controls.Add(this.AddBookGB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AddBook";
            this.Text = "AddBook";
            this.AddBookGB.ResumeLayout(false);
            this.AddBookGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AddBookGB;
        private System.Windows.Forms.Button CnclBtn;
        private System.Windows.Forms.Button ClrBtn;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox Day;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox BookExpText;
        private System.Windows.Forms.TextBox BookPublisherText;
        private System.Windows.Forms.TextBox BookWriterText;
        private System.Windows.Forms.TextBox BookNameText;
        private System.Windows.Forms.TextBox BookIdText;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
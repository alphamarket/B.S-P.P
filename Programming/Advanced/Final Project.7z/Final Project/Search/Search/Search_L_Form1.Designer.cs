﻿namespace Search
{
    partial class Search_L_Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Computer");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Chemistry");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Mechanic");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Mine");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Antitrust");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Electricity");
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("OtherEngineer");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("Engineer", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46,
            treeNode47,
            treeNode48,
            treeNode49,
            treeNode50,
            treeNode51});
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("Math");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("Physic");
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("Poem");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("Prose");
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("Literary", new System.Windows.Forms.TreeNode[] {
            treeNode55,
            treeNode56});
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("Turkish");
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("Enghlish");
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Russian");
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("Other Language");
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("LanguageBook", new System.Windows.Forms.TreeNode[] {
            treeNode58,
            treeNode59,
            treeNode60,
            treeNode61});
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("Cult");
            System.Windows.Forms.TreeNode treeNode64 = new System.Windows.Forms.TreeNode("Public", new System.Windows.Forms.TreeNode[] {
            treeNode53,
            treeNode54,
            treeNode57,
            treeNode62,
            treeNode63});
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("Other");
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("AllBook", new System.Windows.Forms.TreeNode[] {
            treeNode52,
            treeNode64,
            treeNode65});
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.typeSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advanceSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BasicSearch = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.BasicSearchBT = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Reguler = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Similerword = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AlonThisWord = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TreeSearchPanel = new System.Windows.Forms.Panel();
            this.AllBookTV = new System.Windows.Forms.TreeView();
            this.TreeSearchDGV = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.BasicSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Reguler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Similerword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AlonThisWord)).BeginInit();
            this.TreeSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TreeSearchDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(1370, 24);
            this.menuStrip1.TabIndex = 74;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.typeSearchToolStripMenuItem,
            this.backToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // typeSearchToolStripMenuItem
            // 
            this.typeSearchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.basicSearchToolStripMenuItem,
            this.advanceSearchToolStripMenuItem,
            this.treeSearchToolStripMenuItem});
            this.typeSearchToolStripMenuItem.Name = "typeSearchToolStripMenuItem";
            this.typeSearchToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.typeSearchToolStripMenuItem.Text = "Type Search";
            // 
            // basicSearchToolStripMenuItem
            // 
            this.basicSearchToolStripMenuItem.Name = "basicSearchToolStripMenuItem";
            this.basicSearchToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.basicSearchToolStripMenuItem.Text = "Basic Search";
            this.basicSearchToolStripMenuItem.Click += new System.EventHandler(this.basicSearchToolStripMenuItem_Click);
            // 
            // advanceSearchToolStripMenuItem
            // 
            this.advanceSearchToolStripMenuItem.Name = "advanceSearchToolStripMenuItem";
            this.advanceSearchToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.advanceSearchToolStripMenuItem.Text = "Advance Search";
            // 
            // treeSearchToolStripMenuItem
            // 
            this.treeSearchToolStripMenuItem.Name = "treeSearchToolStripMenuItem";
            this.treeSearchToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.treeSearchToolStripMenuItem.Text = "Tree Search";
            this.treeSearchToolStripMenuItem.Click += new System.EventHandler(this.treeSearchToolStripMenuItem_Click);
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.backToolStripMenuItem.Text = "&Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // BasicSearch
            // 
            this.BasicSearch.BackColor = System.Drawing.Color.DimGray;
            this.BasicSearch.Controls.Add(this.button3);
            this.BasicSearch.Controls.Add(this.label6);
            this.BasicSearch.Controls.Add(this.label7);
            this.BasicSearch.Controls.Add(this.label8);
            this.BasicSearch.Controls.Add(this.comboBox1);
            this.BasicSearch.Controls.Add(this.textBox2);
            this.BasicSearch.Controls.Add(this.BasicSearchBT);
            this.BasicSearch.Controls.Add(this.label9);
            this.BasicSearch.Controls.Add(this.label10);
            this.BasicSearch.Controls.Add(this.Reguler);
            this.BasicSearch.Controls.Add(this.Similerword);
            this.BasicSearch.Controls.Add(this.AlonThisWord);
            this.BasicSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BasicSearch.Location = new System.Drawing.Point(0, 24);
            this.BasicSearch.Name = "BasicSearch";
            this.BasicSearch.Size = new System.Drawing.Size(1370, 459);
            this.BasicSearch.TabIndex = 75;
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(-1, 53);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(1365, 10);
            this.button3.TabIndex = 68;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 69;
            this.label6.Text = "Your query";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 256);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 13);
            this.label7.TabIndex = 70;
            this.label7.Text = "Found in title your query word";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(570, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 67;
            this.label8.Text = "Search Type :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Name Book",
            "Writer",
            "Publisher",
            "Key Word",
            "ById"});
            this.comboBox1.Location = new System.Drawing.Point(701, 7);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(252, 21);
            this.comboBox1.TabIndex = 66;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(161, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(344, 20);
            this.textBox2.TabIndex = 64;
            // 
            // BasicSearchBT
            // 
            this.BasicSearchBT.Location = new System.Drawing.Point(1055, 5);
            this.BasicSearchBT.Name = "BasicSearchBT";
            this.BasicSearchBT.Size = new System.Drawing.Size(266, 23);
            this.BasicSearchBT.TabIndex = 63;
            this.BasicSearchBT.Text = "Saerch";
            this.BasicSearchBT.UseVisualStyleBackColor = true;
            this.BasicSearchBT.Click += new System.EventHandler(this.BasicSearchBT_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 13);
            this.label9.TabIndex = 65;
            this.label9.Text = "Enter  Search Key     :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 466);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(168, 13);
            this.label10.TabIndex = 71;
            this.label10.Text = "All  Book Regular Base your query";
            // 
            // Reguler
            // 
            this.Reguler.AllowUserToAddRows = false;
            this.Reguler.AllowUserToDeleteRows = false;
            this.Reguler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Reguler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn19});
            this.Reguler.Location = new System.Drawing.Point(21, 506);
            this.Reguler.Name = "Reguler";
            this.Reguler.ReadOnly = true;
            this.Reguler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Reguler.Size = new System.Drawing.Size(1319, 203);
            this.Reguler.TabIndex = 62;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "ID";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 75;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.HeaderText = "Book ID";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 240;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "Name";
            this.dataGridViewTextBoxColumn20.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 280;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.HeaderText = "Writer";
            this.dataGridViewTextBoxColumn22.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 230;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "Publisher";
            this.dataGridViewTextBoxColumn21.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 230;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "Category";
            this.dataGridViewTextBoxColumn19.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 220;
            // 
            // Similerword
            // 
            this.Similerword.AllowUserToAddRows = false;
            this.Similerword.AllowUserToDeleteRows = false;
            this.Similerword.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Similerword.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn36});
            this.Similerword.Location = new System.Drawing.Point(21, 285);
            this.Similerword.Name = "Similerword";
            this.Similerword.ReadOnly = true;
            this.Similerword.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Similerword.Size = new System.Drawing.Size(1319, 170);
            this.Similerword.TabIndex = 61;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "ID";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 75;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Book ID";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Width = 240;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "Name";
            this.dataGridViewTextBoxColumn34.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Width = 280;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "Writer";
            this.dataGridViewTextBoxColumn35.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Width = 230;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "Publisher";
            this.dataGridViewTextBoxColumn31.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 230;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "Category";
            this.dataGridViewTextBoxColumn36.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 220;
            // 
            // AlonThisWord
            // 
            this.AlonThisWord.AllowUserToAddRows = false;
            this.AlonThisWord.AllowUserToDeleteRows = false;
            this.AlonThisWord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AlonThisWord.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn30});
            this.AlonThisWord.Location = new System.Drawing.Point(21, 100);
            this.AlonThisWord.Name = "AlonThisWord";
            this.AlonThisWord.ReadOnly = true;
            this.AlonThisWord.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AlonThisWord.Size = new System.Drawing.Size(1319, 139);
            this.AlonThisWord.TabIndex = 60;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "ID";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 75;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "Book ID";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 240;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "Name";
            this.dataGridViewTextBoxColumn25.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 280;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "Writer";
            this.dataGridViewTextBoxColumn24.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 230;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "Publisher";
            this.dataGridViewTextBoxColumn26.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 230;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "Category";
            this.dataGridViewTextBoxColumn30.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 220;
            // 
            // TreeSearchPanel
            // 
            this.TreeSearchPanel.BackColor = System.Drawing.Color.DimGray;
            this.TreeSearchPanel.Controls.Add(this.AllBookTV);
            this.TreeSearchPanel.Controls.Add(this.TreeSearchDGV);
            this.TreeSearchPanel.Location = new System.Drawing.Point(553, 23);
            this.TreeSearchPanel.Name = "TreeSearchPanel";
            this.TreeSearchPanel.Size = new System.Drawing.Size(1366, 471);
            this.TreeSearchPanel.TabIndex = 76;
            // 
            // AllBookTV
            // 
            this.AllBookTV.Location = new System.Drawing.Point(17, 25);
            this.AllBookTV.Name = "AllBookTV";
            treeNode45.Name = "Node17";
            treeNode45.Text = "Computer";
            treeNode46.Name = "Node18";
            treeNode46.Text = "Chemistry";
            treeNode47.Name = "Node19";
            treeNode47.Text = "Mechanic";
            treeNode48.Name = "Node20";
            treeNode48.Text = "Mine";
            treeNode49.Name = "Node21";
            treeNode49.Text = "Antitrust";
            treeNode50.Name = "Node22";
            treeNode50.Text = "Electricity";
            treeNode51.Name = "Node23";
            treeNode51.Text = "OtherEngineer";
            treeNode52.Name = "Node12";
            treeNode52.Text = "Engineer";
            treeNode53.Name = "Node24";
            treeNode53.Text = "Math";
            treeNode54.Name = "Node25";
            treeNode54.Text = "Physic";
            treeNode55.Name = "Node28";
            treeNode55.Text = "Poem";
            treeNode56.Name = "Node29";
            treeNode56.Text = "Prose";
            treeNode57.Name = "Node26";
            treeNode57.Text = "Literary";
            treeNode58.Name = "Node34";
            treeNode58.Text = "Turkish";
            treeNode59.Name = "Node30";
            treeNode59.Text = "Enghlish";
            treeNode60.Name = "Node31";
            treeNode60.Text = "Russian";
            treeNode61.Name = "Node32";
            treeNode61.Text = "Other Language";
            treeNode62.Name = "Node27";
            treeNode62.Text = "LanguageBook";
            treeNode63.Name = "Node33";
            treeNode63.Text = "Cult";
            treeNode64.Name = "Node14";
            treeNode64.Text = "Public";
            treeNode65.Name = "Node16";
            treeNode65.Text = "Other";
            treeNode66.Name = "Node11";
            treeNode66.Text = "AllBook";
            this.AllBookTV.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode66});
            this.AllBookTV.Size = new System.Drawing.Size(219, 401);
            this.AllBookTV.TabIndex = 64;
            this.AllBookTV.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.AllBookTV_AfterSelect);
            // 
            // TreeSearchDGV
            // 
            this.TreeSearchDGV.AllowUserToAddRows = false;
            this.TreeSearchDGV.AllowUserToDeleteRows = false;
            this.TreeSearchDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TreeSearchDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42});
            this.TreeSearchDGV.Location = new System.Drawing.Point(261, 25);
            this.TreeSearchDGV.Name = "TreeSearchDGV";
            this.TreeSearchDGV.ReadOnly = true;
            this.TreeSearchDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TreeSearchDGV.Size = new System.Drawing.Size(1081, 401);
            this.TreeSearchDGV.TabIndex = 63;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.HeaderText = "ID";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 75;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.HeaderText = "Book ID";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Width = 200;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.HeaderText = "Name";
            this.dataGridViewTextBoxColumn39.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Width = 220;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "Writer";
            this.dataGridViewTextBoxColumn40.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.Width = 200;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.HeaderText = "Publisher";
            this.dataGridViewTextBoxColumn41.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            this.dataGridViewTextBoxColumn41.Width = 200;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.HeaderText = "Category";
            this.dataGridViewTextBoxColumn42.MinimumWidth = 100;
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            this.dataGridViewTextBoxColumn42.Width = 200;
            // 
            // Search_L_Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1370, 483);
            this.Controls.Add(this.BasicSearch);
            this.Controls.Add(this.TreeSearchPanel);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Search_L_Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search";
            this.Load += new System.EventHandler(this.Search_L_Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.BasicSearch.ResumeLayout(false);
            this.BasicSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Reguler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Similerword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AlonThisWord)).EndInit();
            this.TreeSearchPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TreeSearchDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem typeSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advanceSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem treeSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.Panel BasicSearch;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button BasicSearchBT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.DataGridView Reguler;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        public System.Windows.Forms.DataGridView Similerword;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        public System.Windows.Forms.DataGridView AlonThisWord;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.Panel TreeSearchPanel;
        private System.Windows.Forms.TreeView AllBookTV;
        public System.Windows.Forms.DataGridView TreeSearchDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
    }
}
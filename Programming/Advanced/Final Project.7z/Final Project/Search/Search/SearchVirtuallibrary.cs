﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Search
{
    class SearchVirtuallibrary
    {
        public SearchVirtuallibrary(string KeySearchID)
        {
            DirectoryInfo DI = new DirectoryInfo(Application.StartupPath + @"\Files\Virtual");
            if (!DI.Exists)
            {
                throw new Exception("Not find directoy Virtual in start path");
            }
            else
            {
                DirectoryInfo[] DInfo = DI.GetDirectories();
            }


        }
    }
}

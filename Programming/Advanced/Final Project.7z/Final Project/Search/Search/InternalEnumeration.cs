﻿namespace Search
{
    namespace InternalEnumeration
    {
        public enum SortType { ByID, ByName, ByWritter, ByPublisher, ByKeyword, NotNeeded }
        public enum path { Book, User }
        public enum ResultSearchBook { AloneThisWord, ThisWordInTitle, SimilerThisWord, NotNeeded }
    }
}
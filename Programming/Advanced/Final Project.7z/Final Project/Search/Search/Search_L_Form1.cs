﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Search
{
    public partial class Search_L_Form1 : Form
    {
        public Search_L_Form1()
        {
            InitializeComponent();
        }      

        private void Search_L_Form1_Load(object sender, EventArgs e)
        {
            FI = new FormInitialize(this, 488, 99, false);
            Sundries.Opacity.OpacityOpen(this);
        }

        private void BasicSearchBT_Click(object sender, EventArgs e)
        {
            try
            {
                string type = comboBox1.Text;
                Search s;
                Search s2;
                Search s3;
                switch (type)
                {
                    case "Name Book":
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByName);
                        break;
                    case "Writer":
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByWritter);
                        break;
                    case "Publisher":
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByPublisher);
                        break;
                    case "Key Word":
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByKeyword);
                        break;
                    case "ById":
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByID);
                        break;
                    default:
                        s = new Search(InternalEnumeration.ResultSearchBook.AloneThisWord, InternalEnumeration.SortType.ByName);

                        break;
                }
                string[] value = new string[1];
                value[0] = textBox2.Text;
                Sundries.DataGridViewSetting.InitializeDataGrid(s.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBook), ref AlonThisWord);

                switch (type)
                {
                    case "Name Book":
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByName);
                        break;
                    case "Writer":
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByWritter);
                        break;
                    case "Publisher":
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByPublisher);
                        break;
                    case "Key Word":
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByKeyword);
                        break;
                    case "ById":
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByID);
                        break;
                    default:
                        s2 = new Search(InternalEnumeration.ResultSearchBook.SimilerThisWord, InternalEnumeration.SortType.ByWritter);
                        break;
                }
                Sundries.DataGridViewSetting.InitializeDataGrid(s2.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBook), ref Similerword);
                switch (type)
                {
                    case "Name Book":
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByName);
                        break;
                    case "Writer":
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByWritter);
                        break;
                    case "Publisher":
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByPublisher);
                        break;
                    case "Key Word":
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByKeyword);
                        break;
                    case "ById":
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByID);
                        break;
                    default:
                        s3 = new Search(InternalEnumeration.ResultSearchBook.ThisWordInTitle, InternalEnumeration.SortType.ByWritter);
                        break;
                }
                Sundries.DataGridViewSetting.InitializeDataGrid(s3.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBook), ref Reguler);


            }
            catch { };
        }

        private void AllBookTV_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                Search Tsearch = new Search(InternalEnumeration.ResultSearchBook.NotNeeded, InternalEnumeration.SortType.NotNeeded);
                string[] value = new string[1];
                value[0] = AllBookTV.SelectedNode.Text;
                Sundries.DataGridViewSetting.InitializeDataGrid(Tsearch.newsearch(value, Communication.Protocol.ClientSendQueryType.TreeSearch), ref TreeSearchDGV);
            }
            catch (Exception ex)
            {
                TreeSearchDGV.Rows.Clear();
                MessageBox.Show(ex.Message);
            }
        }
        FormInitialize FI;
        private void basicSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control[] con = new Control[1];
            con[0] = TreeSearchPanel;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            FI = new FormInitialize(con, false, BasicSearch, true);
        }

        private void treeSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control[] con = new Control[1];
            con[0] = BasicSearch;
            FI = new FormInitialize(this, 1366, 500);
            FI = new FormInitialize(con, false, TreeSearchPanel, true);
            FI = new FormInitialize(TreeSearchPanel, 0, 24);
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

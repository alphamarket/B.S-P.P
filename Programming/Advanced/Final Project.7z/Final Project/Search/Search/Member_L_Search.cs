﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Search
{
    public partial class Member_L_Search : Form
    {
        public Member_L_Search()
        {
            InitializeComponent();
        }

        private void SearchBT_Click(object sender, EventArgs e)
        {
            try
            {
                string[] value = new string[1];
                value[0] = KeySearchTB.Text;
                 Search search = new Search(InternalEnumeration.ResultSearchBook.NotNeeded, InternalEnumeration.SortType.NotNeeded);
                Search se = new Search(InternalEnumeration.ResultSearchBook.NotNeeded, InternalEnumeration.SortType.NotNeeded);
                if((search.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchMember).Count!=0))
                    Sundries.DataGridViewSetting.InitializeDataGrid(search.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchMember), ref dataGridView1, "0");
                if(se.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBorrower).Count!=0)
                    Sundries.DataGridViewSetting.InitializeDataGrid(se.newsearch(value, Communication.Protocol.ClientSendQueryType.SearchBorrower), ref dataGridView2, true);
                
              
            }
           
            catch(Exception ex)
            {
                
            }

        }

        private void Member_L_Search_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System.Collections.Generic;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System;
namespace Search
{
    public class TreeSearch
    {

        private List<string> result;
        public TreeSearch(string[] keyWord)
        {
            result = new List<string>();
            newsearch1(keyWord);
        }
        static string Path = Application.StartupPath + @"\Files\DataBase\BookDate.xml";
        public static List<string> SearchTree(string[] KeyWord)
        {
            List<string> list = new List<string>();
            //if (!File.Exists(Path))
            // SetData.CreateEmptyXml.Create();
            FileStream file = new FileStream(Path, FileMode.Open, FileAccess.Read, FileShare.None);
            try
            {
                using (StreamReader read = new StreamReader(file))
                {
                    while (!read.EndOfStream)
                    {
                        string tmp = read.ReadLine();
                        if (tmp.Contains("<" + KeyWord[0] + " />"))
                            return new List<string>();
                        if (tmp.Contains("<" + KeyWord[0] + ">"))
                        {
                            int i = 0;
                            string _tmp = "";
                            string aval = "";
                            LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus();
                            while (true)
                            {
                                if (_tmp.Contains("<BookId>"))
                                {
                                    BS = new LibraryTransactionSystem.BookStatus(_tmp.Split(new string[] { "<BookId>", "</BookId>" }, StringSplitOptions.RemoveEmptyEntries)[0]);
                                }
                                _tmp = read.ReadLine().Split(new string[] { "<BookId>", "</BookId>", "<BookName>", "</BookName>", "<Writer>", "</Writer>", "<Publisher>", "</Publisher>", "<EXPLANATION>", "</EXPLANATION>"
                                    ,"<Computer>","<Mechanic>","<Chemistry>","<Mine>","<Antitrust>","<Electricity>","<Other>","<Engineer>","<Math>","<Physic>","<Poem>","<Prose>","<Turkish>","<Enghlish>","<Russian>","<Other>","<Language>","<Member>","<Cult>",
                                    "</Computer>","</Mechanic>","</Chemistry>","</Mine>","</Antitrust>","</Electricity>","</Other>","</Engineer>","</Math>","</Physic>","</Poem>"
                                    ,"</Prose>","</Turkish>","</Enghlish>","</Russian>","</Other>","</Language>","</Member>","</Cult>"}, StringSplitOptions.RemoveEmptyEntries)[0];
                                if (_tmp.Contains("</" + KeyWord[0] + ">"))
                                {
                                    _tmp = _tmp.Replace("</" + KeyWord[0] + ">", "");
                                    list.Add(_tmp);
                                    return list;
                                }
                                if (i == 4)
                                    list.Add(SearchBook.category(KeyWord[0]));
                                else if (i == 6)
                                {
                                    list.Add((!BS.IsBorrow).ToString());
                                    i = 0;
                                }
                                else
                                    list.Add(_tmp);
                                i++;
                            }
                        }
                    }
                }
            }


            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return new List<string>();
            }
            finally
            {
                file.Close();
            }
            return new List<string>();
        }
        List<string> keep = new List<string>();
        public void newsearch1(string[] keytree)
        {

            XmlTextReader XTR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\BookDate.xml");
            bool issave = false;
            keep = new List<string>();

            while (XTR.Read())
            {

                if (XTR.NodeType == XmlNodeType.Text)
                    if (issave)
                    {
                        result.Add(XTR.Value);

                    }

                if (XTR.NodeType == XmlNodeType.Element)
                    if (XTR.Name == keytree[0])
                        issave = true;


                if (XTR.NodeType == XmlNodeType.EndElement)
                    if (XTR.Name == keytree[0])
                        break;
                if (XTR.NodeType == XmlNodeType.Element)
                    if (XTR.Name != "BookId" && XTR.Name != "BookName" && XTR.Name != "Writer" && XTR.Name != "Publisher" && XTR.Name != "EXPLANATION" && XTR.Name != "AllBook" && XTR.Name != "Engineer" && XTR.Name != "Public" && XTR.Name != "Cult" && XTR.Name != "Other" && XTR.Name != "Literary" && XTR.Name != "LanguageBook")
                    {
                        keep.Add(XTR.Name);

                    }


            }
            XTR.Close();
            //return result;
        }
        private List<string> allData;
        public List<string> newsearch()
        {
            allData = new List<string>();
            for (int i = 0; i < result.Count; i += 5)
            {
                allData.Add(result[i]);
                allData.Add(result[i + 1]);
                allData.Add(result[i + 2]);
                allData.Add(result[i + 3]);
                allData.Add(keep[i]);
                allData.Add(result[i + 4]);
                LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus(result[i]);
                allData.Add(BS.IsBorrow.ToString());
            }
            return allData;
        }
        public TreeSearch(string Nodetext)
        {
            List<string> Newresult = new List<string>();
            try
            {
                bool state = false;
                string keepbackname = "";
                List<string> list = new List<string>();
                List<string> categorylist = new List<string>();
                List<string> IsBorrowList = new List<string>();                
                int count = 0;
                int nullstate = 0;
                XmlTextReader xmlR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\BookDate.xml");
                while (xmlR.Read())
                {
                    if (xmlR.NodeType == XmlNodeType.Element)
                        if (xmlR.Name == Nodetext)
                            state = true;
                    if (xmlR.NodeType == XmlNodeType.EndElement)
                        if (xmlR.Name == Nodetext)
                        {
                            state = false;
                            nullstate++;
                        }

                    if (state)
                    {
                        LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus(Nodetext);
                        if (xmlR.NodeType == XmlNodeType.Element)
                            if (xmlR.Name != "BookId" && xmlR.Name != "BookName" && xmlR.Name != "Writer" && xmlR.Name != "Publisher" && xmlR.Name != "EXPLANATION" && xmlR.Name != "AllBook")
                                keepbackname = xmlR.Name;
                        if (xmlR.NodeType == XmlNodeType.Text)
                        {

                            if (count == 4)
                            {
                                IsBorrowList.Add(BS.IsBorrow.ToString());
                                count = 0;
                            }

                            if (count == 3)
                                categorylist.Add(keepbackname);
                            list.Add(xmlR.Value);
                            count++;
                        }
                    }

                }
                int countstate = 0;

                for (int i = 0; i < list.Count; i += 5)
                {
                    Newresult.Add(list[i]);
                    Newresult.Add(list[i + 1]);
                    Newresult.Add(list[i + 2]);
                    Newresult.Add(list[i + 3]);
                    Newresult.Add(categorylist[countstate]);
                    Newresult.Add(list[i + 4]);
                    Newresult.Add(IsBorrowList[countstate]);
                    if (i == list.Count - 5)
                    {
                        break;
                    }
                    countstate++;
                }
                result = Newresult;
            }
            catch (FileNotFoundException) { result = Newresult; }
        }
        public List<string> Result { get {return result; } }
    }
}

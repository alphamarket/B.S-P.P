﻿using System.Collections.Generic;
using System;

namespace Search
{
    public class Search
    {
        private List<string> _Result;
        private static int type = 0;
        static InternalEnumeration.ResultSearchBook IRB = InternalEnumeration.ResultSearchBook.NotNeeded;
        public static InternalEnumeration.ResultSearchBook getBookSearchResult()
        {
            return IRB;
        }
        public Search() { }
        public Search(InternalEnumeration.ResultSearchBook RSB, InternalEnumeration.SortType ST)
        {
            SetTypeofRank(ST);
            setBookSearchResult(RSB);
        }
        public List<string> newsearch(string[] value, Communication.Protocol.ClientSendQueryType section)
        {
            _Result = new List<string>();

            switch (section)
            {
                case Communication.Protocol.ClientSendQueryType.SearchBorrower:
                    SearchBorrowerinfo SBI = new SearchBorrowerinfo(value);
                    _Result = SBI.BorrowerInfo;
                    break;
                case Communication.Protocol.ClientSendQueryType.SearchBook:
                    SearchBook search = new SearchBook();
                    switch (IRB)
                    {
                        case InternalEnumeration.ResultSearchBook.AloneThisWord:
                            search = new SearchBook(InternalEnumeration.path.Book, type);
                            _Result = search.newSearch2(value);
                            break;
                        case InternalEnumeration.ResultSearchBook.SimilerThisWord:
                            search = new SearchBook(InternalEnumeration.path.Book, type);
                            _Result = search.newSearch1(value);
                            break;
                        case InternalEnumeration.ResultSearchBook.ThisWordInTitle:
                            search = new SearchBook(InternalEnumeration.path.Book, type);
                            _Result = search.newSearch(value);
                            break;
                    }
                    break;
                case Communication.Protocol.ClientSendQueryType.SearchMember:
                    SearchMember searchM = new SearchMember();
                    _Result = searchM.getMemberinfo(value);
                    break;
                case Communication.Protocol.ClientSendQueryType.Login:
                    CheckUserName a = new CheckUserName();
                    if (a.istrue(value))
                        _Result.Add("true");
                    else
                        _Result.Add("false");
                    break;
                case Communication.Protocol.ClientSendQueryType.CheckAdmin:
                    ChekAdmin CA = new ChekAdmin(value);
                    _Result.Add(CA.IsAdmin.ToString());
                    break;
                case Communication.Protocol.ClientSendQueryType.TreeSearch:
                    TreeSearch T = new TreeSearch(value[0]);
                    _Result = T.Result;
                    break;
            }
            return _Result;
        }
        public static void SetTypeofRank(InternalEnumeration.SortType ST)
        {
            switch (ST)
            {
                case InternalEnumeration.SortType.ByName:
                    type = 1;
                    break;
                case InternalEnumeration.SortType.ByWritter:
                    type = 2;
                    break;
                case InternalEnumeration.SortType.ByPublisher:
                    type = 3;
                    break;
                case InternalEnumeration.SortType.ByKeyword:
                    type = 4;
                    break;
                case InternalEnumeration.SortType.ByID:
                    type = 0;
                    break;
            }
        }
        public static void setBookSearchResult(InternalEnumeration.ResultSearchBook ibr)
        {
            IRB = ibr;
        }
    }
}

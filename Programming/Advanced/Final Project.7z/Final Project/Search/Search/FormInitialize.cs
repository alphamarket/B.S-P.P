﻿using System.Windows.Forms;
namespace Search
{
    class FormInitialize
    {
        public FormInitialize(Control[] conP, bool state, Control contP, bool stateC)
        {
            for (int i = 0; i < conP.Length; i++)
            {
                conP[i].Visible = state;
            }
            contP.Visible = true;
            contP.Location = new System.Drawing.Point(0, 24);
        }
        public FormInitialize(Form form, int x, int y)
        {
            form.WindowState = System.Windows.Forms.FormWindowState.Normal;
            form.Size = new System.Drawing.Size(x, y);

        }
        public FormInitialize(Control con, int x, int y)
        {
            con.Location = new System.Drawing.Point(x, y);
        }
        public FormInitialize(Form form, int x, int y, bool state)
        {
            form.WindowState = System.Windows.Forms.FormWindowState.Normal;
            form.Size = new System.Drawing.Size(x, y);
            foreach (Control con in form.Controls)
            {
                if (con is MenuStrip)
                {
                    continue;
                }
                else
                    con.Visible = state;
            }
        }
    }
}

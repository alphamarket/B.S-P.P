﻿using System.Xml;
using System.Windows.Forms;
using System.IO;
using System;

namespace Search
{
    class ChekAdmin
    {
        private bool testAdmin=false;
        public ChekAdmin(string[]Admin_N_P)
        {
            try
            {
                FileInfo F = new FileInfo(Application.StartupPath + @"\Files\DataBase\Admin.xml");
                if (!F.Exists)
                {
                    XmlTextWriter XTR = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\Admin.xml", null);
                    XTR.Formatting = Formatting.Indented;
                    XTR.WriteStartDocument();
                    XTR.WriteStartElement("asd");
                    XTR.WriteStartElement("Name");
                    XTR.WriteString("admin");
                    XTR.WriteEndElement();
                    XTR.WriteStartElement("asghar");
                    XTR.WriteString("1234");
                    XTR.WriteEndElement();
                    XTR.WriteEndElement();
                    XTR.WriteEndDocument();
                    XTR.Close();

                }
                bool tmp = false;
                bool tmp2 = false;
                XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\Admin.xml");
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                        if (reader.Name == "Name")
                        {
                            tmp = true;
                        }
                    if (tmp)
                        if (reader.Value == Admin_N_P[0])
                            tmp2 = true;
                    if (tmp2)
                        if (reader.Value == Admin_N_P[1])
                            testAdmin = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public bool IsAdmin { get { return testAdmin; } }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;
namespace Search
{
    class SearchBook
    {
        private List<string> _value;
        private List<string> Result;
        private int type;
        List<string> Indexer;
        static string xmlpath;
        internal SearchBook() { }
        internal SearchBook(InternalEnumeration.path path, int setType)
        {
            type = setType;
            Result = new List<string>();
            this._value = new List<string>();
            xmlpath = Application.StartupPath + @"\Files\DataBase\BookDate.xml";
            _value = new List<string>();
            Indexer = new List<string>();
            XmlTextReader reader = new XmlTextReader(xmlpath);
            string keepbacknaeme = "";
            try
            {
                int count = 0;
                bool nullstate = false;
                int keepbackcount = -1;

                while (reader.Read())
                {

                    if (reader.NodeType == XmlNodeType.Text)
                    {
                        _value.Add(reader.Value);
                        count++;
                    }
                    //if (reader.NodeType == XmlNodeType.Element)
                    //    if (reader.Name != "BookId" && reader.Name != "BookName" && reader.Name != "Writer" && reader.Name != "Publisher" && reader.Name != "EXPLANATION" && reader.Name != "AllBook" && reader.Name != "Engineer" && reader.Name != "Public" && reader.Name != "LanguageBook")
                    //    {

                    //        if (keepbackcount == count)
                    //        {
                    //            Indexer.Add((count).ToString());
                    //            Indexer.Add(keepbacknaeme);
                    //            nullstate = true;

                    //        }
                    //        else
                    //        {
                    //            Indexer.Add((count).ToString());
                    //            Indexer.Add(reader.Name);
                    //        }
                    //        keepbackcount = count;
                    //        keepbacknaeme = reader.Name;
                    //    }
                    //if (reader.NodeType == XmlNodeType.EndElement)
                    //{
                    //    if (reader.Name != "BookId" && reader.Name != "BookName" && reader.Name != "Writer" && reader.Name != "Publisher" && reader.Name != "EXPLANATION" && reader.Name != "AllBook" && reader.Name != "Engineer" && reader.Name != "Public" && reader.Name != "LanguageBook")
                    //    {
                    //        if (nullstate)                          
                    //            if (reader.Name == keepbacknaeme)
                    //            {
                    //                Indexer.Add((keepbackcount + 1).ToString());
                    //                Indexer.Add(keepbacknaeme);
                    //                nullstate = false;
                    //            }
                    //            Indexer.Add((count - 1).ToString());


                    //    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                reader.Close();
            }
        }

        internal List<string> newSearch(string[] keep4)
        {
            int count = 0;
            int count2 = 0;
            for (int i = 0; i < _value.Count; i += 5)
            {
                string keep1 = _value[i + type];
                string keep = keep4[0];
                int j = 0;
                while (j < (keep.Length > keep1.Length ? keep1.Length : keep.Length))
                {
                    if (keep[j] == keep1[j])
                        count++;
                    j++;
                }
                Result.Add(count + "_" + count2 + "_" + (count + 6) + "_A" + _value[i]);
                Result.Add(count + "_" + count2 + "_" + (count + 5) + "_A" + _value[i + 1]);
                Result.Add(count + "_" + count2 + "_" + (count + 4) + "_A" + _value[i + 2]);
                Result.Add(count + "_" + count2 + "_" + (count + 3) + "_A" + _value[i + 3]);
                Result.Add(count + "_" + count2 + "_" + (count + 2) + "_A" + category(_value[i]));
                Result.Add(count + "_" + count2 + "_" + (count + 1) + "_A" + _value[i + 4]);
                LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus(_value[i]);
                Result.Add(count + "_" + count2 + "_" + (count) + "_A" + (!BS.IsBorrow).ToString());
                count = 0;
                count2++;
            }
            
            Result.Sort();
            _value.Clear();
            for (int i = Result.Count - 1; i >= 0; i--)
            {
                String keep2 = Result[i];
                int j = 0;
                while (j < keep2.Length)
                {
                    if (keep2[j] == '_' && keep2[j + 1] == 'A')
                    {
                        string keep3 = "";
                        for (int k = j + 2; k < keep2.Length; k++)
                        {
                            keep3 += keep2[k];
                        }
                        _value.Add(keep3);
                    }
                    j++;
                }
            }
            return _value;
        }
        internal List<string> newSearch1(string[] keep4)
        {
            for (int i = 0; i < _value.Count; i += 5)
            {
                string keep2 = _value[i + type];
                if (keep2.Contains(keep4[0]))
                {
                    for (int j = 0; j < keep4.Length; j++)
                    {
                        if (keep2.Contains(keep4[j]))
                        {
                            Result.Add(_value[i]);
                            Result.Add(_value[i + 1]);
                            Result.Add(_value[i + 2]);
                            Result.Add(_value[i + 3]);
                            Result.Add(category(_value[i]));
                            Result.Add(_value[i + 4]);
                            LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus(_value[i]);
                            Result.Add((!BS.IsBorrow).ToString());
                        }
                    }
                }
            }
            return Result;
        }
        internal List<string> newSearch2(string[] keep4)
        {
            for (int i = 0; i < _value.Count; i += 5)
            {
                string keep2 = _value[i + type];
                if (keep2.Contains(keep4[0]))
                {
                    for (int j = 0; j < keep4.Length; j++)
                    {
                        if (keep2==keep4[j])
                        {
                            Result.Add(_value[i]);
                            Result.Add(_value[i + 1]);
                            Result.Add(_value[i + 2]);
                            Result.Add(_value[i + 3]);
                            Result.Add(category(_value[i]));
                            Result.Add(_value[i + 4]);
                            LibraryTransactionSystem.BookStatus BS = new LibraryTransactionSystem.BookStatus(_value[i]);
                            Result.Add((!BS.IsBorrow).ToString());
                        }
                    }
                }
            }
            return Result;
        }
        static int count = 0;
        internal static string category(string keep4)
        {
            string tmp="";
            XmlTextReader XMLR = new XmlTextReader(xmlpath); 
            try
            {
                
                while (XMLR.Read())
                {
                    if (XMLR.NodeType == XmlNodeType.Element)
                    {
                        if (XMLR.Name != "BookId" && XMLR.Name != "BookName" && XMLR.Name != "Writer" && XMLR.Name != "Publisher" && XMLR.Name != "EXPLANATION" && XMLR.Name != "AllBook" && XMLR.Name != "Engineer")
                        {
                            tmp = XMLR.Name;                   
                        }
                    }
                    else
                        if (XMLR.NodeType == XmlNodeType.Text)
                        {
                            if ( XMLR.Value == keep4 )
                            {
                                break;
                            }
                        }

                }
                return tmp;
            }
            catch { return ""; }
            finally { XMLR.Close(); count++; }
        }
    }
}


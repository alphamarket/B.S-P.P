﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;

namespace Search
{
    class SearchBorrowerinfo
    {
         List<string> borrowerinfo;
         public SearchBorrowerinfo(string[] Id)
        {
            try
            {
                int count = 0;
                int count1 = 0;
                int count2 = 0;
                string keepbackvalue = "";
                borrowerinfo = new List<string>();
                List<string> tmp = new List<string>();
                XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowlist.xml");
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Text)
                        tmp.Add(reader.Value);
                    if (reader.NodeType == XmlNodeType.Element)
                        if (reader.Name == "borrowserID")
                            count++;
                    if (count != 0)
                        if (reader.NodeType == XmlNodeType.Text)
                            if (reader.Value == Id[0])
                                count2++;
                    if (count1 == 8)

                        if (count2 != 0)
                            break;
                        else
                        {
                            tmp.Clear();
                            count = 0;
                            count2 = 0;
                            count1 = 0;
                        }


                    if (reader.NodeType == XmlNodeType.Text)
                        count1++;

                }
                for (int i = 0; i < tmp.Count; i += 8)
                {
                    borrowerinfo.Add(tmp[i]);
                    borrowerinfo.Add(tmp[i + 1]);
                    borrowerinfo.Add(tmp[i + 2] + " / " + tmp[i + 3] + " / " + tmp[i + 4]);
                    borrowerinfo.Add(tmp[i + 5]);
                    borrowerinfo.Add(tmp[i + 6]);
                    borrowerinfo.Add(tmp[i + 7]);

                }

                reader.Close();
            }
            catch
            {
            }

        }
        public List<string> BorrowerInfo { get { return borrowerinfo; } }
    }
}

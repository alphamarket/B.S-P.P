﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
namespace Search
{
    class CheckUserName
    {
        internal bool istrue(string[] value)
        {
                XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml");
                try
                {
                    int count = 0;
                    while (reader.Read())
                    {
                        if (count != 0)
                        {
                            if (reader.NodeType == XmlNodeType.Text)
                            {
                                if (reader.Value == value[1])
                                    return true;
                                count = 0;
                            }
                        }
                        if (reader.NodeType == XmlNodeType.Text)
                        {
                            if (reader.Value == value[0])
                                count++;
                        }
                    }
                    return false;
                }
                catch
                {
                    return false;
                }
                finally
                {
                    reader.Close();
                }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace Search
{
   public class Show
    {

        List<string> value;
        public Show()
        {
            value = new List<string>();
        }
        int count = 0;
        public List<string> newShow(string str)
        {
            XmlTextReader xmlreader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\BookDate.xml");
            while (xmlreader.Read())
            {
                if (xmlreader.NodeType == XmlNodeType.Element)
                {
                    if (xmlreader.Name == str)
                    {
                        count = 1;
                    }

                }
                if (count == 1)
                {
                    if (xmlreader.NodeType == XmlNodeType.Text)
                    {
                        value.Add(xmlreader.Value);

                    }
                }
                if (xmlreader.NodeType == XmlNodeType.EndElement)
                {
                    if (xmlreader.Name == str)
                    {
                        count = 0;
                    }
                }
            }
            xmlreader.Close();
            return value;
        }
    }
}

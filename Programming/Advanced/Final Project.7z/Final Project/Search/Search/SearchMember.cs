﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace Search
{
    class SearchMember
    {
        string xmlpath;
        private List<string> Minfo;
        private List<string> Minfo1;
        public SearchMember()
        {
            Minfo = new List<string>();
            Minfo1 = new List<string>();
            xmlpath = Application.StartupPath + @"\Files\DataBase\MemberInfo.xml";
            XmlTextReader reader = new XmlTextReader(xmlpath);
            try
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Text)
                        Minfo.Add(reader.Value);
                }

            }
            catch
            { }
            finally { reader.Close(); }
        }
        public List<string> getMemberinfo(string[] MINFO)
        {
            for (int i = 0; i < Minfo.Count; i += 8)
            {
                if (Minfo[i+2] == MINFO[0])
                {

                    Minfo1.Add(Minfo[i]);
                    Minfo1.Add(Minfo[i + 1]);
                    Minfo1.Add(Minfo[i + 2]);
                    Minfo1.Add(Minfo[i + 3]);
                    Minfo1.Add(Minfo[i + 4]);
                    Minfo1.Add(Minfo[i + 5]);
                    Minfo1.Add(Minfo[i + 6]);
                    Minfo1.Add(Minfo[i + 7]);
                    return Minfo1;
                }
            }
            Minfo.Clear();
            Minfo.Add("False");
            return Minfo;
        }

    }
}


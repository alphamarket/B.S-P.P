﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace LibraryTransactionSystem
{
    public class IsJoinMember
    {
        bool keepstate=false;
        bool checkId = false;
        public IsJoinMember(string[] UsernNamePassId)
        {
            try
            {

                XmlTextReader XmlR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml");
                int count = 0;

                while (XmlR.Read())
                {
                    if (count != 0)
                        if (XmlR.NodeType == XmlNodeType.Text)
                        {
                            if (XmlR.Value == UsernNamePassId[1])
                                keepstate = true;
                            count = 0;
                        }
                    if (XmlR.NodeType == XmlNodeType.Text)
                        if (XmlR.Value == UsernNamePassId[0])
                            count++;
                }
                count = 0;
                while (XmlR.Read())
                {
                    if (XmlR.NodeType == XmlNodeType.Element)
                        if (XmlR.Name == "IdStudent")
                            count++;
                    if (count != 0)
                        if (XmlR.NodeType == XmlNodeType.Text)
                            if (XmlR.Value == UsernNamePassId[2])
                                checkId = true;

                }
                XmlR.Close();
            }
            catch (System.IO.FileNotFoundException)
            {

            }
        }
           public bool IsJoin{ get{return keepstate;} }
           public bool IsIdExist { get { return checkId; } }
    }
}

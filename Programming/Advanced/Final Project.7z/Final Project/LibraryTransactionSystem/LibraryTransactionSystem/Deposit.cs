﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using System.Windows.Forms;
namespace LibraryTransactionSystem
{
   public class Deposit
    {
        private List<string> borrowlist;
        private string path;
        public Deposit()
        {
            XmlTextReader XmlRead = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowlist.xml"); 
            try
            {
                FileInfo File = new FileInfo(Application.StartupPath + @"\Files\DataBase\borrowlist.xml");
                if (!File.Exists)
                {
                    XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml", null);
                    objXmlTextWriter.Formatting = Formatting.Indented;
                    objXmlTextWriter.WriteStartDocument();
                    objXmlTextWriter.WriteStartElement("ListBorrowed");
                    objXmlTextWriter.WriteEndElement();
                    objXmlTextWriter.WriteEndDocument();
                    objXmlTextWriter.Flush();
                    objXmlTextWriter.Close();
                }
                this.path = Application.StartupPath;
                bool controldata = false;
                borrowlist = new List<string>();
                XmlRead = new XmlTextReader(path + @"\Files\DataBase\borrowlist.xml");
                while (XmlRead.Read())
                {
                    if (!controldata)
                        if (XmlRead.NodeType == XmlNodeType.Text)
                            borrowlist.Add(XmlRead.Value);
                    if (XmlRead.NodeType == XmlNodeType.Element)
                        if (XmlRead.Name == "BorrowDate")
                        {
                            controldata = true;
                        }
                    if (XmlRead.NodeType == XmlNodeType.EndElement)
                        if (XmlRead.Name == "BorrowDate")
                        {
                            controldata = false;
                        }
                }
                XmlRead.Close();
            }
            catch
            {

            }
            finally { XmlRead.Close(); }

        }
        public void BorrowBook(List<string> info)
        {
            for (int i = 0; i < borrowlist.Count; i+=5)
            {
                if (info[1] == borrowlist[i + 1])
                    throw new Exception("The demanded book has been borrowed!"); 
            }
            int count = 0;
            while (count < info.Count)
            {
                borrowlist.Add(info[count]);
                count++;
            }
            
            try
            {
                int count1 = 1;
                XmlTextWriter xmlW = new XmlTextWriter(path+@"\Files\DataBase\Borrowlist.xml", null);
                xmlW.Formatting = Formatting.Indented;
                xmlW.WriteStartDocument();
                xmlW.WriteStartElement("ListBorrowed");
                for (int i = 0; i < borrowlist.Count; i += 5)
                {

                    xmlW.WriteStartElement("Borrowing");
                    xmlW.WriteStartElement("BookName");
                    xmlW.WriteString(borrowlist[i]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("BookId");
                    xmlW.WriteString(borrowlist[i + 1]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("Date");
                    xmlW.WriteStartElement("BorrowDate");
                    xmlW.WriteStartElement("Year");
                    xmlW.WriteString(DateTime.Now.Year.ToString());
                    xmlW.WriteEndElement();
                    xmlW.WriteStartElement("Month");
                    xmlW.WriteString(DateTime.Now.Month.ToString());
                    xmlW.WriteEndElement();
                    xmlW.WriteStartElement("Day");
                    xmlW.WriteString(DateTime.Now.Day.ToString());
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("ReturnDate");
                    xmlW.WriteString(borrowlist[i+2]);
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("borrowserID");
                    xmlW.WriteString(borrowlist[i + 3]);
                    xmlW.WriteEndElement();
                    //
                    xmlW.WriteStartElement("borrowserName");
                    xmlW.WriteString(borrowlist[i + 4]);
                    xmlW.WriteEndElement();
                    xmlW.WriteEndElement();
                    count1++;
                }
                xmlW.WriteEndElement();
                xmlW.WriteEndDocument();
                xmlW.Flush();
                xmlW.Close();

            }
            catch (Exception ex)
            {

            }
          
        }
    }
}

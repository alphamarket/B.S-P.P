﻿using System.Xml;
using System.Windows.Forms;
namespace LibraryTransactionSystem
{
    public class MemberStatus
    {

        bool keepstate = false;
        public MemberStatus(string[] UsernNamePass)
        {
            try
            {
                XmlTextReader XmlR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowlist.xml");
                int count = 0;

                while (XmlR.Read())
                {
                    if (count != 0)
                        if (XmlR.NodeType == XmlNodeType.Text)
                        {
                            if (XmlR.Value == UsernNamePass[1])
                                keepstate = true;
                            count = 0;
                        }
                    if (XmlR.NodeType == XmlNodeType.Text)
                        if (XmlR.Value == UsernNamePass[0])
                            count++;
                }
                XmlR.Close();
            }
            catch
            {
                keepstate = false;
            }
        }
        public bool IsBorrowed { get { return keepstate; } }

    }
}

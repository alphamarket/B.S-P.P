﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
namespace LibraryTransactionSystem
{
    public class BookStatus
    {

        bool BookState = false;
        public BookStatus() { }
        public BookStatus(string BookId)
        {
            try
            {
                bool status = false;
                XmlTextReader XmlR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowlist.xml");
                while (XmlR.Read())
                {
                    if (XmlR.NodeType == XmlNodeType.Element)
                        if (XmlR.Name == "BookId")
                            status = true;
                    if (status)
                    {
                        if (XmlR.NodeType == XmlNodeType.Text)
                        {
                            if (XmlR.Value == BookId)
                            {
                                BookState = true;
                                XmlR.Close();
                                return;
                            }
                            status = false;
                        }
                    }
                }
                XmlR.Close();
            }
            catch
            {
                BookState = false;
            }
        }
        public bool IsBorrow { get { return BookState; } }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetData
{
    namespace InternalEnumeration
    {
        internal enum path { Book, User }
        //internal enum ResultSearchBook { AloneThisWord, ThisWordInTitle, SimilerThisWord }
        internal enum Rank { Computer, Mechanic, Chemistry, Mine, Antitrust, Electricity, OtherEngineer, Math, Physic, Literary, Poem, Prose, LanguageBook, Turkish, Enghlish, Russian, OtherLanguage, Cult, Other }
    }
}

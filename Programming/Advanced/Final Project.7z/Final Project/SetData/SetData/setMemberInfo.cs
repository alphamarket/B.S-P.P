﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
namespace SetData
{
    public class SetMemberInfo
    {
        private List<string> value1;
        public SetMemberInfo()
        {
            FileInfo info = new FileInfo(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml");
            if (!info.Exists)
            {
                XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml", null);
                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartDocument();
                objXmlTextWriter.WriteStartElement("AllMember");
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteEndDocument();
                objXmlTextWriter.Flush();
                objXmlTextWriter.Close();
            }
            value1 = new List<string>();
        }
        public bool addNewMember(List<string> MemberInfo)
        {
            try
            {
                XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml");
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Text)
                        value1.Add(reader.Value);
                }
                int j = 0;
                while (j < MemberInfo.Count)
                {
                    value1.Add(MemberInfo[j]);
                    j++;
                }
                reader.Close();
                XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml", null);
                objXmlTextWriter.Formatting = Formatting.Indented;
                j = 0;
                objXmlTextWriter.WriteStartDocument();
                objXmlTextWriter.WriteStartElement("Member");
                while (j < value1.Count)
                {
                    objXmlTextWriter.Formatting = Formatting.Indented;
                    objXmlTextWriter.WriteStartElement("Name");
                    objXmlTextWriter.WriteString(value1[j].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("LastName");
                    objXmlTextWriter.WriteString(value1[j + 1].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("IdStudent");
                    objXmlTextWriter.WriteString(value1[j + 2].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("UserName");
                    objXmlTextWriter.WriteString(value1[j + 3].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("PassWord");
                    objXmlTextWriter.WriteString(value1[j + 4].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("PhoneNumber");
                    objXmlTextWriter.WriteString(value1[j + 5].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("Address");
                    objXmlTextWriter.WriteString(value1[j + 6].ToString());
                    objXmlTextWriter.WriteEndElement();
                    //
                    objXmlTextWriter.WriteStartElement("Rank");
                    objXmlTextWriter.WriteString(value1[j + 7].ToString());
                    objXmlTextWriter.WriteEndElement();
                    j += 8;


                }
                objXmlTextWriter.WriteEndDocument();
                objXmlTextWriter.Flush();
                objXmlTextWriter.Close();
                SetUser_Pass set = new SetUser_Pass();
                set.setNew_User_Password();
                return true;

            }
            catch
            {
                return false;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetData
{
    public class SetData
    {
        public static void SetNewData(string TargetArea, List<string> Data, Communication.Protocol.ClientSendQueryType Section)
        {
            switch (Section)
            {
                case Communication.Protocol.ClientSendQueryType.AddBook:
                    new AddBook(TargetArea, Data);
                    return;
                case Communication.Protocol.ClientSendQueryType.JoinMember:
                    SetMemberInfo addM = new SetMemberInfo();
                    addM.addNewMember(Data);
                    return;
            }
        }
    }
}
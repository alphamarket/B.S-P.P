﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace SetData
{
   internal class newAdd
    {
        XmlTextWriter d;
        int End;
        int Begin;
        public XmlTextWriter get(XmlTextWriter objXmlTextWriter, List<string> str, List<string> str2, string str3)
        {

            for (int i = 0; i < str2.Count; i++)
            {
                if (str2[i] == str3)
                {
                    Begin = int.Parse(str2[i + 1]);
                    End = int.Parse(str2[i + 2]);
                    break;
                }
            }
            for (int i = Begin; i < End; i += 5)
            {

                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartElement("BookName");
                objXmlTextWriter.WriteString(str[i].ToString());
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteStartElement("BookName");
                objXmlTextWriter.WriteString(str[i+1].ToString());
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteStartElement("Writer");
                objXmlTextWriter.WriteString(str[i + 2].ToString());
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteStartElement("Publisher");
                objXmlTextWriter.WriteString(str[i  +3].ToString());
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteStartElement("EXPLANATION");
                objXmlTextWriter.WriteString(str[i +4].ToString());
                objXmlTextWriter.WriteEndElement();
                d = objXmlTextWriter;
            }
            return d;
        }
    }
}

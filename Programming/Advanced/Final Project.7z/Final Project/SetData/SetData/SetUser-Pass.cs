﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
namespace SetData
{
    public class SetUser_Pass
    {
        private List<string> value1;
        public SetUser_Pass()
        {
            FileInfo info = new FileInfo(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml");
            if (!info.Exists)
            {
                XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml", null);
                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartDocument();
                objXmlTextWriter.WriteStartElement("UserInfo");
                objXmlTextWriter.WriteEndElement();
                objXmlTextWriter.WriteEndDocument();
                objXmlTextWriter.Flush();
                objXmlTextWriter.Close();
            }
            value1 = new List<string>();

        }
        public bool setNew_User_Password()
        {
            try
            {
                XmlTextReader reader = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\MemberInfo.xml");
                int count = 0;
                while (reader.Read())
                {
                    if (count != 0)
                    {
                        if (reader.NodeType == XmlNodeType.Text)
                            value1.Add(reader.Value);
                        count = 0;
                    }
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name == "UserName")
                            count++;
                        if (reader.Name == "PassWord")
                            count++;
                    }
                }
                int j = 0;
                reader.Close();
                XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\UserName&Password.xml", null);
                objXmlTextWriter.Formatting = Formatting.Indented;
                objXmlTextWriter.WriteStartDocument();
                objXmlTextWriter.WriteStartElement("asd");
                while (j < value1.Count)
                {
                    objXmlTextWriter.Formatting = Formatting.Indented;
                    objXmlTextWriter.WriteStartElement("UserName");
                    objXmlTextWriter.WriteString(value1[j].ToString());
                    objXmlTextWriter.WriteEndElement();
                    objXmlTextWriter.WriteStartElement("PassWord");
                    objXmlTextWriter.WriteString(value1[j + 1].GetHashCode().ToString());
                    objXmlTextWriter.WriteEndElement();
                    j += 2;

                }
                objXmlTextWriter.WriteEndDocument();
                objXmlTextWriter.Flush();
                objXmlTextWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
namespace SetData
{
    public class CreateEmptyXml
    {
        public static void Create()
        {
            XmlTextWriter objXmlTextWriter = new XmlTextWriter(Application.StartupPath + @"\Files\DataBase\BookDate.xml", null);
            objXmlTextWriter.Formatting = Formatting.Indented;
            objXmlTextWriter.WriteStartDocument();
            objXmlTextWriter.WriteStartElement("AllBook");
            objXmlTextWriter.WriteStartElement("Engineer");
            objXmlTextWriter.WriteStartElement("Computer");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Mechanic");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Chemistry");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Mine");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Antitrust");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Electricity");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("OtherEngineer");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Public");
            objXmlTextWriter.WriteStartElement("Math");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Physic");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Literary");
            objXmlTextWriter.WriteStartElement("Poem");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Prose");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("LanguageBook");
            objXmlTextWriter.WriteStartElement("Turkish");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Enghlish");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Russian");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("OtherLanguage");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Cult");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteStartElement("Other");
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndElement();
            objXmlTextWriter.WriteEndDocument();
            objXmlTextWriter.Flush();
            objXmlTextWriter.Close();
        }
    }
    class AddBook
    {
        string Path = Application.StartupPath + @"\Files\DataBase\BookDate.xml", TmpPath = Application.StartupPath + @"\Files\DataBase\TmpBookDate.xml";
        public AddBook(string TargetArea, List<string> Book)
        {
            if (!File.Exists(Path))
                CreateEmptyXml.Create();
            if (File.Exists(TmpPath))
                File.Delete(TmpPath);
            FileStream tmpFile = new FileStream(TmpPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            FileStream file = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            try
            {
                bool found = false;
                file.CopyTo(tmpFile);
                tmpFile.Close();
                file.Close();
                file = new FileStream(this.Path, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
                tmpFile = new FileStream(TmpPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
                using (StreamReader read = new StreamReader(tmpFile))
                {
                    using (StreamWriter write = new StreamWriter(file))
                    {
                        while (!read.EndOfStream)
                        {
                            string tmp = read.ReadLine();
                            if (tmp.Contains("<" + TargetArea + ">") || tmp.Contains("<" + TargetArea + " />"))
                            {
                                found = true;
                                write.WriteLine("<" + TargetArea + ">");
                                for (int i = 0; i < Book.Count; i++)
                                {
                                    switch (i)
                                    {
                                        case 0:
                                            write.WriteLine("<BookId>" + Book[i] + "</BookId>");
                                            break;
                                        case 1:
                                            write.WriteLine("<BookName>" + Book[i] + "</BookName>");
                                            break;
                                        case 2:
                                            write.WriteLine("<Writer>" + Book[i] + "</Writer>");
                                            break;
                                        case 3:
                                            write.WriteLine("<Publisher>" + Book[i] + "</Publisher>");
                                            break;
                                        case 4:
                                            write.WriteLine("<EXPLANATION>" + Book[i] + "</EXPLANATION>");
                                            break;
                                    }
                                }
                                if (tmp.Contains("</" + TargetArea + ">") || tmp.Contains("<" + TargetArea + " />"))
                                    write.WriteLine("</" + TargetArea + ">");
                            }
                            else
                                write.WriteLine(tmp);
                            write.Flush();
                        }
                    }
                }
                if (found)
                    Sundries.MessageBox.ShowMessage("Book has been added to database successfully");
                else
                    Sundries.MessageBox.ShowMessage("The category not found !");
            }
            catch (Exception e)
            {
                Sundries.MessageBox.ShowMessage(e.Message);
            }
            finally
            {
                if (File.Exists(TmpPath))
                    File.Delete(TmpPath);
                file.Close();
                tmpFile.Dispose();
                tmpFile.Close();
            }
        }
    }
}
﻿using System.Windows.Forms;
using System.Xml;
using System.Collections.Generic;

namespace DayNews
{
   public class PersonTarydy
    {
        
        private List<string> value;
        public List<string> TrydyInfo { get { return value; } }
        public PersonTarydy()
        {
            try
            {
                value = new List<string>();
                List<string> value1 = new List<string>();

                bool clearitem = false;
                XmlTextReader XMlR = new XmlTextReader(Application.StartupPath + @"\Files\DataBase\borrowList.xml");
                while (XMlR.Read())
                {

                    if (XMlR.NodeType == XmlNodeType.Text)
                    {
                        if (!clearitem)
                            value1.Add(XMlR.Value);
                        clearitem = false;
                    }
                    if (XMlR.NodeType == XmlNodeType.Element)
                        if (XMlR.Name == "ReturnDate")
                            clearitem = true;
                }
                for (int i = 0; i < value1.Count; i += 7)
                {
                    CalculatSubsequence CS = new CalculatSubsequence(int.Parse(value1[i + 2]), int.Parse(value1[i + 3]), int.Parse(value1[i + 4]));
                    CS.calculatTime();
                    if (CS.IsTarydy)
                    {
                        CalculatFine CF = new CalculatFine(CS.calculatTime());
                        value.Add(value1[i + 5]); value.Add(value1[i + 6]); value.Add(value1[i + 0]);
                        value.Add(value1[i + 1]); value.Add(value1[i + 2] + " / " + value1[i + 3] + " / " + value1[i + 4]);
                        value.Add(CS.calculatTime().ToString()); value.Add(CF.WhatFine.ToString());
                    }

                }
                if (value.Count == 0)
                {
                    value.Add("No Tarydy Person !!!"); value.Add("------------"); value.Add("---------"); value.Add("---------"); value.Add("------------"); value.Add("-----------"); value.Add("-----------");
                }
                XMlR.Close();
            }
            catch
            { }
            finally {  }
        }
       
    }
}

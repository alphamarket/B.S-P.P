﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DayNews
{
   internal class CalculatSubsequence
    {
         private int d, m, y;
         public CalculatSubsequence(int Year, int Month, int Day)
        {
            d = Day;
            m = Month;
            y = Year;
        }
        public int calculatTime()
        {
            if (y == 0 || d == 0 || m == 0)
            {
                throw new Exception("Please Enter valid value");
            }
            else
            {
                try
                {
                    int keep1 = 0;
                    int count = 0;
                    int count1 = 0;
                    int keep4 = 0;
                    int keep5 = 0;
                    int keep3 = 0;

                    if (DateTime.Now.Year - y == 0)
                    {
                        keep4 = DateTime.Now.Month;
                    }
                    else
                    { keep4 = 12; }
                    for (int i = 0; i <= DateTime.Now.Year - y; i++)
                    {
                        int count3 = 0;
                        for (int j = (i == 0 ? m : 0); j <= keep4; j++)
                        {
                            count3++;
                            if (count == DateTime.Now.Year - y)
                                if (count3 == DateTime.Now.Month)
                                {
                                    keep5 = count1;
                                    break;
                                }

                            count1++;
                        }
                        count++;
                    }
                    count = 0;
                    count1 = 0;
                    //?:
                    if (keep5 == 0)
                    {
                        keep3 = DateTime.Now.Day;
                    }
                    else
                    {
                        keep3 = 30;
                    }
                    if (DateTime.Now.Year - y <= 0)
                    {
                        if (DateTime.Now.Month - m < 0)
                        { keep5 = -1; }
                    }

                    for (int i = 0; i <= keep5; i++)
                    {
                        int count3 = 0;
                        for (int j = (i == 0 ? d : 0); j <= keep3; j++)
                        {
                            count3++;
                            if (count == keep5)
                                if (count3 == DateTime.Now.Day)
                                {
                                    keep1 += count1 - count + 1;
                                    if (keep1 > 15)
                                    { stateTarydy = true; }
                                    else { stateTarydy = false; }
                                    return keep1;
                                }

                            count1++;
                        }
                        count++;
                    }
                    if (DateTime.Now.Year - y <= 0)
                    {
                        if (DateTime.Now.Month - m < 0)
                        { keep1 = 0; }
                    }
                    if (keep1 > 15)
                    { stateTarydy = true; }
                    else { stateTarydy = false; }
                    return keep1;
                }
                catch { throw new Exception(); }
            }
        }
        private bool stateTarydy;
        public bool IsTarydy { get { return stateTarydy; } }
    }
}

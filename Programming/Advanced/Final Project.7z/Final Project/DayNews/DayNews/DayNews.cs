﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DayNews
{
    internal class CalculatFine
    {
        private int BalanceFine;
        public CalculatFine(int DaySub)
        {
            BalanceFine = DaySub * 1000;
        }
        public int WhatFine { get { return BalanceFine;} }
    }
}

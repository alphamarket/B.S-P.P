﻿using System;
using System.Xml;
using System.IO;
using System.Windows.Forms;

namespace StartUpProject
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        enum _Application { Server, Client, Local, Startup }
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                _Application var = _Application.Startup;
                if (File.Exists(@"Application.xml"))
                {
                    using (XmlTextReader read = new XmlTextReader(@"Application.xml"))
                    {
                        while (read.Read())
                        {
                            switch (read.NodeType)
                            {
                                case XmlNodeType.Text:
                                    switch (read.Value)
                                    {
                                        case "Launch Local Application":
                                            var=_Application.Local;
                                            break;
                                        case "Launch Server":
                                            var = _Application.Server;
                                            break;
                                        case "Launch Client":
                                            var = _Application.Client;
                                            break;
                                    }
                                    break;
                            }
                        }
                    }
                    switch (var)
                    {
                        case _Application.Client:
                            Client.Program.Main();
                            break;
                        case _Application.Server:
                            Server.Program.Main();
                            break;
                        case _Application.Local:
                            LocalLibrary.Program.Main();
                            break;
                        case _Application.Startup:
                            Application.Run(new Startup());
                            break;
                    }
                }
                else
                    Application.Run(new Startup());
            }
            catch { }
        }
    }
}
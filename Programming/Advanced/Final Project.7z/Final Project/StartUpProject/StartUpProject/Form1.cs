﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Xml;
using System.Windows.Forms;

namespace StartUpProject
{
    public partial class Startup : Form
    {
        public Startup()
        {
            InitializeComponent();
        }

        private void okBtn_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                System.Windows.Forms.DialogResult res = MessageBox.Show("Are you sure?\nThere is no going back!", "Choose Carefully ...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == System.Windows.Forms.DialogResult.Yes)
                {
                    try
                    {
                        using (XmlTextWriter wr = new XmlTextWriter(@"Application.xml", null))
                        {
                            wr.WriteStartDocument();
                            wr.WriteStartElement("Configuration");
                            wr.WriteStartElement("Launch_Application");
                            wr.WriteString(comboBox1.SelectedItem.ToString());
                            wr.WriteEndElement();
                            wr.WriteEndElement();
                            wr.WriteEndDocument();
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Something goes bad while trying to save your selected option!!\nPlease try again ...", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            Application.Restart();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
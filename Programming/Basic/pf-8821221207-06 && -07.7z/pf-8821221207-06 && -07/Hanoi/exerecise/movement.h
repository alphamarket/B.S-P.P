#pragma once

class movement
{
	int movementCounter;
public:
	movement(void);
	~movement(void);
	void POSITIONS(char,char);
	int destiny(char);
	void rules();
	void setMovementCounter();
	int getMovementCounter();
	void movement::resetCounter();
};

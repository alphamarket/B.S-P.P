#include "StdAfx.h"
#include "HanoiSolver.h"

HanoiSolver::HanoiSolver(void)
{
}

HanoiSolver::~HanoiSolver(void)
{
}
void HanoiSolver::Solver(int nDisk, char source='A' , char dest='C', char help='B'){
	extern disks myDisks;
	extern display myDisplay;
	if(nDisk==1){
		Sleep((clock_t)1.5*CLOCKS_PER_SEC);
		extern movement myMovement;
		COORD coordiante;
		HANDLE hndl;
		myMovement.POSITIONS(source,dest);
		myDisplay.frontYardDisplay();
		coordiante.X=15;
		coordiante.Y=20;
		hndl=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hndl,coordiante);
		cout<<"A DISK HAS BEEN MOVED FROM BEG \" "<<source<<" \" TO PEG \" "<<dest<<" \" ."<<endl;
		Sleep((clock_t)1.5*CLOCKS_PER_SEC);
	}else{
		Solver(nDisk-1,source,help,dest);
		Solver(1,source,dest,help);
		Solver(nDisk-1,help,dest,source);
	}
}


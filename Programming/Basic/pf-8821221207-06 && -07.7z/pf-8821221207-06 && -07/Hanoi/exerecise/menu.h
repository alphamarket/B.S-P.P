#pragma once

class menu
{
public:
	menu(void);
	~menu(void);
	void mainMenu(void);//which shown as startup menu
	void manualP(void);//if player want to play by own himself this menu will show difficulty menu
	void help(void);//a text for give more info about tower of hanoi to user
	void disks(void);//quality of disk's display and called with class Disks
	void bars(void);//quality of bar's display and will called with this->menu
	void winMenu();//indicate to the user that you won the game
	void loseMenu();//indicate to the user that you lost the game
	void emptyMenu();
};

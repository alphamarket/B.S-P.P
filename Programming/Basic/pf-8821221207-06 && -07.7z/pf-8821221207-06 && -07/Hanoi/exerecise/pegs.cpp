#include "StdAfx.h"
#include "pegs.h"


pegs::pegs(void)
{
}

pegs::~pegs(void)
{
}
void pegs::matterOfPegA(int Tdestiny){
	extern movement myMovement;
	extern disks myDisks;
	if(myDisks.isThereADisk(0,0)){//it look for if there is any disk on the pegA
		int j=0;
		for(;j<=9;j++){//look for first empty place on peg
			if(!myDisks.isThereADisk(0,j))
				break;
		}
		myDisks.setTempDiskValue(myDisks.getDiskAmount(0,j-1));//get disk amount in place before first empty place
		if(myMovement.destiny(Tdestiny)!=-1){//it set destiny info which will need on next step
			if(myDisks.getDiskAmount(getPegNumber(),0)==0 || 
				myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)>
				myDisks.getTempDiskValue()){//it looking after the rules may not bigger disk put on the smaller one
				myDisks.deleteDisk(0,j-1);//delete disk on the NOW peg 
				myDisks.createDisk( getPegNumber(),myDisks.getRowNumber(),myDisks.getTempDiskValue());//create a disk on the target peg
				myDisks.setTempDiskValue(0);//reset tempDiskValue to zero
				myMovement.setMovementCounter();
			}else if(myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)==myDisks.getTempDiskValue()){}
			else
				myMovement.rules();//if the user move bigger disk on to the smaller one the program will remind him/her the game rules
		}
	}
}
void pegs::matterOfPegB(int Tdestiny){
	extern movement myMovement;
	extern disks myDisks;
	if(myDisks.isThereADisk(1,0)){//it look for if there is any disk on the pegB
		int j=0;
		for(;j<=9;j++){//look for first empty place on peg
			if(!myDisks.isThereADisk(1,j))
				break;
		}
		myDisks.setTempDiskValue(myDisks.getDiskAmount(1,j-1));//get disk amount in place before first empty place
		if(myMovement.destiny(Tdestiny)!=-1){//it set destiny info which will need on next step
			if(myDisks.getDiskAmount(getPegNumber(),0)==0 || 
				myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)>
				myDisks.getTempDiskValue()){//it looking after the rules may not bigger disk put on the smaller one
				myDisks.deleteDisk(1,j-1);//delete disk on the NOW peg 
				myDisks.createDisk( getPegNumber(),myDisks.getRowNumber(),myDisks.getTempDiskValue());//create a disk on the target peg
				myDisks.setTempDiskValue(0);
				myMovement.setMovementCounter();
			}else if(myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)==myDisks.getTempDiskValue()){}
			else
				myMovement.rules();//if the user move bigger disk on to the smaller one the program will remind him/her the game rules
		}
	}
}
void pegs::matterOfPegC(int Tdestiny){
	extern movement myMovement;
	extern disks myDisks;
	if(myDisks.isThereADisk(2,0)){//it look for if there is any disk on the pegC
		int j=0;
		for(;j<=9;j++){//look for first empty place on peg
			if(!myDisks.isThereADisk(2,j))
				break;
		}
		myDisks.setTempDiskValue(myDisks.getDiskAmount(2,j-1));//get disk amount in place before first empty place
		if(myMovement.destiny(Tdestiny)!=-1){//it set destiny info which will need on next step
		if(myDisks.getDiskAmount( getPegNumber(),0)==0 || 
			myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)>
			myDisks.getTempDiskValue()){//it looking after the rules may not bigger disk put on the smaller one
			myDisks.deleteDisk(2,j-1);//delete disk on the NOW peg 
			myDisks.createDisk( getPegNumber(),myDisks.getRowNumber(),myDisks.getTempDiskValue());//create a disk on the target peg
			myDisks.setTempDiskValue(0);//reset tempDiskValue to zero
			myMovement.setMovementCounter();
		}else if(myDisks.getDiskAmount( getPegNumber(),myDisks.getRowNumber()-1)==myDisks.getTempDiskValue()){}
		else
			myMovement.rules();//if the user move bigger disk on to the smaller one the program will remind him/her the game rules
		}
	}
}
void pegs::setPegNumber(int peg){//set number of peg which the user want a disk move from it
	pegNumber=peg;
}
int pegs::getPegNumber(){//get number of peg which the user want a disk move from it
	return pegNumber;
}

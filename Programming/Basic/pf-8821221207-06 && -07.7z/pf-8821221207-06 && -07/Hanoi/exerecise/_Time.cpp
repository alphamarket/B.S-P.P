#include "StdAfx.h"
#include "_Time.h"

_Time::_Time(void){
	_HOUR=0;
	_MINUTE=0;
	_SECOND=0;
	F_T=0;
	S_T=0;
	_ELA_T=0;
}

_Time::~_Time(void)
{
}
void _Time::display_time(){
	calculate_E_TS();
	_ELA_T=int(S_T-F_T);
	cal_hour();
	cal_minute();
	cal_second();
	cout/*<<setfill('0')*/<<setw(2)<<_HOUR<<" : "<<setw(2)<<_MINUTE<<" : "<<setw(2)<<_SECOND<<endl;
}
	

#include "StdAfx.h"
#include "movement.h"



movement::movement(void)
{
	movementCounter=0;
}

movement::~movement(void)
{
}
int movement::destiny(char destiny){//get the status of destiny peg row which disk will be put on this position
	extern disks myDisks;
	extern pegs myPegs;
	switch(destiny){
		case 'a':
		case 'A':
			if(myDisks.getTempDiskValue()){
				int j=0;
				for(;j<=9;j++){
					if(!myDisks.isThereADisk(0,j))
						break;
				}
				myPegs.setPegNumber(0);//set peg number for further stuation
				myDisks.setRowNumber(j);//set row of destiny further stuation
			}
			break;
		case 'b':
		case 'B':
			if(myDisks.getTempDiskValue()){
				int j=0;
				for(;j<=9;j++){
					if(!myDisks.isThereADisk(1,j))
						break;
				}
				myPegs.setPegNumber(1);//set peg number for further stuation
				myDisks.setRowNumber(j);//set row of destiny further stuation
			}
			break;
		case 'c':
		case 'C':
			if(myDisks.getTempDiskValue()){
				int j=0;
				for(;j<=9;j++){
					if(!myDisks.isThereADisk(2,j))
						break;
				}
				myPegs.setPegNumber(2);//set peg number for further stuation
				myDisks.setRowNumber(j);//set row of destiny further stuation
			}
			break;
		default:
			cout<<"Not in valid entered peg symbol!"<<endl;
			_getch();
			return -1;
	}
	return 0;
}
void movement::POSITIONS(char now,char Tdestiny){//calculate peg's disks status
	extern pegs myPegs;
	switch(now){
		case 'a':
		case 'A':
			myPegs.matterOfPegA(Tdestiny);
			break;
		case 'b':
		case 'B':
			myPegs.matterOfPegB(Tdestiny);
			break;
		case 'c':
		case 'C':
			myPegs.matterOfPegC(Tdestiny);
			break;
		default:
			cout<<"Not in valid entered peg symbol!"<<endl;
			_getch();
	}
}

void movement::rules(){//game rules will be shown
	system("cls");
	extern menu myMenu;
	myMenu.emptyMenu();
	COORD coordinate;
	HANDLE hndl;
	
	coordinate.X=0;
	coordinate.Y=8;
	hndl=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hndl,coordinate);
	cout<<"In this game there is only two rules:\n1)You can't move biger disk on to the smaller one."<<endl
		<<"2)You can only move ONE disk every time.\n"<<endl;
	_getch();
	system("cls");
}
void movement::setMovementCounter(){
	movementCounter++;
}
int movement::getMovementCounter(){
	return movementCounter;
}
void movement::resetCounter(){
	movementCounter=0;
}


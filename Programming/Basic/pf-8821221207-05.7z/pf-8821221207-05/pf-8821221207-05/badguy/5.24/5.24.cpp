#include "stdafx.h"
#include <iostream>
#include <string>
#include <conio.h>
using namespace std;
int main()
{
	string ans;
	do{
	cout<<"Enter lines number:\t"<<endl<<system("color f");
	int line;
	cin>>line;
	cin.ignore();
	system("cls");
	while(line%2==0){
		cout<<"Enter odd number."<<endl;
		cin>>line;
		system("cls");
	}
	//while(!(line<20&&line>0)){
	//	cout<<"The entered number should be in range of 1-19."<<endl;
	//	cin>>line;
	//	system("cls");
	//}
	int n=1,b=1;
	for(int l=(line-1)/2;l>=0;l--,n++){
		int i;
		i=1+(n-1)*2;
		for(int y=0;y<l;y++)
			cout<<" ";
		for(int m=0;m<i;m++)
			cout<<"*";
		cout<<endl;
	}
	for(int k=0;k<(line-1)/2;k++,b++){
		int d;
		d=(line-2)-(b-1)*2;
		for(int s=0;s<=k;s++)
			cout<<" ";
		for(int v=0;v<d;v++)
			cout<<"*";
		cout<<endl;
	}
	cout<<"\n\n\n\Press any key to continue..."<<endl;
	getch();
	system("cls");
	cout<<"Do you want to continue?\t"<<endl;
	getline(cin,ans);
	system("cls");
	while(!(ans=="yes"||ans=="no"||ans=="NO"||ans=="YES"||ans=="No"||ans=="Yes")){
		cout<<"Do you want to continue?\t"<<endl;
		getline(cin,ans);
		system("cls");
	}
	}while(!(ans=="no"||ans=="NO"||ans=="No"));

	return 0;
}

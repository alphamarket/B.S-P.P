// 5.29.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iomanip>
#include<string>
#include <math.h>
#include <iostream>
#include <conio.h>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	int year=1626;
	cout<<setprecision(4)<<setw(4)<<"year"<<setw(12)<<"%5"<<setw(12)<<"%6"<<setw(12)<<"%7"
		<<setw(12)<<"%8"<<setw(12)<<"%9"<<setw(12)<<"%10"<<system("color 0f")<<endl;
	cout<<"________________________________________________________________________________"<<endl;
	for(int n=0;n<=380;n++,year++){
		cout<<setw(4)<<year;
		long double seed=24;
		for(float i=0.05;i<=0.10;i+=0.01){
			seed*=pow((1+i),n);
			cout<<setw(12)<<seed;
		}
		cout<<endl;
			if(n>=94 && n%94==0){
				cout<<"\n\nPress any key to see rest of years."<<endl;
				getche();
				system("cls");
			}
			cout<<"________________________________________________________________________________"<<endl;
	}
	return 0;
}


#include "stdafx.h"
#include <iomanip>
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	//cout<<"Enter your investment amount:"<<endl;
	//float seed;
	//cin>>seed;
	//cout<<"How many year do want to invest:"<<endl;
	//int year;
	//cin>>year;
	//for(float percent=0.05;percent<=0.1;percent=percent+0.01){
	//	cout<<setprecision(2)<<fixed<<"for ( "<<percent*100<<" ) percent"
	//		<<" Your invested money will be : $ "<<seed*=pow((1+percent),year)<<endl;
	//}
	long double seed5=24/*,seed6=24,seed7=24,seed8=24,seed9=24,seed9=24,seed10=24*/;
	//float persent5=0.5/*,persent6=0.6,persent7=0.7,persent8=0.8,persent9=0.9,persent10=0.1*/;
	int year=1626;
	cout<<setw(4)<<"year"<<setw(10)<<"persent %5"<<setw(10)<<"persent %6"
		<<setw(10)<<"persent %7"<<setw(10)<<"persent %8"<<setw(10)<"persent %9"<<setw(10)<<"persent %10"<<endl;
	for(int n=1;year<=2006;year++,n++){
		cout<<setw(4)<<year;
		for(float per/*sent5*/=0.5;per/*sent5*/<=0.1;per/*sent5*/+=0.1){
			/*setw(4)<<year<<*/cout<<setprecision(2)<<setw(10)<<seed5=seed5*pow((1+per/*s*//*ent5*/),n);
		}
		cout<<endl;
	}
	return 0;

}
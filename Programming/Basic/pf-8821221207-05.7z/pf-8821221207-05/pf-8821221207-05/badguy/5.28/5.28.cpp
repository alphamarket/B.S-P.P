// 5.28.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <conio.h>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	string ans;
	while(true){
		
		cout<<"\n\nWhich day do you want to print out?\t"<<endl;
		int s;
		cin>>s;
		cin.ignore();
		while(!(s>0&&s<13)){
			cout<<"\n\nEnter Paragraph number in range of 1-12."<<endl;
			cin>>s;
			cin.ignore();
		}
		system("cls");
		switch(s){
			case 1:
				cout<<"\n\nOn the first day of Christmas"<<endl;

				break;
			case 2:
				cout<<"\n\nOn the second day of Christmas"<<endl;

				break;
			case 3:
				cout<<"\n\nOn the third day of Christmas"<<endl;

				break;
			case 4:
				cout<<"\n\nOn the fourth day of Christmas"<<endl;
	
				break;
			case 5:
				cout<<"\n\nOn the fifth day of Christmas"<<endl;
	
				break;
			case 6:
				cout<<"\nOn the sixth day of Christmas"<<endl;

				break;
			case 7:
				cout<<"\n\nOn the seventh day of Christmas"<<endl;

				break;
			case 8:
				cout<<"\n\nOn the eighth day of Christmas"<<endl;

				break;
			case 9:
				cout<<"\n\nOn the ninth day of Christmas"<<endl;

				break;
			case 10:
				cout<<"\n\nOn the tenth day of Christmas"<<endl;

				break;
			case 11:
				cout<<"\n\nOn the eleventh day of Christmas"<<endl;

				break;
			case 12:
				cout<<"\n\nOn the twelfth day of Christmas"<<endl;

				}
				cout<<"\nmy true love sent to me:"<<endl;
				switch(s){
					case 1:
						cout<<"\nA Partridge in a Pear Tree"<<endl;	
						break;
					case 2:
						cout<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
							break;
					case 3:
						cout<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
							break;
					case 4:
						cout<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
							break;
					case 5:
						cout<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
							break;
					case 6:
						cout<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
						break;
					case 7:
						cout<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
					case 8:
						cout<<"\nmy true love sent to me:"<<endl
							<<"\nEight Maids a Milking"<<endl
							<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
					case 9:
						cout<<"\nNine Ladies Dancing"<<endl
							<<"\nEight Maids a Milking"<<endl
							<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
					case 10:
						cout<<"\nTen Lords a Leaping"<<endl
							<<"\nNine Ladies Dancing"<<endl
							<<"\nEight Maids a Milking"<<endl
							<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
						break;
					case 11:
						cout<<"\nEleven Pipers Piping"<<endl
							<<"\nTen Lords a Leaping"<<endl
							<<"\nNine Ladies Dancing"<<endl
							<<"\nEight Maids a Milking"<<endl
							<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
							break;
					case 12:
						cout<<"\n12 Drummers Drumming"<<endl
							<<"\nEleven Pipers Piping"<<endl
							<<"\nTen Lords a Leaping"<<endl
							<<"\nNine Ladies Dancing"<<endl
							<<"\nEight Maids a Milking"<<endl
							<<"\nSeven Swans a Swimming"<<endl
							<<"\nSix Geese a Laying"<<endl
							<<"\nFive Golden Rings"<<endl
							<<"\nFour Calling Birds"<<endl
							<<"\nThree French Hens"<<endl
							<<"\nTwo Turtle Doves"<<endl
							<<"\nand a Partridge in a Pear Tree"<<endl;
						}
					cout<<"\n\nPress any key to continue...\n"<<endl;
					getch();
					system("clS");
					do{
						cout<<"\n\nDo you want to continue (print out music compose)?\n"<<endl;
						getline(cin,ans);
					}while(!(ans=="yes" || ans=="no"||ans=="NO"||ans=="YES"||ans=="Yes"||ans=="No"));
					system("cls");
					if(ans=="no"||ans=="NO"||ans=="No")
						break;
					}
					return 0;
					}
						

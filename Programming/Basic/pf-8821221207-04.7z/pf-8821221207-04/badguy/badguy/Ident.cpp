#include "StdAfx.h"
#include "Ident.h"

Ident::Ident(void)
{
	setfName("no name");
	setlName("no name");
	setGender("unknown");
	setAge(0);
}
Ident::Ident(string tempfname,string templname,string tempgender, int tempage)
{
	setfName(tempfname);
	setlName(templname);
	setGender(tempgender);
	setAge(tempage);
}
void Ident::setfName(string tempfname)
{
	while(tempfname.length()<=3)
	{
		cout<<"\n\nEnter a name !?"<<endl;
		getline(cin,tempfname);
	}
	if (tempfname.length()>20)
	{
		cout<<"\n\nYour entered name has MORE THAN 20 character(!),"
			<<"\nWe limit it to FIRST 20 character , sorry."<<endl<<endl;
		fname=tempfname.substr(0,20);
	}
	else
		fname=tempfname;
}
void Ident::setlName(string templname)
{
	while(templname.length()<=3)
	{
		cout<<"\n\nEnter a name !?"<<endl;
		getline(cin,templname);
	}
	if (templname.length()>30)
	{
		cout<<"\n\nYour entered name has MORE THAN 30 character(!),"
			<<"\nWe limit it to FIRST 30 character , sorry."<<endl<<endl;
		lname=templname.substr(0,20);
	}
	else
		lname=templname;
}
void Ident::setGender(string tempgender)
{
	while (!(tempgender=="male" || tempgender=="female" || tempgender=="unknown" || tempgender=="MALE" || tempgender=="FEMALE"))
	{
		cout<<"\n\nEnter gender:(male or female)\a"<<endl;
		getline(cin,tempgender);
	}
	gender=tempgender;
}
void Ident::setAge(int tempage)
{
	while (!(tempage>=0 && tempage<150))
	{
		cout<<"\n\nEnter valid age:"<<endl;
		cin>>tempage;
	}
	age=tempage;
}
string Ident::getfName()
{
	return fname;
}
string Ident::getlName()
{
	return lname;
}
string Ident::getGender()
{
	return gender;
}
int Ident::getAge()
{
	return age;
}
void Ident::displayBA()
{
	cout<<setw(20)<<getfName()<<setw(30)<<getlName()<<setw(15)<<getGender()<<setw(10)<<getAge()<<endl;
}
void Ident::displayBG()
{
	cout<<setw(20)<<getfName()<<setw(30)<<getlName()/*<<setw(15)<<getGender()*/<<setw(10)<<getAge()<<endl;
}
void Ident::clear()
{
	clear_1();
}
void Ident::clear_1()
{
	setfName("no name");
	setlName("no name");
	setGender("unknown");
	setAge(0);
}


Ident::~Ident(void)
{
}

#pragma once
#include <string>
using namespace std;
class Ident
{
	string fname,lname,gender;
	int age;
public:
	Ident(string,string,string,int);
	void setfName(string);
	void setlName(string);
	void setGender(string);
	void setAge(int);
	string getfName();
	string getlName();
	string getGender();
	int getAge();
	void displayBA();
	void displayBG();
	void clear();
	void clear_1();
	Ident(void);
	~Ident(void);
};

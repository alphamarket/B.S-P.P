#pragma once
class Menu
{

public:
	void menu();
	void enter();
	void reset();
	void print();
	void e_ch(int);
	int menuDisplay();
};

#include "stdafx.h"

static Ident p1,p2;
void Menu::menu()
{
	static int sel=menuDisplay();
	static string ans;
	do
	{
		switch (sel){
			case 1:
				enter();
				break;
			case 2:
				reset();
				break;
			case 3:
				print();
				break;
		}
		if(sel==4){
			do{
				cout<<"\n\nAre you sure ?"<<endl<<endl;
				getline(cin,ans);
			}while(!(ans=="yes"||ans=="YES"||ans=="NO"||ans=="no"));
		}
		system("cls");
	}while(!(sel==4 && (ans=="yes" || ans=="YES")));
}
int Menu::menuDisplay()
{
	int num;
	cout<<"\n\n1) Enter personal information\a"<<endl
		<<"\n2) Reset personal information"<<endl
		<<"\n3) Print personal information"<<endl
		<<"\n4) Quit"<<endl<<endl;
	cin>>num;
	cin.ignore();
	system("cls") ;
	return num;
}
void Menu::enter()
{
	string tempfname,templname,tempgender;
	int tempage,num;
	do{
	cout<<"\n\nTo reset first person information press 1:\a"<<endl<<endl
		<<"To reset second person information press 2:"<<endl<<endl
		<<"Or press zero to back to main menu:"<<endl<<endl;
	int num;
	cin>>num;
	cin.ignore();
	switch(num){
		case 1:
			cout<<"\n\nEnter first name:\a\n"<<endl;
			getline(cin,tempfname);
			p1.setfName(tempfname);
			cout<<"\nEnter last name:\n"<<endl;
			getline(cin,templname);
			p1.setlName(templname);
			cout<<"\nDeclear gender(male or female):\n"<<endl;
			getline(cin,tempgender);
			p1.setGender(tempgender);
			cout<<"\nEnter age:\n"<<endl;
			cin>>tempage;
			cin.ignore();
			p1.setAge(tempage);
			break;
		case 2:
			cout<<"\n\nEnter first name:\a\n"<<endl;
			getline(cin,tempfname);
			p2.setfName(tempfname);
			cout<<"\nEnter last name:\n"<<endl;
			getline(cin,templname);
			p2.setlName(templname);
			cout<<"\nDeclear gender(male or female):\n"<<endl;
			getline(cin,tempgender);
			p2.setGender(tempgender);
			cout<<"\nEnter age:\n"<<endl;
			cin>>tempage;
			cin.ignore();
			p2.setAge(tempage);
			break;
	}
	 system( "cls" ) ;
	}while (num!=0);
}
void Menu::reset()
{
	int num1;
	do{
	cout<<"\n\nTo enter first person identity press 1:\a"<<endl<<endl
		<<"To enter second person identity press 2:"<<endl<<endl
		<<"Or press zero to back to main menu:"<<endl<<endl;
	cin>>num1;
	cin.ignore();
	system("clS");
	switch(num1)
	{
	case 1:
		p1.clear();
		break;
	case 2:
		p2.clear();
		break;
	}
	system( "cls" ) ;
	}while(num1!=0);
}
void Menu::print()
{
	int num3;
	
	do{
	cout<<"\n\nTo print out personal information in order of age press 1:\a"<<endl<<endl
		<<"To print out older person information press 2:"<<endl<<endl
		<<"Just print out male(s) information press 3:"<<endl<<endl
		<<"Or press zero to back to main menu:"<<endl<<endl;
	cin>>num3;
	cin.ignore();
	system( "cls" ) ;
	 switch(num3){
		 case 1:
			cout<<"\n\n"<<setw(20)<<"First Name"<<setw(30)<<"Last Name"<<setw(15)<<"Gender"<<setw(10)<<"Age"<<endl;
			cout<<"***************************************************************************"<<endl;

				if(p2.getAge()<=p1.getAge())
				{

					p1.displayBA();
					cout<<"***************************************************************************"<<endl;
					p2.displayBA();

				}
				else
				{
					p2.displayBA();
					cout<<"***************************************************************************"<<endl;

					p1.displayBA();

				}
				cout<<"***************************************************************************"<<endl;
				cout<<"Press any key to continue ....."<<endl<<endl;
				getch();
				system("cls");
				break;
		 case 2:
				cout<<"\n\n"<<setw(20)<<"First Name"<<setw(30)<<"Last Name"<<setw(15)<<"Gender"<<setw(10)<<"Age"<<endl;
				cout<<"***************************************************************************"<<endl;
				if(p1.getAge() < p2.getAge())
				{
					p2.displayBA();
				}
				else if(p2.getAge() < p1.getAge())
				{
					p1.displayBA();
				}
				else if(p1.getAge()==p2.getAge())
				{
					p1.displayBA();
					cout<<"***************************************************************************"<<endl;
					p2.displayBA();
				}
				cout<<"***************************************************************************"<<endl;
				cout<<"Press any key to continue ....."<<endl<<endl;
				getch();
				system("cls");
				break;
		 case 3:
				if(!(p1.getGender()=="male" || p2.getGender()=="male"))
				{
					cout<<"\n\nNO ENTERED MALE INFORMATION!"<<endl<<endl;
					cout<<"Press any key to continue ....."<<endl<<endl;
					getch();
					system("cls");
					continue;
				}
				cout<<"\n\n"<<setw(20)<<"First Name"<<setw(30)<<"Last Name"/*<<setw(15)<<"Gender"*/<<setw(10)<<"Age"<<endl;
				cout<<"***************************************************************************"<<endl;

				if(p1.getGender()=="male")
				{
					
					p1.displayBG();
					cout<<"***************************************************************************"<<endl;

				}
				if(p2.getGender()=="male")
				{
					p2.displayBG();

					cout<<"***************************************************************************"<<endl;
				}
				cout<<"Press any key to continue ....."<<endl<<endl;
				getch();
				system("cls");
	 }while(num3!=0);
	 system("cls");
}
#include "StdAfx.h"
Person::Person(string a,string b,int c)
	{
		setAge(c);
		setFName(a);
		setLName(b);
	}
void Person::setFName(string a)
	{
		fname=a;

	}
string Person::getFName()
	{
		return fname;
	}
void Person::setLName(string b)
	{
		lname=b;
		
	}
string Person::getLName()
	{
		return lname;
	}
void Person::setAge(int c)
	{
		while (c<1 || c>200)
		{
			cout<<"enter valid age number:\a"<<endl;
			cin>>c;
		}
		age=c;
	}
int Person::getAge()
	{
		return age;
	}
void Person::displayMessage()
	{
		cout<<setw(10)<<getFName()<<setw(25)<<getLName()<<setw(25)<<getAge()<<endl;
	}

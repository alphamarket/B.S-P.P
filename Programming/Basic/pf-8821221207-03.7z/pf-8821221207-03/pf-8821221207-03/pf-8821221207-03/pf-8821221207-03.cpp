#include "stdafx.h"					/*ALL OF THE ESSENTIAL INCLUDES HAVE BEEN DEFINED IN stdafx.h HEADER*/
#include "conio.h"
int _tmain(int argc, _TCHAR* argv[])
{
	int g/*,h*/;
	string i,j/*,k,l*/;
	cout<<"enter first name:\a\n"<<endl;
	getline(cin,i);
	cout<<endl;
	cout<<"enter last name:\a\n"<<endl;
	getline(cin,j);
	cout<<endl;
	cout<<"enter age:\a\n"<<endl;
	cin>>g;
	cout<<endl;
	/*cout<<"enter your second first Person name:\a\n"<<endl;
	getline(cin,k);
	getline(cin,k);
	cout<<endl;
	cout<<"enter your second Person last name:\a\n"<<endl;
	getline(cin,l);
	cout<<endl;
	cout<<"enter your second Person age:\a\n"<<endl;
	cin>>h;
	cout<<endl;*/
	Person x(i,j,g);
	cout<<"enter first name:\a\n"<<endl;
	getline(cin,i);
	getline(cin,i);
	cout<<endl;
	cout<<"enter last name:\a\n"<<endl;
	getline(cin,j);
	cout<<endl;
	cout<<"enter age:\a\n"<<endl;
	cin>>g;
	cout<<endl;
	Person y(i,j,g);
	cout<<"first name\a"<<setw(25)<<"second name"<<setw(25)<<"age"<<endl;
	cout<<"***********************************************************************"<<endl;
	if(x.getAge() >= y.getAge())
	{
		x.displayMessage();
		y.displayMessage();
	}
	else
	{
		y.displayMessage();
		x.displayMessage();
	}
	_getch();
	return 0;
}


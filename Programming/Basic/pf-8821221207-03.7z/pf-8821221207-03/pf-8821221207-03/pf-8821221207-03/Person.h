#pragma once
#include <string>
using namespace std;
class Person
{
	string fname,lname;
	int age;
public:
	Person(string,string,int);
	void setFName(string);
	string getFName();
	void setLName(string);
	string getLName();
	void setAge(int);
	int getAge();
	void displayMessage();
};

#pragma once
#include "hexa.h"

namespace Calculator {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	protected:
	private: System::Windows::Forms::HelpProvider^  helpProvider1;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  basicToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  programmerToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
	private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  editToolStripMenuItem;

	private: System::Windows::Forms::Panel^  panel2;
	private: System::Windows::Forms::Button^  btn00;
	private: System::Windows::Forms::Button^  btnA;
	private: System::Windows::Forms::Button^  btnB;
	private: System::Windows::Forms::Button^  btnC;
	private: System::Windows::Forms::Button^  btnD;
	private: System::Windows::Forms::Button^  btnE;
	private: System::Windows::Forms::Button^  btnF;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  btn0;
	private: System::Windows::Forms::Button^  btnEq;
	private: System::Windows::Forms::Button^  btnce;
	private: System::Windows::Forms::Button^  btnPlus;
	private: System::Windows::Forms::Button^  btn1;
	private: System::Windows::Forms::Button^  btn6;
	private: System::Windows::Forms::Button^  btn3;
	private: System::Windows::Forms::Button^  btn8;
	private: System::Windows::Forms::Button^  btn2;
	private: System::Windows::Forms::Button^  btn5;
	private: System::Windows::Forms::Button^  btn7;
	private: System::Windows::Forms::Button^  btn4;
	private: System::Windows::Forms::Button^  btn9;

private: System::Windows::Forms::ToolStripMenuItem^  copyToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  pasteToolStripMenuItem;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->helpProvider1 = (gcnew System::Windows::Forms::HelpProvider());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->basicToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->programmerToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->editToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->copyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pasteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->btn00 = (gcnew System::Windows::Forms::Button());
			this->btnA = (gcnew System::Windows::Forms::Button());
			this->btnB = (gcnew System::Windows::Forms::Button());
			this->btnC = (gcnew System::Windows::Forms::Button());
			this->btnD = (gcnew System::Windows::Forms::Button());
			this->btnE = (gcnew System::Windows::Forms::Button());
			this->btnF = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->btn0 = (gcnew System::Windows::Forms::Button());
			this->btnEq = (gcnew System::Windows::Forms::Button());
			this->btnce = (gcnew System::Windows::Forms::Button());
			this->btnPlus = (gcnew System::Windows::Forms::Button());
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->menuStrip1->Dock = System::Windows::Forms::DockStyle::None;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->viewToolStripMenuItem, 
				this->editToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(91, 24);
			this->menuStrip1->TabIndex = 1;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// viewToolStripMenuItem
			// 
			this->viewToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->basicToolStripMenuItem, 
				this->programmerToolStripMenuItem, this->toolStripSeparator1, this->exitToolStripMenuItem});
			this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
			this->viewToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::D1));
			this->viewToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->viewToolStripMenuItem->Text = L"&View";
			// 
			// basicToolStripMenuItem
			// 
			this->basicToolStripMenuItem->Enabled = false;
			this->basicToolStripMenuItem->Name = L"basicToolStripMenuItem";
			this->basicToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::D1));
			this->basicToolStripMenuItem->Size = System::Drawing::Size(177, 22);
			this->basicToolStripMenuItem->Text = L"&Basic";
			this->basicToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::basicToolStripMenuItem_Click_1);
			// 
			// programmerToolStripMenuItem
			// 
			this->programmerToolStripMenuItem->Checked = true;
			this->programmerToolStripMenuItem->CheckOnClick = true;
			this->programmerToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
			this->programmerToolStripMenuItem->Name = L"programmerToolStripMenuItem";
			this->programmerToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::D2));
			this->programmerToolStripMenuItem->Size = System::Drawing::Size(177, 22);
			this->programmerToolStripMenuItem->Text = L"&Programmer";
			this->programmerToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::programmerToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(174, 6);
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::F4));
			this->exitToolStripMenuItem->Size = System::Drawing::Size(177, 22);
			this->exitToolStripMenuItem->Text = L"&Exit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
			// 
			// editToolStripMenuItem
			// 
			this->editToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->copyToolStripMenuItem, 
				this->pasteToolStripMenuItem});
			this->editToolStripMenuItem->Name = L"editToolStripMenuItem";
			this->editToolStripMenuItem->Size = System::Drawing::Size(39, 20);
			this->editToolStripMenuItem->Text = L"&Edit";
			// 
			// copyToolStripMenuItem
			// 
			this->copyToolStripMenuItem->Name = L"copyToolStripMenuItem";
			this->copyToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::C));
			this->copyToolStripMenuItem->Size = System::Drawing::Size(144, 22);
			this->copyToolStripMenuItem->Text = L"&Copy";
			this->copyToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::copyToolStripMenuItem_Click);
			// 
			// pasteToolStripMenuItem
			// 
			this->pasteToolStripMenuItem->Enabled = false;
			this->pasteToolStripMenuItem->Name = L"pasteToolStripMenuItem";
			this->pasteToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::V));
			this->pasteToolStripMenuItem->Size = System::Drawing::Size(144, 22);
			this->pasteToolStripMenuItem->Text = L"&Paste";
			this->pasteToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::pasteToolStripMenuItem_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::SystemColors::GradientInactiveCaption;
			this->panel2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"panel2.BackgroundImage")));
			this->panel2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->panel2->Controls->Add(this->btn00);
			this->panel2->Controls->Add(this->btnA);
			this->panel2->Controls->Add(this->btnB);
			this->panel2->Controls->Add(this->btnC);
			this->panel2->Controls->Add(this->btnD);
			this->panel2->Controls->Add(this->btnE);
			this->panel2->Controls->Add(this->btnF);
			this->panel2->Controls->Add(this->textBox1);
			this->panel2->Controls->Add(this->btn0);
			this->panel2->Controls->Add(this->btnEq);
			this->panel2->Controls->Add(this->btnce);
			this->panel2->Controls->Add(this->btnPlus);
			this->panel2->Controls->Add(this->btn1);
			this->panel2->Controls->Add(this->btn6);
			this->panel2->Controls->Add(this->btn3);
			this->panel2->Controls->Add(this->btn8);
			this->panel2->Controls->Add(this->btn2);
			this->panel2->Controls->Add(this->btn5);
			this->panel2->Controls->Add(this->btn7);
			this->panel2->Controls->Add(this->btn4);
			this->panel2->Controls->Add(this->btn9);
			this->panel2->Location = System::Drawing::Point(0, 27);
			this->panel2->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(196, 213);
			this->panel2->TabIndex = 1;
			// 
			// btn00
			// 
			this->btn00->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn00->Location = System::Drawing::Point(49, 178);
			this->btn00->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn00->Name = L"btn00";
			this->btn00->Size = System::Drawing::Size(64, 25);
			this->btn00->TabIndex = 1;
			this->btn00->Text = L"00";
			this->btn00->UseVisualStyleBackColor = true;
			this->btn00->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btnA
			// 
			this->btnA->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnA->Location = System::Drawing::Point(49, 61);
			this->btnA->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnA->Name = L"btnA";
			this->btnA->Size = System::Drawing::Size(29, 24);
			this->btnA->TabIndex = 2;
			this->btnA->Text = L"A";
			this->btnA->UseVisualStyleBackColor = true;
			this->btnA->Click += gcnew System::EventHandler(this, &Form1::btnA_Click);
			// 
			// btnB
			// 
			this->btnB->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnB->Location = System::Drawing::Point(17, 61);
			this->btnB->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnB->Name = L"btnB";
			this->btnB->Size = System::Drawing::Size(29, 24);
			this->btnB->TabIndex = 3;
			this->btnB->Text = L"B";
			this->btnB->UseVisualStyleBackColor = true;
			this->btnB->Click += gcnew System::EventHandler(this, &Form1::btnB_Click);
			// 
			// btnC
			// 
			this->btnC->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnC->Location = System::Drawing::Point(17, 90);
			this->btnC->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnC->Name = L"btnC";
			this->btnC->Size = System::Drawing::Size(29, 24);
			this->btnC->TabIndex = 4;
			this->btnC->Text = L"C";
			this->btnC->UseVisualStyleBackColor = true;
			this->btnC->Click += gcnew System::EventHandler(this, &Form1::btnC_Click);
			// 
			// btnD
			// 
			this->btnD->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnD->Location = System::Drawing::Point(17, 120);
			this->btnD->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnD->Name = L"btnD";
			this->btnD->Size = System::Drawing::Size(29, 24);
			this->btnD->TabIndex = 5;
			this->btnD->Text = L"D";
			this->btnD->UseVisualStyleBackColor = true;
			this->btnD->Click += gcnew System::EventHandler(this, &Form1::btnD_Click);
			// 
			// btnE
			// 
			this->btnE->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnE->Location = System::Drawing::Point(17, 149);
			this->btnE->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnE->Name = L"btnE";
			this->btnE->Size = System::Drawing::Size(29, 24);
			this->btnE->TabIndex = 6;
			this->btnE->Text = L"E";
			this->btnE->UseVisualStyleBackColor = true;
			this->btnE->Click += gcnew System::EventHandler(this, &Form1::btnE_Click);
			// 
			// btnF
			// 
			this->btnF->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnF->Location = System::Drawing::Point(18, 179);
			this->btnF->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnF->Name = L"btnF";
			this->btnF->Size = System::Drawing::Size(29, 24);
			this->btnF->TabIndex = 7;
			this->btnF->Text = L"F";
			this->btnF->UseVisualStyleBackColor = true;
			this->btnF->Click += gcnew System::EventHandler(this, &Form1::btnF_Click);
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox1->ImeMode = System::Windows::Forms::ImeMode::Off;
			this->textBox1->Location = System::Drawing::Point(17, 11);
			this->textBox1->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->textBox1->MaxLength = 19;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(166, 31);
			this->textBox1->TabIndex = 0;
			this->textBox1->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// btn0
			// 
			this->btn0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn0->Location = System::Drawing::Point(119, 178);
			this->btn0->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn0->Name = L"btn0";
			this->btn0->Size = System::Drawing::Size(29, 27);
			this->btn0->TabIndex = 9;
			this->btn0->Text = L"0";
			this->btn0->UseVisualStyleBackColor = true;
			this->btn0->Click += gcnew System::EventHandler(this, &Form1::btn0_Click);
			// 
			// btnEq
			// 
			this->btnEq->Font = (gcnew System::Drawing::Font(L"Mistral", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnEq->Location = System::Drawing::Point(154, 129);
			this->btnEq->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnEq->Name = L"btnEq";
			this->btnEq->Size = System::Drawing::Size(29, 74);
			this->btnEq->TabIndex = 10;
			this->btnEq->Text = L"=";
			this->btnEq->UseVisualStyleBackColor = true;
			this->btnEq->Click += gcnew System::EventHandler(this, &Form1::btnEq_Click);
			// 
			// btnce
			// 
			this->btnce->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btnce->Location = System::Drawing::Point(84, 60);
			this->btnce->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnce->Name = L"btnce";
			this->btnce->Size = System::Drawing::Size(64, 24);
			this->btnce->TabIndex = 11;
			this->btnce->Text = L"CE";
			this->btnce->UseVisualStyleBackColor = true;
			this->btnce->Click += gcnew System::EventHandler(this, &Form1::btnce_Click);
			// 
			// btnPlus
			// 
			this->btnPlus->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btnPlus->Location = System::Drawing::Point(154, 61);
			this->btnPlus->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btnPlus->Name = L"btnPlus";
			this->btnPlus->Size = System::Drawing::Size(29, 66);
			this->btnPlus->TabIndex = 12;
			this->btnPlus->Text = L"+";
			this->btnPlus->UseVisualStyleBackColor = true;
			this->btnPlus->Click += gcnew System::EventHandler(this, &Form1::btnPlus_Click);
			// 
			// btn1
			// 
			this->btn1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn1->Location = System::Drawing::Point(49, 150);
			this->btn1->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(29, 24);
			this->btn1->TabIndex = 13;
			this->btn1->Text = L"1";
			this->btn1->UseVisualStyleBackColor = true;
			this->btn1->Click += gcnew System::EventHandler(this, &Form1::btn1_Click);
			// 
			// btn6
			// 
			this->btn6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn6->Location = System::Drawing::Point(119, 120);
			this->btn6->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(29, 24);
			this->btn6->TabIndex = 14;
			this->btn6->Text = L"6";
			this->btn6->UseVisualStyleBackColor = true;
			this->btn6->Click += gcnew System::EventHandler(this, &Form1::btn6_Click);
			// 
			// btn3
			// 
			this->btn3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn3->Location = System::Drawing::Point(119, 150);
			this->btn3->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(29, 24);
			this->btn3->TabIndex = 15;
			this->btn3->Text = L"3";
			this->btn3->UseVisualStyleBackColor = true;
			this->btn3->Click += gcnew System::EventHandler(this, &Form1::btn3_Click);
			// 
			// btn8
			// 
			this->btn8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn8->Location = System::Drawing::Point(84, 90);
			this->btn8->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(29, 24);
			this->btn8->TabIndex = 16;
			this->btn8->Text = L"8";
			this->btn8->UseVisualStyleBackColor = true;
			this->btn8->Click += gcnew System::EventHandler(this, &Form1::btn8_Click);
			// 
			// btn2
			// 
			this->btn2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn2->Location = System::Drawing::Point(84, 150);
			this->btn2->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(29, 24);
			this->btn2->TabIndex = 17;
			this->btn2->Text = L"2";
			this->btn2->UseVisualStyleBackColor = true;
			this->btn2->Click += gcnew System::EventHandler(this, &Form1::btn2_Click);
			// 
			// btn5
			// 
			this->btn5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn5->Location = System::Drawing::Point(84, 120);
			this->btn5->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(29, 24);
			this->btn5->TabIndex = 18;
			this->btn5->Text = L"5";
			this->btn5->UseVisualStyleBackColor = true;
			this->btn5->Click += gcnew System::EventHandler(this, &Form1::btn5_Click);
			// 
			// btn7
			// 
			this->btn7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn7->Location = System::Drawing::Point(49, 90);
			this->btn7->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(29, 24);
			this->btn7->TabIndex = 19;
			this->btn7->Text = L"7";
			this->btn7->UseVisualStyleBackColor = true;
			this->btn7->Click += gcnew System::EventHandler(this, &Form1::btn7_Click);
			// 
			// btn4
			// 
			this->btn4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn4->Location = System::Drawing::Point(49, 120);
			this->btn4->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(29, 24);
			this->btn4->TabIndex = 20;
			this->btn4->Text = L"4";
			this->btn4->UseVisualStyleBackColor = true;
			this->btn4->Click += gcnew System::EventHandler(this, &Form1::btn4_Click);
			// 
			// btn9
			// 
			this->btn9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(178)));
			this->btn9->Location = System::Drawing::Point(119, 90);
			this->btn9->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(29, 24);
			this->btn9->TabIndex = 21;
			this->btn9->Text = L"9";
			this->btn9->UseVisualStyleBackColor = true;
			this->btn9->Click += gcnew System::EventHandler(this, &Form1::btn9_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->BackColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->ClientSize = System::Drawing::Size(194, 238);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->menuStrip1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->HelpButton = true;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(2, 3, 2, 3);
			this->MaximizeBox = false;
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		hexa^Objhex1,^Objhex2;
	private: System::Void btn1_Click(System::Object^  sender, System::EventArgs^  e) {
				 textBox1->Text+="1";
			 }
private: System::Void btn2_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="2";
		 }
private: System::Void btn3_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="3";
		 }
private: System::Void btn4_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="4";
		 }
private: System::Void btn5_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="5";
		 }
private: System::Void btn6_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="6";
		 }
private: System::Void btn7_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="7";
		 }
private: System::Void btn8_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="8";
		 }
private: System::Void btn9_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="9";
		 }
private: System::Void btn0_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="0";
		 }
private: System::Void btnce_Click(System::Object^  sender, System::EventArgs^  e) {
			 delete Objhex1,Objhex2;
			 textBox1->Clear();
		 }
private: System::Void btnC_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="C";
		 }
private: System::Void btnB_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="B";
		 }
private: System::Void btnA_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="A";
		 }
private: System::Void btnF_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="F";
		 }
private: System::Void btnE_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="E";
		 }
private: System::Void btnD_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="D";
		 }
private: System::Void btnPlus_Click(System::Object^  sender, System::EventArgs^  e) {
			Objhex1=gcnew hexa();
			while(textBox1->Text->Length::get()<19){
				textBox1->Text="0"+textBox1->Text;
			}
			if(!(Objhex1->setValue(textBox1->Text))){
				MessageBox::Show("The entered hexa number is not valid"
					+" the context must have only these charartors:"
				+" 'A' , 'B' , 'C' , 'D' , 'E' , 'F' and 0-9 numbers","An unexpected entered context (Error)");
			}
			textBox1->Clear();
		 }
private: System::Void btnEq_Click(System::Object^  sender, System::EventArgs^  e) {
			 Objhex2=gcnew hexa();
			 if(textBox1->Text->IsNullOrEmpty(textBox1->Text)){
				 Objhex2->indiv_setValue(Objhex1->getValue());
				 hexa^Objhex3=gcnew hexa();
				 Objhex3=Objhex1->sum(Objhex2);
				 String^a=Objhex3->getValue();
				 textBox1->Clear();
				 for(int i=0,j=0;i<19;i++){
				 if(a[i]=='0'&& j==0){}
				 else {textBox1->Text+=a[i];j++;}}
			 }else{
				 while(this->textBox1->Text->Length::get()<19){
					 textBox1->Text="0"+textBox1->Text;
				 }
				 if(!(Objhex2->setValue(textBox1->Text))){
					 MessageBox::Show("The Entered hexa number is not valid"
						 +" The context must have only these charartors:"
					 +" 'A' , 'B' , 'C' , 'D' , 'E' , 'F' and 0-9 numbers","An unexpected entered context (Error)");
					}
				 hexa^Objhex3=gcnew hexa();
				 Objhex3=Objhex1->sum(Objhex2);
				 String^a=Objhex3->getValue();
				 textBox1->Clear();
				 int j=0;
				 for(int i=0;i<19;i++){
					 if(a[i]=='0'&& j==0){}
					 else {textBox1->Text+=a[i];j=1;}
				 }
				delete Objhex1,Objhex2,Objhex3;
			 }			 
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text+="00";
		 }

private: System::Void basicToolStripMenuItem_Click_1(System::Object^  sender, System::EventArgs^  e) {
			// panel3->Visible::set(true);
			 panel2->Visible::set(false);
			 basicToolStripMenuItem->Checked::set(true);
			 programmerToolStripMenuItem->Checked::set(false);
		 }
private: System::Void programmerToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 panel2->Visible::set(true);
			// panel3->Visible::set(false);
			 basicToolStripMenuItem->Checked::set(false);
			 programmerToolStripMenuItem->Checked::set(true);
		 }
private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close();
		 }
		// TextBox^b=(TextBox^)this->ActiveControl;
		 String^b1;
private: System::Void copyToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 b1=textBox1->Text;
			 pasteToolStripMenuItem->Enabled::set(true);
		 }
private: System::Void pasteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 textBox1->Text=b1;
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			// panel3->Visible::set(true);
			 panel2->Visible::set(true);
			 textBox1->MaxLength::set(19);
		 }
		 };
		 }
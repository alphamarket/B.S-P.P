#include "StdAfx.h"
#include "hexa.h"
using namespace System;
hexa::hexa(){}
bool hexa::setValue(String^tmpStr){
	if(isValid(tmpStr)){
		value=tmpStr;
		return true;
	}return false;
}
void hexa::indiv_setValue(String^ tmp){
	value=tmp;
}
String^ hexa::getValue(){
	return value;
}
int hexa::cal_num(wchar_t _Str){
	int _Int;
	switch(_Str){
			case '1':_Int=1;break;
			case '2':_Int=2;break;
			case '3':_Int=3;break;
			case '4':_Int=4;break;
			case '5':_Int=5;break;
			case '6':_Int=6;break;
			case '7':_Int=7;break;
			case '8':_Int=8;break;
			case '9':_Int=9;break;
			case 'A':_Int=10;break;
			case 'B':_Int=11;break;
			case 'C':_Int=12;break;
			case 'D':_Int=13;break;
			case 'E':_Int=14;break;
			case 'F':_Int=15;break;
	}
	return _Int;
}
String^hexa::cal_hex(int _Int){
	String^str;
	switch(_Int){
			case 1:str="1";break;
			case 2:str="2";break;
			case 3:str="3";break;
			case 4:str="4";break;
			case 5:str="5";break;
			case 6:str="6";break;
			case 7:str="7";break;
			case 8:str="8";break;
			case 9:str="9";break;
			case 0:str="0";break;
			case 10:str="A";break;
			case 11:str="B";break;
			case 12:str="C";break;
			case 13:str="D";break;
			case 14:str="E";break;
			case 15:str="F";break;
		}
	return str;
}
hexa^hexa::sum(hexa^hex){
	hexa^Objhex3=gcnew hexa();
	String^TmpStr=hex->getValue();
	String^Finalization="";
	int x[19];
	for(int i=18;i>=0;i--){
		x[i]=0;
	}
	for(int i=18;i>=0;i--){
		x[i]+=cal_num(value[i])+cal_num(TmpStr[i]);
		if(x[i]>15){
			x[i]%=16;
			x[i-1]++;
		}
	}
	for(int i=0;i<19;i++){
		Finalization+=cal_hex(x[i]);
	}
	Objhex3->setValue(Finalization);
	return Objhex3;		
}
	

bool hexa::isValid(String^ _Str){
	bool validate=true;
	for(int i=0;i<19;i++){
		switch(_Str[i]){
			case'1':break;
			case'2':break;
			case'3':break;
			case'4':break;
			case'5':break;
			case'6':break;
			case'7':break;
			case'8':break;
			case'9':break;
			case'0':break;
			case'A':break;
			case'B':break;
			case'C':break;
			case'D':break;
			case'E':break;
			case'F':break;
			default:validate=false;
		}
		if(!validate)break;
	}
	return validate;
}



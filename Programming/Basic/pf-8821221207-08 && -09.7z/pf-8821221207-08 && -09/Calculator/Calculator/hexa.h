#pragma once
using namespace System;
ref class hexa
{
	String^value;
	bool isValid(String^);
public:
	hexa(void);
	bool setValue(String^);
	void indiv_setValue(String^);
	String^getValue();
	hexa^sum(hexa^);
	int cal_num(wchar_t);
	String^cal_hex(int);
};

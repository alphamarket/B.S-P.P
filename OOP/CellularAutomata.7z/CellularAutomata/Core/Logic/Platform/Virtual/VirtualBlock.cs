﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Logic;
using System.Drawing;
namespace Core.Logic.Platform.Virtual
{
    /// <summary>
    /// This is a base controller which all Chess controllers in Core.UI.Controls.Button should inherit from
    /// </summary>
    public class VirtualBlock<T>
    {
        #region EVENTS


        #endregion

        #region PROPERTIES

        #region PUBLIC

        public T Tag { get; set; }
        /// <summary>
        /// Get the parent board's size
        /// </summary>
        public Size ParentBoardSize { get; protected set; }

        /// <summary>
        /// Get or Set the location of current man on board
        /// </summary>
        public Point Location_On_Board
        {
            get;
            set;
        }

        #endregion

        #endregion

        #region CTOR

        public VirtualBlock(VirtualBlock<T> lblock)
            : this(lblock.ParentBoardSize, lblock.Location_On_Board, lblock.Tag)
        {
        }

        public VirtualBlock(Size parentBoardSize, Point location_on_board, T tag)
        {
            this.ParentBoardSize = parentBoardSize;
            this.Location_On_Board = location_on_board;
            this.Tag = tag;
        }
        #endregion

        #region METHODES

        #region NON-ABSTRACT

        #region PUBLIC

        /// <summary>
        /// Get the proper string of current man
        /// </summary>
        public override string ToString()
        {
            return String.Format("{0} : {1}", this.Location_On_Board, this.Tag.ToString());
        }

        /// <summary>
        /// Get name according to current instance's Man_Type Value
        /// </summary>
        public string Name { get { return this.Tag.ToString(); } } 
        
        /// <summary>
        /// Get string info about current instance
        /// </summary>
        public string GetInfoString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.Name);
            sb.AppendLine("ID : " + this.ToString());
            sb.AppendLine("Tagged with : " + this.Tag.ToString());
            return sb.ToString();
        }

        public List<Point> GetNeighborPoints(bool crossPointsOnly = false)
        {
            List<Point> p = new List<Point>();
            for (int x = this.Location_On_Board.X - 1; x <= this.Location_On_Board.X + 1; x++)
            {
                for (int y = this.Location_On_Board.Y - 1; y <= this.Location_On_Board.Y + 1; y++)
                {
                    if (new Point(x, y) == this.Location_On_Board) continue;
                    if (x == this.Location_On_Board.X || y == this.Location_On_Board.Y)
                    {
                        // A non-cross point
                        if (!crossPointsOnly)
                            p.Add(new Point(x, y));
                    }
                    else
                        p.Add(new Point(x, y));
                }
            }
            return p;
        }
        #endregion

        #endregion

        #endregion
    }
}
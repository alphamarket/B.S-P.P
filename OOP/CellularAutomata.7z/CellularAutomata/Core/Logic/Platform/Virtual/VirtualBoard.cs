﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Logic;
using Core.Logic.Platform.Visual;
using System.Drawing;

namespace Core.Logic.Platform.Virtual
{
    public class VirtualBoard : ICloneable 
    {

        /// <summary>
        /// Get or Set mans' flag on board
        /// </summary>
        public int[][] OnBoard { get; set; }
        /// <summary>
        /// Get or Set realated man's instance on the board
        /// </summary>
        public VirtualBlock<int>[][] MenOnBoard { get; set; }
        /// <summary>
        /// Get size of the board
        /// </summary>
        public Size Size { get; protected set; }
        /// <summary>
        /// Get object counts that the board is holding
        /// </summary>
        public uint ObjectCounts { get; protected set; }
        /// <summary>
        /// Get active blocks
        /// </summary>
        public List<VirtualBlock<int>> ActiveBlocks { get; set; }

        protected VirtualBoard() { }

        public VirtualBoard(uint objectCounts, Size size)
        {
            this.Size = size;
            this.ObjectCounts = objectCounts;
            this.Init();
            this.Int_InitBoard();
            this.Man_InitBoard();
        }

        private void Init()
        {
            var w = this.Size.Width;
            var h = this.Size.Height;
            // define a 8*8 matrix
            this.MenOnBoard = new VirtualBlock<int>[h][];
            for (int i = 0; i < h; i++)
            {
                this.MenOnBoard[i] = new VirtualBlock<int>[w];
                this.MenOnBoard[i].Initialize();
            }
            //define a 8*8 matrix
            this.OnBoard = new int[h][];
            for (int i = 0; i < h; i++)
            {
                this.OnBoard[i] = new int[w];
                this.OnBoard[i].Initialize();
            }
            this.ActiveBlocks = new List<VirtualBlock<int>>();
        }
        /// <summary>
        /// Inits the Man[][] array of board
        /// </summary>
        private void Man_InitBoard()
        {
            for (int i = 0; i < this.Size.Height; i++)
            {
                for (int j = 0; j < this.Size.Width; j++)
                {
                    this.MenOnBoard[i][j] = new VirtualBlock<int>(this.Size, new Point(j, i), this.OnBoard[i][j]);
                    if (this.OnBoard[i][j] != 0)
                        this.ActiveBlocks.Add(this.MenOnBoard[i][j]);
                }
            }
        }
        /// <summary>
        /// Inits the int[][] arrays of board
        /// </summary>
        private void Int_InitBoard()
        {
            Random r = new Random(Environment.TickCount - this.GetHashCode());
            for (int i = 0; i < this.ObjectCounts; i++)
            {
                var x = r.Next(0, this.Size.Width);
                var y = r.Next(0, this.Size.Height);
                if (this.OnBoard[y][x] == 1)
                {
                    i--;
                    continue;
                }
                this.OnBoard[y][x] = 1;
            }
        }
        public KeyValuePair<int, VirtualBlock<int>> this[Point block]
        {
            get
            {
                return this[block.Y, block.X];
            }
            set
            {
                this[block.Y, block.X] = value;
            }
        }

        public KeyValuePair<int, VirtualBlock<int>> this[int y, int x]
        {
            get
            {
                return new KeyValuePair<int, VirtualBlock<int>>(this.OnBoard[y][x], this.MenOnBoard[y][x]);
            }
            set
            {
                this.OnBoard[y][x] = value.Key;
                this.MenOnBoard[y][x] = value.Value;
                this.MenOnBoard[y][x].Location_On_Board = new Point(x, y);
                this.MenOnBoard[y][x].Tag = this.OnBoard[y][x];
            }
        }
        /// <summary>
        /// Get a cloned board array from current status
        /// </summary>
        public int[][] StateClone()
        {
            int[][] b = new int[8][];
            for (int i = 0; i < 8; i++)
            {
                b[i] = new int[8];
                for (int j = 0; j < 8; j++)
                {
                    b[i][j] = this.OnBoard[i][j];
                }
            }
            return b;
        }

        public object Clone()
        {
            var vb = new VirtualBoard();
            vb.Size = new Size(this.Size.Width, this.Size.Height);
            vb.ObjectCounts = this.ObjectCounts;
            vb.Init(); 
            vb.OnBoard = this.StateClone();
            vb.Man_InitBoard();
            return vb;
        }

        internal bool IsValidPoint(Point point)
        {
            try
            {
                if (point.X < 0 || point.Y < 0)
                    return false;
                if (point.X >= this.Size.Width || point.Y >= this.Size.Height)
                    return false;
                if (this[point].Value != null) { }
                return true;
            }
            catch (IndexOutOfRangeException)
            {
                return false;
            }
        }
        public List<VirtualBlock<int>> GetNeighborBlock(Point point, bool crossPointsOnly = false)
        {
            var points = this[point].Value.GetNeighborPoints(crossPointsOnly);
            var blocks = new List<VirtualBlock<int>>();
            foreach (var p in points)
            {
                if (this.IsValidPoint(p))
                {
                    blocks.Add(this[p].Value);
                }
            }
            return blocks;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Core.Logic.Platform.Virtual;

namespace Core.Logic.Platform.Visual
{
    /// <summary>
    /// Represents the chess board
    /// </summary>
    /// <remarks>
    /// In this board the BLACK controller's positions are presented as POSITIVE values
    /// and the WHITE controller's positions are presented as NEGATIVE value
    /// and the blank spaces are presented as 0;
    /// </remarks>
    public class VisualBoard : ICloneable
    {
        public Virtual.VirtualBoard VirtualBoard { get; protected set; }
        public int[][] OnBoard
        {
            get { return this.VirtualBoard.OnBoard; }
            set { this.VirtualBoard.OnBoard = value; }
        }
        /// <summary>
        /// Get or Set realated man's instance on the board
        /// </summary>
        public VisualBlock<int>[][] MenOnBoard { get; set; }
        /// <summary>
        /// Get or Set ActiveBlocks on the board
        /// </summary>
        public List<VisualBlock<int>> ActiveBlocks { get; set; }
        
        public VisualBoard(Virtual.VirtualBoard vboard)
        {
            this.VirtualBoard = vboard;
            this.Init();
            this.Man_InitBoard();
        }

        protected VisualBoard()
        {
            // TODO: Complete member initialization
        }

        private void Init()
        {
            // define a 8*8 matrix
            this.MenOnBoard = new VisualBlock<int>[this.VirtualBoard.Size.Height][];
            for (int i = 0; i < this.VirtualBoard.Size.Height; i++)
            {
                this.MenOnBoard[i] = new VisualBlock<int>[this.VirtualBoard.Size.Width];
                this.MenOnBoard[i].Initialize();
            }
            this.ActiveBlocks = new List<VisualBlock<int>>();
        }
        /// <summary>
        /// Inits the Man[][] array of board
        /// </summary>
        private void Man_InitBoard()
        {
            for (int i = 0; i < this.VirtualBoard.Size.Height; i++)
            {
                for (int j = 0; j < this.VirtualBoard.Size.Width; j++)
                {
                    this.MenOnBoard[i][j] = new VisualBlock<int>(this.VirtualBoard[new Point(j, i)].Value);
                    if (this[i, j].Value.LBlock.Tag == 1)
                        this.ActiveBlocks.Add(this.MenOnBoard[i][j]);
                }
            }
        }
        public KeyValuePair<int, VisualBlock<int>> this[Point block]
        {
            get
            {
                return this[block.Y, block.X];
            }
            set
            {
                this[block.Y, block.X] = value;
            }
        }

        public KeyValuePair<int, VisualBlock<int>> this[int y, int x]
        {
            get
            {
                return new KeyValuePair<int, VisualBlock<int>>(this.VirtualBoard.OnBoard[y][x], this.MenOnBoard[y][x]);
            }
            set
            {
                this.VirtualBoard[y, x] = new KeyValuePair<int, VirtualBlock<int>>(value.Key, value.Value.LBlock);
                this.MenOnBoard[y][x] = value.Value;
            }
        }
        /// <summary>
        /// Get a cloned board array from current status
        /// </summary>
        public int[][] StateClone()
        {
            return this.VirtualBoard.StateClone();
        }

        public object Clone()
        {
            var b = new VisualBoard();
            b.VirtualBoard = this.VirtualBoard.Clone() as Virtual.VirtualBoard;
            b.Init();
            b.Man_InitBoard();
            return b;
        }

        internal bool IsValidPoint(Point point)
        {
            return this.VirtualBoard.IsValidPoint(point);
        }

        public Size Size { get { return this.VirtualBoard.Size; } }

        public List<VisualBlock<int>> GetNeighborBlock(Point point, bool crossPointsOnly=false)
        {
            var points = this[point].Value.GetNeighborPoints(crossPointsOnly);
            var blocks = new List<VisualBlock<int>>();
            foreach (var p in points)
            {
                if (this.IsValidPoint(p))
                {
                    blocks.Add(this[p].Value);
                }
            }
            return blocks;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Logic;
using System.Drawing;
using Core.Logic.Platform.Visual;
using Core.Logic.Platform.Virtual;

namespace Core.Logic.Platform.Visual
{
    /// <summary>
    /// This is a base controller which all Chess controllers in Core.UI.Controls.Button should inherit from
    /// </summary>
    /// <remarks>
    /// Do not forget to assign the LMan some object in your class' ctor 
    /// Otherwise the null referenced exception will be thrown
    /// </remarks>
    public class VisualBlock<T> : System.Windows.Forms.Button
    {
        #region PROPERTIES

        #region PUBLIC

        public VirtualBlock<T> LBlock { get; set; }

        /// <summary>
        /// Get or Set the location of current man on board
        /// </summary>
        public Point Location_On_Board
        {
            get { return LBlock.Location_On_Board; }
            set { LBlock.Location_On_Board = value; }
        }

        #endregion

        #endregion

        #region CTOR

        public VisualBlock(VirtualBlock<T> lblock)
        {
            this.LBlock = new VirtualBlock<T>(lblock);
        }
        
        #endregion

        #region METHODES

        #region NON-ABSTRACT

        #region PUBLIC

        /// <summary>
        /// Get the proper string of current man
        /// </summary>
        public override string ToString()
        {
            return String.Format("{0}({1}) : {2}", this.LBlock.ToString());
        }

        /// <summary>
        /// Get name according to current instance's Man_Type Value
        /// </summary>
        public new string Name { get { return LBlock.Name; } }
        /// <summary>
        /// Get string info about current instance
        /// </summary>
        public string GetInfoString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.LBlock.GetInfoString());
            sb.AppendLine("Visual ForeColor : " + this.ForeColor.ToString());
            sb.AppendLine("Visual BackColor : " + this.BackColor.ToString());

            return sb.ToString();
        }

        public List<Point> GetNeighborPoints(bool crossPointsOnly = false)
        {
            return this.LBlock.GetNeighborPoints(crossPointsOnly);
        }

        public new T Tag
        {
            get { return this.LBlock.Tag; }
            set { this.LBlock.Tag = value; }
        }

        #endregion

        #endregion

        #endregion
    }
}
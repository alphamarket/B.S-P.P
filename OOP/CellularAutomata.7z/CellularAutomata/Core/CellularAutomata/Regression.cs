﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core.Logic.Platform.Visual;
using System.Drawing;
using System.Windows.Forms;

namespace Core.CellularAutomata
{
    public class Regression
    {
        public Regression(VisualBoard board)
        {
            this.Board = board;
        }

        public VisualBoard Board { get; set; }

        public void Run(Object callBackFunc)
        {
            if (!(callBackFunc is Action))
                throw new InvalidCastException("Unable to cast : { callBackFunc ~> Class::Action }");
            // define a bq<KeyValuePair<int, Block<int>>
            Strib.Sorting.Queue.BinaryQueue<KeyValuePair<int, VisualBlock<int>>> bq = new Strib.Sorting.Queue.BinaryQueue<KeyValuePair<int, VisualBlock<int>>>(new Comparison<KeyValuePair<int, VisualBlock<int>>>((A, B) =>
            {
                if (A.Key < B.Key)
                    return 1;
                if (A.Key == B.Key)
                    return 0;
                return -1;
            }));
            int swapCounter = -1;

            while (swapCounter == -1 || Math.Abs(swapCounter - this.Board.ActiveBlocks.Count / 100) > 3)
            {
                swapCounter = 0;
                Random rand = new Random(Environment.TickCount + new Random().Next());
                for (int m = 0; m < this.Board.ActiveBlocks.Count; m++)
                {
                    bq.Clear();
                    var i = this.Board.ActiveBlocks[m];
                    List<VisualBlock<int>> n = new List<VisualBlock<int>>();
                    int neigh = 0;
                    foreach (var j in this.Board.GetNeighborBlock(i.Location_On_Board))
                    {
                        if (j.Tag != 0)
                            neigh++;
                    }
                    bq.Enqueue(new KeyValuePair<int, VisualBlock<int>>(neigh, i));
                    foreach (var j in this.Board.GetNeighborBlock(i.Location_On_Board, true))
                    {
                        if (j.Tag == 0)
                            n.Add(j);
                    }
                    neigh = 0;
                    foreach (var j in n)
                    {
                        neigh = 0;
                        foreach (var k in this.Board.GetNeighborBlock(j.Location_On_Board))
                        {
                            if (k == i) continue;
                            if (k.Tag != 0)
                                neigh++;
                        }
                        bq.Enqueue(new KeyValuePair<int, VisualBlock<int>>(neigh, j));
                    }
                    if (bq.Count != 0 && (bq[0].Value != i || bq[0].Key == 0))
                    {
                        List<VisualBlock<int>> semiz = new List<VisualBlock<int>>();
                        for (int k = 0; k < bq.Count; k++)
                        {
                            if (bq[k].Key == bq[0].Key)
                                semiz.Add(bq[k].Value);
                        }
                        var selected_neighbor = semiz[rand.Next(0, semiz.Count)];
                        if (i != selected_neighbor)
                        {
                            lock (this)
                            {
                                i.Tag = 0; 
                                selected_neighbor.Tag = 1;
                                int index = this.Board.ActiveBlocks.IndexOf(i);
                                this.Board.ActiveBlocks.RemoveAt(index);
                                this.Board.ActiveBlocks.Add(selected_neighbor);
                                i.Invoke(new Action(() => { i.BackColor = SystemColors.Control; }));
                                selected_neighbor.Invoke(new Action(() => { selected_neighbor.BackColor = Color.LightBlue; Application.DoEvents(); }));
                                swapCounter++;
                            }
                        }
                    }
                }
            }
            (callBackFunc as Action)();
        }
    }
}
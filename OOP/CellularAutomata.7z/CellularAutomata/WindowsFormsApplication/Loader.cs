﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication
{
    public partial class Loader : Form
    {
        public Loader()
        {
            InitializeComponent();
            this.width.Value = Properties.Settings.Default.BoardSize.Width;
            this.height.Value = Properties.Settings.Default.BoardSize.Height;
            this.activeCounts.Value = Properties.Settings.Default.ActiveCounts;
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler((sender, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.Escape:
                        btn_Clicked(new object(), new EventArgs());
                        break;
                    case Keys.Enter:
                        btn_Clicked(okbtn, new EventArgs());
                        break;
                }
            });
        }

        protected void btn_Clicked(object sender, EventArgs e)
        {
            Properties.Settings.Default.BoardSize = new System.Drawing.Size((int)this.width.Value, (int)this.height.Value);
            Properties.Settings.Default.ActiveCounts = (uint)this.activeCounts.Value;
            Properties.Settings.Default.Save();
            this.Hide();
            if (sender == okbtn)
            {
                new Plat(Properties.Settings.Default.BoardSize, (uint)this.activeCounts.Value).ShowDialog();
            }
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
        private void numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            this.activeCounts.Maximum = this.width.Value * this.height.Value;
            this.activeCounts.Value = (this.width.Value * this.height.Value) / 3;
        }
    }
}

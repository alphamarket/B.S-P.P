﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Core.Logic.Platform.Visual;
using Core.Logic.Platform.Virtual;
using System.Windows.Shapes;
using System.IO;

namespace WindowsFormsApplication
{
    public partial class Plat : Form
    {
        protected VisualBoard Board { get; set; } 
        protected Panel BoardPanel { get; set; }
        protected System.Threading.Thread RegressionThread { get; set; }
        public Plat(System.Drawing.Size size, uint activeBlocks)
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.KeyDown += new KeyEventHandler((sende, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.Z:
                        try
                        {
                            this.RegressionThread.Abort();
                            MessageBox.Show("Regression Thread Aborted ...");
                        }
                        catch { }
                        break;
                    case Keys.R:
                        if (e.Control)
                        {
                            try
                            {
                                this.RegressionThread.Abort();
                            }
                            catch { }
                            this.Plat_Loader(new VirtualBoard(activeBlocks, size));
                            return;
                        }
                        this.RegressionThread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(new Core.CellularAutomata.Regression(this.Board).Run));
                        this.RegressionThread.Start(new Action(() =>
                        {
                            MessageBox.Show("Regression is done ...");
                        }));
                        break;
                    case Keys.Escape:
                        this.Hide();
                        if (e.Shift)
                        {
                            System.Diagnostics.Process.Start(System.Diagnostics.Process.GetCurrentProcess().ProcessName + ".exe");
                        }
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        break;
                }
            });
            this.Plat_Loader(new Core.Logic.Platform.Virtual.VirtualBoard(activeBlocks, size));
            this.Hide();
        }

        private void Plat_Loader(VirtualBoard vboard)
        {
            this.Hide();
            var tmp_file = System.IO.Path.GetTempFileName() + ".exe";
            File.Copy("Initializing.exe.dll", tmp_file);
            var initp = System.Diagnostics.Process.Start(tmp_file);
            try { this.RegressionThread.Abort(); }
            catch { }
            foreach (var i in this.Controls)
            {
                if (i is MenuStrip) continue;
                (i as Control).Dispose();
            }
            this.BoardPanel = new Panel();
            this.Board = new VisualBoard(vboard);
            this.BoardPanel.Top = menuStrip1.Bottom;
            var def_size = new Size(18, 18);
            Control lastc = null;
            for (int i = 0; i < this.Board.Size.Height; i++)
            {
                for (int j = 0; j < this.Board.Size.Width; j++)
                {
                    VisualBlock<int> c = this.Board[i, j].Value;
                    c.Size = def_size;

                    c.Text = "";// c.Location_On_Board.ToString();
                    if (c.Tag == 1)
                        c.BackColor = Color.LightBlue;
                    else
                        c.BackColor = SystemColors.Control;
                    if (this.BoardPanel.Controls.Count != 0)
                    {
                        if (lastc == null)
                            lastc = this.BoardPanel.Controls[this.BoardPanel.Controls.Count - 1];
                        c.Location = new Point(j * lastc.Width, i * lastc.Height);
                        lastc = c;
                    }
                    c.TabStop = false;
#if __DEBUG__
                    c.Click += new EventHandler((sender, e) =>
                    {
                        Stack<KeyValuePair<VisualBlock<int>, Color>> s = new Stack<KeyValuePair<VisualBlock<int>, Color>>();
                        foreach (var tmp in this.Board.GetNeighborBlock(c.Location_On_Board))
                        {
                            s.Push(new KeyValuePair<VisualBlock<int>, Color>(tmp, tmp.BackColor));
                            tmp.BackColor = Color.Black;
                        }
                        MessageBox.Show((sender as VisualBlock<int>).GetInfoString());
                        foreach (var color in s)
                        {
                            color.Key.BackColor = color.Value;
                        }
                    });
#endif
                    this.BoardPanel.Controls.Add(c);
                }
            }
            this.Controls.Add(this.BoardPanel);
            this.BoardPanel.Size = new Size(lastc.Right, lastc.Bottom);
            this.Size = new Size(this.BoardPanel.Right + 5, this.BoardPanel.Bottom + this.BoardPanel.Location.Y + 0);
            initp.Kill();
            this.Show();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Help().Show();
        }
    }
}

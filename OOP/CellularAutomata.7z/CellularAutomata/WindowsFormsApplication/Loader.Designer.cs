﻿namespace WindowsFormsApplication
{
    partial class Loader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.width = new System.Windows.Forms.NumericUpDown();
            this.height = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.activeCounts = new System.Windows.Forms.NumericUpDown();
            this.okbtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.activeCounts)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose the board\'s size";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose the active objects on the board";
            // 
            // width
            // 
            this.width.Location = new System.Drawing.Point(284, 11);
            this.width.Name = "width";
            this.width.Size = new System.Drawing.Size(70, 20);
            this.width.TabIndex = 2;
            this.width.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.width.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.width.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // height
            // 
            this.height.Location = new System.Drawing.Point(380, 11);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(70, 20);
            this.height.TabIndex = 3;
            this.height.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.height.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.height.ValueChanged += new System.EventHandler(this.numericUpDown_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(360, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "X";
            // 
            // activeCounts
            // 
            this.activeCounts.Location = new System.Drawing.Point(284, 44);
            this.activeCounts.Name = "activeCounts";
            this.activeCounts.Size = new System.Drawing.Size(166, 20);
            this.activeCounts.TabIndex = 5;
            this.activeCounts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.activeCounts.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // okbtn
            // 
            this.okbtn.Location = new System.Drawing.Point(363, 83);
            this.okbtn.Name = "okbtn";
            this.okbtn.Size = new System.Drawing.Size(87, 33);
            this.okbtn.TabIndex = 6;
            this.okbtn.Text = "&Ok";
            this.okbtn.UseVisualStyleBackColor = true;
            this.okbtn.Click += new System.EventHandler(this.btn_Clicked);
            // 
            // exitbtn
            // 
            this.exitbtn.Location = new System.Drawing.Point(12, 83);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(87, 33);
            this.exitbtn.TabIndex = 7;
            this.exitbtn.Text = "&Exit";
            this.exitbtn.UseVisualStyleBackColor = true;
            this.exitbtn.Click += new System.EventHandler(this.btn_Clicked);
            // 
            // Loader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 128);
            this.Controls.Add(this.exitbtn);
            this.Controls.Add(this.okbtn);
            this.Controls.Add(this.activeCounts);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.height);
            this.Controls.Add(this.width);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Loader";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loader";
            ((System.ComponentModel.ISupportInitialize)(this.width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.activeCounts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown width;
        private System.Windows.Forms.NumericUpDown height;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown activeCounts;
        private System.Windows.Forms.Button okbtn;
        private System.Windows.Forms.Button exitbtn;
    }
}